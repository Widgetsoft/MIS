#pragma once
namespace Database
{
	class AFX_EXT_CLASS CProductInfo : public CFlybyItem
	{
	public:
		CProductInfo();
		CProductInfo(const CProductInfo&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 26; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return ProdID; }

	public:
		BEGIN_COLUMN_MAP(CProductInfo)
			COLUMN_ENTRY(1, ProdID)
			COLUMN_ENTRY(2, ProdName)
			COLUMN_ENTRY(3, ProdCustomID)
			COLUMN_ENTRY(4, ProductType)
			COLUMN_ENTRY(5, ProductSpec)
			COLUMN_ENTRY(6, ProductUnit1)
			COLUMN_ENTRY(7, ProductUnit2)
			COLUMN_ENTRY(8, Prod1To2Rate)
			COLUMN_ENTRY(9, ProductLife)
			COLUMN_ENTRY(10, SafeStorage)
			COLUMN_ENTRY(11, ProdPurchasePrice)
			COLUMN_ENTRY(12, ProdSalesPrice)
			COLUMN_ENTRY(13, ProductFirm)
			COLUMN_ENTRY(14, ProdDescription)
			COLUMN_ENTRY(15, IsDiscount)
			COLUMN_ENTRY(16, IsIntegral)
			COLUMN_ENTRY(17, AsGift)

			COLUMN_ENTRY(18, JM)


			COLUMN_ENTRY(19, CreateDate)
			COLUMN_ENTRY(20, ModifyDate)
			COLUMN_ENTRY(21, CreatedUser)
			COLUMN_ENTRY(22, ModifierUser)

			COLUMN_ENTRY(23, TypeID)
			COLUMN_ENTRY(24, SpecID)
			COLUMN_ENTRY(25, UnitID1)
			COLUMN_ENTRY(26, UnitID2)
		END_COLUMN_MAP()

	private:
		GUID ProdID;
		OLECHAR ProdName[60];
		OLECHAR ProdCustomID[40];
		OLECHAR ProductType[40];
		OLECHAR ProductSpec[40];
		OLECHAR ProductUnit1[40];
		OLECHAR ProductUnit2[40];
		double Prod1To2Rate;
		unsigned int ProductLife;
		double SafeStorage;
		double ProdPurchasePrice;
		double ProdSalesPrice;
		OLECHAR ProductFirm[100];
		OLECHAR ProdDescription[120];
		BOOL IsDiscount;
		BOOL IsIntegral;
		BOOL AsGift;
		OLECHAR JM[60];

		CComVariant CreateDate;
		CComVariant ModifyDate;
		GUID CreatedUser;
		GUID ModifierUser;

		GUID TypeID;
		GUID SpecID;
		GUID UnitID1;
		GUID UnitID2;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CProductInfo& ProdInfo);
		friend STDInStream& operator >> (STDInStream& is, CProductInfo& ProdInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CProductInfo& ProdInfo);
	STDInStream& operator >> (STDInStream& is, CProductInfo& ProdInfo);

	class AFX_EXT_CLASS CProductInfoVector : public CFlybyData
	{
	public:
		CProductInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewProductInfo");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CProductInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CProductInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CProductInfo>(new CProductInfo()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA