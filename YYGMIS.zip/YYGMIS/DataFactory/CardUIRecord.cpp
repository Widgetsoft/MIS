#include "stdafx.h"
#include "FlybyData.h"
#include "CardUIRecord.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace Database;

CCardUIRecord::CCardUIRecord(void)
{
	CoCreateGuid(&CUIRID);
	ocscpy_s(CardNumber, _countof(CardNumber), OLESTR(""));
	ocscpy_s(CustName, _countof(CustName), OLESTR(""));
	ocscpy_s(Summary, _countof(CustName), OLESTR(""));


	Debit = { 0 };
	Credit = { 0 };
	RealMoney = { 0 };


	ocscpy_s(TableUserName, _countof(TableUserName), OLESTR(""));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	TableDate.vt = VT_DATE;
	TableDate.date = timeNow.m_dt;

	CurrentRate = { 0 };

	CreditRecordType = TRUE;

	SourceID = GUID_NULL;
	TableUser = GUID_NULL;
	CardID = GUID_NULL;

	State = Initial;
}


CCardUIRecord::CCardUIRecord(const CCardUIRecord& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CCardUIRecord::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CCardUIRecord(*this);
	}
}

CString CCardUIRecord::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), CardNumber);
		break;
	case 2:
		strRet.Format(_T("%s"), CustName);
		break;
	case 3:
		strRet.Format(_T("%s"), Summary);
		break;
	case 4:
		strRet.Format(_T("%.2f"), Debit);
		break;
	case 5:
		strRet.Format(_T("%.2f"), Credit);
		break;
	case 6:
		strRet.Format(_T("%.2f"), RealMoney);
		break;
	case 8:
		strRet.Format(_T("%s"), TableUserName);
		break;
	case 9:
		strRet.Format(_T("%.2f"), CurrentRate);
		break; 
	case 10:
		strRet.Format(_T("%s"), CreditRecordType ? _T("����¼") : _T("���ּ�¼"));
		break;
	case 7:
		strRet = __super::FormatDateTime(TableDate);
		break;
	case 0:
		idRet = CUIRID;
		break;
	case 11:
		idRet = SourceID;
		break;
	case 12:
		idRet = TableUser;
		break;
	case 13:
		idRet = CardID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CCardUIRecord::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�ͻ�"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("ժҪ"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("׷��"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��ֵ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("ҵ��Ա"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�Ż���"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("��¼����"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("��Դ����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("ҵ��Ա����"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("������"));
		break;
	}

	return strRet;
}

BOOL CCardUIRecord::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	double dblVal = { 0 };
	if (nCol == 0 || (nCol > 10 && nCol < 14))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 10)
	{
		bTemp = (strTemp.CompareNoCase(_T("����¼")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 7)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 9 ||( nCol > 3 && nCol < 7 ))
	{
		TCHAR* pstrStop;
		dblVal = _tcstod(strTemp, &pstrStop);
	}
	switch (nCol)
	{
	case 0:
		CUIRID = idTemp;
		break;
	case 1:
		_tcscpy_s(CardNumber, _countof(CardNumber), Truncate(strTemp, _countof(CardNumber) + 1));
		break;
	case 2:
		_tcscpy_s(CustName, _countof(CustName), Truncate(strTemp, _countof(CustName) + 1));
		break;
	case 3:
		_tcscpy_s(Summary, _countof(Summary), Truncate(strTemp, _countof(Summary) + 1));
		break;
	case 4:
		Debit = dblVal;
		break;
	case 5:
		Credit = dblVal;
		break;
	case 6:
		RealMoney = dblVal;
		break;
	case 7:
		TableDate.date = dtTemp;
		break;
	case 8:
		_tcscpy_s(TableUserName, _countof(TableUserName), Truncate(strTemp, _countof(TableUserName) + 1));
		break;
	case 9:
		CurrentRate = dblVal;
		break;
	case 10:
		CreditRecordType = bTemp;
		break;
	case 11:
		SourceID = idTemp;
		break;
	case 12:
		TableUser = idTemp;
		break;
	case 13:
		CardID = idTemp;
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CCardUIRecord& agenInfo)
{
	UINT ui = 0;
	for (; ui != agenInfo.GetColCount() - 1; ui++)
	{
		os << agenInfo.GetCellText(ui) << _T("��");
	}
	os << agenInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CCardUIRecord& agenInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			agenInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
