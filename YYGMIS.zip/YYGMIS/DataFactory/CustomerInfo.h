#pragma once
namespace Database
{
	class AFX_EXT_CLASS CCustomerInfo : public CFlybyItem
	{
	public:
		CCustomerInfo();
		CCustomerInfo(const CCustomerInfo& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 17; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return custID; }

	public:	//��ӳ��
		BEGIN_COLUMN_MAP(CCustomerInfo)
			COLUMN_ENTRY(1, custID)
			COLUMN_ENTRY(2, custCustomID)
			COLUMN_ENTRY(3, CustomerName)
			COLUMN_ENTRY(4, CustomerSex)
			COLUMN_ENTRY(5, CustomerPN)
			COLUMN_ENTRY(6, CustomerPrefer)
			COLUMN_ENTRY(7, CustomerMemo)
			COLUMN_ENTRY(8, ContactAddress)
			COLUMN_ENTRY(9, CustomerPostalCode)
			COLUMN_ENTRY(10, JM)
			COLUMN_ENTRY(11, custHadCard)
			COLUMN_ENTRY(12, custBirthday)
			COLUMN_ENTRY(13, CreateDate)
			COLUMN_ENTRY(14, ModifyDate)
			COLUMN_ENTRY(15, CreatedUser)
			COLUMN_ENTRY(16, ModifierUser)
			COLUMN_ENTRY(17, compID)
		END_COLUMN_MAP()
	private:	//˽�г�Ա
		GUID custID;
		OLECHAR custCustomID[40];
		OLECHAR CustomerName[120];
		OLECHAR CustomerSex[3];
		OLECHAR CustomerPN[255];
		OLECHAR CustomerPrefer[120];
		OLECHAR CustomerMemo[120];
		OLECHAR ContactAddress[150];
		OLECHAR CustomerPostalCode[7];
		OLECHAR JM[120];
		BOOL custHadCard;
		CComVariant custBirthday;
		CComVariant CreateDate;
		CComVariant ModifyDate;

		GUID CreatedUser;
		GUID ModifierUser;
		GUID compID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CCustomerInfo& custInfo);
		friend STDInStream& operator >> (STDInStream& is, CCustomerInfo& custInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CCustomerInfo& custInfo);
	STDInStream& operator >> (STDInStream& is, CCustomerInfo& custInfo);

	class CCustomerInfoVector : public CFlybyData
	{
	public:
		CCustomerInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewCustomer");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CCustomerInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CCustomerInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CCustomerInfo>(new CCustomerInfo()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA