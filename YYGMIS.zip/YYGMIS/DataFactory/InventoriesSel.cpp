#include "stdafx.h"
#include "FlybyData.h"
#include "InventoriesSel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CInventoriesSel::CInventoriesSel()
{
	CoCreateGuid(&InvID);
	IsSelected = FALSE;
	ocscpy_s(WSPName, _countof(WSPName), OLESTR(""));
	ocscpy_s(ProdName, _countof(ProdName), OLESTR(""));
	ocscpy_s(ProdCustomID, _countof(ProdCustomID), OLESTR(""));
	ocscpy_s(ProductType, _countof(ProductType), OLESTR(""));
	ocscpy_s(ProductSpec, _countof(ProductSpec), OLESTR(""));
	ocscpy_s(ProductUnit1, _countof(ProductUnit1), OLESTR(""));

	StockQuantity = { 0 };
	WSPID = GUID_NULL;
	ProdID = GUID_NULL;

	State = Modified;
}

CInventoriesSel::CInventoriesSel(const CInventoriesSel& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CInventoriesSel::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CInventoriesSel(*this);
	}
}

CString CInventoriesSel::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;

	switch (nCol)
	{
	case 0:
		idRet = InvID;
		break;
	case 1:
		if (IsSelected)
		{
			strRet.Format(_T("%s"), _T("��ѡ��"));
		}
		else
		{
			strRet.Format(_T("%s"), _T("���ѡ��"));
		}
		break;
	case 2:
		strRet.Format(_T("%s"), WSPName);
		break;
	case 3:
		strRet.Format(_T("%s"), ProdName);
		break;
	case 4:
		strRet.Format(_T("%s"), ProdCustomID);
		break;
	case 5:
		strRet.Format(_T("%s"), ProductType);
		break;
	case 6:
		strRet.Format(_T("%s"), ProductSpec);
		break;
	case 7:
		strRet.Format(_T("%s"), ProductUnit1);
		break;
	case 8:
		strRet.Format(_T("%.2f"), StockQuantity);
		break;
	case 9:
		idRet = WSPID;
		break;
	case 10:
		idRet = ProdID;
		break;
	}

	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}

	return strRet;
}

CString CInventoriesSel::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("ѡ������"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�ⷿ"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("���"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("��λ"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�ⷿ����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	}
	return strRet;
}

BOOL CInventoriesSel::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	CString strTemp(strText);
	double dblTemp = { 0 };
	GUID idTemp = GUID_NULL;
	if (nCol == 0)
	{
		if (strText.Compare(_T("{00000000-0000-0000-0000-000000000000}")) == 0)
		{
			CoCreateGuid(&idTemp);
		}
	}
	else if (nCol >= 9 && nCol <= 10)
	{
		LPOLESTR strID = strTemp.AllocSysString();
		HRESULT hr = IIDFromString(strID, &idTemp);
		bRet = SUCCEEDED(hr);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 8)
	{
		TCHAR* pstrStop;
		dblTemp = _tcstod(strTemp, &pstrStop);
	}

	switch (nCol)
	{
	case 0:
		InvID = idTemp;
		break;
	case 1:
		if (strTemp.Compare(_T("��ѡ��")) == 0
			|| strTemp.Compare(_T("1")) == 0)
		{
			IsSelected = TRUE;
		}
		else
		{
			IsSelected = FALSE;
		}
		break;
	case 2:
		ocscpy_s(WSPName, _countof(WSPName), Truncate(strTemp, _countof(WSPName) + 1));
		break;
	case 3:
		ocscpy_s(ProdName, _countof(ProdName), Truncate(strTemp, _countof(ProdName) + 1));
		break;
	case 4:
		ocscpy_s(ProdCustomID, _countof(ProdCustomID), Truncate(strTemp, _countof(ProdCustomID) + 1));
		break;
	case 5:
		ocscpy_s(ProductType, _countof(ProductType), Truncate(strTemp, _countof(ProductType) + 1));
		break;
	case 6:
		ocscpy_s(ProductSpec, _countof(ProductSpec), Truncate(strTemp, _countof(ProductSpec) + 1));
		break;
	case 7:
		ocscpy_s(ProductUnit1, _countof(ProductUnit1), Truncate(strTemp, _countof(ProductUnit1) + 1));
		break;
	case 8:
		StockQuantity = dblTemp;
		break;
	case 9:
		WSPID = idTemp;
		break;
	case 10:
		ProdID = idTemp;
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CInventoriesSel& itemInfo)
{
	UINT ui = 0;
	for (; ui != itemInfo.GetColCount() - 1; ui++)
	{
		os << itemInfo.GetCellText(ui) << _T("��");
	}
	os << itemInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CInventoriesSel& itemInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			itemInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
