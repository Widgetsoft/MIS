#include "stdafx.h"
#include "FlybyData.h"
#include "SalesFlow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace Database;

#pragma region ���۵�
CSalesFlow::CSalesFlow()
{
	CoCreateGuid(&SalesID);
	ocscpy_s(SalesCustomID, _countof(SalesCustomID), OLESTR(""));
	COleDateTime tempCurrDate = COleDateTime::GetCurrentTime();
	SalesDate.vt = VT_DATE;
	SalesDate.date = tempCurrDate.m_dt;

	ocscpy_s(DetpName, _countof(DetpName), OLESTR(""));
	ocscpy_s(BusinessMan, _countof(BusinessMan), OLESTR(""));
	ocscpy_s(CustomerName, _countof(CustomerName), OLESTR(""));

	IsCheckOut = FALSE;
	ocscpy_s(CheckoutMan, _countof(CheckoutMan), OLESTR(""));

	Amount = { 0 };

	ocscpy_s(Memo, _countof(Memo), OLESTR(""));


	DetpID = GUID_NULL;
	BusinessManID = GUID_NULL;
	CheckoutManID = GUID_NULL;
	custID = GUID_NULL;

	CreateDate.vt = VT_DATE;
	CreateDate.date = tempCurrDate.m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = tempCurrDate.m_dt;
	CheckOutDate.vt = VT_DATE;
	CheckOutDate.date = tempCurrDate.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;

	State = Initial;
}


CSalesFlow::CSalesFlow(const CSalesFlow& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CSalesFlow::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), SalesCustomID);
		break;
	case 2:
		strRet = __super::FormatDateTime(SalesDate);
		break;
	case 3:
		strRet.Format(_T("%s"), DetpName);
		break;
	case 4:
		strRet.Format(_T("%s"), BusinessMan);
		break;
	case 5:
		strRet.Format(_T("%s"), CustomerName);
		break;
	case 6:
		strRet.Format(_T("%s"), IsCheckOut ? _T("�����") : _T("δ���"));
		break;
	case 7:
		strRet.Format(_T("%s"), CheckoutMan);
		break;
	case 8:
		strRet.Format(_T("%.2f"), Amount);
		break;
	case 9:
		strRet.Format(_T("%s"), Memo);
		break;
	case 14:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 15:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 16:
		strRet = __super::FormatDateTime(CheckOutDate);
		break;
	case 0:
		idRet = SalesID;
		break;
	case 10:
		idRet = DetpID;
		break;
	case 11:
		idRet = BusinessManID;
		break;
	case 12:
		idRet = CheckoutManID;
		break;
	case 13:
		idRet = custID;
		break;
	case 17:
		idRet = CreatedUser;
		break;
	case 18:
		idRet = ModifierUser;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CSalesFlow::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("���۱���"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("���ݱ���"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("���۲���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("ҵ��Ա"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�ͻ�����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�Ƿ����"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�ϼƽ��"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("���۱�ע"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("���ű���"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("ҵ��Ա����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("����˱���"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("�ͻ�����"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("�����˱���"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�޸��˱���"));
		break;
	}

	return strRet;
}

BOOL CSalesFlow::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 10 && nCol <= 13)
		|| (nCol >= 17 && nCol <= 18))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 6)
	{
		bTemp = (strTemp.CompareNoCase(_T("�����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 2 || (nCol >= 14 || nCol == 16))
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 8)
	{
		TCHAR* tcsStop = nullptr;
		dblTemp = _tcstod(strTemp, &tcsStop);
	}

	switch (nCol)
	{
	case 0:
		SalesID = idTemp;
		break;
	case 1:
		_tcscpy_s(SalesCustomID, _countof(SalesCustomID), Truncate(strTemp, _countof(SalesCustomID) + 1));
		break;
	case 2:
		SalesDate.date = dtTemp;
		break;
	case 3:
		_tcscpy_s(DetpName, _countof(DetpName), Truncate(strTemp, _countof(DetpName) + 1));
		break;
	case 4:
		_tcscpy_s(BusinessMan, _countof(BusinessMan), Truncate(strTemp, _countof(BusinessMan) + 1));
		break;
	case 5:
		_tcscpy_s(CustomerName, _countof(CustomerName), Truncate(strTemp, _countof(CustomerName) + 1));
		break;
	case 6:
		IsCheckOut = bTemp;
		break;
	case 7:
		_tcscpy_s(CheckoutMan, _countof(CheckoutMan), Truncate(strTemp, _countof(CheckoutMan) + 1));
		break;
	case 8:
		Amount = dblTemp;
		break;
	case 9:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 10:
		DetpID = idTemp;
		break;
	case 11:
		BusinessManID = idTemp;
		break;
	case 12:
		CheckoutManID = idTemp;
		break;
	case 13:
		custID = idTemp;
		break;
	case 14:
		CreateDate.date = dtTemp;
		break;
	case 15:
		ModifyDate.date = dtTemp;
		break;
	case 16:
		CheckOutDate.date = dtTemp;
		break;
	case 17:
		CreatedUser = idTemp;
		break;
	case 18:
		ModifierUser = idTemp;
		break;
	}
	return bRet;
}

void CSalesFlow::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CSalesFlow(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CSalesFlow& sfInfo)
{
	UINT ui = 0;
	for (; ui != sfInfo.GetColCount() - 1; ui++)
	{
		os << sfInfo.GetCellText(ui) << _T("��");
	}
	os << sfInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CSalesFlow& sfInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			sfInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

#pragma endregion

#pragma region ���۵��굥 
CSalesFlowDetails::CSalesFlowDetails()
{
	CoCreateGuid(&SalesDetailsID);

	ocscpy_s(ProdName, _countof(ProdName), OLESTR(""));
	ocscpy_s(ProdType, _countof(ProdType), OLESTR(""));
	ocscpy_s(ProdSpec, _countof(ProdSpec), OLESTR(""));
	Price = { 0 };
	Quantity = { 0 };
	ocscpy_s(ProdUnit, _countof(ProdUnit), OLESTR(""));
	Discount = { 0 };
	Amount = { 0 };
	FinalAmount = { 0 };
	Score = { 0 };
	Commission = { 0 };
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	Unit1ToUnit2Rate = { 1 };

	ProdID = GUID_NULL;
	SalesID = GUID_NULL;

	State = Initial;
}

CSalesFlowDetails::CSalesFlowDetails(const CSalesFlowDetails& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CSalesFlowDetails::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), ProdName);
		break;
	case 2:
		strRet.Format(_T("%s"), ProdType);
		break;
	case 3:
		strRet.Format(_T("%s"), ProdSpec);
		break;
	case 4:
		strRet.Format(_T("%.2f"), Price);
		break;
	case 5:
		strRet.Format(_T("%.2f"), Quantity);
		break;
	case 6:
		strRet.Format(_T("%s"), ProdUnit);
		break;
	case 7:
		strRet.Format(_T("%.2f"), Discount);
		break;
	case 8:
		strRet.Format(_T("%.2f"), Amount);
		break;
	case 9:
		strRet.Format(_T("%.2f"), FinalAmount);
		break;
	case 10:
		strRet.Format(_T("%.2f"), Score);
		break;
	case 11:
		strRet.Format(_T("%.2f"), Commission);
		break;
	case 12:
		strRet.Format(_T("%s"), Memo);
		break;
	case 13:
		strRet.Format(_T("%.6f"), Unit1ToUnit2Rate);
		break;
	case 0:
		idRet = SalesDetailsID;
		break;
	case 14:
		idRet = ProdID;
		break;
	case 15:
		idRet = SalesID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CSalesFlowDetails::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�굥����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��λ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�Żݽ��"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("���"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("ʵ�����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("ҵ��Ա���"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("��λת��ϵ��"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�ܵ�����"));
		break;
	}
	return strRet;
}

BOOL CSalesFlowDetails::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	COleDateTime dtTemp;
	double dblTemp = { 0 };

	if (nCol == 0 || (nCol >= 14 && nCol <= 15))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 4 || nCol == 5 || (nCol >= 7 && nCol <= 11) || nCol == 13)
	{
		TCHAR *tcsStopToken;
		dblTemp = _tcstod(strTemp, &tcsStopToken);
	}

	switch (nCol)
	{
	case 0:
		SalesDetailsID = idTemp;
		break;
	case 1:
		ocscpy_s(ProdName, _countof(ProdName), Truncate(strTemp, _countof(ProdName) + 1));
		break;
	case 2:
		ocscpy_s(ProdType, _countof(ProdType), Truncate(strTemp, _countof(ProdType) + 1));
		break;
	case 3:
		ocscpy_s(ProdSpec, _countof(ProdSpec), Truncate(strTemp, _countof(ProdSpec) + 1));
		break;
	case 4:
		Price = dblTemp;
		break;
	case 5:
		Quantity = dblTemp;
		break;
	case 6:
		ocscpy_s(ProdUnit, _countof(ProdUnit), Truncate(strTemp, _countof(ProdUnit) + 1));
		break;
	case 7:
		Discount = dblTemp;
		break;
	case 8:
		Amount = dblTemp;
		break;
	case 9:
		FinalAmount = dblTemp;
		break;
	case 10:
		Score = dblTemp;
		break;
	case 11:
		Commission = dblTemp;
		break;
	case 12:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 13:
		Unit1ToUnit2Rate = dblTemp;
		break;
	case 14:
		ProdID = idTemp;
		break;
	case 15:
		SalesID = idTemp;
		break;
	}
	return bRet;
}

void CSalesFlowDetails::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CSalesFlowDetails(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CSalesFlowDetails& sfdFlow)
{
	UINT ui = 0;
	for (; ui != sfdFlow.GetColCount() - 1; ui++)
	{
		os << sfdFlow.GetCellText(ui) << _T("��");
	}
	os << sfdFlow.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CSalesFlowDetails& sfdFlow)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			sfdFlow.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
#pragma endregion
