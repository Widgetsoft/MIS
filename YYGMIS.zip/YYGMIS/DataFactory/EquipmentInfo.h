#pragma once
namespace Database
{
	class AFX_EXT_CLASS CEquipmentInfo : public CFlybyItem
	{
	public:
		CEquipmentInfo();
		CEquipmentInfo(const CEquipmentInfo&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 19; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return EIID; }

	public:
		BEGIN_COLUMN_MAP(CEquipmentInfo)
			COLUMN_ENTRY(1, EIID)
			COLUMN_ENTRY(2, EICustomCode)
			COLUMN_ENTRY(3, EIName)
			COLUMN_ENTRY(4, EISpec)
			COLUMN_ENTRY(5, EICost)
			COLUMN_ENTRY(6, EIOneTime)
			COLUMN_ENTRY(7, EIPurchaseDate)
			COLUMN_ENTRY(8, JM)
			COLUMN_ENTRY(9, UsingLife)
			COLUMN_ENTRY(10, PowerDissipation)
			COLUMN_ENTRY(11, CountHours)
			COLUMN_ENTRY(12, IsBusy)
			COLUMN_ENTRY(13, CurrentCount)
			COLUMN_ENTRY(14, EICapacity)

			COLUMN_ENTRY(15, CreateDate)
			COLUMN_ENTRY(16, ModifyDate)
			COLUMN_ENTRY(17, CreatedUser)
			COLUMN_ENTRY(18, ModifierUser)

			COLUMN_ENTRY(19, compID)
		END_COLUMN_MAP()

	private:
		GUID EIID;
		OLECHAR EICustomCode[20];
		OLECHAR EIName[60];
		OLECHAR EISpec[100];
		double EICost;
		BOOL EIOneTime;
		CComVariant EIPurchaseDate;
		OLECHAR JM[60];

		double UsingLife;
		double PowerDissipation;
		double CountHours;
		BOOL IsBusy;
		unsigned int CurrentCount;
		unsigned int EICapacity;

		CComVariant CreateDate;
		CComVariant ModifyDate;
		GUID CreatedUser;
		GUID ModifierUser;

		GUID compID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CEquipmentInfo& ProdInfo);
		friend STDInStream& operator >> (STDInStream& is, CEquipmentInfo& ProdInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CEquipmentInfo& ProdInfo);
	STDInStream& operator >> (STDInStream& is, CEquipmentInfo& ProdInfo);

	class AFX_EXT_CLASS CEquipmentInfoVector : public CFlybyData
	{
	public:
		CEquipmentInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewEquipmentInfo");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CEquipmentInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CEquipmentInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CEquipmentInfo>(new CEquipmentInfo()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA