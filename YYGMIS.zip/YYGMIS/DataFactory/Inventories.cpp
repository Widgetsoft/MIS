#include "stdafx.h"
#include "FlybyData.h"
#include "Inventories.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CInventories::CInventories()
{
	CoCreateGuid(&InvID);
	ocscpy_s(WSPName, _countof(WSPName), OLESTR(""));
	ocscpy_s(ProdName, _countof(ProdName), OLESTR(""));
	ocscpy_s(ProdCustomID, _countof(ProdCustomID), OLESTR(""));
	ocscpy_s(ProductType, _countof(ProductType), OLESTR(""));
	ocscpy_s(ProductSpec, _countof(ProductSpec), OLESTR(""));
	ocscpy_s(ProductUnit1, _countof(ProductUnit1), OLESTR(""));

	StockQuantity = { 0 };
	WSPID = GUID_NULL;
	ProdID = GUID_NULL;

	State = Initial;
}

CInventories::CInventories(const CInventories& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CInventories::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CInventories(*this);
	}
}

CString CInventories::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;

	switch (nCol)
	{
	case 0:
		idRet = InvID;
		break;
	case 1:
		strRet.Format(_T("%s"), WSPName);
		break;
	case 2:
		strRet.Format(_T("%s"), ProdName);
		break;
	case 3:
		strRet.Format(_T("%s"), ProdCustomID);
		break;
	case 4:
		strRet.Format(_T("%s"), ProductType);
		break;
	case 5:
		strRet.Format(_T("%s"), ProductSpec);
		break;
	case 6:
		strRet.Format(_T("%s"), ProductUnit1);
		break;
	case 7:
		strRet.Format(_T("%.2f"), StockQuantity);
		break;
	case 8:
		idRet = WSPID;
		break;
	case 9:
		idRet = ProdID;
		break;
	}

	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}

	return strRet;
}

CString CInventories::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�ⷿ"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("���"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��λ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�ⷿ����"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	}
	return strRet;
}

BOOL CInventories::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	CString strTemp(strText);
	double dblTemp = { 0 };
	GUID idTemp = GUID_NULL;
	if (nCol == 0 || (nCol >= 8 && nCol <= 9))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		HRESULT hr = IIDFromString(strID, &idTemp);
		bRet = SUCCEEDED(hr);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 7)
	{
		TCHAR* pstrStop;
		dblTemp = _tcstod(strTemp, &pstrStop);
	}

	switch (nCol)
	{
	case 0:
		InvID = idTemp;
		break;
	case 1:
		ocscpy_s(WSPName, _countof(WSPName), Truncate(strTemp, _countof(WSPName) + 1));
		break;
	case 2:
		ocscpy_s(ProdName, _countof(ProdName), Truncate(strTemp, _countof(ProdName) + 1));
		break;
	case 3:
		ocscpy_s(ProdCustomID, _countof(ProdCustomID), Truncate(strTemp, _countof(ProdCustomID) + 1));
		break;
	case 4:
		ocscpy_s(ProductType, _countof(ProductType), Truncate(strTemp, _countof(ProductType) + 1));
		break;
	case 5:
		ocscpy_s(ProductSpec, _countof(ProductSpec), Truncate(strTemp, _countof(ProductSpec) + 1));
		break;
	case 6:
		ocscpy_s(ProductUnit1, _countof(ProductUnit1), Truncate(strTemp, _countof(ProductUnit1) + 1));
		break;
	case 7:
		StockQuantity = dblTemp;
		break;
	case 8:
		WSPID = idTemp;
		break;
	case 9:
		ProdID = idTemp;
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CInventories& itemInfo)
{
	UINT ui = 0;
	for (; ui != itemInfo.GetColCount() - 1; ui++)
	{
		os << itemInfo.GetCellText(ui) << _T("��");
	}
	os << itemInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CInventories& itemInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			itemInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}