namespace Database
{
	class AFX_EXT_CLASS CSalesFlow : public CFlybyItem
	{
	public:
		CSalesFlow();
		CSalesFlow(const CSalesFlow&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 19; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return SalesID; }

	public:
		BEGIN_COLUMN_MAP(CSalesFlow)
			COLUMN_ENTRY(1, SalesID)
			COLUMN_ENTRY(2, SalesCustomID)
			COLUMN_ENTRY(3, SalesDate)
			COLUMN_ENTRY(4, DetpName)
			COLUMN_ENTRY(5, BusinessMan)
			COLUMN_ENTRY(6, CustomerName)
			COLUMN_ENTRY(7, IsCheckOut)
			COLUMN_ENTRY(8, CheckoutMan)
			COLUMN_ENTRY(9, Amount)
			COLUMN_ENTRY(10, Memo)
			COLUMN_ENTRY(11, DetpID)
			COLUMN_ENTRY(12, BusinessManID)
			COLUMN_ENTRY(13, CheckoutManID)
			COLUMN_ENTRY(14, custID)
			COLUMN_ENTRY(15, CreateDate)
			COLUMN_ENTRY(16, ModifyDate)
			COLUMN_ENTRY(17, CheckOutDate)
			COLUMN_ENTRY(18, CreatedUser)
			COLUMN_ENTRY(19, ModifierUser)
		END_COLUMN_MAP()
	private:
		GUID		SalesID;				//���۵��ڲ�����
		OLECHAR		SalesCustomID[17];		//���۵�����
		CComVariant SalesDate;				//��������
		OLECHAR		DetpName[60];			//���۲���
		OLECHAR		BusinessMan[20];		//�ۻ�Ա
		OLECHAR		CustomerName[60];		//�ͻ�����
		BOOL		IsCheckOut;				//�Ƿ����
		OLECHAR		CheckoutMan[20];		//�����
		double		Amount;					//�ϼƽ�� 
		OLECHAR		Memo[MAX_PATH];			//��ע

		GUID		DetpID;				//���첿�ű���
		GUID		BusinessManID;		//����Ա����
		GUID		CheckoutManID;		//����˱���
		GUID		custID;				//����ͻ�

		CComVariant CreateDate;			//��������
		CComVariant ModifyDate;			//�޸�����
		CComVariant CheckOutDate;		//�������
		GUID		CreatedUser;		//������
		GUID		ModifierUser;		//�޸���

		DataState	State;				//����״̬
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CSalesFlow& SvcFlow);
		friend STDInStream& operator >> (STDInStream& is, CSalesFlow& SvcFlow);
	}; //����Դ������ǰ׺

	STDOutStream& operator<<(STDOutStream& os, const CSalesFlow& SvcFlow);
	STDInStream& operator >> (STDInStream& is, CSalesFlow& SvcFlow);

	class AFX_EXT_CLASS CSalesFlowVector : public CFlybyData
	{
	public:
		CSalesFlowVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewSalesFlow");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CSalesFlow().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CSalesFlow().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CSalesFlow>(new CSalesFlow()).release(); }
	};

	class AFX_EXT_CLASS CSalesFlowDetails : public CFlybyItem
	{
	public:
		CSalesFlowDetails();
		CSalesFlowDetails(const CSalesFlowDetails&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 16; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return SalesDetailsID; }

	public:
		BEGIN_COLUMN_MAP(CSalesFlowDetails)
			COLUMN_ENTRY(1, SalesDetailsID)
			COLUMN_ENTRY(2, ProdName)
			COLUMN_ENTRY(3, ProdType)
			COLUMN_ENTRY(4, ProdSpec)
			COLUMN_ENTRY(5, Price)
			COLUMN_ENTRY(6, Quantity)
			COLUMN_ENTRY(7, ProdUnit)
			COLUMN_ENTRY(8, Discount)
			COLUMN_ENTRY(9, Amount)
			COLUMN_ENTRY(10, FinalAmount)
			COLUMN_ENTRY(11, Score)
			COLUMN_ENTRY(12, Commission)
			COLUMN_ENTRY(13, Memo)
			COLUMN_ENTRY(14, Unit1ToUnit2Rate)
			COLUMN_ENTRY(15, ProdID)
			COLUMN_ENTRY(16, SalesID)
		END_COLUMN_MAP()

	private:
		GUID		SalesDetailsID;
		OLECHAR		ProdName[60];		//Ʒ��
		OLECHAR		ProdType[40];		//��Ʒ���
		OLECHAR		ProdSpec[40];		//��Ʒ���
		double		Price;				//����
		double		Quantity;			//����
		OLECHAR		ProdUnit[40];		//������λ
		double		Discount;			//�Ż��ۿ�
		double		Amount;				//�����۽��
		double		FinalAmount;		//���׽��
		double		Score;				//����
		double		Commission;			//ҵ��Ա���

		OLECHAR		Memo[MAX_PATH];		//��ע

		double		Unit1ToUnit2Rate;	//��λת��ϵ��

		GUID		ProdID;				//�ײͱ���
		GUID		SalesID;			//�ܵ�����

		DataState State;

	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CSalesFlowDetails& SvcFlowD);
		friend STDInStream& operator >> (STDInStream& is, CSalesFlowDetails& SvcFlowD);
	};

	STDOutStream& operator<<(STDOutStream& os, const CSalesFlowDetails& SvcFlowD);
	STDInStream& operator >> (STDInStream& is, CSalesFlowDetails& SvcFlowD);

	class AFX_EXT_CLASS CSalesFlowDetailsVector : public CFlybyData
	{
	public:
		CSalesFlowDetailsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewSalesFlowDetails");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CSalesFlowDetails().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CSalesFlowDetails().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CSalesFlowDetails>(new CSalesFlowDetails()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA