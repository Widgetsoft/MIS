namespace Database
{
	class AFX_EXT_CLASS CCardUIRecord : public CFlybyItem
	{
	public:
		CCardUIRecord();
		CCardUIRecord(const CCardUIRecord& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 14; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return CardID; }


	public:
		BEGIN_COLUMN_MAP(CCardUIRecord)
			COLUMN_ENTRY(1, CUIRID)
			COLUMN_ENTRY(2, CardNumber)
			COLUMN_ENTRY(3, CustName)
			COLUMN_ENTRY(4, Summary)
			COLUMN_ENTRY(5, Debit)
			COLUMN_ENTRY(6, Credit)
			COLUMN_ENTRY(7, RealMoney)
			COLUMN_ENTRY(8, TableDate)
			COLUMN_ENTRY(9, TableUserName)
			COLUMN_ENTRY(10, CurrentRate)
			COLUMN_ENTRY(11, CreditRecordType)
			COLUMN_ENTRY(12, SourceID)
			COLUMN_ENTRY(13, TableUser)
			COLUMN_ENTRY(14, CardID)
		END_COLUMN_MAP()

	private:
		GUID CUIRID;
		OLECHAR CardNumber[60];
		OLECHAR CustName[120];
		OLECHAR Summary[120];

		double Debit;
		double Credit;
		double RealMoney;

		CComVariant TableDate;
		OLECHAR TableUserName[20];

		double CurrentRate;

		BOOL CreditRecordType;

		GUID SourceID;
		GUID TableUser;
		GUID CardID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CCardUIRecord& agenInfo);
		friend STDInStream& operator >>(STDInStream& is, CCardUIRecord& agenInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CCardUIRecord& agenInfo);
	STDInStream& operator >>(STDInStream& is, CCardUIRecord& agenInfo);

	class AFX_EXT_CLASS CCardUIRecordVector : public CFlybyData
	{
	public:
		CCardUIRecordVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewCardUIRecord");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CCardUIRecord().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CCardUIRecord().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CCardUIRecord>(new CCardUIRecord()).release(); }
	};
}

#undef AFX_DATA
#define AFX_DATA


