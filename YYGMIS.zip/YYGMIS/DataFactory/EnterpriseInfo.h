#pragma once
namespace Database
{
	class AFX_EXT_CLASS CEnterpriseInfo : public CFlybyItem
	{
	public:
		CEnterpriseInfo();
		CEnterpriseInfo(const CEnterpriseInfo& refInput);

	public:
		BEGIN_COLUMN_MAP(CEnterpriseInfo)
			COLUMN_ENTRY(1, compID)
			COLUMN_ENTRY(2, compName)
			COLUMN_ENTRY(3, compPhoneNum)
			COLUMN_ENTRY(4, compFaxNum)
			COLUMN_ENTRY(5, compValidAddr)
			COLUMN_ENTRY(6, compEmail)
			COLUMN_ENTRY(7, URL)
			COLUMN_ENTRY(8, compPostCode)
			COLUMN_ENTRY(9, compAddr)
			COLUMN_ENTRY(10, LegalRepresentative)
			COLUMN_ENTRY(11, Memo)
			COLUMN_ENTRY(12, IsUsing)
			COLUMN_ENTRY(13, JM)
			COLUMN_ENTRY(14, CreateDate)
			COLUMN_ENTRY(15, ModifyDate)
		END_COLUMN_MAP()

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		virtual inline UINT GetColCount() const { return 15; }
		virtual inline DataState GetState() const { return State; }
		virtual inline void SetState(const DataState state) { State = state; }
		virtual GUID GetItemID() const { return compID; }

	protected: //˽�����ݳ�Ա
		GUID	compID;
		OLECHAR compName[100];
		OLECHAR compPhoneNum[255];
		OLECHAR compFaxNum[255];
		OLECHAR compValidAddr[120];
		OLECHAR compEmail[60];
		OLECHAR URL[60];
		OLECHAR compPostCode[7];
		OLECHAR compAddr[120];
		OLECHAR LegalRepresentative[60];
		OLECHAR Memo[255];
		BOOL IsUsing;
		OLECHAR JM[100];
		CComVariant CreateDate;
		CComVariant ModifyDate;
		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CEnterpriseInfo& entInfo);
		friend STDInStream& operator >> (STDInStream& is, CEnterpriseInfo& entInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CEnterpriseInfo& entInfo);
	STDInStream& operator >> (STDInStream& is, CEnterpriseInfo& entInfo);

	class AFX_EXT_CLASS CEnterpriseInfoVector : public CFlybyData
	{
	public:
		CEnterpriseInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewEnterprise");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CEnterpriseInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CEnterpriseInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CEnterpriseInfo>(new CEnterpriseInfo()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA