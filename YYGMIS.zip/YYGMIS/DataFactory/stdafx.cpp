// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// DataFactory.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void Split(PTSTR strSource, PTSTR strSeps, Concurrency::concurrent_vector<CString>* pRet)
{
	if (pRet == nullptr)
	{
		pRet = std::auto_ptr<Concurrency::concurrent_vector<CString>>(new Concurrency::concurrent_vector<CString>()).release();
	}
	if (strSource == nullptr)
	{
		return;
	}
	pRet->clear();
	TCHAR *token = nullptr;
	TCHAR *next_token = nullptr;
	// Establish string and get the first token:
	token = _tcstok_s(strSource, strSeps, &next_token);
	// While there are tokens in "strSource"
	while (token != nullptr)
	{
		// Get next token:
		if (token != nullptr)
		{
			if (_tcslen(token) > 0)
			{
				pRet->push_back(token);
			}
			token = _tcstok_s(nullptr, strSeps, &next_token);
		}
	}
}

std::string CT2ALocal(const TCHAR* tcsInput)
{
#ifndef _UNICODE
	return std::string(tcsInput);
#endif // !_UNICODE
	std::string strRet;
	int nLength = WideCharToMultiByte(CP_ACP, 0, tcsInput, -1, nullptr, 0, nullptr, nullptr);
	if (nLength > 0)
	{
		PSTR pStrRet = (char*)HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, nLength);
		WideCharToMultiByte(CP_ACP, 0, tcsInput, -1, pStrRet, nLength, nullptr, nullptr);
		strRet.append(pStrRet);
		HeapFree(GetProcessHeap(), 0, pStrRet);
	}
	return strRet;
}

STDString CA2TLocal(const char* strInput)
{
#ifndef _UNICODE
	return STDString(strInput);
#endif // !_UNICODE

	std::wstring stdstrRet;
	int nLength = MultiByteToWideChar(CP_ACP, 0, strInput, -1, nullptr, 0);
	if (nLength > 0)
	{
		PTSTR ptStrRet = (TCHAR*)HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, nLength * sizeof(TCHAR));
		MultiByteToWideChar(CP_ACP, 0, strInput, -1, ptStrRet, nLength);
		stdstrRet.append(ptStrRet);
		HeapFree(GetProcessHeap(), 0, ptStrRet);
	}
	return stdstrRet;
}