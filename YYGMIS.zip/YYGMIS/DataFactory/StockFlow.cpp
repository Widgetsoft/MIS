#include "StdAfx.h"
#include "FlybyData.h"
#include "StockFlow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

#pragma region ���ҵ����
CStockFlow::CStockFlow()
{
	CoCreateGuid(&StockID);
	ocscpy_s(StockCustomID, _countof(StockCustomID), OLESTR(""));
	COleDateTime currentTime = COleDateTime::GetCurrentTime();
	StockDate.vt = VT_DATE;
	StockDate.date = currentTime.m_dt;
	ocscpy_s(StockMan, _countof(StockMan), OLESTR(""));
	ocscpy_s(Warehouse, _countof(Warehouse), OLESTR(""));
	ocscpy_s(StockDescripion, _countof(StockDescripion), OLESTR(""));
	Quantity = { 0 };
	Amount = { 0 };
	IsCheckOut = FALSE;
	ocscpy_s(CheckoutMan, _countof(CheckoutMan), OLESTR(""));
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	IsStockIn = TRUE;
	CreateDate.vt = VT_DATE;
	CreateDate.date = currentTime.m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = currentTime.m_dt;
	CheckOutDate.vt = VT_DATE;
	CheckOutDate.date = currentTime.m_dt;
	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	CheckoutManID = GUID_NULL;
	StockManID = GUID_NULL;
	StockSourceID = GUID_NULL;
	WarehouseID = GUID_NULL;

	State = Initial;
}


CStockFlow::CStockFlow(const CStockFlow& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CStockFlow::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), StockCustomID);
		break;
	case 2:
		strRet = __super::FormatDateTime(StockDate);
		break;
	case 3:
		strRet.Format(_T("%s"), StockMan);
		break;
	case 4:
		strRet.Format(_T("%s"), Warehouse);
		break;
	case 5:
		strRet.Format(_T("%s"), StockDescripion);
		break;
	case 6:
		strRet.Format(_T("%.2f"), Quantity);
		break;
	case 7:
		strRet.Format(_T("%.2f"), Amount);
		break;
	case 8:
		strRet.Format(_T("%s"), IsCheckOut ? _T("�����") : _T("δ���"));
		break;
	case 9:
		strRet.Format(_T("%s"), CheckoutMan);
		break;
	case 10:
		strRet.Format(_T("%s"), Memo);
		break;
	case 11:
		strRet.Format(_T("%s"), IsStockIn ? _T("���") : _T("����"));
		break;
	case 12:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 13:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 14:
		strRet = __super::FormatDateTime(CheckOutDate);
		break;
	case 0:
		idRet = StockID;
		break;
	case 15:
		idRet = CreatedUser;
		break;
	case 16:
		idRet = ModifierUser;
		break;
	case 17:
		idRet = CheckoutManID;
		break;
	case 18:
		idRet = StockManID;
		break;
	case 19:
		idRet = StockSourceID;
		break;
	case 20:
		idRet = WarehouseID;
		break;

	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CStockFlow::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��浥��"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("���ʱ��"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�ֿ�����"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("���ժҪ"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�Ƿ����"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("��汸ע"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�����û�"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("�޸��û�"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("����˱���"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�����˱���"));
		break;
	case 19:
		strRet.Format(_T("%s"), _T("��Դ����"));
		break;
	case 20:
		strRet.Format(_T("%s"), _T("�ⷿ����"));
		break;
	}

	return strRet;
}

BOOL CStockFlow::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 15 && nCol <= 20))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 8)
	{
		bTemp = (strTemp.CompareNoCase(_T("�����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 11)
	{
		bTemp = (strTemp.CompareNoCase(_T("���")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 2 || (nCol >= 12 && nCol  <= 14))
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol >= 6 && nCol <= 7)
	{
		TCHAR *tcsStopToken;
		dblTemp = _tcstod(strTemp, &tcsStopToken);
	}

	switch (nCol)
	{
	case 0:
		StockID = idTemp;
		break;
	case 1:
		_tcscpy_s(StockCustomID, _countof(StockCustomID), Truncate(strTemp, _countof(StockCustomID) + 1));
		break;
	case 2:
		StockDate.date = dtTemp;
		break;
	case 3:
		_tcscpy_s(StockMan, _countof(StockMan), Truncate(strTemp, _countof(StockMan) + 1));
		break;
	case 4:
		_tcscpy_s(Warehouse, _countof(Warehouse), Truncate(strTemp, _countof(Warehouse) + 1));
		break;
	case 5:
		_tcscpy_s(StockDescripion, _countof(StockDescripion), Truncate(strTemp, _countof(StockDescripion) + 1));
		break;
	case 6:
		Quantity = dblTemp;
		break;
	case 7:
		Amount = dblTemp;
		break;
	case 8:
		IsCheckOut = bTemp;
		break;
	case 9:
		_tcscpy_s(CheckoutMan, _countof(CheckoutMan), Truncate(strTemp, _countof(CheckoutMan) + 1));
		break;
	case 10:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 11:
		IsStockIn = bTemp;
		break;
	case 12:
		CreateDate.date = dtTemp;
		break;
	case 13:
		ModifyDate.date = dtTemp;
		break;
	case 14:
		CheckOutDate.date = dtTemp;
		break;
	case 15:
		CreatedUser = idTemp;
		break;
	case 16:
		ModifierUser = idTemp;
		break;
	case 17:
		CheckoutManID = idTemp;
		break;
	case 18:
		StockManID = idTemp;
		break;
	case 19:
		StockSourceID = idTemp;
		break;
	case 20:
		WarehouseID = idTemp;
		break;
	}
	return bRet;
}

void CStockFlow::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CStockFlow(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CStockFlow& sfInfo)
{
	UINT ui = 0;
	for (; ui != sfInfo.GetColCount() - 1; ui++)
	{
		os << sfInfo.GetCellText(ui) << _T("��");
	}
	os << sfInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CStockFlow& sfInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			sfInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
#pragma endregion

#pragma region ���ҵ���굥��
CStockFlowDetails::CStockFlowDetails()
{
	CoCreateGuid(&SDID);
	ocscpy_s(ProductName, _countof(ProductName), OLESTR(""));
	ocscpy_s(ProductType, _countof(ProductType), OLESTR(""));
	ocscpy_s(SpecName, _countof(SpecName), OLESTR(""));
	Price = { 0 };
	Quantity = { 0 };
	ocscpy_s(ProductUnit, _countof(ProductUnit), OLESTR(""));
	Amount = .00f;
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	ProdID = GUID_NULL;
	StoreID = GUID_NULL;

	State = Initial;
}

CStockFlowDetails::CStockFlowDetails(const CStockFlowDetails& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CStockFlowDetails::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), ProductName);
		break;
	case 2:
		strRet.Format(_T("%s"), ProductType);
		break;
	case 3:
		strRet.Format(_T("%s"), SpecName);
		break;
	case 4:
		strRet.Format(_T("%.2f"), Price);
		break;
	case 5:
		strRet.Format(_T("%.2f"), Quantity);
		break;
	case 6:
		strRet.Format(_T("%s"), ProductUnit);
		break;
	case 7:
		strRet.Format(_T("%.2f"), Amount);
		break;
	case 8:
		strRet.Format(_T("%s"), Memo);
		break;
	case 0:
		idRet = SDID;
		break;
	case 9:
		idRet = ProdID;
		break;
	case 10:
		idRet = StoreID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CStockFlowDetails::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�굥����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("��浥��"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("������λ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("��汸ע"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("������"));
		break;
	}

	return strRet;
}

BOOL CStockFlowDetails::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 9 && nCol <= 10))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if ((nCol >= 4 && nCol <= 5) || nCol == 7)
	{
		TCHAR *tcsErrorStop = nullptr;
		dblTemp = _tcstod(strTemp, &tcsErrorStop);
	}

	switch (nCol)
	{
	case 0:
		SDID = idTemp;
		break;
	case 1:
		_tcscpy_s(ProductName, _countof(ProductName), Truncate(strTemp, _countof(ProductName) + 1));
		break;
	case 2:
		_tcscpy_s(ProductType, _countof(ProductType), Truncate(strTemp, _countof(ProductType) + 1));
		break;
	case 3:
		_tcscpy_s(SpecName, _countof(SpecName), Truncate(strTemp, _countof(SpecName) + 1));
		break;
	case 4:
		Price = dblTemp;
		break;
	case 5:
		Quantity = dblTemp;
		break;
	case 6:
		_tcscpy_s(ProductUnit, _countof(ProductUnit), Truncate(strTemp, _countof(ProductUnit) + 1));
		break;
	case 7:
		Amount = dblTemp;
		break;
	case 8:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 9:
		ProdID = idTemp;
		break;
	case 10:
		StoreID = idTemp;
		break;
	}
	return bRet;
}

void CStockFlowDetails::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CStockFlowDetails(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CStockFlowDetails& sfdInfo)
{
	UINT ui = 0;
	for (; ui != sfdInfo.GetColCount() - 1; ui++)
	{
		os << sfdInfo.GetCellText(ui) << _T("��");
	}
	os << sfdInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CStockFlowDetails& sfdInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			sfdInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

#pragma endregion