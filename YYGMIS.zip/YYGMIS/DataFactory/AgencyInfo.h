#pragma once
namespace Database
{
	class AFX_EXT_CLASS CAgencyInfo : public CFlybyItem
	{
	public:
		CAgencyInfo();
		CAgencyInfo(const CAgencyInfo& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 17; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return deptID; }


	public:
		BEGIN_COLUMN_MAP(CAgencyInfo)
			COLUMN_ENTRY(1, deptID)
			COLUMN_ENTRY(2, deptName)
			COLUMN_ENTRY(3, compName)
			COLUMN_ENTRY(4, deptChief)
			COLUMN_ENTRY(5, deptPhoneNum)
			COLUMN_ENTRY(6, detpFaxNum)
			COLUMN_ENTRY(7, deptEmail)
			COLUMN_ENTRY(8, deptPostCode)
			COLUMN_ENTRY(9, deptAddress)
			COLUMN_ENTRY(10, IsUsing)
			COLUMN_ENTRY(11, Memo)
			COLUMN_ENTRY(12, JM)
			COLUMN_ENTRY(13, CreateDate)
			COLUMN_ENTRY(14, ModifyDate)
			COLUMN_ENTRY(15, CreatedUser)
			COLUMN_ENTRY(16, ModifierUser)
			COLUMN_ENTRY(17, compID)
		END_COLUMN_MAP()

	private:
		GUID deptID;
		OLECHAR deptName[100];
		OLECHAR compName[100];
		OLECHAR deptChief[60];
		OLECHAR deptPhoneNum[255];
		OLECHAR detpFaxNum[255];
		OLECHAR deptEmail[60];
		OLECHAR deptPostCode[7];
		OLECHAR deptAddress[120];
		BOOL IsUsing;
		OLECHAR Memo[255];
		OLECHAR JM[100];
		CComVariant CreateDate;
		CComVariant ModifyDate;
		GUID CreatedUser;
		GUID ModifierUser;
		GUID compID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CAgencyInfo& agenInfo);
		friend STDInStream& operator >>(STDInStream& is, CAgencyInfo& agenInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CAgencyInfo& agenInfo);
	STDInStream& operator >>(STDInStream& is, CAgencyInfo& agenInfo);

	class AFX_EXT_CLASS CAgencyInfoVector : public CFlybyData
	{
	public:
		CAgencyInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewAgency");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CAgencyInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CAgencyInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CAgencyInfo>(new CAgencyInfo()).release(); }
	};
}

#undef AFX_DATA
#define AFX_DATA