#include "stdafx.h"
#include "FlybyData.h"
#include "YYGMISSystemInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CYYGMISSystemInfo::CYYGMISSystemInfo()
{
	CoCreateGuid(&SYSID);
	ocscpy_s(SystemProof, _countof(SystemProof), OLESTR("C:\\"));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	TimeStamp.vt = VT_DATE;
	TimeStamp.date = timeNow.m_dt;

	ocscpy_s(FinalCode, _countof(FinalCode), OLESTR(""));

	IsInitialized = FALSE;


	ProdScoreRate = { 1 };
	SvsScoreRate = { 1 };

	StartDate.vt = VT_DATE;
	timeNow.SetDateTime(1970, 1, 1, 0, 0, 0);
	StartDate.date = timeNow.m_dt;

	LoadPeriod = 0;
}


CYYGMISSystemInfo::CYYGMISSystemInfo(const CYYGMISSystemInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CYYGMISSystemInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CYYGMISSystemInfo(*this);
	}
}

CString CYYGMISSystemInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), SystemProof);
		break;
	case 2:
		strRet = __super::FormatDateTime(TimeStamp);
		break;
	case 3:
		strRet.Format(_T("%s"), FinalCode);
		break;
	case 4:
		strRet.Format(_T("%s"), IsInitialized ? _T("�����") : _T("δ���"));
		break;
	case 5:
		strRet.Format(_T("%.6f"), ProdScoreRate);
		break;
	case 6:
		strRet.Format(_T("%.6f"), SvsScoreRate);
		break;
	case 7:
		strRet = __super::FormatDateTime(StartDate);
		break;
	case 8:
		strRet.Format(_T("%i"), LoadPeriod);
		break;
	case 0:
		idRet = SYSID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CYYGMISSystemInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("ϵͳ����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("ʱ���"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��֤��Կ"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�Ƿ��ʼ��"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("��Ʒ������"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�ײͻ�����"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("Ĭ�ϼ�������"));
		break;
	}

	return strRet;
}

BOOL CYYGMISSystemInfo::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	double dblVal = { 0 };
	if (nCol == 0 )
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 4)
	{
		bTemp = (strTemp.CompareNoCase(_T("�����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 2 || nCol == 7)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 5 || nCol == 6)
	{
		TCHAR* pstrStop;
		dblVal = _tcstod(strTemp, &pstrStop);
	}
	switch (nCol)
	{
	case 0:
		SYSID = idTemp;
		break;
	case 1:
		_tcscpy_s(SystemProof, _countof(SystemProof), Truncate(strTemp, _countof(SystemProof) + 1));
		break;
	case 2:
		TimeStamp = dtTemp;
		break;
	case 3:
		_tcscpy_s(FinalCode, _countof(FinalCode), Truncate(strTemp, _countof(FinalCode) + 1));
		break;
	case 4:
		IsInitialized = bTemp;
		break;
	case 5:
		ProdScoreRate = dblVal;
		break;
	case 6:
		SvsScoreRate = dblVal;
		break;
	case 7:
		StartDate = dtTemp;
		break;
	case 8:
		LoadPeriod = _ttoi(strTemp);
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CYYGMISSystemInfo& agenInfo)
{
	UINT ui = 0;
	for (; ui != agenInfo.GetColCount() - 1; ui++)
	{
		os << agenInfo.GetCellText(ui) << _T("��");
	}
	os << agenInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CYYGMISSystemInfo& agenInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			agenInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
