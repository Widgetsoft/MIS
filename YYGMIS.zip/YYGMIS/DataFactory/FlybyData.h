#pragma once

namespace Database
{
	const GUID cgIDTest = { 0xF8CEE3C3, 0xC70B, 0x4911,{ 0x9F, 0x81, 0x57, 0xFC, 0xB0, 0xF6, 0x6C, 0x2E } };

	enum AFX_EXT_CLASS DataState
	{
		Initial = 10010,
		NewItem,
		Modified,
		Deleted
	};

	class AFX_EXT_CLASS CSortInfo : public CObject
	{
	public:
		CSortInfo(UINT uiSortCol, BOOL bSortDirection, CString strOrderStr)
			: m_uiSortCol(uiSortCol), m_bSortDirection(bSortDirection),
			m_strOrderStr(strOrderStr)
		{
		}

	public:
		CString GetOrderBy() const;

	public:
		UINT m_uiSortCol;
		BOOL m_bSortDirection;
		CString m_strOrderStr;
		CString m_strFilterString;

	};


	typedef Concurrency::concurrent_vector< STDString, CSortInfo* > CSortInfoVector;

	extern CString AFX_EXT_API Truncate(CString& strInput, UINT nWords);

	class AFX_EXT_CLASS CFlybyItem
	{
	public:
		CFlybyItem() : m_pExtraData(nullptr) {}
	public:
		//��ȡ��Ԫ������
		virtual CString GetCellText(UINT nCol) const = 0;
		//��ȡ��Ŀ�б���
		virtual CString GetColumnName(UINT nCol) const = 0;
		//���õ�Ԫ������
		virtual BOOL SetCellText(UINT nCol, const CString& strText) = 0;
		//��ȡ������
		virtual UINT GetColCount() const = 0;
		//��ȡ��¼״̬
		virtual DataState GetState() const = 0;
		//������״̬
		virtual void SetState(const DataState state) = 0;
		//��ȡ��¼Ψһ��ʶ
		virtual GUID GetItemID() const = 0;
		//��¡����
		virtual void Clone(CFlybyItem** ppOutObj) = 0;

		//�ж��Ƿ�Ϊ��ID
		static BOOL IsNullGuid(LPCTSTR strID);
		static CString GetNullID();
		//������ID
		static CString GenerateNewID();
		void SetItemPtr(PVOID pvItem) { m_pExtraData = pvItem; }
		PVOID GetItemPtr() const { return m_pExtraData; }
		static CString FormatDate(LPCTSTR strSource);
		static CString FormatDateTime(LPCTSTR strSource);

	protected:
		CString FormatDate(const CComVariant varSource) const;
		CString FormatDateTime(const CComVariant varSource) const;
		CString FormatGUID(const GUID guidSource) const;


	protected:
		PVOID m_pExtraData;
	};

	typedef Concurrency::concurrent_vector<CFlybyItem*> FlybyItem;

	class AFX_EXT_CLASS CFlybyData : public CObject
	{
	public:
		CFlybyData(BOOL bRefOnly = FALSE) : m_bRefOnly(bRefOnly),
			m_mutex(FALSE, nullptr), m_strBindTable(_T("")), m_strFilterCondition(_T("")),
			m_strOrder(_T("")), m_bAssending(TRUE)
		{};
		~CFlybyData();

	public:
		//����һ���ռ�¼
		virtual CFlybyItem* NewItem() = 0;
		//�Զ������
		virtual size_t CustomFindItem(LPCTSTR strKeyWords, size_t iStart = 0, BOOL bBackward = FALSE, BOOL bAllWordsMatch = FALSE);
		//�Զ�������
		virtual void CustomColumnSort(int nCol, bool bAscending);
		//��ȡ�б���
		virtual CString GetColTitle(UINT nCol) const = 0;
		//���õ�Ԫ������
		inline virtual BOOL SetCellText(size_t setupId, int col, const CString& strText)
		{
			return m_records.at(setupId)->SetCellText(col, strText);
		}
		//��ȡ��Ԫ������
		inline virtual CString GetCellText(size_t lookupId, int col)
		{
			return lookupId < m_records.size() ? m_records.at(lookupId)->GetCellText(col) : CString(_T(""));
		}
		//��ȡ��¼����
		inline virtual size_t GetCount() { return m_records.size(); }
		//��������ȡ��¼
		virtual CFlybyItem* GetItem(size_t setupId);
		//��Ψһ��ʶ��ȡ��¼
		virtual CFlybyItem* GetItemByID(GUID setupId);
		//��Ψһ��ʶ��ȡ��¼
		virtual CFlybyItem* GetItemByID(const CString setupId);
		//��ȡ����Ŀ
		virtual int GetColCount() const = 0;
		//��ȡ��Ԫ����ɫ
		inline virtual COLORREF GetCellColor(int nRow, int nCell) { return RGB(14, 99, 246); /*::GetSysColor( COLOR_WINDOWTEXT );*/ }
		//��ռ�¼
		virtual void ClearItems();
		//׷�Ӽ�¼
		virtual void AddItem(CFlybyItem* pItem);
		//��������ɾ���ض���Ŀ
		virtual BOOL RemoveItem(UINT nIndex);
		//���ݵ�����ɾ���ض���Ŀ
		virtual BOOL RevoveItem(FlybyItem::iterator);
		//ɾ���ض���Ŀ
		virtual BOOL RemoveItem(CFlybyItem* pItem);
		//��ȸ���
		virtual BOOL DeepClone(CFlybyData* pVector);

		inline virtual FlybyItem::iterator begin() { return m_records.begin(); }
		inline virtual FlybyItem::iterator end() { return m_records.end(); }

		//��¼����
		virtual BOOL Filter(CFlybyData* pData, UINT colNum = 0, CString strKey = _T(""), BOOL bAllMatch = FALSE, BOOL bClonePoint = FALSE);
	public:
		CMutex m_mutex;

	private: //�ڲ��������ߺ���	
		size_t ParallelFind(const Concurrency::concurrent_vector<CFlybyItem*> records, size_t nStart, size_t nEnd,
			const CString& strKeyWords, BOOL bAllWordsMatch) const;

	public:
		CString m_strBindTable;
		CString m_strFilterCondition;
		CString m_strOrder;
		BOOL m_bAssending;


	protected:
		BOOL m_bRefOnly;
		Concurrency::concurrent_vector<CFlybyItem*> m_records;
	};
}
#undef AFX_DATA
#define AFX_DATA