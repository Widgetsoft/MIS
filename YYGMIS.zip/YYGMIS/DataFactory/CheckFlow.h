#pragma once
namespace Database
{
	class AFX_EXT_CLASS CCheckFlow : public CFlybyItem
	{
	public:
		CCheckFlow();
		CCheckFlow(const CCheckFlow&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 22; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return CheckID; }

	public:
		BEGIN_COLUMN_MAP(CCheckFlow)
			COLUMN_ENTRY(1, CheckID)
			COLUMN_ENTRY(2, CheckCustomID)
			COLUMN_ENTRY(3, CheckDate)
			COLUMN_ENTRY(4, CheckDept)
			COLUMN_ENTRY(5, CheckWHName)
			COLUMN_ENTRY(6, CheckManName)
			COLUMN_ENTRY(7, Quantity)
			COLUMN_ENTRY(8, Quantity1)
			COLUMN_ENTRY(9, Balance)
			COLUMN_ENTRY(10, IsCheckout)
			COLUMN_ENTRY(11, CheckoutMan)
			COLUMN_ENTRY(12, Memo)
			COLUMN_ENTRY(13, IsIncrement)
			COLUMN_ENTRY(14, CheckDeptID)
			COLUMN_ENTRY(15, CheckWH)
			COLUMN_ENTRY(16, CheckMan)
			COLUMN_ENTRY(17, CheckoutManID)
			COLUMN_ENTRY(18, CreateDate)
			COLUMN_ENTRY(19, ModifyDate)
			COLUMN_ENTRY(20, CheckOutDate)
			COLUMN_ENTRY(21, CreatedUser)
			COLUMN_ENTRY(22, ModifierUser)
		END_COLUMN_MAP()

	private:
		GUID			CheckID;			//�̵㵥����
		OLECHAR			CheckCustomID[17];	//�̵㵥�ڲ�����
		CComVariant		CheckDate;			//�̵�����
		OLECHAR			CheckDept[60];		//���㲿��
		OLECHAR			CheckWHName[60];	//�̵�ⷿ
		OLECHAR			CheckManName[20];	//�̵���Ա
		double			Quantity;			//��������
		double			Quantity1;			//ʵ������
		double			Balance;			//�̿���
		BOOL			IsCheckout;			//�Ƿ����
		OLECHAR			CheckoutMan[20];	//�����
		OLECHAR			Memo[MAX_PATH];		//��ע

		BOOL			IsIncrement;		//��������

		GUID			CheckDeptID;		//�̵㲿�ű���
		GUID			CheckWH;			//�̵�ֿ����
		GUID			CheckMan;			//�̵���Ա����
		GUID			CheckoutManID;		//�����

		CComVariant		CreateDate;			//��������
		CComVariant		ModifyDate;			//�޸�����
		CComVariant		CheckOutDate;		//�������

		GUID			CreatedUser;		//�����û�
		GUID			ModifierUser;		//�޸��û�

		DataState		State;				//����״̬
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CCheckFlow& cfInfo);
		friend STDInStream& operator >> (STDInStream& is, CCheckFlow& cfInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CCheckFlow& cfInfo);
	STDInStream& operator >> (STDInStream& is, CCheckFlow& cfInfo);

	class AFX_EXT_CLASS CCheckFlowVector : public CFlybyData
	{
	public:
		CCheckFlowVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewCheckFlow");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CCheckFlow().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CCheckFlow().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CCheckFlow>(new CCheckFlow()).release(); }
	};

	//�̵�ҵ����
	class AFX_EXT_CLASS CCheckFlowDetails : public CFlybyItem
	{
	public:
		CCheckFlowDetails();
		CCheckFlowDetails(const CCheckFlowDetails&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 10; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return CheckDatailsID; }

	public:
		BEGIN_COLUMN_MAP(CCheckFlowDetails)
			COLUMN_ENTRY(1, CheckDatailsID)
			COLUMN_ENTRY(2, ProductName)
			COLUMN_ENTRY(3, ProductType)
			COLUMN_ENTRY(4, SpecName)
			COLUMN_ENTRY(5, Quantity)
			COLUMN_ENTRY(6, Quantity1)
			COLUMN_ENTRY(7, Balance)
			COLUMN_ENTRY(8, ProductUnit)
			COLUMN_ENTRY(9, ProdID)
			COLUMN_ENTRY(10, CheckID)
		END_COLUMN_MAP()

	private:
		GUID		CheckDatailsID;
		OLECHAR		ProductName[60];	//��Ʒ����
		OLECHAR		ProductType[40];	//��Ʒ���
		OLECHAR		SpecName[40];		//��Ʒ���
		double		Quantity;			//�������
		double		Quantity1;			//�̵�����
		double		Balance;			//�̿�����
		OLECHAR		ProductUnit[40];	//������λ

		GUID ProdID;
		GUID CheckID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CCheckFlowDetails& cfdInfo);
		friend STDInStream& operator >> (STDInStream& is, CCheckFlowDetails& cfdInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CCheckFlowDetails& cfdInfo);
	STDInStream& operator >> (STDInStream& is, CCheckFlowDetails& cfdInfo);

	class AFX_EXT_CLASS CCheckFlowDetailsVector : public CFlybyData
	{
	public:
		CCheckFlowDetailsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewCheckDetails");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CCheckFlowDetails().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CCheckFlowDetails().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CCheckFlowDetails>(new CCheckFlowDetails()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA