#pragma once
namespace Database
{
	class AFX_EXT_CLASS CCardInfo : public CFlybyItem
	{
	public:
		CCardInfo();
		CCardInfo(const CCardInfo& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 14; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return CardID; }


	public:
		BEGIN_COLUMN_MAP(CCardInfo)
			COLUMN_ENTRY(1, CardID)
			COLUMN_ENTRY(2, CardNumber)
			COLUMN_ENTRY(3, CardName)
			COLUMN_ENTRY(4, CustName)
			COLUMN_ENTRY(5, CTName)
			COLUMN_ENTRY(6, IsUsing)
			COLUMN_ENTRY(7, AutoGrowPeriod)
			COLUMN_ENTRY(8, AutoGrowScore)
			COLUMN_ENTRY(9, CardMemo)
			COLUMN_ENTRY(10, CreateDate)
			COLUMN_ENTRY(11, ModifyDate)
			COLUMN_ENTRY(12, CreatedUser)
			COLUMN_ENTRY(13, CTID)
			COLUMN_ENTRY(14, custID)
		END_COLUMN_MAP()

	private:
		GUID CardID;
		OLECHAR CardNumber[60];
		OLECHAR CardName[100];
		OLECHAR CustName[120];
		OLECHAR CTName[50];

		BOOL IsUsing;
		double AutoGrowPeriod;
		double AutoGrowScore;
		OLECHAR CardMemo[255];

		CComVariant CreateDate;
		CComVariant ModifyDate;

		GUID CreatedUser;

		GUID CTID;
		GUID custID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CCardInfo& agenInfo);
		friend STDInStream& operator >>(STDInStream& is, CCardInfo& agenInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CCardInfo& agenInfo);
	STDInStream& operator >>(STDInStream& is, CCardInfo& agenInfo);

	class AFX_EXT_CLASS CCardInfoVector : public CFlybyData
	{
	public:
		CCardInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewCardInfo");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CCardInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CCardInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CCardInfo>(new CCardInfo()).release(); }
	};
}

#undef AFX_DATA
#define AFX_DATA
