#include "StdAfx.h"
#include "FlybyData.h"
#include "StaffInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CStaffInfo::CStaffInfo()
{
	CoCreateGuid(&EID);
	ocscpy_s(UID, _countof(UID), OLESTR(""));
	ocscpy_s(EName, _countof(EName), OLESTR(""));
	ocscpy_s(EPassword, _countof(EPassword), OLESTR(""));
	ocscpy_s(deptName, _countof(deptName), OLESTR(""));
	ocscpy_s(ESex, _countof(ESex), OLESTR("����"));
	ocscpy_s(ETitle, _countof(ETitle), OLESTR(""));
	ocscpy_s(EDuty, _countof(EDuty), OLESTR(""));
	ESalary = { 0 };
	ocscpy_s(EDegree, _countof(EDegree), OLESTR(""));

	COleDateTime timeTemp;
	timeTemp.SetDate(1970, 1, 1);
	EBirthday.vt = VT_DATE;
	EBirthday.date = timeTemp.m_dt;

	ocscpy_s(EPID, _countof(EPID), OLESTR(""));
	ocscpy_s(EEmail, _countof(EEmail), OLESTR(""));
	ocscpy_s(EPhoneNum, _countof(EPhoneNum), OLESTR(""));
	ocscpy_s(EPostCode, _countof(EPostCode), OLESTR(""));
	ocscpy_s(EAddress, _countof(EAddress), OLESTR(""));
	ocscpy_s(EMemo, _countof(EMemo), OLESTR(""));
	ocscpy_s(JM, _countof(JM), OLESTR(""));

	EIsOperator = TRUE;
	EIsAdjusting = FALSE;
	EIsRollBack = FALSE;
	EIsPurchase = FALSE;
	EIsSales = FALSE;
	EIsStoreIn = FALSE;
	EIsStoreOut = FALSE;
	EIsUsing = FALSE;

	timeTemp = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeTemp.m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeTemp.m_dt;

	ETitleID = GUID_NULL;
	EDutyID = GUID_NULL;
	EDegreeID = GUID_NULL;
	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	deptID = GUID_NULL;

	State = Initial;
}

CStaffInfo::CStaffInfo(const CStaffInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CStaffInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CStaffInfo(*this);
	}
}

CString CStaffInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 0:
		idRet = EID;
		break;
	case 1:
		strRet.Format(_T("%s"), EName);
		break;
	case 2:
		strRet.Format(_T("%s"), deptName);
		break;
	case 3:
		strRet.Format(_T("%s"), ESex);
		break;
	case 4:
		strRet.Format(_T("%s"), ETitle);
		break;
	case 5:
		strRet.Format(_T("%s"), EDuty);
		break;
	case 6:
		strRet.Format(_T("%.6f"), ESalary);
		break;
	case 7:
		strRet.Format(_T("%s"), EDegree);
		break;
	case 8:
		strRet = __super::FormatDate(EBirthday);
		break;
	case 9:
		strRet.Format(_T("%s"), EPID);
		break;
	case 10:
		strRet.Format(_T("%s"), EEmail);
		break;
	case 11:
		strRet.Format(_T("%s"), EPhoneNum);
		break;
	case 12:
		strRet.Format(_T("%s"), EPostCode);
		break;
	case 13:
		strRet.Format(_T("%s"), EAddress);
		break;
	case 14:
		strRet.Format(_T("%s"), EMemo);
		break;
	case 15:
		strRet.Format(_T("%s"), JM);
		break;
	case 16:
		strRet.Format(_T("%s"), UID);
		break;
	case 17:
		strRet.Format(_T("%s"), EPassword); //���⴦��
		break;
	case 18:
		strRet.Format(_T("%s"), EIsOperator ? _T("����") : _T("������"));
		break;
	case 19:
		strRet.Format(_T("%s"), EIsAdjusting ? _T("����") : _T("������"));
		break;
	case 20:
		strRet.Format(_T("%s"), EIsRollBack ? _T("����") : _T("������"));
		break;
	case 21:
		strRet.Format(_T("%s"), EIsPurchase ? _T("����") : _T("������"));
		break;
	case 22:
		strRet.Format(_T("%s"), EIsSales ? _T("����") : _T("������"));
		break;
	case 23:
		strRet.Format(_T("%s"), EIsStoreIn ? _T("����") : _T("������"));
		break;
	case 24:
		strRet.Format(_T("%s"), EIsStoreOut ? _T("����") : _T("������"));
		break;
	case 25:
		strRet.Format(_T("%s"), EIsUsing ? _T("����") : _T("ͣ��"));
		break;
	case 26:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 27:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 28:
		idRet = ETitleID;
		break;
	case 29:
		idRet = EDutyID;
		break;
	case 30:
		idRet = EDegreeID;
		break;
	case 31:
		idRet = CreatedUser;
		break;
	case 32:
		idRet = ModifierUser;
		break;
	case 33:
		idRet = deptID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CStaffInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("Ա������"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("Ա������"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("Ա���Ա�"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("Ա��ְ��"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("Ա��ְ��"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("Ӷ�����"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�Ļ��̶�"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("����֤��"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("���ʵ�ַ"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("�绰����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("ͨ�ŵ�ַ"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("��¼��"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("��¼����"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("ҵ�����"));
		break;
	case 19:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 20:
		strRet.Format(_T("%s"), _T("�̵�ҵ��"));
		break;
	case 21:
		strRet.Format(_T("%s"), _T("�ɹ�ҵ��"));
		break;
	case 22:
		strRet.Format(_T("%s"), _T("����ҵ��"));
		break;
	case 23:
		strRet.Format(_T("%s"), _T("���ҵ��"));
		break;
	case 24:
		strRet.Format(_T("%s"), _T("����ҵ��"));
		break;
	case 25:
		strRet.Format(_T("%s"), _T("ʹ��״̬"));
		break;
	case 26:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 27:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 28:
		strRet.Format(_T("%s"), _T("ְ�Ʊ���"));
		break;
	case 29:
		strRet.Format(_T("%s"), _T("ְ�����"));
		break;
	case 30:
		strRet.Format(_T("%s"), _T("ѧ������"));
		break;
	case 31:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 32:
		strRet.Format(_T("%s"), _T("�޸���"));
		break;
	case 33:
		strRet.Format(_T("%s"), _T("���ű���"));
		break;
	}
	return strRet;
}

BOOL CStaffInfo::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	CString strTemp(strText);
	GUID idTemp = GUID_NULL;
	COleDateTime dateTemp;
	BOOL bTemp;
	double dblTemp = { 0 };

	if (nCol == 0 || (nCol >= 28 && nCol < 34))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		HRESULT hr = IIDFromString(strID, &idTemp);
		bRet = SUCCEEDED(hr);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 8 || nCol == 26 || nCol == 27)
	{
		bRet = dateTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol >= 18 && nCol < 26)
	{
		if (nCol == 25)
		{
			bTemp = (strTemp.CompareNoCase(_T("����")) == 0 || strTemp.Compare(_T("1")) == 0);
		}
		else
		{
			bTemp = (strTemp.CompareNoCase(_T("����")) == 0 || strTemp.Compare(_T("1")) == 0);
		}
	}
	else if (nCol == 6)
	{
		TCHAR *tcsStop = nullptr;
		dblTemp = _tcstod(strTemp, &tcsStop);
	}

	switch (nCol)
	{
	case 0:
		EID = idTemp;
		break;
	case 1:
		_tcscpy_s(EName, _countof(EName), Truncate(strTemp, _countof(EName) + 1));
		break;
	case 2:
		_tcscpy_s(deptName, _countof(deptName), Truncate(strTemp, _countof(deptName) + 1));
		break;
	case 3:
		if (strTemp.Find(_T("��")) != -1)
		{
			_tcscpy_s(ESex, _countof(ESex), _T("��"));
		}
		else
		{
			_tcscpy_s(ESex, _countof(ESex), _T("Ů"));
		}
		break;
	case 4:
		_tcscpy_s(ETitle, _countof(ETitle), Truncate(strTemp, _countof(ETitle) + 1));
		break;
	case 5:
		_tcscpy_s(EDuty, _countof(EDuty), Truncate(strTemp, _countof(EDuty) + 1));
		break;
	case 6:
		ESalary = dblTemp;
		break;
	case 7:
		_tcscpy_s(EDegree, _countof(EDegree), Truncate(strTemp, _countof(EDegree) + 1));
		break;
	case 8:
		EBirthday.date = dateTemp;
		break;
	case 9:
		_tcscpy_s(EPID, _countof(EPID), Truncate(strTemp, _countof(EPID) + 1));
		break;
	case 10:
		_tcscpy_s(EEmail, _countof(EEmail), Truncate(strTemp, _countof(EEmail) + 1));
		break;
	case 11:
		_tcscpy_s(EPhoneNum, _countof(EPhoneNum), Truncate(strTemp, _countof(EPhoneNum) + 1));
		break;
	case 12:
		_tcscpy_s(EPostCode, _countof(EPostCode), Truncate(strTemp, _countof(EPostCode) + 1));
		break;
	case 13:
		_tcscpy_s(EAddress, _countof(EAddress), Truncate(strTemp, _countof(EAddress) + 1));
		break;
	case 14:
		_tcscpy_s(EMemo, _countof(EMemo), Truncate(strTemp, _countof(EMemo) + 1 ));
		break;
	case 15:
		_tcscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 16:
		_tcscpy_s(UID, _countof(UID), Truncate(strTemp, _countof(UID) + 1));
		break;
	case 17:
		_tcscpy_s(EPassword, _countof(EPassword), Truncate(strTemp, _countof(EPassword)));
		break;
	case 18:
		EIsOperator = bTemp;
		break;
	case 19:
		EIsAdjusting = bTemp;
		break;
	case 20:
		EIsRollBack = bTemp;
		break;
	case 21:
		EIsPurchase = bTemp;
		break;
	case 22:
		EIsSales = bTemp;
		break;
	case 23:
		EIsStoreIn = bTemp;
		break;
	case 24:
		EIsStoreOut = bTemp;
		break;
	case 25:
		EIsUsing = bTemp;
		break;
	case 26:
		CreateDate.date = dateTemp;
		break;
	case 27:
		ModifyDate.date = dateTemp;
		break;
	case 28:
		ETitleID = idTemp;
		break;
	case 29:
		EDutyID = idTemp;
		break;
	case 30:
		EDegreeID = idTemp;
		break;
	case 31:
		CreatedUser = idTemp;
		break;
	case 32:
		ModifierUser = idTemp;
		break;
	case 33:
		deptID = idTemp;
		break;
	}

	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CStaffInfo& staffInfo)
{
	UINT ui = 0;
	for (; ui != staffInfo.GetColCount() - 1; ui++)
	{
		os << staffInfo.GetCellText(ui) << _T("��");
	}
	os << staffInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CStaffInfo& staffInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			staffInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}