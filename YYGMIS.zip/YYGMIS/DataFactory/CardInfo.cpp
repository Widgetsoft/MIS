#include "stdafx.h"
#include "FlybyData.h"
#include "CardInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace Database;

CCardInfo::CCardInfo(void)
{
	CoCreateGuid(&CardID);
	ocscpy_s(CardNumber, _countof(CardNumber), OLESTR(""));
	ocscpy_s(CardName, _countof(CardName), OLESTR(""));
	ocscpy_s(CustName, _countof(CustName), OLESTR(""));
	ocscpy_s(CTName, _countof(CTName), OLESTR(""));
	IsUsing = TRUE;
	AutoGrowPeriod = { 365.5 };
	AutoGrowScore = { 1000 };

	ocscpy_s(CardMemo, _countof(CardMemo), OLESTR(""));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;


	CTID = GUID_NULL;
	custID = GUID_NULL;

	State = Initial;
}


CCardInfo::CCardInfo(const CCardInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CCardInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CCardInfo(*this);
	}
}

CString CCardInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), CardNumber);
		break;
	case 2:
		strRet.Format(_T("%s"), CardName);
		break;
	case 3:
		strRet.Format(_T("%s"), CustName);
		break;
	case 4:
		strRet.Format(_T("%s"), CTName);
		break;
	case 5:
		strRet.Format(_T("%s"), IsUsing ? _T("����ʹ��") : _T("������"));
		break;
	case 6:
		strRet.Format(_T("%.3f"), AutoGrowPeriod);
		break;
	case 7:
		strRet.Format(_T("%.3f"), AutoGrowScore);
		break;
	case 8:
		strRet.Format(_T("%s"), CardMemo);
		break;
	case 9:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 10:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = CardID;
		break;
	case 11:
		idRet = CreatedUser;
		break;
	case 12:
		idRet = CTID;
		break;
	case 13:
		idRet = custID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CCardInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("�ͻ�"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�ȼ�"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("״̬"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("�ȼ�����"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("�ͻ�����"));
		break;
	}

	return strRet;
}

BOOL CCardInfo::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	double dblVal = { 0 };
	if (nCol == 0 || (nCol > 10 && nCol < 14))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 5)
	{
		bTemp = (strTemp.CompareNoCase(_T("����ʹ��")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 9 || nCol == 10)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 6 || nCol == 7)
	{
		TCHAR* pstrStop;
		dblVal = _tcstod(strTemp, &pstrStop);
	}
	switch (nCol)
	{
	case 0:
		CardID = idTemp;
		break;
	case 1:
		_tcscpy_s(CardNumber, _countof(CardNumber), Truncate(strTemp, _countof(CardNumber) + 1));
		break;
	case 2:
		_tcscpy_s(CardName, _countof(CardName), Truncate(strTemp, _countof(CardName) + 1));
		break;
	case 3:
		_tcscpy_s(CustName, _countof(CustName), Truncate(strTemp, _countof(CustName) + 1));
		break;
	case 4:
		_tcscpy_s(CTName, _countof(CTName), Truncate(strTemp, _countof(CTName) + 1));
		break;
	case 5:
		IsUsing = bTemp;
		break;
	case 6:
		AutoGrowPeriod = dblVal;
		break;
	case 7:
		AutoGrowScore = dblVal;
		break;
	case 8:
		_tcscpy_s(CardMemo, _countof(CardMemo), Truncate(strTemp, _countof(CardMemo) + 1));
		break;
	case 9:
		CreateDate.date = dtTemp;
		break;
	case 10:
		ModifyDate.date = dtTemp;
		break;
	case 11:
		CreatedUser = idTemp;
		break;
	case 12:
		CTID = idTemp;
		break;
	case 13:
		custID = idTemp;
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CCardInfo& agenInfo)
{
	UINT ui = 0;
	for (; ui != agenInfo.GetColCount() - 1; ui++)
	{
		os << agenInfo.GetCellText(ui) << _T("��");
	}
	os << agenInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CCardInfo& agenInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			agenInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
