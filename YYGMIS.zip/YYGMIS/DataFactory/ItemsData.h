#pragma once
namespace GenerialPattern
{
	class AFX_EXT_CLASS CItemData
	{
	public:
		void AddRange(LPCTSTR lpcszItemText, ...);
		static STDString ParallelFind(Concurrency::concurrent_vector<STDString>& vectData, const STDString& strKey,
			BOOL bPrecise = FALSE, BOOL bRetDefaultValue = TRUE);
	public:
		Concurrency::concurrent_vector<STDString>::iterator push_back(const STDString& _Item) { return m_vector.push_back(_Item); }
		STDString& operator[](UINT _Index);
		const STDString& operator[](UINT _Index) const;
		STDString& at(UINT _Index);
		const STDString& at(UINT _Index) const;
		size_t size() const;
		bool empty() const { return m_vector.empty(); }
		void clear() { m_vector.clear(); }
		Concurrency::concurrent_vector<STDString>::iterator begin() { return m_vector.begin(); }
		Concurrency::concurrent_vector<STDString>::iterator end() { return m_vector.end(); }
		Concurrency::concurrent_vector<STDString>::const_iterator begin() const { return m_vector.begin(); }
		Concurrency::concurrent_vector<STDString>::const_iterator end() const { return m_vector.end(); }
		Concurrency::concurrent_vector<STDString>::reverse_iterator rbegin() { return m_vector.rbegin(); }
		Concurrency::concurrent_vector<STDString>::reverse_iterator rend() { return m_vector.rend(); }
		Concurrency::concurrent_vector<STDString>::const_reverse_iterator rbegin() const { return m_vector.rbegin(); }
		Concurrency::concurrent_vector<STDString>::const_reverse_iterator rend() const { return m_vector.rend(); }
		Concurrency::concurrent_vector<STDString>::const_iterator cbegin() const { return m_vector.cbegin(); }
		Concurrency::concurrent_vector<STDString>::const_iterator cend() const { return m_vector.cend(); }
		Concurrency::concurrent_vector<STDString>::const_reverse_iterator crbegin() const { return m_vector.crbegin(); }
		Concurrency::concurrent_vector<STDString>::const_reverse_iterator crend() const { return m_vector.crend(); }

	private:
		Concurrency::concurrent_vector<STDString> m_vector;
	};

	typedef Concurrency::concurrent_unordered_map<UINT, CItemData*> CItemDataMap;

	// CItemsData ����Ŀ��

	class AFX_EXT_CLASS CItemsData : public CObject
	{
	public:
		CItemsData(void);
		virtual ~CItemsData(void);

	public:
		void ClearItemDatas();
		inline BOOL IsExistIndex(const int nRow) const { return m_mapItems.find(nRow) != m_mapItems.end(); }; //�Ƿ��������
		BOOL AddItemData(const int nRow, CItemData* pData);
		CItemData* GetItemData(const int nRow) const;
		int FindItem(LPCTSTR lpszKey, BOOL bPrecise = FALSE);
		const CItemData* FindItem1(LPCTSTR lpszKey);

	public:
		inline size_t GetSize() const { return m_mapItems.size(); }
		inline CItemDataMap::iterator begin() { return m_mapItems.begin(); }
		inline CItemDataMap::iterator end() { return m_mapItems.end(); }

	public:
		static std::pair<STDString, STDString> GetMatchItem(CItemsData& itemData, int lParam, PTSTR ptStrKey, UINT uiCaptionCol = 1);

	private:
		CItemDataMap m_mapItems;
	};
}


#undef AFX_DATA
#define AFX_DATA
