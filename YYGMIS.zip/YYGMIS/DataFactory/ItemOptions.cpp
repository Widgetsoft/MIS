#include "StdAfx.h"
#include "FlybyData.h"
#include "ItemOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CItemOptions::CItemOptions()
{
	CoCreateGuid(&OptionID);
	ocscpy_s(OptionCategory, _countof(OptionCategory), OLESTR(""));
	ocscpy_s(OptionName, _countof(OptionName), OLESTR(""));
	ocscpy_s(OptionDescription, _countof(OptionDescription), OLESTR(""));
	ocscpy_s(OptionMemo, _countof(OptionMemo), OLESTR(""));
	ocscpy_s(OptionJM, _countof(OptionJM), OLESTR(""));
	State = Initial;
}

CItemOptions::CItemOptions(const CItemOptions& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CItemOptions::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CItemOptions(*this);
	}
}

CString CItemOptions::GetCellText(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet = __super::FormatGUID(OptionID);
		break;
	case 1:
		strRet.Format(_T("%s"), OptionCategory);
		break;
	case 2:
		strRet.Format(_T("%s"), OptionName);
		break;
	case 3:
		strRet.Format(_T("%s"), OptionDescription);
		break;
	case 4:
		strRet.Format(_T("%s"), OptionMemo);
		break;
	case 5:
		strRet.Format(_T("%s"), OptionJM);
		break;
	}
	return strRet;
}

CString CItemOptions::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("ѡ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("ѡ���"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("ѡ������"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("ѡ������"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("ѡ�ע"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("ѡ�����"));
		break;
	}
	return strRet;
}

BOOL CItemOptions::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	CString strTemp(strText);
	switch (nCol)
	{
	case 0:
		{
			LPOLESTR strID = strTemp.AllocSysString();
			if (FAILED(IIDFromString(strID, &OptionID)))
			{
				bRet = FALSE;
			}
		}
		break;
	case 1:
		ocscpy_s(OptionCategory, _countof(OptionCategory), Truncate(strTemp, _countof(OptionCategory) + 1));
		break;
	case 2:
		ocscpy_s(OptionName, _countof(OptionName), Truncate(strTemp, _countof(OptionName) + 1));
		break;
	case 3:
		ocscpy_s(OptionDescription, _countof(OptionDescription), Truncate(strTemp, _countof(OptionDescription) + 1));
		break;
	case 4:
		ocscpy_s(OptionMemo, _countof(OptionMemo), Truncate(strTemp, _countof(OptionMemo) + 1));
		break;
	case 5:
		ocscpy_s(OptionJM, _countof(OptionJM), Truncate(strTemp, _countof(OptionJM) + 1));
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CItemOptions& itemInfo)
{
	UINT ui = 0;
	for (; ui != itemInfo.GetColCount() - 1; ui++)
	{
		os << itemInfo.GetCellText(ui) << _T("��");
	}
	os << itemInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CItemOptions& itemInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			itemInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}