#include "StdAfx.h"
#include "FlybyData.h"
#include "ServiceFlow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace Database;

#pragma region ����
CServiceFlow::CServiceFlow()
{
	CoCreateGuid(&SvcID);
	ocscpy_s(SvcCustomID, _countof(SvcCustomID), OLESTR(""));
	COleDateTime tempCurrDate = COleDateTime::GetCurrentTime();
	ServiceDate.vt = VT_DATE;
	ServiceDate.date = tempCurrDate.m_dt;

	ocscpy_s(DetpName, _countof(DetpName), OLESTR(""));
	ocscpy_s(BusinessMan, _countof(BusinessMan), OLESTR(""));
	ocscpy_s(CustomerName, _countof(CustomerName), OLESTR(""));
	
	IsCheckOut = FALSE;
	ocscpy_s(CheckoutMan, _countof(CheckoutMan), OLESTR(""));

	Amount = { 0 };

	ocscpy_s(Memo, _countof(Memo), OLESTR(""));


	DetpID = GUID_NULL;
	BusinessManID = GUID_NULL;
	CheckoutManID = GUID_NULL;
	custID = GUID_NULL;

	CreateDate.vt = VT_DATE;
	CreateDate.date = tempCurrDate.m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = tempCurrDate.m_dt;
	CheckOutDate.vt = VT_DATE;
	CheckOutDate.date = tempCurrDate.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;

	State = Initial;
}


CServiceFlow::CServiceFlow(const CServiceFlow& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CServiceFlow::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), SvcCustomID);
		break;
	case 2:
		strRet = __super::FormatDateTime(ServiceDate);
		break;
	case 3:
		strRet.Format(_T("%s"), DetpName);
		break;
	case 4:
		strRet.Format(_T("%s"), BusinessMan);
		break;
	case 5:
		strRet.Format(_T("%s"), CustomerName);
		break;
	case 6:
		strRet.Format(_T("%s"), IsCheckOut ? _T("�����") : _T("δ���"));
		break;
	case 7:
		strRet.Format(_T("%s"), CheckoutMan);
		break;
	case 8:
		strRet.Format(_T("%.2f"), Amount);
		break;
	case 9:
		strRet.Format(_T("%s"), Memo);
		break;
	case 14:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 15:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 16:
		strRet = __super::FormatDateTime(CheckOutDate);
		break;
	case 0:
		idRet = SvcID;
		break;
	case 10:
		idRet = DetpID;
		break;
	case 11:
		idRet = BusinessManID;
		break;
	case 12:
		idRet = CheckoutManID;
		break;
	case 13:
		idRet = custID;
		break;
	case 17:
		idRet = CreatedUser;
		break;
	case 18:
		idRet = ModifierUser;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CServiceFlow::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("���ݱ���"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("ҵ��Ա"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�ͻ�����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�Ƿ����"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�ϼƽ��"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("���ű���"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("ҵ��Ա����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("����˱���"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("�ͻ�����"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("�����˱���"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�޸��˱���"));
		break;
	}

	return strRet;
}

BOOL CServiceFlow::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 10 && nCol <= 13)
		|| (nCol >= 17 && nCol <= 18))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 6)
	{
		bTemp = (strTemp.CompareNoCase(_T("�����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 2 || (nCol >= 14|| nCol == 16))
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 8)
	{
		TCHAR* tcsStop = nullptr;
		dblTemp = _tcstod(strTemp, &tcsStop);
	}

	switch (nCol)
	{
	case 0:
		SvcID = idTemp;
		break;
	case 1:
		_tcscpy_s(SvcCustomID, _countof(SvcCustomID), Truncate(strTemp, _countof(SvcCustomID) + 1));
		break;
	case 2:
		ServiceDate.date = dtTemp;
		break;
	case 3:
		_tcscpy_s(DetpName, _countof(DetpName), Truncate(strTemp, _countof(DetpName) + 1));
		break;
	case 4:
		_tcscpy_s(BusinessMan, _countof(BusinessMan), Truncate(strTemp, _countof(BusinessMan) + 1));
		break;
	case 5:
		_tcscpy_s(CustomerName, _countof(CustomerName), Truncate(strTemp, _countof(CustomerName) + 1));
		break;
	case 6:
		IsCheckOut = bTemp;
		break;
	case 7:
		_tcscpy_s(CheckoutMan, _countof(CheckoutMan), Truncate(strTemp, _countof(CheckoutMan) + 1));
		break;
	case 8:
		Amount = dblTemp;
		break;
	case 9:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 10:
		DetpID = idTemp;
		break;
	case 11:
		BusinessManID = idTemp;
		break;
	case 12:
		CheckoutManID = idTemp;
		break;
	case 13:
		custID = idTemp;
		break;
	case 14:
		CreateDate.date = dtTemp;
		break;
	case 15:
		ModifyDate.date = dtTemp;
		break;
	case 16:
		CheckOutDate.date = dtTemp;
		break;
	case 17:
		CreatedUser = idTemp;
		break;
	case 18:
		ModifierUser = idTemp;
		break;
	}
	return bRet;
}

void CServiceFlow::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CServiceFlow(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CServiceFlow& sfInfo)
{
	UINT ui = 0;
	for (; ui != sfInfo.GetColCount() - 1; ui++)
	{
		os << sfInfo.GetCellText(ui) << _T("��");
	}
	os << sfInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CServiceFlow& sfInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			sfInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

#pragma endregion

#pragma region �����굥 
CServiceFlowDetails::CServiceFlowDetails()
{
	CoCreateGuid(&SvcDetailsID);

	ocscpy_s(ServName, _countof(ServName), OLESTR(""));
	ocscpy_s(ServType, _countof(ServType), OLESTR(""));
	ocscpy_s(ServSpec, _countof(ServSpec), OLESTR(""));
	Price = { 0 };
	Quantity = { 0 };

	COleDateTime tempCurrDate = COleDateTime::GetCurrentTime();
	StartTime.vt = VT_DATE;
	StartTime.date = tempCurrDate.m_dt;

	EndTime.vt = VT_DATE;
	EndTime.date = tempCurrDate.m_dt;

	ocscpy_s(ServUnit, _countof(ServUnit), OLESTR(""));
	Discount = { 0 };
	Amount = { 0 };
	FinalAmount = { 0 };
	Score = { 0 };
	Commission = { 0 };
	IsTimeCount = TRUE;
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	Unit1ToUnit2Rate = { 1 };

	ServiceID = GUID_NULL;
	SvcID = GUID_NULL;

	State = Initial;
}

CServiceFlowDetails::CServiceFlowDetails(const CServiceFlowDetails& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CServiceFlowDetails::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), ServName);
		break;
	case 2:
		strRet.Format(_T("%s"), ServType);
		break;
	case 3:
		strRet.Format(_T("%s"), ServSpec);
		break;
	case 4:
		strRet.Format(_T("%.2f"), Price);
		break;
	case 5:
		strRet.Format(_T("%.2f"), Quantity);
		break;
	case 6:
		strRet = __super::FormatDateTime(StartTime);
		break;
	case 7:
		strRet = __super::FormatDateTime(EndTime);
		break;
	case 8:
		strRet.Format(_T("%s"), ServUnit);
		break;
	case 9:
		strRet.Format(_T("%.2f"), Discount);
		break;
	case 10:
		strRet.Format(_T("%.2f"), Amount);
		break;
	case 11:
		strRet.Format(_T("%.2f"), FinalAmount);
		break;
	case 12:
		strRet.Format(_T("%.2f"), Score);
		break;
	case 13:
		strRet.Format(_T("%.2f"), Commission);
		break;
	case 14:
		strRet.Format(_T("%s"), IsTimeCount ? _T("��ʱ") : _T("�Ƽ�"));
		break;
	case 15:
		strRet.Format(_T("%s"), Memo);
		break;
	case 16:
		strRet.Format(_T("%.6f"), Unit1ToUnit2Rate);
		break;
	case 0:
		idRet = SvcDetailsID;
		break;
	case 17:
		idRet = ServiceID;
		break;
	case 18:
		idRet = SvcID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CServiceFlowDetails::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�굥����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�ײ�����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�ײ����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("�ײ�����"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��ʼʱ��"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("����ʱ��"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�շѵ�λ"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�����Ż�"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("���"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("ʵ�����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("ҵ��Ա���"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("�Ʒѷ�ʽ"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("��λת��ϵ��"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("�ײͱ���"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�ܵ�����"));
		break;
	}
	return strRet;
}

BOOL CServiceFlowDetails::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	COleDateTime dtTemp;
	double dblTemp = { 0 };
	BOOL bTemp = TRUE;

	if (nCol == 0 || (nCol >= 17 && nCol <= 18))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 6 || nCol == 7)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 4 || nCol == 5 ||( nCol >= 9 && nCol <= 13) || nCol == 16)
	{
		TCHAR *tcsStopToken;
		dblTemp = _tcstod(strTemp, &tcsStopToken);
	}
	else if (nCol == 14)
	{
		bTemp = strTemp.Compare(_T("��ʱ")) == 0 || strTemp.Compare(_T("1"));
	}

	switch (nCol)
	{
	case 0:
		SvcDetailsID = idTemp;
		break;
	case 1:
		ocscpy_s(ServName, _countof(ServName), Truncate(strTemp, _countof(ServName) + 1));
		break;
	case 2:
		ocscpy_s(ServType, _countof(ServType), Truncate(strTemp, _countof(ServType) + 1));
		break;
	case 3:
		ocscpy_s(ServSpec, _countof(ServSpec), Truncate(strTemp, _countof(ServSpec) + 1));
		break;
	case 4:
		Price = dblTemp;
		break;
	case 5:
		Quantity = dblTemp;
		break;
	case 6:
		StartTime.date = dtTemp.m_dt;
		break;
	case 7:
		EndTime.date = dtTemp.m_dt;
		break;
	case 8:
		ocscpy_s(ServUnit, _countof(ServUnit), Truncate(strTemp, _countof(ServUnit) + 1));
		break;
	case 9:
		Discount = dblTemp;
		break;
	case 10:
		Amount = dblTemp;
		break;
	case 11:
		FinalAmount = dblTemp;
		break;
	case 12:
		Score = dblTemp;
		break;
	case 13:
		Commission = dblTemp;
		break;
	case 14:
		IsTimeCount = bTemp;
		break;
	case 15:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 16:
		Unit1ToUnit2Rate = dblTemp;
		break;
	case 17:
		ServiceID = idTemp;
		break;
	case 18:
		SvcID = idTemp;
		break;
	}
	return bRet;
}

void CServiceFlowDetails::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CServiceFlowDetails(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CServiceFlowDetails& sfdFlow)
{
	UINT ui = 0;
	for (; ui != sfdFlow.GetColCount() - 1; ui++)
	{
		os << sfdFlow.GetCellText(ui) << _T("��");
	}
	os << sfdFlow.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CServiceFlowDetails& sfdFlow)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			sfdFlow.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
#pragma endregion