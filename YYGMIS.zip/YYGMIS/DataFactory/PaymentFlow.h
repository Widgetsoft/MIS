#pragma once
namespace Database
{
	//�ո�����Ϣ
	class AFX_EXT_CLASS CPaymentFlow : public CFlybyItem
	{
	public:
		CPaymentFlow();
		CPaymentFlow(const CPaymentFlow&);
	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 25; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return PayID; }

	public:
		BEGIN_COLUMN_MAP(CPaymentFlow)
			COLUMN_ENTRY(1, PayID)
			COLUMN_ENTRY(2, PayCustomID)
			COLUMN_ENTRY(3, PayDate)
			COLUMN_ENTRY(4, DeptName)
			COLUMN_ENTRY(5, ObjectName)
			COLUMN_ENTRY(6, PaymentState)
			COLUMN_ENTRY(7, ExecuteMan)
			COLUMN_ENTRY(8, Discount)
			COLUMN_ENTRY(9, Payable)
			COLUMN_ENTRY(10, Payed)
			COLUMN_ENTRY(11, Balance)
			COLUMN_ENTRY(12, IsCheckOut)
			COLUMN_ENTRY(13, CheckoutMan)
			COLUMN_ENTRY(14, PaymentType)
			COLUMN_ENTRY(15, ObjectType)
			COLUMN_ENTRY(16, CreateDate)
			COLUMN_ENTRY(17, ModifyDate)
			COLUMN_ENTRY(18, CheckOutDate)
			COLUMN_ENTRY(19, CreatedUser)
			COLUMN_ENTRY(20, ModifierUser)
			COLUMN_ENTRY(21, ExecuteManID)
			COLUMN_ENTRY(22, CheckoutManID)
			COLUMN_ENTRY(23, objectID)
			COLUMN_ENTRY(24, deptID)
			COLUMN_ENTRY(25, sourceID)
		END_COLUMN_MAP()

	private:
		GUID		PayID;
		OLECHAR		PayCustomID[17];
		CComVariant PayDate;
		OLECHAR		DeptName[60];			//�ո����
		OLECHAR		ObjectName[100];		//�ո������
		OLECHAR		PaymentState[10];		//�����Ѹ����գ���ȫ�����գ���δ�����գ�
		OLECHAR		ExecuteMan[20];			//ִ����
		double		Discount;				//�ۿ�

		double		Payable;				//Ӧ�ո���
		double		Payed;					//ʵ�ո���
		double		Balance;				//���

		BOOL		IsCheckOut;				//�Ƿ����
		OLECHAR		CheckoutMan[20];		//�����

		OLECHAR		PaymentType[4];			//�������ͣ�Ӧ�տӦ���
		OLECHAR		ObjectType[10];			//�����������

		CComVariant CreateDate;				//��������
		CComVariant ModifyDate;				//�޸�����
		CComVariant CheckOutDate;			//�������
		GUID		CreatedUser;			//�����û�
		GUID		ModifierUser;			//�޸��û�

		GUID ExecuteManID;					//ִ���˱���
		GUID CheckoutManID;					//����˱���
		GUID objectID;						//Ӧ�ա��������
		GUID deptID;						//�ո����
		GUID sourceID;						//��Դ����

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CPaymentFlow& pfInfo);
		friend STDInStream& operator >> (STDInStream& is, CPaymentFlow& pfInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CPaymentFlow& pfInfo);
	STDInStream& operator >> (STDInStream& is, CPaymentFlow& pfInfo);

	class AFX_EXT_CLASS CPaymentFlowVector : public CFlybyData
	{
	public:
		CPaymentFlowVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewPaymentFlow");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CPaymentFlow().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CPaymentFlow().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CPaymentFlow>(new CPaymentFlow()).release(); }
	};

	class AFX_EXT_CLASS CPaymentFlowDetails : public CFlybyItem
	{
	public:
		CPaymentFlowDetails();
		CPaymentFlowDetails(const CPaymentFlowDetails&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 7; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return PayDetailsID; }

	public:
		BEGIN_COLUMN_MAP(CPaymentFlowDetails)
			COLUMN_ENTRY(1, PayDetailsID)
			COLUMN_ENTRY(2, PayCatalog)
			COLUMN_ENTRY(3, Payed)
			COLUMN_ENTRY(4, PayMethodName)
			COLUMN_ENTRY(5, IsCredit)
			COLUMN_ENTRY(6, PayMethodID)
			COLUMN_ENTRY(7, PayID)
		END_COLUMN_MAP()
	private:
		GUID		PayDetailsID;			//�굥����
		OLECHAR		PayCatalog[40];			//ժҪ
		double		Payed;					//���
		OLECHAR		PayMethodName[50];		//���㷽ʽ
		BOOL		IsCredit;				//ˢ��
		GUID		PayMethodID;			//���㷽ʽ����
		GUID		PayID;					//��������

		DataState State;

	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CPaymentFlowDetails& pfdInfo);
		friend STDInStream& operator >> (STDInStream& is, CPaymentFlowDetails& pfdInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CPaymentFlowDetails& pfdInfo);
	STDInStream& operator >> (STDInStream& is, CPaymentFlowDetails& pfdInfo);

	class AFX_EXT_CLASS CPaymentFlowDetailsVector : public CFlybyData
	{
	public:
		CPaymentFlowDetailsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewPaymentDetails");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CPaymentFlowDetails().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CPaymentFlowDetails().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CPaymentFlowDetails>(new CPaymentFlowDetails()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA