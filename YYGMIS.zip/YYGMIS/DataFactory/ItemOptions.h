#pragma once

namespace Database
{
	class AFX_EXT_CLASS CItemOptions : public CFlybyItem
	{
	public:
		CItemOptions();
		CItemOptions(const CItemOptions& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 6; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return OptionID; }
	public:
		BEGIN_COLUMN_MAP(CItemOptions)
			COLUMN_ENTRY(1, OptionID)
			COLUMN_ENTRY(2, OptionCategory)
			COLUMN_ENTRY(3, OptionName)
			COLUMN_ENTRY(4, OptionDescription)
			COLUMN_ENTRY(5, OptionMemo)
			COLUMN_ENTRY(6, OptionJM)
		END_COLUMN_MAP()

	private:
		GUID OptionID;
		OLECHAR OptionCategory[20];
		OLECHAR OptionName[50];
		OLECHAR OptionDescription[120];
		OLECHAR OptionMemo[255];
		OLECHAR OptionJM[50];

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CItemOptions& itemInfo);
		friend STDInStream& operator >> (STDInStream& is, CItemOptions& itemInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CItemOptions& itemInfo);
	STDInStream& operator >> (STDInStream& is, CItemOptions& itemInfo);

	class AFX_EXT_CLASS CItemOptionsVector : public CFlybyData
	{
	public:
		CItemOptionsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewOptions");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CItemOptions().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CItemOptions().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CItemOptions>(new CItemOptions()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA

