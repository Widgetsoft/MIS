#include "StdAfx.h"
#include "FlybyData.h"
#include "PaymentFlow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

#pragma region �������
CPaymentFlow::CPaymentFlow()
{
	CoCreateGuid(&PayID);
	ocscpy_s(PayCustomID, _countof(PayCustomID), OLESTR(""));

	COleDateTime timeCurrent = COleDateTime::GetCurrentTime();
	PayDate.vt = VT_DATE;
	PayDate.date = timeCurrent.m_dt;

	ocscpy_s(DeptName, _countof(DeptName), OLESTR(""));
	ocscpy_s(ObjectName, _countof(ObjectName), OLESTR(""));
	ocscpy_s(PaymentState, _countof(PaymentState), OLESTR(""));
	ocscpy_s(ExecuteMan, _countof(ExecuteMan), OLESTR(""));

	Discount = { 0 };
	Payable = { 0 };
	Payed = { 0 };
	Balance = { 0 };

	IsCheckOut = FALSE;
	ocscpy_s(CheckoutMan, _countof(CheckoutMan), OLESTR(""));
	ocscpy_s(PaymentType, _countof(PaymentType), OLESTR("Ӧ�տ�"));
	ocscpy_s(ObjectType, _countof(ObjectType), OLESTR(""));
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeCurrent.m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeCurrent.m_dt;
	CheckOutDate.vt = VT_DATE;
	CheckOutDate.date = timeCurrent.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	CheckoutManID = GUID_NULL;
	objectID = GUID_NULL;
	deptID = GUID_NULL;
	sourceID = GUID_NULL;

	State = Initial;
}


CPaymentFlow::CPaymentFlow(const CPaymentFlow& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CPaymentFlow::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;

	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), PayCustomID);
		break;
	case 2:
		strRet = __super::FormatDateTime(PayDate);
		break;
	case 3:
		strRet.Format(_T("%s"), DeptName);
		break;
	case 4:
		strRet.Format(_T("%s"), ObjectName);
		break;
	case 5:
		strRet.Format(_T("%s"), Balance > 0 ? _T("���") : _T("ȫ��"));
		break;
	case 6:
		strRet.Format(_T("%s"), ExecuteMan);
		break;
	case 7:
		strRet.Format(_T("%.2f"), Discount);
		break;
	case 8:
		strRet.Format(_T("%.2f"), Payable);
		break;
	case 9:
		strRet.Format(_T("%.2f"), Payed);
		break;
	case 10:
		strRet.Format(_T("%.2f"), Balance);
		break;
	case 11:
		strRet.Format(_T("%s"), IsCheckOut ? _T("�����") : _T("δ���"));
		break;
	case 12:
		strRet.Format(_T("%s"), CheckoutMan);
		break;
	case 13:
		strRet.Format(_T("%s"), PaymentType);
		break;
	case 14:
		strRet.Format(_T("%s"), ObjectType);
		break;
	case 15:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 16:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 17:
		strRet = __super::FormatDateTime(CheckOutDate);
		break;
	case 0:
		idRet = PayID;
		break;
	case 18:
		idRet = CreatedUser;
		break;
	case 19:
		idRet = ModifierUser;
		break;
	case 20:
		idRet = ExecuteManID;
		break;
	case 21:
		idRet = CheckoutManID;
		break;
	case 22:
		idRet = objectID;
		break;
	case 23:
		idRet = deptID;
		break;
	case 24:
		idRet = sourceID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CPaymentFlow::GetColumnName(UINT nCol) const
{
	CString strRet;

	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�˵���"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("���ײ���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("���׶���"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�˵�״̬"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�����ۿ�"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("���׶�"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("ʵ����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("���ײ��"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("�Ƿ����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("�Է�����"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�����û�"));
		break;
	case 19:
		strRet.Format(_T("%s"), _T("�޸��û�"));
		break;
	case 20:
		strRet.Format(_T("%s"), _T("�����˱���"));
		break;
	case 21:
		strRet.Format(_T("%s"), _T("����˱���"));
		break;
	case 22:
		strRet.Format(_T("%s"), _T("���׶������"));
		break;
	case 23:
		strRet.Format(_T("%s"), _T("���ű���"));
		break;
	case 24:
		strRet.Format(_T("%s"), _T("��Դ����"));
		break;
	}

	//if (_tcsstr(PaymentType, _T("��")) != nullptr)
	//{
	//	strRet.Replace(_T("��"), _T("��"));
	//}

	return strRet;
}

BOOL CPaymentFlow::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 18 && nCol <= 24))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 11)
	{
		bTemp = (strTemp.CompareNoCase(_T("�����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 2 || (nCol >= 15 && nCol <= 17))
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol >= 7 && nCol <= 10)
	{
		TCHAR* tcsStop;
		dblTemp = _tcstod(strTemp, &tcsStop);
	}

	switch (nCol)
	{
	case 0:
		PayID = idTemp;
		break;
	case 1:
		_tcscpy_s(PayCustomID, _countof(PayCustomID), Truncate(strTemp, _countof(PayCustomID) + 1));
		break;
	case 2:
		PayDate.date = dtTemp;
		break;
	case 3:
		_tcscpy_s(DeptName, _countof(DeptName), Truncate( strTemp, _countof(DeptName) + 1 ) );
		break;
	case 4:
		_tcscpy_s(ObjectName, _countof(ObjectName), Truncate(strTemp, _countof(ObjectName) + 1));
		break;
	case 5:
		_tcscpy_s(PaymentState, _countof(PaymentState), Truncate(strTemp, _countof(PaymentState) + 1));
		break;
	case 6:
		_tcscpy_s(ExecuteMan, _countof(ExecuteMan), Truncate(strTemp, _countof(ExecuteMan) + 1));
		break;
	case 7:
		Discount = dblTemp;
		break;
	case 8:
		Payable = dblTemp;
		Balance = Payable - Payed - Discount;
		break;
	case 9:
		Payed = dblTemp;
		Balance = Payable - Payed - Discount;
		break;
	case 10:
		Balance = dblTemp;
	case 11:
		IsCheckOut = bTemp;
		break;
	case 12:
		_tcscpy_s(CheckoutMan, _countof(CheckoutMan), Truncate(strTemp, _countof(CheckoutMan) + 1));
		break;
	case 13:
		_tcscpy_s(PaymentType, _countof(PaymentType), Truncate(strTemp, _countof(PaymentType) + 1));
		break;
	case 14:
		_tcscpy_s(ObjectType, _countof(ObjectType), Truncate(strTemp, _countof(ObjectType) + 1));
		break;
	case 15:
		CreateDate.date = dtTemp;
		break;
	case 16:
		ModifyDate.date = dtTemp;
		break;
	case 17:
		CheckOutDate.date = dtTemp;
		break;
	case 18:
		CreatedUser = idTemp;
		break;
	case 19:
		ModifierUser = idTemp;
		break;
	case 20:
		ExecuteManID = idTemp;
		break;
	case 21:
		CheckoutManID = idTemp;
		break;
	case 22:
		objectID = idTemp;
		break;
	case 23:
		deptID = idTemp;
		break;
	case 24:
		sourceID = idTemp;
		break;
	}
	return bRet;
}

void CPaymentFlow::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CPaymentFlow(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CPaymentFlow& pfInfo)
{
	UINT ui = 0;
	for (; ui != pfInfo.GetColCount() - 1; ui++)
	{
		os << pfInfo.GetCellText(ui) << _T("��");
	}
	os << pfInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CPaymentFlow& pfInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			pfInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

#pragma endregion

#pragma region ����굥
CPaymentFlowDetails::CPaymentFlowDetails()
{
	CoCreateGuid(&PayDetailsID);
	ocscpy_s(PayCatalog, _countof(PayCatalog), OLESTR(""));
	Payed = { 0 };
	ocscpy_s(PayMethodName, _countof(PayMethodName), OLESTR(""));
	IsCredit = FALSE;
	PayMethodID = GUID_NULL;
	PayID = GUID_NULL;

	State = Initial;
}

CPaymentFlowDetails::CPaymentFlowDetails(const CPaymentFlowDetails& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CPaymentFlowDetails::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), PayCatalog);
		break;
	case 2:
		strRet.Format(_T("%.2f"), Payed);
		break;
	case 3:
		strRet.Format(_T("%s"), PayMethodName);
		break;
	case 4:
		strRet.Format(_T("%s"), IsCredit ? _T("ʹ��") : _T("δʹ��"));
		break;
	case 0:
		idRet = PayDetailsID;
		break;
	case 5:
		idRet = PayMethodID;
		break;
	case 6:
		idRet = PayID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CPaymentFlowDetails::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�굥����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("ժҪ"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("���"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("���㷽ʽ"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("����ȯ"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("���ʽ����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	}
	return strRet;
}

BOOL CPaymentFlowDetails::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	TCHAR* ptsStop;
	double dblTemp = { 0 };
	switch (nCol)
	{
	case 0:
	case 5:
	case 6:
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	break;
	case 2:
		dblTemp = _tcstod(strTemp, &ptsStop);
		break;
	case 4:
		bTemp = (strTemp.Compare(OLESTR("ʹ��")) == 0) || (strTemp.Compare(OLESTR("1")) == 0);
		break;
	}

	switch (nCol)
	{
	case 0:
		PayDetailsID = idTemp;
		break;
	case 1:
		_tcscpy_s(PayCatalog, _countof(PayCatalog), Truncate(strTemp, _countof(PayCatalog) + 1));
		break;
	case 2:
		Payed = dblTemp;
		break;
	case 3:
		_tcscpy_s(PayMethodName, _countof(PayMethodName), Truncate(strTemp, _countof(PayMethodName) + 1));
		break;
	case 4:
		IsCredit = bTemp;
		break;
	case 5:
		PayMethodID = idTemp;
		break;
	case 6:
		PayID = idTemp;
		break;
	}
	return bRet;
}

void CPaymentFlowDetails::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CPaymentFlowDetails(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CPaymentFlowDetails& cfdFlow)
{
	UINT ui = 0;
	for (; ui != cfdFlow.GetColCount() - 1; ui++)
	{
		os << cfdFlow.GetCellText(ui) << _T("��");
	}
	os << cfdFlow.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CPaymentFlowDetails& cfdFlow)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			cfdFlow.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

#pragma endregion
