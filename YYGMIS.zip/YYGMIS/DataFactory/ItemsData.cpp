#include "stdafx.h"
#include "ItemsData.h"


#include <ppl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace GenerialPattern;

STDString MakeUpper(STDString x)
{
	const auto nSize = x.length() + 1;
	TCHAR* __tcsTemp = new TCHAR[nSize];
	_tcscpy_s(__tcsTemp, nSize, x.c_str());
	_tcsupr_s(__tcsTemp, nSize);
	STDString strRet;
	strRet.append(__tcsTemp);
	delete[] __tcsTemp;
	return strRet;
}

/////////////////////////////////////////////
//CItemData��

void CItemData::AddRange(LPCTSTR lpcszItemText, ...)
{
	va_list argptr;
	va_start(argptr, lpcszItemText);	/* Initialize variable arguments. */
	LPCTSTR strTemp = lpcszItemText;
	while (strTemp != nullptr)
	{
		m_vector.push_back(strTemp);
		strTemp = va_arg(argptr, LPCTSTR);
	}
	va_end(argptr);              /* Reset variable arguments.      */
}

STDString CItemData::ParallelFind(Concurrency::concurrent_vector<STDString>& vectData, const STDString& strKey,
	BOOL bPrecise, BOOL bRetDefaultValue)
{
	STDString strRetKey(_T(""));
	BOOL bFound = FALSE;
	Concurrency::structured_task_group tasks;
	tasks.run_and_wait([&] {
		Concurrency::parallel_for_each(vectData.begin(), vectData.end(), [&](const STDString& strArgs)
		{
			STDString strArgsKey = strArgs;
			if (strArgsKey.empty())
			{
				strArgsKey.append(_T("|||||||||||||||||||||||||||"));
			}
			if (strArgsKey.compare(strKey) == 0)
			{
				strRetKey = strArgs;
				bFound = TRUE;
				tasks.cancel();
			}
		});
	});

	if (!bFound && !bPrecise)
	{

		Concurrency::structured_task_group tasks1;
		STDString strFindKey = MakeUpper(strKey);
		tasks1.run_and_wait([&] {
			Concurrency::parallel_for_each(vectData.begin(), vectData.end(), [&](const STDString& strArgs)
			{
				STDString strArgsKey = strArgs;
				if (strArgsKey.empty())
				{
					strArgsKey.append(_T("|||||||||||||||||||||||||||"));
				}
				strArgsKey = MakeUpper(strArgsKey);
				if (_tcsstr(strArgsKey.c_str(), strFindKey.c_str()) != nullptr ||
					_tcsstr(strFindKey.c_str(), strArgsKey.c_str()) != nullptr)
				{
					strRetKey = strArgs;
					bFound = TRUE;
					tasks1.cancel();
				}
			});
		});
	}

	if (bRetDefaultValue && !bPrecise && !bFound && vectData.size() > 0)
	{
		strRetKey = vectData[0];
	}
	return strRetKey;
}

STDString& CItemData::operator[](UINT _Index)
{
	return m_vector[_Index];
}

const STDString& CItemData::operator[](UINT _Index) const
{
	return m_vector[_Index];
}

STDString& CItemData::at(UINT _Index)
{
	return m_vector.at(_Index);
}

const STDString& CItemData::at(UINT _Index) const
{
	return m_vector.at(_Index);
}

size_t CItemData::size() const
{
	return m_vector.size();
}


/////////////////////////////////////////////
//CItemsData��

CItemsData::CItemsData(void)
{

}


CItemsData::~CItemsData(void)
{
	ClearItemDatas();
}

void CItemsData::ClearItemDatas()
{
	auto it = m_mapItems.begin();
	for (; it != m_mapItems.begin(); it++)
	{
		CItemData* pData = it->second;
		delete pData;
	}
	m_mapItems.clear();
}

BOOL CItemsData::AddItemData(const int nRow, CItemData* pData)
{
	BOOL bRet = FALSE;
	if (m_mapItems.find(nRow) == m_mapItems.end())
	{
		m_mapItems.insert(std::pair<UINT, CItemData*>(nRow, pData));
		bRet = TRUE;
	}
	return bRet;
}

CItemData* CItemsData::GetItemData(const int nRow) const
{
	auto itFind = m_mapItems.find(nRow);
	if (itFind != m_mapItems.end())
	{
		return itFind->second;
	}
	else
	{
		return nullptr;
	}
}


int CItemsData::FindItem(LPCTSTR lpszKey, BOOL bPrecise)
{
	int nRet = -1;
	Concurrency::structured_task_group tasks;
	STDString strFindKey(lpszKey);
	//��һ����ִ�о�ȷ����
	tasks.run_and_wait(
		[&] {
		Concurrency::parallel_for_each(m_mapItems.cbegin(), m_mapItems.cend(),
			[&](const std::pair<UINT, CItemData*> itemData)
		{
			Concurrency::parallel_for_each(itemData.second->begin(),
				itemData.second->end(), [&](const STDString strArgs) {
				STDString strArgsKey = strArgs;
				if (strArgsKey.empty())
				{
					strArgsKey.append(_T("|||||||||||||||||||||||||||"));
				}
				if (strArgsKey.find(strFindKey) != STDString::npos)
				{
					nRet = itemData.first;
					tasks.cancel();
				}
			});
		});
	});

	//�ڶ�����ִ��ģ������
	if (nRet = -1 && !bPrecise)
	{
		strFindKey = MakeUpper(strFindKey);
		Concurrency::structured_task_group tasks1;
		//��һ����ִ�о�ȷ����
		tasks1.run_and_wait(
			[&] {
			Concurrency::parallel_for_each(m_mapItems.begin(), m_mapItems.end(),
				[&](std::pair<UINT, CItemData*> itemData)
			{
				Concurrency::parallel_for_each(itemData.second->begin(),
					itemData.second->end(), [&](STDString strArgs) {
					STDString strNewArgs = MakeUpper(strArgs);
					if (strNewArgs.empty())
					{
						strNewArgs.append(_T("|||||||||||||||||||||||||||"));
					}
					if (_tcsstr(strNewArgs.c_str(), strFindKey.c_str()) != nullptr ||
						_tcsstr(strFindKey.c_str(), strNewArgs.c_str()) != nullptr)
					{
						nRet = itemData.first;
						tasks1.cancel();
					}
				});
			});
		});
	}

	return nRet;
}

const CItemData* CItemsData::FindItem1(LPCTSTR lpszKey)
{
	CItemData* pItemRet = nullptr;
	Concurrency::structured_task_group tasks;
	STDString strFindKey(lpszKey);
	//��һ����ִ�о�ȷ����
	tasks.run_and_wait(
		[&] {
		Concurrency::parallel_for_each(m_mapItems.cbegin(), m_mapItems.cend(),
			[&](const std::pair<UINT, CItemData*> itemData)
		{
			Concurrency::parallel_for_each(itemData.second->begin(),
				itemData.second->end(), [&](const STDString strArgs) {
				STDString strArgsKey = strArgs;
				if (strArgsKey.empty())
				{
					strArgsKey.append(_T("|||||||||||||||||||||||||||"));
				}
				if (strArgsKey.find(strFindKey) != STDString::npos)
				{
					pItemRet = itemData.second;
					tasks.cancel();
				}
			});
		});
	});

	return pItemRet;
}

std::pair<STDString, STDString> CItemsData::GetMatchItem(CItemsData& itemData, int lParam, PTSTR ptStrKey, UINT uiCaptionCol)
{
	std::pair<STDString, STDString> pairRet;
	CItemData* pData = nullptr;
	if (ptStrKey != nullptr)
	{
		if (lParam != -1)
		{
			//���Է��Ϸ�Χ
			pData = itemData.GetItemData(lParam);
		}
		else
		{
			//��ʼ����
			int nIndex = itemData.FindItem(ptStrKey);
			if (nIndex != -1)
			{
				pData = itemData.GetItemData(nIndex);
			}
		}
	}
	if (pData == nullptr)
	{
		pData = itemData.GetItemData(0);
	}

	pairRet.first = pData->at(0);
	pairRet.second = pData->at(uiCaptionCol);

	return pairRet;
}
