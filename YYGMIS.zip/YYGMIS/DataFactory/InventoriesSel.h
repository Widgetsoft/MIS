#pragma once
namespace Database
{
	class AFX_EXT_CLASS CInventoriesSel : public CFlybyItem
	{
	public:
		CInventoriesSel();
		CInventoriesSel(const CInventoriesSel& input);
	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 11; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return InvID; }
	public:
		BEGIN_COLUMN_MAP(CInventoriesSel)
			COLUMN_ENTRY(1, InvID)
			COLUMN_ENTRY(2, IsSelected)
			COLUMN_ENTRY(3, WSPName)
			COLUMN_ENTRY(4, ProdName)
			COLUMN_ENTRY(5, ProdCustomID)
			COLUMN_ENTRY(6, ProductType)
			COLUMN_ENTRY(7, ProductSpec)
			COLUMN_ENTRY(8, ProductUnit1)
			COLUMN_ENTRY(9, StockQuantity)
			COLUMN_ENTRY(10, WSPID)
			COLUMN_ENTRY(11, ProdID)
		END_COLUMN_MAP()

	private:
		GUID InvID;
		BOOL IsSelected;
		OLECHAR WSPName[100];
		OLECHAR ProdName[60];
		OLECHAR ProdCustomID[40];
		OLECHAR ProductType[40];
		OLECHAR ProductSpec[40];
		OLECHAR ProductUnit1[40];
		double StockQuantity;
		GUID WSPID;
		GUID ProdID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CInventoriesSel& itemInfo);
		friend STDInStream& operator >> (STDInStream& is, CInventoriesSel& itemInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CInventoriesSel& itemInfo);
	STDInStream& operator >> (STDInStream& is, CInventoriesSel& itemInfo);

	class AFX_EXT_CLASS CInventoriesSelVector : public CFlybyData
	{
	public:
		CInventoriesSelVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewnullptrInventories");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CInventoriesSel().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CInventoriesSel().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CInventoriesSel>(new CInventoriesSel()).release(); }
	};
}

#undef AFX_DATA
#define AFX_DATA