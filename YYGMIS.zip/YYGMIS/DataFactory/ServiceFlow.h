#pragma once
//������Ϣ��:����ʱѡ�����ͷ����ˣ��Զ����ɸ÷�����Ϣ��ִ�����۰󶨼ƻ�
//�������ɷ�����Ϣ�� ���˷��� Ҳ����һ�ַ���
namespace Database
{
	class AFX_EXT_CLASS CServiceFlow : public CFlybyItem
	{
	public:
		CServiceFlow();
		CServiceFlow(const CServiceFlow&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 19; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return SvcID; }

	public:
		BEGIN_COLUMN_MAP(CServiceFlow)
			COLUMN_ENTRY(1, SvcID)
			COLUMN_ENTRY(2, SvcCustomID)
			COLUMN_ENTRY(3, ServiceDate)
			COLUMN_ENTRY(4, DetpName)
			COLUMN_ENTRY(5, BusinessMan)
			COLUMN_ENTRY(6, CustomerName)
			COLUMN_ENTRY(7, IsCheckOut)
			COLUMN_ENTRY(8, CheckoutMan)
			COLUMN_ENTRY(9, Amount)
			COLUMN_ENTRY(10, Memo)
			COLUMN_ENTRY(11, DetpID)
			COLUMN_ENTRY(12, BusinessManID)
			COLUMN_ENTRY(13, CheckoutManID)
			COLUMN_ENTRY(14, custID)
			COLUMN_ENTRY(15, CreateDate)
			COLUMN_ENTRY(16, ModifyDate)
			COLUMN_ENTRY(17, CheckOutDate)
			COLUMN_ENTRY(18, CreatedUser)
			COLUMN_ENTRY(19, ModifierUser)
		END_COLUMN_MAP()
	private:
		GUID		SvcID;				//����������
		OLECHAR		SvcCustomID[17];	//�����ڲ�����
		CComVariant ServiceDate;		//��������
		OLECHAR		DetpName[60];		//���첿��
		OLECHAR		BusinessMan[20];	//����Ա
		OLECHAR		CustomerName[60];	//����ͻ�
		BOOL		IsCheckOut;			//�Ƿ����
		OLECHAR		CheckoutMan[20];	//�����
		double		Amount;				//������� 
		OLECHAR		Memo[MAX_PATH];		//����ע

		GUID		DetpID;				//���첿�ű���
		GUID		BusinessManID;		//����Ա����
		GUID		CheckoutManID;		//����˱���
		GUID		custID;				//����ͻ�

		CComVariant CreateDate;			//��������
		CComVariant ModifyDate;			//�޸�����
		CComVariant CheckOutDate;		//�������
		GUID		CreatedUser;		//������
		GUID		ModifierUser;		//�޸���

		DataState	State;				//����״̬
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CServiceFlow& SvcFlow);
		friend STDInStream& operator >> (STDInStream& is, CServiceFlow& SvcFlow);
	}; //����Դ������ǰ׺

	STDOutStream& operator<<(STDOutStream& os, const CServiceFlow& SvcFlow);
	STDInStream& operator >> (STDInStream& is, CServiceFlow& SvcFlow);

	class AFX_EXT_CLASS CServiceFlowVector : public CFlybyData
	{
	public:
		CServiceFlowVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewServiceFlow");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CServiceFlow().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CServiceFlow().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CServiceFlow>(new CServiceFlow()).release(); }
	};

	class AFX_EXT_CLASS CServiceFlowDetails : public CFlybyItem
	{
	public:
		CServiceFlowDetails();
		CServiceFlowDetails(const CServiceFlowDetails&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 19; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return SvcDetailsID; }

	public:
		BEGIN_COLUMN_MAP(CServiceFlowDetails)
			COLUMN_ENTRY(1, SvcDetailsID)
			COLUMN_ENTRY(2, ServName)
			COLUMN_ENTRY(3, ServType)
			COLUMN_ENTRY(4, ServSpec)
			COLUMN_ENTRY(5, Price)
			COLUMN_ENTRY(6, Quantity)
			COLUMN_ENTRY(7, StartTime)
			COLUMN_ENTRY(8, EndTime)
			COLUMN_ENTRY(9, ServUnit)
			COLUMN_ENTRY(10, Discount)
			COLUMN_ENTRY(11, Amount)
			COLUMN_ENTRY(12, FinalAmount)
			COLUMN_ENTRY(13, Score)
			COLUMN_ENTRY(14, Commission)
			COLUMN_ENTRY(15, IsTimeCount)
			COLUMN_ENTRY(16, Memo)
			COLUMN_ENTRY(17, Unit1ToUnit2Rate)
			COLUMN_ENTRY(18, ServiceID)
			COLUMN_ENTRY(19, SvcID)
		END_COLUMN_MAP()

	private:
		GUID		SvcDetailsID;
		OLECHAR		ServName[60];		//��������
		OLECHAR		ServType[40];		//�������
		OLECHAR		ServSpec[40];		//����Ҫ��
		double		Price;				//����
		double		Quantity;			//����
		CComVariant	StartTime;			//��ʼʱ��
		CComVariant	EndTime;			//����ʱ��
		OLECHAR		ServUnit[40];		//������λ
		double		Discount;			//�Ż��ۿ�
		double		Amount;				//�����۽��
		double		FinalAmount;		//���׽��
		double		Score;				//����
		double		Commission;			//ҵ��Ա���

		BOOL		IsTimeCount;		//��ʱ��Ƽ�
		OLECHAR		Memo[MAX_PATH];		//��ע
		double		Unit1ToUnit2Rate;	//��λת��ϵ��


		GUID		ServiceID;			//�ײͱ���
		GUID		SvcID;				//�ܵ�����

		DataState State;

	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CServiceFlowDetails& SvcFlowD);
		friend STDInStream& operator >> (STDInStream& is, CServiceFlowDetails& SvcFlowD);
	};

	STDOutStream& operator<<(STDOutStream& os, const CServiceFlowDetails& SvcFlowD);
	STDInStream& operator >> (STDInStream& is, CServiceFlowDetails& SvcFlowD);

	class AFX_EXT_CLASS CServiceFlowDetailsVector : public CFlybyData
	{
	public:
		CServiceFlowDetailsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewServiceDetails");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CServiceFlowDetails().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CServiceFlowDetails().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CServiceFlowDetails>(new CServiceFlowDetails()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA