#include "stdafx.h"
#include "FlybyData.h"
#include "EquipmentInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CEquipmentInfo::CEquipmentInfo()
{
	CoCreateGuid(&EIID);
	ocscpy_s(EICustomCode, _countof(EICustomCode), OLESTR(""));
	ocscpy_s(EIName, _countof(EIName), OLESTR(""));
	ocscpy_s(EISpec, _countof(EISpec), OLESTR(""));

	EICost = { 0 };
	EIOneTime = FALSE;

	ocscpy_s(JM, _countof(JM), OLESTR(""));
	UsingLife = { 0 };
	PowerDissipation = { 0 };
	CountHours = { 0 };
	IsBusy = FALSE;

	CurrentCount = 0;
	EICapacity = 0;

	COleDateTime timeNow = COleDateTime::GetCurrentTime();

	EIPurchaseDate.vt = VT_DATE;
	EIPurchaseDate.date = timeNow.m_dt;

	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	compID = GUID_NULL;

	State = Initial;
}


CEquipmentInfo::CEquipmentInfo(const CEquipmentInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CEquipmentInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), EICustomCode);
		break;
	case 2:
		strRet.Format(_T("%s"), EIName);
		break;
	case 3:
		strRet.Format(_T("%s"), EISpec);
		break;
	case 4:
		strRet.Format(_T("%.2f"), EICost);
		break;
	case 5:
		strRet.Format(_T("%s"), EIOneTime ? _T("һ����") : _T("������"));
		break;
	case 6:
		strRet = __super::FormatDate(EIPurchaseDate);
		break;
	case 7:
		strRet.Format(_T("%s"), JM);
		break;
	case 8:
		strRet.Format(_T("%.2f"), UsingLife);
		break;
	case 9:
		strRet.Format(_T("%.2f"), PowerDissipation);
		break;
	case 10:
		strRet.Format(_T("%.2f"), CountHours);
		break;
	case 11:
		strRet.Format(_T("%s"), IsBusy ? _T("��æ") : _T("����"));
		break;
	case 12:
		strRet.Format(_T("%i"), CurrentCount);
		break;
	case 13:
		strRet.Format(_T("%i"), EICapacity);
		break;
	case 14:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 15:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = EIID;
		break;
	case 16:
		idRet = CreatedUser;
		break;
	case 17:
		idRet = ModifierUser;
		break;
	case 18:
		idRet = compID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CEquipmentInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�豸����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�豸����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("�豸���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�豸��ֵ"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�豸����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�ɹ�����"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�豸����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("ʹ��ʱ��"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�豸����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("����Сʱ��"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("�豸״̬"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��ǰ����"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("�޸���"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("��˾����"));
		break;
	}
	return strRet;
}

BOOL CEquipmentInfo::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	double dblTemp = { 0 };
	int nTemp = 0;
	if (nCol == 0 || (nCol >= 16 && nCol <= 18))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 6 || nCol == 14 || nCol == 15)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 4 || (nCol >= 8 && nCol <= 10))
	{
		TCHAR* pstrStop;
		dblTemp = _tcstod(strTemp, &pstrStop);
	}
	else if (nCol == 12 || nCol == 13)
	{
		nTemp = _ttoi(strTemp);
	}

	switch (nCol)
	{
	case 0:
		EIID = idTemp;
		break;
	case 1:
		_tcscpy_s(EICustomCode, _countof(EICustomCode), Truncate(strTemp, _countof(EICustomCode) + 1));
		break;
	case 2:
		_tcscpy_s(EIName, _countof(EIName), Truncate(strTemp, _countof(EIName) + 1));
		break;
	case 3:
		_tcscpy_s(EISpec, _countof(EISpec), Truncate(strTemp, _countof(EISpec) + 1));
		break;
	case 4:
		EICost = dblTemp;
		break;
	case 5:
		EIOneTime = (strTemp.Compare(_T("һ����")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 6:
		EIPurchaseDate.date = dtTemp;
		break;
	case 7:
		_tcscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 8:
		UsingLife = dblTemp;
		break;
	case 9:
		PowerDissipation = dblTemp;
		break;
	case 10:
		CountHours = dblTemp;
		break;
	case 11:
		IsBusy = (strTemp.Compare(_T("��æ")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 12:
		CurrentCount = nTemp;
		break;
	case 13:
		EICapacity = nTemp;
		break;
	case 14:
		CreateDate.date = dtTemp;
		break;
	case 15:
		ModifyDate.date = dtTemp;
		break;
	case 16:
		CreatedUser = idTemp;
		break;
	case 17:
		ModifierUser = idTemp;
		break;
	case 18:
		compID = idTemp;
		break;
	}
	return bRet;
}

void CEquipmentInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CEquipmentInfo(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CEquipmentInfo& ProdInfo)
{
	UINT ui = 0;
	for (; ui != ProdInfo.GetColCount() - 1; ui++)
	{
		os << ProdInfo.GetCellText(ui) << _T("��");
	}
	os << ProdInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CEquipmentInfo& ProdInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			ProdInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
