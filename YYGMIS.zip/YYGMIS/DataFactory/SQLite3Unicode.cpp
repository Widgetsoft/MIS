#include "stdafx.h"
#include "SQLite3Unicode.h"

#ifndef _WIN64
#ifdef _DEBUG 
#pragma comment(lib, "../../YYGMIS/Debug/sqlite3.lib")
#else
#pragma comment(lib, "../../YYGMIS/Release/sqlite3.lib")
#endif
#else
#ifdef _DEBUG 
#pragma comment(lib, "../../YYGMIS/x64/Debug/sqlite3.lib")
#else
#pragma comment(lib, "../../YYGMIS/x64/Release/sqlite3.lib")
#endif
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// CppSQLite3Exception

CSQLite3Exception::CSQLite3Exception(const int nErrCode,
	LPTSTR szErrMess,
	bool bDeleteMsg/*=true*/) :
	mnErrCode(nErrCode)
{
	size_t szTemp = szErrMess ? _tcslen(szErrMess) + 50 : 50;
	mpszErrMess = new TCHAR[szTemp];
	_stprintf_s(mpszErrMess, szTemp, _T("%s[%d]: %s"),
		errorCodeAsString(nErrCode),
		nErrCode,
		szErrMess ? szErrMess : _T(""));

	if (bDeleteMsg && szErrMess)
	{
		_sqlite3_free((char*)szErrMess);
	}
}


CSQLite3Exception::CSQLite3Exception(const CSQLite3Exception&  e) :
	mnErrCode(e.mnErrCode)
{
	mpszErrMess = 0;
	if (e.mpszErrMess)
	{
		size_t szRange = _tcslen(e.mpszErrMess) + 10;
		mpszErrMess = new TCHAR[szRange];
		_stprintf_s(mpszErrMess, szRange, _T("%s"), e.mpszErrMess);
	}
}


LPCTSTR CSQLite3Exception::errorCodeAsString(int nErrCode)
{
	switch (nErrCode)
	{
	case SQLITE_OK: return _T("SQLITE_OK");
	case SQLITE_ERROR: return _T("SQLITE_ERROR");
	case SQLITE_INTERNAL: return _T("SQLITE_INTERNAL");
	case SQLITE_PERM: return _T("SQLITE_PERM");
	case SQLITE_ABORT: return _T("SQLITE_ABORT");
	case SQLITE_BUSY: return _T("SQLITE_BUSY");
	case SQLITE_LOCKED: return _T("SQLITE_LOCKED");
	case SQLITE_NOMEM: return _T("SQLITE_NOMEM");
	case SQLITE_READONLY: return _T("SQLITE_READONLY");
	case SQLITE_INTERRUPT: return _T("SQLITE_INTERRUPT");
	case SQLITE_IOERR: return _T("SQLITE_IOERR");
	case SQLITE_CORRUPT: return _T("SQLITE_CORRUPT");
	case SQLITE_NOTFOUND: return _T("SQLITE_NOTFOUND");
	case SQLITE_FULL: return _T("SQLITE_FULL");
	case SQLITE_CANTOPEN: return _T("SQLITE_CANTOPEN");
	case SQLITE_PROTOCOL: return _T("SQLITE_PROTOCOL");
	case SQLITE_EMPTY: return _T("SQLITE_EMPTY");
	case SQLITE_SCHEMA: return _T("SQLITE_SCHEMA");
	case SQLITE_TOOBIG: return _T("SQLITE_TOOBIG");
	case SQLITE_CONSTRAINT: return _T("SQLITE_CONSTRAINT");
	case SQLITE_MISMATCH: return _T("SQLITE_MISMATCH");
	case SQLITE_MISUSE: return _T("SQLITE_MISUSE");
	case SQLITE_NOLFS: return _T("SQLITE_NOLFS");
	case SQLITE_AUTH: return _T("SQLITE_AUTH");
	case SQLITE_FORMAT: return _T("SQLITE_FORMAT");
	case SQLITE_RANGE: return _T("SQLITE_RANGE");
	case SQLITE_ROW: return _T("SQLITE_ROW");
	case SQLITE_DONE: return _T("SQLITE_DONE");
	case TSWSQLITE_ERROR: return _T("TSWSQLITE_ERROR");
	default: return _T("UNKNOWN_ERROR");
	}
}


CSQLite3Exception::~CSQLite3Exception()
{
	if (mpszErrMess)
	{
		delete[] mpszErrMess;
		mpszErrMess = 0;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSQLite3Unicode

CSQLite3Unicode::CSQLite3Unicode()
{
	mpDB = 0;
	mnBusyTimeoutMs = 60000; // 60 seconds
}

CSQLite3Unicode::CSQLite3Unicode(const CSQLite3Unicode& db)
{
	mpDB = db.mpDB;
	mnBusyTimeoutMs = 60000; // 60 seconds
}


CSQLite3Unicode::~CSQLite3Unicode()
{
	close();
}

////////////////////////////////////////////////////////////////////////////////

CSQLite3Unicode& CSQLite3Unicode::operator=(const CSQLite3Unicode& db)
{
	mpDB = db.mpDB;
	mnBusyTimeoutMs = 60000; // 60 seconds
	return *this;
}

void CSQLite3Unicode::open(LPCTSTR szFile)
{
	int nRet;

#if defined(_UNICODE) || defined(UNICODE)

	nRet = sqlite3_open16(szFile, &mpDB); // not tested under window 98 

#else // For Ansi Version
	//*************-  Added by Begemot  szFile must be in unicode- 23/03/06 11:04 - ****
	OSVERSIONINFOEX osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	GetVersionEx((OSVERSIONINFO *)&osvi);

	if (osvi.dwMajorVersion == 5)
	{
		WCHAR pMultiByteStr[MAX_PATH + 1];
		MultiByteToWideChar(CP_ACP, 0, szFile,
			_tcslen(szFile) + 1, pMultiByteStr,
			sizeof(pMultiByteStr) / sizeof(pMultiByteStr[0]));
		nRet = sqlite3_open16(pMultiByteStr, &mpDB);
	}
	else
		nRet = sqlite3_open(szFile, &mpDB);
#endif
	//*************************
	if (nRet != SQLITE_OK)
	{
		LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
		throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
	}
	setBusyTimeout(mnBusyTimeoutMs);
}

void CSQLite3Unicode::close()
{
	if (mpDB)
	{
		int nRet = _sqlite3_close(mpDB);

		if (nRet != SQLITE_OK)
		{
			LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
			throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
		}
		mpDB = nullptr;
	}
}


CSQLite3Statement CSQLite3Unicode::compileStatement(LPCTSTR szSQL)
{
	checkDB();

	sqlite3_stmt* pVM = compile(szSQL);

	return CSQLite3Statement(mpDB, pVM);
}


bool CSQLite3Unicode::tableExists(LPCTSTR szTable)
{
	TCHAR szSQL[128];
	_stprintf_s(szSQL, 128, _T("select count(*) from sqlite_master where type='table' and name='%s'"), szTable);
	int nRet = execScalar(szSQL);
	return (nRet > 0);
}


int CSQLite3Unicode::execDML(LPCTSTR szSQL)
{
	int nRet;
	sqlite3_stmt* pVM;
	checkDB();

	do {
		pVM = compile(szSQL);

		nRet = _sqlite3_step(pVM);

		if (nRet == SQLITE_ERROR)
		{
			LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
			throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
		}
		nRet = _sqlite3_finalize(pVM);
	} while (nRet == SQLITE_SCHEMA);

	return nRet;
}

CSQLite3Query CSQLite3Unicode::execQuery(LPCTSTR szSQL)
{
	checkDB();
	int nRet;
	sqlite3_stmt* pVM;

	do {
		pVM = compile(szSQL);

		nRet = _sqlite3_step(pVM);

		if (nRet == SQLITE_DONE)
		{	// no rows
			return CSQLite3Query(mpDB, pVM, true/*eof*/);
		}
		else if (nRet == SQLITE_ROW)
		{	// at least 1 row
			return CSQLite3Query(mpDB, pVM, false/*eof*/);
		}
		nRet = _sqlite3_finalize(pVM);
	} while (nRet == SQLITE_SCHEMA); // Edit By Begemot 08/16/06 12:44:35 -   read SQLite FAQ 

	LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
	throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
}


int CSQLite3Unicode::execScalar(LPCTSTR szSQL)
{
	CSQLite3Query q = execQuery(szSQL);

	if (q.eof() || q.numFields() < 1)
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��Ч���Զ����ѯ"), DONT_DELETE_MSG);

	return _tstoi(q.fieldValue(0));
}

// Added By Begemot, exact as execScalar but return CString  08/06/06 16:30:37
CString CSQLite3Unicode::execScalarStr(LPCTSTR szSQL)
{
	CSQLite3Query q = execQuery(szSQL);

	if (q.eof() || q.numFields() < 1)
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��Ч���Զ����ѯ"), DONT_DELETE_MSG);

	return (CString)q.getStringField(0);
}

sqlite_int64 CSQLite3Unicode::lastRowId()
{
	return sqlite3_last_insert_rowid(mpDB);
}


void CSQLite3Unicode::setBusyTimeout(int nMillisecs)
{
	mnBusyTimeoutMs = nMillisecs;
	sqlite3_busy_timeout(mpDB, mnBusyTimeoutMs);
}


void CSQLite3Unicode::checkDB()
{
	if (!mpDB)
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("�޷������ݿ�"), DONT_DELETE_MSG);

}


sqlite3_stmt* CSQLite3Unicode::compile(LPCTSTR szSQL)
{
	checkDB();
	sqlite3_stmt* pVM;

	int nRet = _sqlite3_prepare(mpDB, szSQL, -1, &pVM, nullptr);

	if (nRet != SQLITE_OK)
	{
		pVM = nullptr;
		LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
		throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
	}
	return pVM;
}

//////////////////////// CSQLite3Statement  ///////////////////////////////////////////
CSQLite3Statement::CSQLite3Statement()
{
	mpDB = 0;
	mpVM = 0;
}

CSQLite3Statement::CSQLite3Statement(const CSQLite3Statement& rStatement)
{
	mpDB = rStatement.mpDB;
	mpVM = rStatement.mpVM;
	// Only one object can own VM
	const_cast<CSQLite3Statement&>(rStatement).mpVM = 0;
}

CSQLite3Statement::CSQLite3Statement(sqlite3* pDB, sqlite3_stmt* pVM)
{
	mpDB = pDB;
	mpVM = pVM;
}

CSQLite3Statement::~CSQLite3Statement()
{
	try
	{
		finalize();
	}
	catch (...) {}
}

CSQLite3Statement& CSQLite3Statement::operator=(const CSQLite3Statement& rStatement)
{
	mpDB = rStatement.mpDB;
	mpVM = rStatement.mpVM;
	// Only one object can own VM
	const_cast<CSQLite3Statement&>(rStatement).mpVM = 0;
	return *this;
}

int CSQLite3Statement::execDML()
{
	checkDB();
	checkVM();

	int nRet = sqlite3_step(mpVM);

	if (nRet == SQLITE_DONE)
	{
		int nRowsChanged = sqlite3_changes(mpDB);

		nRet = sqlite3_reset(mpVM);

		if (nRet != SQLITE_OK)
		{
			LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
			throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
		}
		return nRowsChanged;
	}
	else
	{
		nRet = sqlite3_reset(mpVM);
		LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
		throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
	}
}

CSQLite3Query CSQLite3Statement::execQuery()
{
	checkDB();
	checkVM();

	int nRet = _sqlite3_step(mpVM);

	if (nRet == SQLITE_DONE)
	{
		// no rows
		return CSQLite3Query(mpDB, mpVM, true/*eof*/, false);
	}
	else if (nRet == SQLITE_ROW)
	{
		// at least 1 row
		return CSQLite3Query(mpDB, mpVM, false/*eof*/, false);
	}
	else
	{
		nRet = sqlite3_reset(mpVM);
		PTSTR szError = (PTSTR)sqlite3_errmsg(mpDB);
		throw CSQLite3Exception(nRet, szError, DONT_DELETE_MSG);
	}
}


void CSQLite3Statement::bind(int nParam, LPCTSTR szValue)
{
	checkVM();
	int nRes = _sqlite3_bind_text(mpVM, nParam, szValue, -1, SQLITE_TRANSIENT);
	if (nRes != SQLITE_OK)
		throw CSQLite3Exception(nRes, _T("�ַ��������󶨳��ִ���"), DONT_DELETE_MSG);
}


void CSQLite3Statement::bind(int nParam, const int nValue)
{
	checkVM();
	int nRes = sqlite3_bind_int(mpVM, nParam, nValue);
	if (nRes != SQLITE_OK)
		throw CSQLite3Exception(nRes, _T("���Ͳ����󶨳��ִ���"), DONT_DELETE_MSG);
}


void CSQLite3Statement::bind(int nParam, const double dValue)
{
	checkVM();
	int nRes = sqlite3_bind_double(mpVM, nParam, dValue);
	if (nRes != SQLITE_OK)
		throw CSQLite3Exception(nRes, _T("˫���ȸ����Ͳ����󶨳��ִ���"), DONT_DELETE_MSG);
}


void CSQLite3Statement::bind(int nParam, const unsigned char* blobValue, int nLen)
{
	checkVM();
	int nRes = sqlite3_bind_blob(mpVM, nParam, (const void*)blobValue, nLen, SQLITE_TRANSIENT);
	if (nRes != SQLITE_OK)
		throw CSQLite3Exception(nRes, _T("blob�����󶨳��ִ���"), DONT_DELETE_MSG);
}


void CSQLite3Statement::bindnullptr(int nParam)
{
	checkVM();
	int nRes = sqlite3_bind_null(mpVM, nParam);

	if (nRes != SQLITE_OK)
		throw CSQLite3Exception(nRes, _T("��ֵ�����󶨳��ִ���"), DONT_DELETE_MSG);
}


void CSQLite3Statement::reset()
{
	if (mpVM)
	{
		int nRet = sqlite3_reset(mpVM);

		if (nRet != SQLITE_OK)
		{
			LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
			throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
		}
	}
}


void CSQLite3Statement::finalize()
{
	if (mpVM)
	{
		int nRet = sqlite3_finalize(mpVM);
		mpVM = 0;

		if (nRet != SQLITE_OK)
		{
			LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
			throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
		}
	}
}


void CSQLite3Statement::checkDB()
{
	if (mpDB == 0) throw CSQLite3Exception(TSWSQLITE_ERROR, _T("���ݿ���δ��"), DONT_DELETE_MSG);
}

void CSQLite3Statement::checkVM()
{
	if (mpVM == 0)
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("�����ָ��Ϊ��ֵ"), DONT_DELETE_MSG);
}

/////////////////////  CSQLite3Query  //////////////////////////////////////////////////
CSQLite3Query::CSQLite3Query()
{
	mpVM = 0;
	mbEof = true;
	mnCols = 0;
	mbOwnVM = false;
}


CSQLite3Query::CSQLite3Query(const CSQLite3Query& rQuery)
{
	mpVM = rQuery.mpVM;
	// Only one object can own the VM
	const_cast<CSQLite3Query&>(rQuery).mpVM = 0;
	mbEof = rQuery.mbEof;
	mnCols = rQuery.mnCols;
	mbOwnVM = rQuery.mbOwnVM;
}


CSQLite3Query::CSQLite3Query(sqlite3* pDB, sqlite3_stmt* pVM,
	bool bEof, bool bOwnVM/*=true*/)
{
	mpDB = pDB;
	mpVM = pVM;
	mbEof = bEof;
	mnCols = _sqlite3_column_count(mpVM);
	mbOwnVM = bOwnVM;
}

CSQLite3Query::~CSQLite3Query()
{
	try
	{
		finalize();
	}
	catch (...) {}
}


CSQLite3Query& CSQLite3Query::operator=(const CSQLite3Query& rQuery)
{
	try
	{
		finalize();
	}
	catch (...) {}

	mpVM = rQuery.mpVM;
	// Only one object can own the VM
	const_cast<CSQLite3Query&>(rQuery).mpVM = 0;
	mbEof = rQuery.mbEof;
	mnCols = rQuery.mnCols;
	mbOwnVM = rQuery.mbOwnVM;
	return *this;
}


int CSQLite3Query::numFields()
{
	checkVM();
	return mnCols;
}


LPCTSTR CSQLite3Query::fieldValue(int nField)
{
	checkVM();

	if (nField < 0 || nField > mnCols - 1)
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("������ֶ�����ֵ��Ч"), DONT_DELETE_MSG);

	return (LPCTSTR)_sqlite3_column_text(mpVM, nField);
}


LPCTSTR CSQLite3Query::fieldValue(LPCTSTR szField)
{
	int nField = fieldIndex(szField);
	return (LPCTSTR)_sqlite3_column_text(mpVM, nField);
}


int CSQLite3Query::getIntField(int nField, int nnullptrValue/*=0*/)
{
	if (fieldDataType(nField) == SQLITE_NULL)
	{
		return nnullptrValue;
	}
	else
	{
		return _sqlite3_column_int(mpVM, nField);
	}
}


int CSQLite3Query::getIntField(LPCTSTR szField, int nnullptrValue/*=0*/)
{
	int nField = fieldIndex(szField);
	return getIntField(nField, nnullptrValue);
}


double CSQLite3Query::getFloatField(int nField, double fnullptrValue/*=0.0*/)
{
	if (fieldDataType(nField) == SQLITE_NULL)
	{
		return fnullptrValue;
	}
	else
	{
		return _sqlite3_column_double(mpVM, nField);
	}
}


double CSQLite3Query::getFloatField(LPCTSTR szField, double fnullptrValue/*=0.0*/)
{
	int nField = fieldIndex(szField);
	return getFloatField(nField, fnullptrValue);
}


LPCTSTR CSQLite3Query::getStringField(int nField, LPCTSTR sznullptrValue/*=""*/)
{
	if (fieldDataType(nField) == SQLITE_NULL)
	{
		return sznullptrValue;
	}
	else
	{
		return (LPCTSTR)_sqlite3_column_text(mpVM, nField);
	}
}


LPCTSTR CSQLite3Query::getStringField(LPCTSTR szField, LPCTSTR sznullptrValue/*=""*/)
{
	int nField = fieldIndex(szField);
	return getStringField(nField, sznullptrValue);
}


const unsigned char* CSQLite3Query::getBlobField(int nField, int& nLen)
{
	checkVM();

	if (nField < 0 || nField > mnCols - 1)
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��������ֶ�����ֵ��Ч"), DONT_DELETE_MSG);

	nLen = _sqlite3_column_bytes(mpVM, nField);
	return (const unsigned char*)sqlite3_column_blob(mpVM, nField);
}


const unsigned char* CSQLite3Query::getBlobField(LPCTSTR szField, int& nLen)
{
	int nField = fieldIndex(szField);
	return getBlobField(nField, nLen);
}


bool CSQLite3Query::fieldIsnullptr(int nField)
{
	return (fieldDataType(nField) == SQLITE_NULL);
}


bool CSQLite3Query::fieldIsnullptr(LPCTSTR szField)
{
	int nField = fieldIndex(szField);
	return (fieldDataType(nField) == SQLITE_NULL);
}


int CSQLite3Query::fieldIndex(LPCTSTR szField)
{
	checkVM();

	if (szField)
	{
		for (int nField = 0; nField < mnCols; nField++)
		{
			LPCTSTR szTemp = (LPCTSTR)_sqlite3_column_name(mpVM, nField);

			if (_tcscmp(szField, szTemp) == 0)
			{
				return nField;
			}
		}
	}
	throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��������ֶ�������Ч"), DONT_DELETE_MSG);
}


LPCTSTR CSQLite3Query::fieldName(int nCol)
{
	checkVM();

	if (nCol < 0 || nCol > mnCols - 1)
	{
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��������ֶ�����ֵ��Ч"), DONT_DELETE_MSG);
	}
	return (LPCTSTR)_sqlite3_column_name(mpVM, nCol);
}


LPCTSTR CSQLite3Query::fieldDeclType(int nCol)
{
	checkVM();

	if (nCol < 0 || nCol > mnCols - 1)
	{
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��������ֶ�����ֵ��Ч"), DONT_DELETE_MSG);
	}
	return (LPCTSTR)_sqlite3_column_decltype(mpVM, nCol);
}


int CSQLite3Query::fieldDataType(int nCol)
{
	checkVM();

	if (nCol < 0 || nCol > mnCols - 1)
	{
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("��������ֶ�����ֵ��Ч"), DONT_DELETE_MSG);
	}
	return _sqlite3_column_type(mpVM, nCol);
}


bool CSQLite3Query::eof()
{
	checkVM();
	return mbEof;
}


void CSQLite3Query::nextRow()
{
	checkVM();

	int nRet = _sqlite3_step(mpVM);

	if (nRet == SQLITE_DONE)
	{
		// no rows
		mbEof = true;
	}
	else if (nRet == SQLITE_ROW)
	{
		// more rows, nothing to do
	}
	else
	{
		nRet = _sqlite3_finalize(mpVM);
		mpVM = 0;
		LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
		throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
	}
}


void CSQLite3Query::finalize()
{
	if (mpVM && mbOwnVM)
	{
		int nRet = _sqlite3_finalize(mpVM);
		mpVM = 0;
		if (nRet != SQLITE_OK)
		{
			LPCTSTR szError = (LPCTSTR)_sqlite3_errmsg(mpDB);
			throw CSQLite3Exception(nRet, (LPTSTR)szError, DONT_DELETE_MSG);
		}
	}
}

void CSQLite3Query::checkVM()
{
	if (mpVM == 0)
	{
		throw CSQLite3Exception(TSWSQLITE_ERROR, _T("�������ָ��ֵΪ��"), DONT_DELETE_MSG);
	}
}


////////////////////////////////////////////////////////////////////////////////
//**************************
CString DoubleQuotes(CString in)
{
	in.Replace(_T("\'"), _T("\'\'"));
	return in;
}