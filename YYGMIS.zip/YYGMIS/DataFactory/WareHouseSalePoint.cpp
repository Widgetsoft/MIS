#include "StdAfx.h"
#include "FlybyData.h"
#include "WareHouseSalePoint.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace Database;

CWareHouseSalePoint::CWareHouseSalePoint()
{
	CoCreateGuid(&WSPID);
	ocscpy_s(WSCustomCode, _countof(WSCustomCode), OLESTR(""));
	ocscpy_s(WSPName, _countof(WSPName), OLESTR(""));
	ocscpy_s(compName, _countof(compName), OLESTR(""));
	ocscpy_s(WSPCheif, _countof(WSPCheif), OLESTR(""));
	ocscpy_s(WSPPhoneNum, _countof(WSPPhoneNum), OLESTR(""));
	ocscpy_s(WSPFaxNum, _countof(WSPFaxNum), OLESTR(""));
	ocscpy_s(WSPhEmail, _countof(WSPhEmail), OLESTR(""));
	ocscpy_s(WSPPostCode, _countof(WSPPostCode), OLESTR(""));
	ocscpy_s(WSPAddress, _countof(WSPAddress), OLESTR(""));
	WSPIsUsing = TRUE;
	WSPIsSalesPoint = FALSE;
	ocscpy_s(WSMemo, _countof(WSMemo), OLESTR(""));
	ocscpy_s(JM, _countof(JM), OLESTR(""));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	compID = GUID_NULL;

	State = Initial;
}

CWareHouseSalePoint::CWareHouseSalePoint(const CWareHouseSalePoint& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());

}

CString CWareHouseSalePoint::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), WSCustomCode);
		break;
	case 2:
		strRet.Format(_T("%s"), WSPName);
		break;
	case 3:
		strRet.Format(_T("%s"), compName);
		break;
	case 4:
		strRet.Format(_T("%s"), WSPCheif);
		break;
	case 5:
		strRet.Format(_T("%s"), WSPPhoneNum);
		break;
	case 6:
		strRet.Format(_T("%s"), WSPFaxNum);
		break;
	case 7:
		strRet.Format(_T("%s"), WSPhEmail);
		break;
	case 8:
		strRet.Format(_T("%s"), WSPPostCode);
		break;
	case 9:
		strRet.Format(_T("%s"), WSPAddress);
		break;
	case 10:
		strRet.Format(_T("%s"), WSPIsUsing ? _T("����") : _T("ͣ��"));
		break;
	case 11:
		strRet.Format(_T("%s"), WSPIsSalesPoint ? _T("��") : _T("��"));
		break;
	case 12:
		strRet.Format(_T("%s"), WSMemo);
		break;
	case 13:
		strRet.Format(_T("%s"), JM);
		break;
	case 14:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 15:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = WSPID;
		break;
	case 16:
		idRet = CreatedUser;
		break;
	case 17:
		idRet = ModifierUser;
		break;
	case 18:
		idRet = compID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CWareHouseSalePoint::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("������˾"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�绰����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("���ʵ�ַ"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("��ϵ��ַ"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("����״̬"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("�޸���"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("��˾����"));
		break;
	}

	return strRet; 
}

BOOL CWareHouseSalePoint::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 16 && nCol <= 18))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 10)
	{
		bTemp = (strTemp.CompareNoCase(_T("����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 11)
	{
		bTemp = (strTemp.CompareNoCase(_T("��")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 14 || nCol == 15)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}

	switch (nCol)
	{
	case 0:
		WSPID = idTemp;
		break;
	case 1:
		_tcscpy_s(WSCustomCode, _countof(WSCustomCode), Truncate(strTemp, _countof(WSCustomCode) + 1));
		break;
	case 2:
		_tcscpy_s(WSPName, _countof(WSPName), Truncate(strTemp, _countof(WSPName) + 1));
		break;
	case 3:
		_tcscpy_s(compName, _countof(compName), Truncate(strTemp, _countof(compName) + 1));
		break;
	case 4:
		_tcscpy_s(WSPCheif, _countof(WSPCheif), Truncate(strTemp, _countof(WSPCheif) + 1));
		break;
	case 5:
		_tcscpy_s(WSPPhoneNum, _countof(WSPPhoneNum), Truncate(strTemp, _countof(WSPPhoneNum) + 1));
		break;
	case 6:
		_tcscpy_s(WSPFaxNum, _countof(WSPFaxNum), Truncate(strTemp, _countof(WSPFaxNum) + 1));
		break;
	case 7:
		_tcscpy_s(WSPhEmail, _countof(WSPhEmail), Truncate(strTemp, _countof(WSPhEmail) + 1));
		break;
	case 8:
		_tcscpy_s(WSPPostCode, _countof(WSPPostCode), Truncate(strTemp, _countof(WSPPostCode) + 1));
		break;
	case 9:
		_tcscpy_s(WSPAddress, _countof(WSPAddress), Truncate(strTemp, _countof(WSPAddress) + 1));
		break;
	case 10:
		WSPIsUsing = bTemp;
		break;
	case 11:
		WSPIsSalesPoint = bTemp;
		break;
	case 12:
		_tcscpy_s(WSMemo, _countof(WSMemo), Truncate(strTemp, _countof(WSMemo) + 1));
		break;
	case 13:
		_tcscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 14:
		CreateDate.date = dtTemp;
		break;
	case 15:
		ModifyDate.date = dtTemp;
		break;
	case 16:
		CreatedUser = idTemp;
		break;
	case 17:
		ModifierUser = idTemp;
		break;
	case 18:
		compID = idTemp;
		break;
	}
	return bRet;
}

void CWareHouseSalePoint::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CWareHouseSalePoint(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CWareHouseSalePoint& WSPInfo)
{
	UINT ui = 0;
	for (; ui != WSPInfo.GetColCount() - 1; ui++)
	{
		os << WSPInfo.GetCellText(ui) << _T("��");
	}
	os << WSPInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CWareHouseSalePoint& WSPInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			WSPInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}