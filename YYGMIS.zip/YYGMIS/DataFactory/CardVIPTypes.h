#pragma once
namespace Database
{
	class AFX_EXT_CLASS CCardVIPTypes : public CFlybyItem
	{
	public:
		CCardVIPTypes();
		CCardVIPTypes(const CCardVIPTypes& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 8; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return CTID; }
	public:
		BEGIN_COLUMN_MAP(CCardVIPTypes)
			COLUMN_ENTRY(1, CTID)
			COLUMN_ENTRY(2, CTCustomCode)
			COLUMN_ENTRY(3, CTName)
			COLUMN_ENTRY(4, DepositRate)
			COLUMN_ENTRY(5, SalesRate)
			COLUMN_ENTRY(6, ServiceRate)
			COLUMN_ENTRY(7, IntegralRate)
			COLUMN_ENTRY(8, CTMemo)
		END_COLUMN_MAP()

	private:
		GUID CTID;
		OLECHAR CTCustomCode[40];
		OLECHAR CTName[50];
		double DepositRate;
		double SalesRate;
		double ServiceRate;
		double IntegralRate;
		OLECHAR CTMemo[120];

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CCardVIPTypes& itemInfo);
		friend STDInStream& operator >> (STDInStream& is, CCardVIPTypes& itemInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CCardVIPTypes& itemInfo);
	STDInStream& operator >> (STDInStream& is, CCardVIPTypes& itemInfo);

	class CCardVIPTypesVector : public CFlybyData
	{
	public:
		CCardVIPTypesVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewCardVIPTypes");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CCardVIPTypes().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CCardVIPTypes().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CCardVIPTypes>(new CCardVIPTypes()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA

