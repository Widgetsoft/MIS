#pragma once
namespace Database
{
	class AFX_EXT_CLASS CWareHouseSalePoint : public CFlybyItem
	{
	public:
		CWareHouseSalePoint();
		CWareHouseSalePoint(const CWareHouseSalePoint&);
	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 19; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return WSPID; }

	public:
		BEGIN_COLUMN_MAP(CWareHouseSalePoint)
			COLUMN_ENTRY(1, WSPID)
			COLUMN_ENTRY(2, WSCustomCode)
			COLUMN_ENTRY(3, WSPName)
			COLUMN_ENTRY(4, compName)
			COLUMN_ENTRY(5, WSPCheif)
			COLUMN_ENTRY(6, WSPPhoneNum)
			COLUMN_ENTRY(7, WSPFaxNum)
			COLUMN_ENTRY(8, WSPhEmail)
			COLUMN_ENTRY(9, WSPPostCode)
			COLUMN_ENTRY(10, WSPAddress)
			COLUMN_ENTRY(11, WSPIsUsing)
			COLUMN_ENTRY(12, WSPIsSalesPoint)
			COLUMN_ENTRY(13, WSMemo)
			COLUMN_ENTRY(14, JM)
			COLUMN_ENTRY(15, CreateDate)
			COLUMN_ENTRY(16, ModifyDate)
			COLUMN_ENTRY(17, CreatedUser)
			COLUMN_ENTRY(18, ModifierUser)
			COLUMN_ENTRY(19, compID)
		END_COLUMN_MAP()

	private:
		GUID WSPID;					//�ⷿ/���۵����
		OLECHAR WSCustomCode[20];	//�ⷿ�Զ������
		OLECHAR WSPName[100];		//�ⷿ/���۵�����
		OLECHAR compName[100];		//��˾����
		OLECHAR WSPCheif[60];		//�ⷿ/���۵㸺����
		OLECHAR WSPPhoneNum[255];	//�ⷿ/���۵�绰����
		OLECHAR WSPFaxNum[255];		//�ⷿ/���۵㴫�����
		OLECHAR WSPhEmail[60];		//�ⷿ/���۵���ʵ�ַ
		OLECHAR WSPPostCode[7];		//�ⷿ/���۵��ʱ�
		OLECHAR WSPAddress[120];	//�ⷿ/���۵���ϵ��ַ
		BOOL WSPIsUsing;			//�ⷿ/���۵�����״̬
		BOOL WSPIsSalesPoint;		//�ⷿ/���۵��Ƿ�Ϊ���۵�
		OLECHAR WSMemo[255];		//�ⷿ/���۵㱸ע
		OLECHAR JM[100];			//����

		CComVariant CreateDate;
		CComVariant ModifyDate;
		GUID CreatedUser;
		GUID ModifierUser;
		GUID compID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CWareHouseSalePoint& WSPInfo);
		friend STDInStream& operator >> (STDInStream& is, CWareHouseSalePoint& WSPInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CWareHouseSalePoint& WSPInfo);
	STDInStream& operator >> (STDInStream& is, CWareHouseSalePoint& WSPInfo);

	class AFX_EXT_CLASS CWareHouseSalePointVector : public CFlybyData
	{
	public:
		CWareHouseSalePointVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewWHSPInfo");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CWareHouseSalePoint().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CWareHouseSalePoint().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CWareHouseSalePoint>(new CWareHouseSalePoint()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA
