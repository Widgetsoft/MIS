#include "stdafx.h"
#include "FlybyData.h"
#include "CardVIPTypes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CCardVIPTypes::CCardVIPTypes()
{
	CoCreateGuid(&CTID);
	ocscpy_s(CTCustomCode, _countof(CTCustomCode), OLESTR(""));
	ocscpy_s(CTName, _countof(CTName), OLESTR(""));
	DepositRate = { 0 };
	SalesRate = { 0 };
	ServiceRate = { 0 };
	IntegralRate = { 0 };
	ocscpy_s(CTMemo, _countof(CTName), OLESTR(""));
	State = Initial;
}

CCardVIPTypes::CCardVIPTypes(const CCardVIPTypes& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CCardVIPTypes::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CCardVIPTypes(*this);
	}
}

CString CCardVIPTypes::GetCellText(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet = __super::FormatGUID(CTID);
		break;
	case 1:
		strRet.Format(_T("%s"), CTCustomCode);
		break;
	case 2:
		strRet.Format(_T("%s"), CTName);
		break;
	case 3:
		strRet.Format(_T("%.6f"), DepositRate);
		break;
	case 4:
		strRet.Format(_T("%.6f"), SalesRate);
		break;
	case 5:
		strRet.Format(_T("%.6f"), ServiceRate);
		break;
	case 6:
		strRet.Format(_T("%.6f"), IntegralRate);
		break;
	case 7:
		strRet.Format(_T("%s"), CTMemo);
		break;
	}
	return strRet;
}

CString CCardVIPTypes::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�ȼ�����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�ȼ�����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��ֵ�Ż�"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�����Ż�"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�ײ��Ż�"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("�����Ż�"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�ȼ���ע"));
		break;
	}
	return strRet;
}

BOOL CCardVIPTypes::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	CString strTemp(strText);
	double dblRate = { 0 };
	if (nCol > 2 && nCol < 7)
	{
		TCHAR* pstrEnd;
		dblRate = _tcstod(strTemp, &pstrEnd);
	}
	switch (nCol)
	{
	case 0:
		{
			LPOLESTR strID = strTemp.AllocSysString();
			if (FAILED(IIDFromString(strID, &CTID)))
			{
				bRet = FALSE;
			}
		}
	break;
	case 1:
		ocscpy_s(CTCustomCode, _countof(CTCustomCode), Truncate(strTemp, _countof(CTCustomCode) + 1));
		break;
	case 2:
		ocscpy_s(CTName, _countof(CTName), Truncate(strTemp, _countof(CTName) + 1));
		break;
	case 3:
		DepositRate = dblRate;
		break;
	case 4:
		SalesRate = dblRate;
		break;
	case 5:
		ServiceRate = dblRate;
		break;
	case 6:
		IntegralRate = dblRate;
		break;
	case 7:
		ocscpy_s(CTMemo, _countof(CTMemo), Truncate(strTemp, _countof(CTMemo) + 1));
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CCardVIPTypes& itemInfo)
{
	UINT ui = 0;
	for (; ui != itemInfo.GetColCount() - 1; ui++)
	{
		os << itemInfo.GetCellText(ui) << _T("��");
	}
	os << itemInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CCardVIPTypes& itemInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			itemInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
