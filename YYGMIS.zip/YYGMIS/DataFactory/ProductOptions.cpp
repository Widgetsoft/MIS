#include "stdafx.h"
#include "FlybyData.h"
#include "ProductOptions.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CProductOptions::CProductOptions()
{
	CoCreateGuid(&POID);
	ocscpy_s(POName, _countof(POName), OLESTR(""));
	ocscpy_s(PODescription, _countof(PODescription), OLESTR(""));
	ocscpy_s(POMemo, _countof(POMemo), OLESTR(""));
	ocscpy_s(POJM, _countof(POJM), OLESTR(""));
	ocscpy_s(PSCategory, _countof(PSCategory), OLESTR(""));

	COleDateTime timeNow;
	timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;

	State = Initial;
}

CProductOptions::CProductOptions(const CProductOptions& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CProductOptions::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CProductOptions(*this);
	}
}

CString CProductOptions::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), PSCategory);
		break;
	case 2:
		strRet.Format(_T("%s"), POName);
		break;
	case 3:
		strRet.Format(_T("%s"), PODescription);
		break;
	case 4:
		strRet.Format(_T("%s"), POMemo);
		break;
	case 5:
		strRet.Format(_T("%s"), POJM);
		break;
	case 6:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 7:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = POID;
		break;
	case 8:
		idRet = CreatedUser;
		break;
	case 9:
		idRet = ModifierUser;
		break;
	}

	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}

	return strRet;
}

CString CProductOptions::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��Ŀ����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��Ŀ����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��Ŀ����"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("��Ŀ��ע"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("��Ŀ����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�����˱���"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�޸��˱���"));
		break;
	}
	return strRet;
}

BOOL CProductOptions::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;

	CString strTemp(strText);

	if (nCol == 0 || (nCol > 7 && nCol < 10))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 6 || nCol == 7)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}

	switch (nCol)
	{
	case 0:
		POID = idTemp;
		break;
	case 1:
		ocscpy_s(PSCategory, _countof(PSCategory), Truncate(strTemp, _countof(PSCategory) + 1));
		break;
	case 2:
		ocscpy_s(POName, _countof(POName), Truncate(strTemp, _countof(POName) + 1));
		break;
	case 3:
		ocscpy_s(PODescription, _countof(PODescription), Truncate(strTemp, _countof(PODescription) + 1));
		break;
	case 4:
		ocscpy_s(POMemo, _countof(POMemo), Truncate(strTemp, _countof(POMemo) + 1));
		break;
	case 5:
		ocscpy_s(POJM, _countof(POJM), Truncate(strTemp, _countof(POJM) + 1));
		break;
	case 6:
		CreateDate.date = dtTemp;
		break;
	case 7:
		ModifyDate.date = dtTemp;
		break;
	case 8:
		CreatedUser = idTemp;
		break;
	case 9:
		ModifierUser = idTemp;
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CProductOptions& itemInfo)
{
	UINT ui = 0;
	for (; ui != itemInfo.GetColCount() - 1; ui++)
	{
		os << itemInfo.GetCellText(ui) << _T("��");
	}
	os << itemInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CProductOptions& itemInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			itemInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}