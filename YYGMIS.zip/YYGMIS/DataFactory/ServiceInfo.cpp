#include "stdafx.h"
#include "FlybyData.h"
#include "ServiceInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CServiceInfo::CServiceInfo()
{
	CoCreateGuid(&ServiceID);
	ocscpy_s(ServiceCustomCode, _countof(ServiceCustomCode), OLESTR(""));
	ocscpy_s(ServiceName, _countof(ServiceName), OLESTR(""));
	ocscpy_s(ServiceType, _countof(ServiceType), OLESTR(""));
	ocscpy_s(ServiceSpec, _countof(ServiceSpec), OLESTR(""));
	ocscpy_s(ServiceUnit1, _countof(ServiceUnit1), OLESTR(""));
	ocscpy_s(ServiceUnit2, _countof(ServiceUnit2), OLESTR(""));
	Service1To2Rate = { 0 };
	ServicePrice = { 0 };
	ocscpy_s(EIName, _countof(EIName), OLESTR(""));

	IsTimeCount = TRUE;
	IsDiscount = TRUE;
	IsIntegral = TRUE;
	AsGift = TRUE;
	IsUsing = TRUE;

	ocscpy_s(ServiceMemo, _countof(ServiceMemo), OLESTR(""));
	ocscpy_s(JM, _countof(JM), OLESTR(""));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	TypeID = GUID_NULL;
	SpecID = GUID_NULL;
	UnitID1 = GUID_NULL;
	UnitID2 = GUID_NULL;
	EIID = GUID_NULL;
	compID = GUID_NULL;

	State = Initial;
}


CServiceInfo::CServiceInfo(const CServiceInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CServiceInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), ServiceCustomCode);
		break;
	case 2:
		strRet.Format(_T("%s"), ServiceName);
		break;
	case 3:
		strRet.Format(_T("%s"), ServiceType);
		break;
	case 4:
		strRet.Format(_T("%s"), ServiceSpec);
		break;
	case 5:
		strRet.Format(_T("%s"), ServiceUnit1);
		break;
	case 6:
		strRet.Format(_T("%s"), ServiceUnit2);
		break;
	case 7:
		strRet.Format(_T("%.6f"), Service1To2Rate);
		break;
	case 8:
		strRet.Format(_T("%.2f"), ServicePrice);
		break;
	case 9:
		strRet.Format(_T("%s"), EIName);
		break;
	case 10:
		strRet.Format(_T("%s"), IsTimeCount ? _T("��ʱ") : _T("�Ƽ�"));
		break;
	case 11:
		strRet.Format(_T("%s"), IsDiscount ? _T("�ɴ���") : _T("������"));
		break;
	case 12:
		strRet.Format(_T("%s"), IsIntegral ? _T("�ɻ���") : _T("������"));
		break;
	case 13:
		strRet.Format(_T("%s"), AsGift ? _T("������") : _T("��������"));
		break;
	case 14:
		strRet.Format(_T("%s"), AsGift ? _T("����") : _T("ͣ��"));
		break;
	case 15:
		strRet.Format(_T("%s"), ServiceMemo);
		break;
	case 16:
		strRet.Format(_T("%s"), JM);
		break;
	case 17:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 18:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = ServiceID;
		break;
	case 19:
		idRet = CreatedUser;
		break;
	case 20:
		idRet = ModifierUser;
		break;
	case 21:
		idRet = EIID;
		break;
	case 22:
		idRet = TypeID;
		break;
	case 23:
		idRet = SpecID;
		break;
	case 24:
		idRet = UnitID1;
		break;
	case 25:
		idRet = UnitID2;
		break;
	case 26:
		idRet = compID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CServiceInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�ڲ�����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�ײ�����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("�ײ�����"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�ײ͹��"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�Ʒѵ�λ"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("������λ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("��λϵ��"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�ײͼ۸�"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�����豸"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("�Ʒѷ�ʽ"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("�����Ż�"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("ʹ��״̬"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�ײ�����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("�ײͼ���"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 19:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 20:
		strRet.Format(_T("%s"), _T("�޸���"));
		break;
	case 21:
		strRet.Format(_T("%s"), _T("�����豸����"));
		break;
	case 22:
		strRet.Format(_T("%s"), _T("�ײ����ͱ���"));
		break;
	case 23:
		strRet.Format(_T("%s"), _T("�ײ͹�����"));
		break;
	case 24:
		strRet.Format(_T("%s"), _T("��������λ����"));
		break;
	case 25:
		strRet.Format(_T("%s"), _T("��������λ����"));
		break;
	case 26:
		strRet.Format(_T("%s"), _T("������˾����"));
		break;
	}
	return strRet;
}

BOOL CServiceInfo::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	double dblTemp = { 0 };
	int nTemp = 0;
	if (nCol == 0 || (nCol >= 19 && nCol <= 26))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 17 || nCol == 18)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 7 || nCol == 8)
	{
		TCHAR* pstrStop;
		dblTemp = _tcstod(strTemp, &pstrStop);
	}

	switch (nCol)
	{
	case 0:
		ServiceID = idTemp;
		break;
	case 1:
		_tcscpy_s(ServiceCustomCode, _countof(ServiceCustomCode), Truncate(strTemp, _countof(ServiceCustomCode) + 1));
		break;
	case 2:
		_tcscpy_s(ServiceName, _countof(ServiceName), Truncate(strTemp, _countof(ServiceName) + 1));
		break;
	case 3:
		_tcscpy_s(ServiceType, _countof(ServiceType), Truncate(strTemp, _countof(ServiceType) + 1));
		break;
	case 4:
		_tcscpy_s(ServiceSpec, _countof(ServiceSpec), Truncate(strTemp, _countof(ServiceSpec) + 1));
		break;
	case 5:
		_tcscpy_s(ServiceUnit1, _countof(ServiceUnit1), Truncate(strTemp, _countof(ServiceUnit1) + 1));
		break;
	case 6:
		_tcscpy_s(ServiceUnit2, _countof(ServiceUnit2), Truncate(strTemp, _countof(ServiceUnit2) + 1));
		break;
	case 7:
		Service1To2Rate = dblTemp;
		break;
	case 8:
		ServicePrice = nTemp;
		break;
	case 9:
		_tcscpy_s(EIName, _countof(EIName), Truncate(strTemp, _countof(EIName) + 1));
		break;
	case 10:
		IsTimeCount = (strTemp.Compare(_T("��ʱ")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 11:
		IsDiscount = (strTemp.Compare(_T("�ɴ���")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 12:
		IsIntegral = (strTemp.Compare(_T("�ɻ���")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 13:
		AsGift = (strTemp.Compare(_T("������")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 14:
		IsUsing = (strTemp.Compare(_T("����")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 15:
		_tcscpy_s(ServiceMemo, _countof(ServiceMemo), Truncate(strTemp, _countof(ServiceMemo) + 1));
		break;
	case 16:
		_tcscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 17:
		CreateDate.date = dtTemp;
		break;
	case 18:
		ModifyDate.date = dtTemp;
		break;
	case 19:
		CreatedUser = idTemp;
		break;
	case 20:
		ModifierUser = idTemp;
		break;
	case 21:
		EIID = idTemp;
		break;
	case 22:
		TypeID = idTemp;
		break;
	case 23:
		SpecID = idTemp;
		break;
	case 24:
		UnitID1 = idTemp;
		break;
	case 25:
		UnitID2 = idTemp;
		break;
	case 26:
		compID = idTemp;
		break;
	}
	return bRet;
}

void CServiceInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CServiceInfo(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CServiceInfo& ProdInfo)
{
	UINT ui = 0;
	for (; ui != ProdInfo.GetColCount() - 1; ui++)
	{
		os << ProdInfo.GetCellText(ui) << _T("��");
	}
	os << ProdInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CServiceInfo& ProdInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			ProdInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

