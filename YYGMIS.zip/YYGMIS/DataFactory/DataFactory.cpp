// DataFactory.cpp : ���� DLL �ĳ�ʼ�����̡�
//

#include "stdafx.h"
#include "DataFactory.h"

#include <afxwin.h>
#include <afxdllx.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

static AFX_EXTENSION_MODULE DataFactoryDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// ���ʹ�� lpReserved���뽫���Ƴ�
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("DataFactory.DLL ���ڳ�ʼ��!\n");

		// ��չ DLL һ���Գ�ʼ��
		if (!AfxInitExtensionModule(DataFactoryDLL, hInstance))
			return 0;

		// ���� DLL ���뵽��Դ����
		// ע��:  �������չ DLL ��
		//  MFC ���� DLL (�� ActiveX �ؼ�)��ʽ���ӵ���
		//  �������� MFC Ӧ�ó������ӵ�������Ҫ
		//  �����д� DllMain ���Ƴ������������һ��
		//  �Ӵ���չ DLL �����ĵ����ĺ����С�  ʹ�ô���չ DLL ��
		//  ���� DLL Ȼ��Ӧ��ʽ
		//  ���øú����Գ�ʼ������չ DLL��  ����
		//  CDynLinkLibrary ���󲻻ḽ�ӵ�
		//  ���� DLL ����Դ���������������ص�
		//  ���⡣

		new CDynLinkLibrary(DataFactoryDLL);

	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("DataFactory.DLL ������ֹ!\n");

		// �ڵ�����������֮ǰ��ֹ�ÿ�
		AfxTermExtensionModule(DataFactoryDLL);
	}
	return 1;   // ȷ��
}

#include "SQLite3Unicode.h"

using namespace Database;

CDataFactory::CDataFactory(LPCTSTR strPath)
	: m_mutex(FALSE, nullptr)
{
	m_pDB = new CSQLite3Unicode();
	CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
	try
	{
		pTempDB->open(strPath);
		m_bDBOpened = TRUE;
	}
	catch (CSQLite3Exception&)
	{
		m_bDBOpened = FALSE;
	}

}

CDataFactory::~CDataFactory()
{
	if (m_bDBOpened)
	{
		CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
		try
		{
			pTempDB->close();
		}
		catch (CSQLite3Exception&)
		{
		}
	}
	delete m_pDB;
}

////////////////////////////////////////////
//Member Functions 

BOOL CDataFactory::ExecuteNonQuery(PCTSTR strSQL)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
		try
		{
			int iRet = pTempDB->execDML(strSQL);
			if (iRet == SQLITE_OK)
			{
				bRet = TRUE;
			}
		}
		catch (CSQLite3Exception& ex)
		{
			MessageBox(nullptr, ex.errorMessage(), nullptr, MB_OK | MB_ICONERROR);
		}
	}
	return bRet;
}

BOOL CDataFactory::ExecuteNonQueryBatch(PVOID pvCommands, BOOL bStdString)
{
	BOOL bRet = FALSE;
	StringVector* pSQLBatch = nullptr;
	if (bStdString)
	{
		pSQLBatch = new StringVector();
		STDStringVector* pVectorTemp = reinterpret_cast<STDStringVector*>(pvCommands);
		ASSERT(pVectorTemp != nullptr);
		for (int i = 0; i != pVectorTemp->size(); i++)
		{
			pSQLBatch->push_back(pVectorTemp->at(i).c_str());
		}
	}
	else
	{
		pSQLBatch = reinterpret_cast<StringVector*>(pvCommands);
	}
	ASSERT(pSQLBatch != nullptr);
	auto argsSQL = *pSQLBatch;
	if (argsSQL.size() > 0 && m_bDBOpened)
	{
		CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
		BOOL bTransAgain = FALSE;
		int RollbackLine = 0;
		try
		{
			int nState = pTempDB->execDML(_T("begin;"));
			bTransAgain = (nState == SQLITE_OK);
			BOOL bSucccess = TRUE;
			if (bTransAgain)
			{
				for (int n = 0; n != argsSQL.size(); n++)
				{
					RollbackLine = n;
					nState = pTempDB->execDML(argsSQL.at(n));
					bSucccess = bSucccess && (nState == SQLITE_OK);
					if (!bSucccess)
					{
						break;
					}
				}
				if (bSucccess)
				{
					bRet = bSucccess;
					pTempDB->execDML(_T("commit;"));
				}
				else
				{
					bTransAgain = FALSE;
					pTempDB->execDML(_T("rollback;"));
				}
			}
		}
		catch (CSQLite3Exception& ex)
		{
			if (bTransAgain)
			{
				pTempDB->execDML(_T("rollback;"));
			}
			TCHAR tcsErrMessage[MAX_PATH * 4];
			_stprintf_s(tcsErrMessage, _countof(tcsErrMessage), _T("��%i�г�������������Ϊ:%s��"), RollbackLine, ex.errorMessage());
			MessageBox(nullptr, tcsErrMessage, nullptr, MB_OK | MB_ICONERROR);
		}

	}
	if (bStdString && pSQLBatch)
	{
		delete pSQLBatch;
	}
	return bRet;
}

BOOL CDataFactory::NormalQuery(CString strQuery, PVOID *ppRet,
	BOOL bContainsTitle)
{
	BOOL bRet = FALSE;
	if (ppRet == nullptr)
	{
		return bRet;
	}
	auto ppRetTable = reinterpret_cast<PStrVector**>(ppRet);
	ASSERT(ppRetTable != nullptr);
	*ppRetTable = new PStrVector();
	if (m_bDBOpened)
	{
		CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
		try
		{
			CSQLite3Query query = pTempDB->execQuery(strQuery);
			int nCol = query.numFields();
			if (bContainsTitle)
			{
				std::auto_ptr< StringVector > atpRow(new StringVector());
				for (int i = 0; i != nCol; i++)
				{
					atpRow->push_back(query.fieldName(i));
				}
				(*ppRetTable)->push_back(atpRow.release());
			}
			while (!query.eof())
			{
				std::auto_ptr< StringVector >
					atpRow(new StringVector());
				for (int i = 0; i != nCol; i++)
				{
					atpRow->push_back(query.fieldValue(i));
				}
				(*ppRetTable)->push_back(atpRow.release());
				query.nextRow();
			}
			bRet = TRUE;
		}
		catch (CSQLite3Exception& ex)
		{
			MessageBox(nullptr, ex.errorMessage(), nullptr, MB_OK | MB_ICONERROR);
		}
	}
	return bRet;
}

BOOL CDataFactory::NormalGetItemsData(CString strQuery, GenerialPattern::CItemsData** ppItem, BOOL bBatch)
{
	BOOL bRet = FALSE;
	if (ppItem == nullptr)
	{
		return bRet;
	}
	*ppItem = std::auto_ptr<GenerialPattern::CItemsData>(new GenerialPattern::CItemsData()).release();
	if (m_bDBOpened)
	{
		CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
		try
		{
			if (bBatch)
			{
				int nItem = 0;
				Concurrency::concurrent_vector< CString >  strQuerys;
				Split(strQuery.AllocSysString(), _T(";"), &strQuerys);
				size_t nSize = strQuerys.size();
				bRet = true;
				for (int iOuter = 0; iOuter != nSize; iOuter++)
				{
					CSQLite3Query query = pTempDB->execQuery(strQuerys.at(iOuter));
					int nCol = query.numFields();
					GenerialPattern::CItemData* pItemData = new GenerialPattern::CItemData();
					while (!query.eof())
					{
						for (int i = 0; i != nCol; i++)
						{
							pItemData->push_back(query.fieldValue(i));
						}
						query.nextRow();
					}
					(*ppItem)->AddItemData(nItem, pItemData);
					nItem++;
					bRet = bRet && TRUE;
				}
			}
			else
			{
				CSQLite3Query query = pTempDB->execQuery(strQuery);
				int nCol = query.numFields();
				int nItem = 0;
				while (!query.eof())
				{
					std::auto_ptr<GenerialPattern::CItemData> apItemData(new GenerialPattern::CItemData());
					for (int i = 0; i != nCol; i++)
					{
						apItemData->push_back(query.fieldValue(i));
					}
					(*ppItem)->AddItemData(nItem, apItemData.release());
					query.nextRow();
					nItem++;
				}
				bRet = TRUE;
			}
		}
		catch (CSQLite3Exception& ex)
		{
			//ex;
			MessageBox(nullptr, ex.errorMessage(), nullptr, MB_OK | MB_ICONERROR);
		}
	}
	return bRet;
}

BOOL CDataFactory::NormalGetItemData(CString strQuery, GenerialPattern::CItemData** ppItem)
{
	BOOL bRet = FALSE;
	if (ppItem == nullptr)
	{
		return bRet;
	}
	*ppItem = std::auto_ptr<GenerialPattern::CItemData>(new GenerialPattern::CItemData()).release();
	if (m_bDBOpened)
	{
		CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
		try
		{
			CSQLite3Query query = pTempDB->execQuery(strQuery);
			int nCol = query.numFields();
			int nItem = 0;
			while (!query.eof() && nItem < 2)
			{
				for (int i = 0; i != nCol; i++)
				{
					(*ppItem)->push_back(query.fieldValue(i));
				}
				query.nextRow();
				nItem++;
			}
			bRet = TRUE;
		}
		catch (CSQLite3Exception& ex)
		{
			ex;
			//MessageBox( nullptr, ex.errorMessage(), nullptr, MB_OK | MB_ICONERROR );
		}
	}
	return bRet;
}

template<typename DynamicItem >
BOOL LocalQuery(PCTSTR strSQL, CFlybyData* pOutRector, PVOID m_pDB)
{
	BOOL bRet = FALSE;
	__if_not_exists(DynamicItem::GetItemID)
	{
		return bRet;
	}
	CSingleLock localLock(&pOutRector->m_mutex);
	localLock.Lock();
	pOutRector->ClearItems();
	CSQLite3Unicode* pTempDB = reinterpret_cast<CSQLite3Unicode*>(m_pDB);
	try
	{
		CSQLite3Query query = pTempDB->execQuery(strSQL);
		while (!query.eof())
		{
			DynamicItem* pItem = new DynamicItem();
			for (int n = 0; n != query.numFields(); n++)
			{
				pItem->SetCellText(n, query.fieldValue(n));
			}
			pOutRector->AddItem(pItem);
			query.nextRow();
		}
		bRet = TRUE;
	}
	catch (CSQLite3Exception& ex)
	{
		MessageBox(nullptr, ex.errorMessage(), ex.errorCodeAsString(ex.errorCode()), MB_OK);
		pOutRector->ClearItems();
	}
	localLock.Unlock();
	return bRet;
}


//��ȡѡ����Ŀ
BOOL CDataFactory::GetItemOptions(PCTSTR strSQL, CItemOptionsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CItemOptions>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ��ҵ��Ϣ
BOOL CDataFactory::GetEnterpriseInfo(PCTSTR strSQL, CEnterpriseInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery< CEnterpriseInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�ⷿ��Ϣ��¼����
BOOL CDataFactory::GetWareHouseSalePoint(PCTSTR strSQL, CWareHouseSalePointVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery< CWareHouseSalePoint>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ������Ϣ
BOOL CDataFactory::GetAgencyInfo(PCTSTR strSQL, CAgencyInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CAgencyInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡְ����Ϣ
BOOL CDataFactory::GetStaffInfo(PCTSTR strSQL, CStaffInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CStaffInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�˿���Ϣ
BOOL CDataFactory::GetCustomerInfo(PCTSTR strSQL, CCustomerInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CCustomerInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ��Ա���ȼ���¼����
BOOL CDataFactory::GetCardVIPTypes(PCTSTR strSQL, CCardVIPTypesVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CCardVIPTypes>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ��Ա����Ϣ��¼����
BOOL CDataFactory::GetCardInfo(PCTSTR strSQL, CCardInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CCardInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�����ѡ����ּ�¼����
BOOL CDataFactory::GetCardUIRecord(PCTSTR strSQL, CCardUIRecordVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CCardUIRecord>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ��Ʒ������ѡ���
BOOL CDataFactory::GetProductOptions(PCTSTR strSQL, CProductOptionsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CProductOptions>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ��Ʒ��Ϣ��¼����
BOOL CDataFactory::GetProductInfo(PCTSTR strSQL, CProductInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CProductInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�豸��Ϣ��¼����
BOOL CDataFactory::GetEquipmentInfo(PCTSTR strSQL, CEquipmentInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CEquipmentInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�ײ���Ϣ��¼����
BOOL CDataFactory::GetServiceInfo(PCTSTR strSQL, CServiceInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CServiceInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ��Ʒ��������Ϣ
BOOL CDataFactory::GetInventories(PCTSTR strSQL, CInventoriesVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CInventories>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡδ��������Ʒ�����Ϣ�б�
BOOL CDataFactory::GetInventoriesSel(PCTSTR strSQL, CInventoriesSelVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CInventoriesSel>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ����¼����
BOOL CDataFactory::GetStockFlow(PCTSTR strSQL, CStockFlowVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CStockFlow>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ����굥��¼����
BOOL CDataFactory::GetStockFlowDetails(PCTSTR strSQL, CStockFlowDetailsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CStockFlowDetails>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�����¼����
BOOL CDataFactory::GetServiceFlow(PCTSTR strSQL, CServiceFlowVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery< CServiceFlow>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�����굥��¼����
BOOL CDataFactory::GetServiceFlowDetails(PCTSTR strSQL, CServiceFlowDetailsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CServiceFlowDetails>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ���ۼ�¼����
BOOL CDataFactory::GetSalesFlow(PCTSTR strSQL, CSalesFlowVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CSalesFlow>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}
//��ȡ�����굥��¼����
BOOL CDataFactory::GetSalesFlowDetails(PCTSTR strSQL, CSalesFlowDetailsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CSalesFlowDetails>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�����¼����
BOOL CDataFactory::GetPaymentFlow(PCTSTR strSQL, CPaymentFlowVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CPaymentFlow>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�����굥��¼����
BOOL CDataFactory::GetPaymentFlowDetails(PCTSTR strSQL, CPaymentFlowDetailsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CPaymentFlowDetails>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�̵��¼����
BOOL CDataFactory::GetCheckFlow(PCTSTR strSQL, CCheckFlowVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CCheckFlow>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

//��ȡ�̵��굥��¼����
BOOL CDataFactory::GetCheckFlowDetails(PCTSTR strSQL, CCheckFlowDetailsVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CCheckFlowDetails>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}

BOOL CDataFactory::GetSystemInfo(PCTSTR strSQL, CYYGMISSystemInfoVector& outRector)
{
	BOOL bRet = FALSE;
	if (m_bDBOpened)
	{
		bRet = LocalQuery<CYYGMISSystemInfo>(strSQL, &outRector, m_pDB);
	}
	return bRet;
}