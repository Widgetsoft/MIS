#pragma once
namespace Database
{
	//���ҵ����
	class AFX_EXT_CLASS CStockFlow : public CFlybyItem
	{
	public:
		CStockFlow();
		CStockFlow(const CStockFlow&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 21; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return StockID; }

	public:
		BEGIN_COLUMN_MAP(CStockFlow)
			COLUMN_ENTRY(1, StockID)
			COLUMN_ENTRY(2, StockCustomID)
			COLUMN_ENTRY(3, StockDate)
			COLUMN_ENTRY(4, StockMan)
			COLUMN_ENTRY(5, Warehouse)
			COLUMN_ENTRY(6, StockDescripion)
			COLUMN_ENTRY(7, Quantity)
			COLUMN_ENTRY(8, Amount)
			COLUMN_ENTRY(9, IsCheckOut)
			COLUMN_ENTRY(10, CheckoutMan)
			COLUMN_ENTRY(11, Memo)
			COLUMN_ENTRY(12, IsStockIn)
			COLUMN_ENTRY(13, CreateDate)
			COLUMN_ENTRY(14, ModifyDate)
			COLUMN_ENTRY(15, CheckOutDate)
			COLUMN_ENTRY(16, CreatedUser)
			COLUMN_ENTRY(17, ModifierUser)
			COLUMN_ENTRY(18, CheckoutManID)
			COLUMN_ENTRY(19, StockManID)
			COLUMN_ENTRY(20, StockSourceID)
			COLUMN_ENTRY(21, WarehouseID)
		END_COLUMN_MAP()

	private:
		GUID StockID;					//�����
		OLECHAR StockCustomID[17];	    //����Զ�����
		CComVariant StockDate;			//���ʱ��
		OLECHAR	StockMan[20];			//������
		OLECHAR	Warehouse[100];			//�ֿ�����
		OLECHAR StockDescripion[20];	//������� ��ɹ����
		double  Quantity;				//�������
		double	Amount;					//�����
		BOOL	IsCheckOut;				//�Ƿ����
		OLECHAR CheckoutMan[20];		//�����
		OLECHAR Memo[MAX_PATH];			//��汸ע

		BOOL	IsStockIn;				//���⡢���

		CComVariant CreateDate;			//��������
		CComVariant ModifyDate;			//�޸�����
		CComVariant CheckOutDate;		//�������
		GUID		CreatedUser;		//�����û�
		GUID		ModifierUser;		//�޸��û�
		GUID		CheckoutManID;		//����˱���

		GUID	StockManID;				//�����˱���
		GUID	StockSourceID;			//��Դ����
		GUID	WarehouseID;			//�ⷿ����

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CStockFlow& sfInfo);
		friend STDInStream& operator >> (STDInStream& is, CStockFlow& sfInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CStockFlow& sfInfo);
	STDInStream& operator >> (STDInStream& is, CStockFlow& sfInfo);

	class AFX_EXT_CLASS CStockFlowVector : public CFlybyData
	{
	public:
		CStockFlowVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewStockFlow");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CStockFlow().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CStockFlow().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CStockFlow>(new CStockFlow()).release(); }
	};

	//���ҵ����
	class AFX_EXT_CLASS CStockFlowDetails : public CFlybyItem
	{
	public:
		CStockFlowDetails();
		CStockFlowDetails(const CStockFlowDetails&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 11; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return SDID; }

	public:
		BEGIN_COLUMN_MAP(CStockFlowDetails)
			COLUMN_ENTRY(1, SDID)
			COLUMN_ENTRY(2, ProductName)
			COLUMN_ENTRY(3, ProductType)
			COLUMN_ENTRY(4, SpecName)
			COLUMN_ENTRY(5, Price)
			COLUMN_ENTRY(6, Quantity)
			COLUMN_ENTRY(7, ProductUnit)
			COLUMN_ENTRY(8, Amount)
			COLUMN_ENTRY(9, Memo)
			COLUMN_ENTRY(10, ProdID)
			COLUMN_ENTRY(11, StoreID)
		END_COLUMN_MAP()

	private:
		GUID SDID;
		OLECHAR		ProductName[60];	//��Ʒ����
		OLECHAR		ProductType[40];	//��Ʒ���
		OLECHAR		SpecName[40];		//��Ʒ���
		double		Price;				//����
		double		Quantity;			//�������
		OLECHAR		ProductUnit[40];	//������λ
		double		Amount;				//�����
		OLECHAR		Memo[MAX_PATH];		//��汸ע

		GUID ProdID;
		GUID StoreID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CStockFlowDetails& sfdInfo);
		friend STDInStream& operator >> (STDInStream& is, CStockFlowDetails& sfdInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CStockFlowDetails& sfdInfo);
	STDInStream& operator >> (STDInStream& is, CStockFlowDetails& sfdInfo);

	class AFX_EXT_CLASS CStockFlowDetailsVector : public CFlybyData
	{
	public:
		CStockFlowDetailsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewStockFlowDetails");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CStockFlowDetails().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CStockFlowDetails().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CStockFlowDetails>(new CStockFlowDetails()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA

