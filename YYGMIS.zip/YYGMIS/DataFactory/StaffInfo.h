#pragma once
namespace Database
{
	class AFX_EXT_CLASS CStaffInfo : public CFlybyItem
	{
	public:
		CStaffInfo();
		CStaffInfo(const CStaffInfo& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 34; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return EID; }
	public:
		BEGIN_COLUMN_MAP(CStaffInfo)
			COLUMN_ENTRY(1, EID)
			COLUMN_ENTRY(2, EName)
			COLUMN_ENTRY(3, deptName)
			COLUMN_ENTRY(4, ESex)
			COLUMN_ENTRY(5, ETitle)
			COLUMN_ENTRY(6, EDuty)
			COLUMN_ENTRY(7, ESalary)
			COLUMN_ENTRY(8, EDegree)
			COLUMN_ENTRY(9, EBirthday)
			COLUMN_ENTRY(10, EPID)
			COLUMN_ENTRY(11, EEmail)
			COLUMN_ENTRY(12, EPhoneNum)
			COLUMN_ENTRY(13, EPostCode)
			COLUMN_ENTRY(14, EAddress)
			COLUMN_ENTRY(15, EMemo)
			COLUMN_ENTRY(16, JM)
			COLUMN_ENTRY(17, UID)
			COLUMN_ENTRY(18, EPassword)
			COLUMN_ENTRY(19, EIsOperator)
			COLUMN_ENTRY(20, EIsAdjusting)
			COLUMN_ENTRY(21, EIsRollBack)
			COLUMN_ENTRY(22, EIsPurchase)
			COLUMN_ENTRY(23, EIsSales)
			COLUMN_ENTRY(24, EIsStoreIn)
			COLUMN_ENTRY(25, EIsStoreOut)
			COLUMN_ENTRY(26, EIsUsing)
			COLUMN_ENTRY(27, CreateDate)
			COLUMN_ENTRY(28, ModifyDate)
			COLUMN_ENTRY(29, ETitleID)
			COLUMN_ENTRY(30, EDutyID)
			COLUMN_ENTRY(31, EDegreeID)
			COLUMN_ENTRY(32, CreatedUser)
			COLUMN_ENTRY(33, ModifierUser)
			COLUMN_ENTRY(34, deptID)
		END_COLUMN_MAP()

	private:
		GUID EID;
		OLECHAR UID[30];
		OLECHAR EName[20];
		OLECHAR EPassword[256];
		OLECHAR deptName[100];
		OLECHAR ESex[3];
		OLECHAR ETitle[50];
		OLECHAR EDuty[50];
		double ESalary;
		OLECHAR EDegree[50];
		CComVariant EBirthday;
		OLECHAR EPID[20];
		OLECHAR EEmail[40];
		OLECHAR EPhoneNum[255];
		OLECHAR EPostCode[7];
		OLECHAR EAddress[120];
		OLECHAR EMemo[255];
		OLECHAR JM[20];

		BOOL EIsOperator;
		BOOL EIsAdjusting;
		BOOL EIsRollBack;
		BOOL EIsPurchase;
		BOOL EIsSales;
		BOOL EIsStoreIn;
		BOOL EIsStoreOut;
		BOOL EIsUsing;

		CComVariant CreateDate;
		CComVariant ModifyDate;

		GUID ETitleID;
		GUID EDutyID;
		GUID EDegreeID;
		GUID CreatedUser;
		GUID ModifierUser;
		GUID deptID;

		DataState State;

	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CStaffInfo& staffInfo);
		friend STDInStream& operator >> (STDInStream& is, CStaffInfo& staffInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CStaffInfo& staffInfo);
	STDInStream& operator >> (STDInStream& is, CStaffInfo& staffInfo);

	class AFX_EXT_CLASS CStaffInfoVector : public CFlybyData
	{
	public:
		CStaffInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewStaff");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CStaffInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CStaffInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CStaffInfo>(new CStaffInfo()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA