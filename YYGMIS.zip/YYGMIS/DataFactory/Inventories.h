#pragma once

namespace Database
{
	class AFX_EXT_CLASS CInventories : public CFlybyItem
	{
	public:
		CInventories();
		CInventories(const CInventories& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 10; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return InvID; }
	public:
		BEGIN_COLUMN_MAP(CInventories)
			COLUMN_ENTRY(1, InvID)
			COLUMN_ENTRY(2, WSPName)
			COLUMN_ENTRY(3, ProdName)
			COLUMN_ENTRY(4, ProdCustomID)
			COLUMN_ENTRY(5, ProductType)
			COLUMN_ENTRY(6, ProductSpec)
			COLUMN_ENTRY(7, ProductUnit1)
			COLUMN_ENTRY(8, StockQuantity)
			COLUMN_ENTRY(9, WSPID)
			COLUMN_ENTRY(10, ProdID)
		END_COLUMN_MAP()

	private:
		GUID InvID;
		OLECHAR WSPName[100];
		OLECHAR ProdName[60];
		OLECHAR ProdCustomID[40];
		OLECHAR ProductType[40];
		OLECHAR ProductSpec[40];
		OLECHAR ProductUnit1[40];
		double StockQuantity;
		GUID WSPID;
		GUID ProdID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CInventories& itemInfo);
		friend STDInStream& operator >> (STDInStream& is, CInventories& itemInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CInventories& itemInfo);
	STDInStream& operator >> (STDInStream& is, CInventories& itemInfo);

	class AFX_EXT_CLASS CInventoriesVector : public CFlybyData
	{
	public:
		CInventoriesVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewInventories");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CInventories().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CInventories().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CInventories>(new CInventories()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA