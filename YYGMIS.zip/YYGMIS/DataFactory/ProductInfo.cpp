#include "StdAfx.h"
#include "FlybyData.h"
#include "ProductInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CProductInfo::CProductInfo()
{
	CoCreateGuid(&ProdID);
	ocscpy_s(ProdName, _countof(ProdName), OLESTR(""));
	ocscpy_s(ProdCustomID, _countof(ProdCustomID), OLESTR(""));
	ocscpy_s(ProductType, _countof(ProductType), OLESTR(""));
	ocscpy_s(ProductSpec, _countof(ProductSpec), OLESTR(""));
	ocscpy_s(ProductUnit1, _countof(ProductUnit1), OLESTR(""));
	ocscpy_s(ProductUnit2, _countof(ProductUnit2), OLESTR(""));
	Prod1To2Rate = { 0 };
	ProductLife = 0;
	SafeStorage = { 0 };
	ProdPurchasePrice = { 0 };
	ProdSalesPrice = { 0 };
	ocscpy_s(ProductFirm, _countof(ProductFirm), OLESTR(""));
	ocscpy_s(ProdDescription, _countof(ProdDescription), OLESTR(""));
	IsDiscount = TRUE;
	IsIntegral = TRUE;
	AsGift = TRUE;
	ocscpy_s(JM, _countof(JM), OLESTR(""));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	TypeID = GUID_NULL;
	SpecID = GUID_NULL;
	UnitID1 = GUID_NULL;
	UnitID2 = GUID_NULL;

	State = Initial;
}


CProductInfo::CProductInfo(const CProductInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CProductInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), ProdName);
		break;
	case 2:
		strRet.Format(_T("%s"), ProdCustomID);
		break;
	case 3:
		strRet.Format(_T("%s"), ProductType);
		break;
	case 4:
		strRet.Format(_T("%s"), ProductSpec);
		break;
	case 5:
		strRet.Format(_T("%s"), ProductUnit1);
		break;
	case 6:
		strRet.Format(_T("%s"), ProductUnit2);
		break;
	case 7:
		strRet.Format(_T("%.6f"), Prod1To2Rate);
		break;
	case 8:
		strRet.Format(_T("%i"), ProductLife);
		break;
	case 9:
		strRet.Format(_T("%.2f"), SafeStorage);
		break;
	case 10:
		strRet.Format(_T("%.2f"), ProdPurchasePrice);
		break;
	case 11:
		strRet.Format(_T("%.2f"), ProdSalesPrice);
		break;
	case 12:
		strRet.Format(_T("%s"), ProductFirm);
		break;
	case 13:
		strRet.Format(_T("%s"), ProdDescription);
		break;
	case 14:
		strRet.Format(_T("%s"), IsDiscount ? _T("�ɴ���") : _T("������"));
		break;
	case 15:
		strRet.Format(_T("%s"), IsIntegral ? _T("�ɻ���") : _T("������"));
		break;
	case 16:
		strRet.Format(_T("%s"), AsGift ? _T("������") : _T("������"));
		break;
	case 17:
		strRet.Format(_T("%s"), JM);
		break;
	case 18:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 19:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = ProdID;
		break;
	case 20:
		idRet = CreatedUser;
		break;
	case 21:
		idRet = ModifierUser;
		break;
	case 22:
		idRet = TypeID;
		break;
	case 23:
		idRet = SpecID;
		break;
	case 24:
		idRet = UnitID1;
		break;
	case 25:
		idRet = UnitID2;
		break;

	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CProductInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("����λ"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("������λ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("����ϵ��"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("��ȫ���"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("�ɹ���"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("���ۼ�"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("�����Ż�"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 19:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 20:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 21:
		strRet.Format(_T("%s"), _T("�޸���"));
		break;
	case 22:
		strRet.Format(_T("%s"), _T("��Ʒ���ͱ���"));
		break;
	case 23:
		strRet.Format(_T("%s"), _T("��Ʒ������"));
		break;
	case 24:
		strRet.Format(_T("%s"), _T("��������λ����"));
		break;
	case 25:
		strRet.Format(_T("%s"), _T("��������λ����"));
		break;
	}
	return strRet;
}

BOOL CProductInfo::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	double dblTemp = { 0 };
	int nTemp = 0;
	if (nCol == 0 || (nCol >= 20 && nCol <= 25))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 18 || nCol == 19)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 7 || (nCol >= 9 && nCol <= 11))
	{
		TCHAR* pstrStop;
		dblTemp = _tcstod(strTemp, &pstrStop);
	}
	else if (nCol == 8)
	{
		nTemp = _ttoi(strTemp);
	}

	switch (nCol)
	{
	case 0:
		ProdID = idTemp;
		break;
	case 1:
		_tcscpy_s(ProdName, _countof(ProdName), Truncate(strTemp, _countof(ProdName) + 1));
		break;
	case 2:
		_tcscpy_s(ProdCustomID, _countof(ProdCustomID), Truncate(strTemp, _countof(ProdCustomID) + 1));
		break;
	case 3:
		_tcscpy_s(ProductType, _countof(ProductType), Truncate(strTemp, _countof(ProductType) + 1));
		break;
	case 4:
		_tcscpy_s(ProductSpec, _countof(ProductSpec), Truncate(strTemp, _countof(ProductSpec) + 1));
		break;
	case 5:
		_tcscpy_s(ProductUnit1, _countof(ProductUnit1), Truncate(strTemp, _countof(ProductUnit1) + 1));
		break;
	case 6:
		_tcscpy_s(ProductUnit2, _countof(ProductUnit2), Truncate(strTemp, _countof(ProductUnit2) + 1));
		break;
	case 7:
		Prod1To2Rate = dblTemp;
		break;
	case 8:
		ProductLife = nTemp;
		break;
	case 9:
		SafeStorage = dblTemp;
		break;
	case 10:
		ProdPurchasePrice = dblTemp;
		break;
	case 11:
		ProdSalesPrice = dblTemp;
		break;
	case 12:
		_tcscpy_s(ProductFirm, _countof(ProductFirm), Truncate(strTemp, _countof(ProductFirm) + 1));
		break;
	case 13:
		_tcscpy_s(ProdDescription, _countof(ProdDescription), Truncate(strTemp, _countof(ProdDescription) + 1));
		break;
	case 14:
		IsDiscount = (strTemp.Compare(_T("�ɴ���")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 15:
		IsIntegral = (strTemp.Compare(_T("�ɻ���")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 16:
		AsGift = (strTemp.Compare(_T("������")) == 0 || strTemp.Compare(_T("1")) == 0);
		break;
	case 17:
		_tcscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 18:
		CreateDate.date = dtTemp;
		break;
	case 19:
		ModifyDate.date = dtTemp;
		break;
	case 20:
		CreatedUser = idTemp;
		break;
	case 21:
		ModifierUser = idTemp;
		break;
	case 22:
		TypeID = idTemp;
		break;
	case 23:
		SpecID = idTemp;
		break;
	case 24:
		UnitID1 = idTemp;
		break;
	case 25:
		UnitID2 = idTemp;
		break;

	}
	return bRet;
}

void CProductInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CProductInfo(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CProductInfo& ProdInfo)
{
	UINT ui = 0;
	for (; ui != ProdInfo.GetColCount() - 1; ui++)
	{
		os << ProdInfo.GetCellText(ui) << _T("��");
	}
	os << ProdInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CProductInfo& ProdInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			ProdInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
