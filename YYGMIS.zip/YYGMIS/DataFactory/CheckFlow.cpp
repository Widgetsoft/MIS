#include "StdAfx.h"
#include "FlybyData.h"
#include "CheckFlow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

#pragma region �̵㵥
CCheckFlow::CCheckFlow()
{
	CoCreateGuid(&CheckID);
	ocscpy_s(CheckCustomID, _countof(CheckCustomID), OLESTR(""));
	CheckDate.vt = VT_DATE;
	CheckDate.date = COleDateTime::GetCurrentTime().m_dt;
	ocscpy_s(CheckDept, _countof(CheckDept), OLESTR(""));
	ocscpy_s(CheckWHName, _countof(CheckWHName), OLESTR(""));
	ocscpy_s(CheckManName, _countof(CheckManName), OLESTR(""));
	Quantity = { 0 };
	Quantity1 = { 0 };
	Balance = { 0 };
	IsCheckout = FALSE;
	ocscpy_s(CheckoutMan, _countof(CheckoutMan), OLESTR(""));
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	IsIncrement = TRUE;
	CheckDeptID = GUID_NULL;
	CheckWH = GUID_NULL;
	CheckMan = GUID_NULL;
	CheckoutManID = GUID_NULL;
	CreateDate.vt = VT_DATE;
	CheckDate.date = COleDateTime::GetCurrentTime().m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = COleDateTime::GetCurrentTime().m_dt;
	CheckOutDate.vt = VT_DATE;
	CheckOutDate.date = COleDateTime::GetCurrentTime().m_dt;
	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;

	State = Initial;
}

CCheckFlow::CCheckFlow(const CCheckFlow& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CCheckFlow::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), CheckCustomID);
		break;
	case 2:
		strRet = __super::FormatDateTime(CheckDate);
		break;
	case 3:
		strRet.Format(_T("%s"), CheckDept);
		break;
	case 4:
		strRet.Format(_T("%s"), CheckWHName);
		break;
	case 5:
		strRet.Format(_T("%s"), CheckManName);
		break;
	case 6:
		strRet.Format(_T("%.2f"), Quantity);
		break;
	case 7:
		strRet.Format(_T("%.2f"), Quantity1);
		break;
	case 8:
		strRet.Format(_T("%.2f"), Balance);
		break;
	case 9:
		strRet.Format(_T("%s"), IsCheckout ? _T("�����") : _T("δ���"));
		break;
	case 10:
		strRet.Format(_T("%s"), CheckoutMan);
		break;
	case 11:
		strRet.Format(_T("%s"), Memo);
		break;
	case 12:
		strRet.Format(_T("%s"), IsIncrement ? _T("��ӯ") : _T("�̿�"));
		break;
	case 17:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 18:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 19:
		strRet = __super::FormatDateTime(CheckOutDate);
		break;
	break;
	case 0:
		idRet = CheckID;
		break;
	case 13:
		idRet = CheckDeptID;
		break;
	case 14:
		idRet = CheckWH;
		break;
	case 15:
		idRet = CheckMan;
		break;
	case 16:
		idRet = CheckoutManID;
		break;
	case 20:
		idRet = CreatedUser;
		break;
	case 21:
		idRet = ModifierUser;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CCheckFlow::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�̵㵥����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("�̵㵥��"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("�̵�����"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("�̵㲿��"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�̵�ⷿ"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�̵���Ա"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("�̵�����"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("�̿�����"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�Ƿ����"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("�����"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("�̵㲿�ű���"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("�̵�ֿ����"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�̵���Ա����"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("����˱���"));
		break;
	case 17:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 18:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 19:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 20:
		strRet.Format(_T("%s"), _T("�����û�"));
		break;
	case 21:
		strRet.Format(_T("%s"), _T("�޸��û�"));
		break;
	}

	return strRet;
}

BOOL CCheckFlow::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 13 && nCol <= 16) ||
		(nCol >= 20 && nCol <= 21))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol == 9)
	{
		bTemp = (strTemp.CompareNoCase(_T("�����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 12)
	{
		bTemp = (strTemp.CompareNoCase(_T("��ӯ")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	else if (nCol == 2 || (nCol >= 17 && nCol <= 19))
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}
	else if (nCol >= 6 && nCol <= 8)
	{
		TCHAR* tcsStop;
		dblTemp = _tcstod(strTemp, &tcsStop);
	}

	switch (nCol)
	{
	case 0:
		CheckID = idTemp;
		break;
	case 1:
		_tcscpy_s(CheckCustomID, _countof(CheckCustomID), Truncate(strTemp, _countof(CheckCustomID) + 1));
		break;
	case 2:
		CheckDate = dtTemp;
		break;
	case 3:
		_tcscpy_s(CheckDept, _countof(CheckDept), Truncate(strTemp, _countof(CheckDept) + 1));
		break;
	case 4:
		_tcscpy_s(CheckWHName, _countof(CheckWHName), Truncate(strTemp, _countof(CheckWHName) + 1));
		break;
	case 5:
		_tcscpy_s(CheckManName, _countof(CheckManName), Truncate(strTemp, _countof(CheckManName) + 1));
		break;
	case 6:
		Quantity = dblTemp;
		break;
	case 7:
		Quantity1 = dblTemp;
		break;
	case 8:
		Balance = dblTemp;
		break;
	case 9:
		IsCheckout = bTemp;
		break;
	case 10:
		_tcscpy_s(CheckoutMan, _countof(CheckoutMan), Truncate(strTemp, _countof(CheckoutMan) + 1));
		break;
	case 11:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 12:
		IsIncrement = bTemp;
		break;
	case 13:
		CheckDeptID = idTemp;
		break;
	case 14:
		CheckWH = idTemp;
		break;
	case 15:
		CheckMan = idTemp;
		break;
	case 16:
		CheckoutManID = idTemp;
		break;
	case 17:
		CreateDate.date = dtTemp;
		break;
	case 18:
		ModifyDate.date = dtTemp;
		break;
	case 19:
		CheckOutDate.date = dtTemp;
		break;
	case 20:
		CreatedUser = idTemp;
		break;
	case 21:
		ModifierUser = idTemp;
		break;
	}
	return bRet;
}

void CCheckFlow::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CCheckFlow(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CCheckFlow& cfInfo)
{
	UINT ui = 0;
	for (; ui != cfInfo.GetColCount() - 1; ui++)
	{
		os << cfInfo.GetCellText(ui) << _T("��");
	}
	os << cfInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CCheckFlow& cfInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			cfInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
#pragma endregion

#pragma region �̵㵥�굥
CCheckFlowDetails::CCheckFlowDetails()
{
	CoCreateGuid(&CheckDatailsID);
	ocscpy_s(ProductName, _countof(ProductName), OLESTR(""));
	ocscpy_s(ProductType, _countof(ProductType), OLESTR(""));
	ocscpy_s(SpecName, _countof(SpecName), OLESTR(""));
	Quantity = { 0 };
	Quantity1 = { 0 };
	Balance = { 0 };
	ocscpy_s(ProductUnit, _countof(ProductUnit), OLESTR(""));
	ProdID = GUID_NULL;
	CheckID = GUID_NULL;

	State = Initial;
}

CCheckFlowDetails::CCheckFlowDetails(const CCheckFlowDetails& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

CString CCheckFlowDetails::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), ProductName);
		break;
	case 2:
		strRet.Format(_T("%s"), ProductType);
		break;
	case 3:
		strRet.Format(_T("%s"), SpecName);
		break;
	case 4:
		strRet.Format(_T("%.2f"), Quantity);
		break;
	case 5:
		strRet.Format(_T("%.2f"), Quantity1);
		break;
	case 6:
		strRet.Format(_T("%.2f"), Balance);
		break;
	case 7:
		strRet.Format(_T("%s"), ProductUnit);
		break;
	case 0:
		idRet = CheckDatailsID;
		break;
	case 8:
		idRet = ProdID;
		break;
	case 9:
		idRet = CheckID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CCheckFlowDetails::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("�굥����"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("��Ʒ���"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�̵�����"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("ӯ������"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("������λ"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("��Ʒ����"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("�̵����"));
		break;
	}

	return strRet;
}

BOOL CCheckFlowDetails::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	double dblTemp = { 0 };
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 8 && nCol <= 9))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	else if ((nCol >= 4 && nCol <= 6))
	{
		TCHAR* tcsStop = nullptr;
		dblTemp = abs(_tcstod(strTemp, &tcsStop));
	}

	switch (nCol)
	{
	case 0:
		CheckDatailsID = idTemp;
		break;
	case 1:
		_tcscpy_s(ProductName, _countof(ProductName), Truncate(strTemp, _countof(ProductName) + 1));
		break;
	case 2:
		_tcscpy_s(ProductType, _countof(ProductType), Truncate(strTemp, _countof(ProductType) + 1));
		break;
	case 3:
		_tcscpy_s(SpecName, _countof(SpecName), Truncate(strTemp, _countof(SpecName) + 1));
		break;
	case 4:
		Quantity = dblTemp;
		break;
	case 5:
		Quantity1 = dblTemp;
		break;
	case 6:
		Balance = dblTemp;
		break;
	case 7:
		_tcscpy_s(ProductUnit, _countof(ProductUnit), Truncate(strTemp, _countof(ProductUnit) + 1));
		break;
	case 8:
		ProdID = idTemp;
		break;
	case 9:
		CheckID = idTemp;
		break;
	}
	return bRet;
}

void CCheckFlowDetails::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CCheckFlowDetails(*this);
	}
}

STDOutStream& operator<<(STDOutStream& os, const CCheckFlowDetails& cfdInfo)
{
	UINT ui = 0;
	for (; ui != cfdInfo.GetColCount() - 1; ui++)
	{
		os << cfdInfo.GetCellText(ui) << _T("��");
	}
	os << cfdInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CCheckFlowDetails& cfdInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			cfdInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}

#pragma endregion