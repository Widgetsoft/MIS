#include "stdafx.h"
#include "FlybyData.h"
#include "EnterpriseInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Database;

CEnterpriseInfo::CEnterpriseInfo(void)
{
	CoCreateGuid(&compID);
	ocscpy_s(compName, _countof(compName), OLESTR(""));
	ocscpy_s(compPhoneNum, _countof(compPhoneNum), OLESTR(""));
	ocscpy_s(compFaxNum, _countof(compFaxNum), OLESTR(""));
	ocscpy_s(compValidAddr, _countof(compValidAddr), OLESTR(""));
	ocscpy_s(compEmail, _countof(compEmail), OLESTR(""));
	ocscpy_s(URL, _countof(URL), OLESTR(""));
	ocscpy_s(compPostCode, _countof(compPostCode), OLESTR(""));
	ocscpy_s(compAddr, _countof(compAddr), OLESTR(""));
	ocscpy_s(LegalRepresentative, _countof(LegalRepresentative), OLESTR(""));
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	IsUsing = TRUE;
	ocscpy_s(JM, 100, OLESTR(""));
	COleDateTime timeNow;
	timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;
	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;
	State = Initial;
}

CEnterpriseInfo::CEnterpriseInfo(const CEnterpriseInfo& refInput)
{
	for (int i = 0; i != refInput.GetColCount(); i++)
	{
		SetCellText(i, refInput.GetCellText(i));
	}
	SetState(refInput.GetState());
}

void CEnterpriseInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CEnterpriseInfo(*this);
	}
}

CString CEnterpriseInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:		//��ҵ����
		strRet = __super::FormatGUID(compID);
	break;
	case 1:
		strRet.Format(_T("%s"), compName);
		break;
	case 2:
		strRet.Format(_T("%s"), compPhoneNum);
		break;
	case 3:
		strRet.Format(_T("%s"), compFaxNum);
		break;
	case 4:
		strRet.Format(_T("%s"), compValidAddr);
		break;
	case 5:
		strRet.Format(_T("%s"), compEmail);
		break;
	case 6:
		strRet.Format(_T("%s"), URL);
		break;
	case 7:
		strRet.Format(_T("%s"), compPostCode);
		break;
	case 8:
		strRet.Format(_T("%s"), compAddr);
		break;
	case 9:
		strRet.Format(_T("%s"), LegalRepresentative);
		break;
	case 10:
		strRet.Format(_T("%s"), Memo);
		break;
	case 11:
		if (IsUsing)
		{
			strRet.Format(_T("%s"), _T("����"));
		}
		else
		{
			strRet.Format(_T("%s"), _T("ͣ��"));
		}
		break;
	case 12:
		strRet.Format(_T("%s"), JM);
		break;
	case 13:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 14:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	}
	return strRet;
}

CString CEnterpriseInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:		//��ҵ����
		strRet.Append(_T("��ҵ����"));
		break;
	case 1:
		strRet.Append(_T("��ҵ����"));
		break;
	case 2:
		strRet.Append(_T("�绰����"));
		break;
	case 3:
		strRet.Append(_T("�������"));
		break;
	case 4:
		strRet.Append(_T("ע���ַ"));
		break;
	case 5:
		strRet.Append(_T("���ʵ�ַ"));
		break;
	case 6:
		strRet.Append(_T("��ҵ��ַ"));
		break;
	case 7:
		strRet.Append(_T("��������"));
		break;
	case 8:
		strRet.Append(_T("��ϵ��ַ"));
		break;
	case 9:
		strRet.Append(_T("��ҵ����"));
		break;
	case 10:
		strRet.Append(_T("��ע"));
		break;
	case 11:
		strRet.Append(_T("״̬"));
		break;
	case 12:
		strRet.Append(_T("����"));
		break;
	case 13:
		strRet.Append(_T("��������"));
		break;
	case 14:
		strRet.Append(_T("�޸�����"));
		break;
	}
	return strRet;
}

BOOL CEnterpriseInfo::SetCellText(UINT nCol, const CString& strText)
{
	BOOL bRet = TRUE;
	CString strTemp(strText);
	switch (nCol)
	{
	case 0:		//��ҵ����
		{
			LPOLESTR strID = strTemp.AllocSysString();
			if (FAILED(IIDFromString(strID, &compID)))
			{
				bRet = FALSE;
			}
		}
		break;
	case 1:
		ocscpy_s(compName, _countof(compName), Truncate(strTemp, _countof(compName) + 1));
		break;
	case 2:
		ocscpy_s(compPhoneNum, _countof(compPhoneNum), Truncate(strTemp, _countof(compPhoneNum) + 1));
		break;
	case 3:
		ocscpy_s(compFaxNum, _countof(compFaxNum), Truncate(strTemp, _countof(compFaxNum) + 1));
		break;
	case 4:
		ocscpy_s(compValidAddr, _countof(compValidAddr), Truncate(strTemp, _countof(compValidAddr) + 1));
		break;
	case 5:
		ocscpy_s(compEmail, _countof(compEmail), Truncate(strTemp, _countof(compEmail) + 1));
		break;
	case 6:
		ocscpy_s(URL, _countof(URL), Truncate(strTemp, _countof(URL) + 1));
		break;
	case 7:
		ocscpy_s(compPostCode, _countof(compPostCode), Truncate(strTemp, _countof(compPostCode) + 1));
		break;
	case 8:
		ocscpy_s(compAddr, _countof(compAddr), Truncate(strTemp, _countof(compAddr) + 1));
		break;
	case 9:
		ocscpy_s(LegalRepresentative, _countof(LegalRepresentative), Truncate(strTemp, _countof(LegalRepresentative) + 1));
		break;
	case 10:
		ocscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 11:
		{
			if (strTemp.Compare(_T("����")) == 0
				|| strTemp.Compare(_T("1")) == 0)
			{
				IsUsing = TRUE;
			}
			else
			{
				IsUsing = FALSE;
			}
		}
		break;
	case 12:
		ocscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 13:
		{
			COleDateTime cDate;
			if (cDate.ParseDateTime(strTemp))
			{
				CreateDate.date = cDate.m_dt;
			}
			else
			{
				bRet = FALSE;
			}
		}
		break;
	case 14:
		{
			COleDateTime cDate;
			if (cDate.ParseDateTime(strTemp))
			{
				ModifyDate.date = cDate.m_dt;
			}
			else
			{
				bRet = FALSE;
			}
		}
		break;
	}
	return bRet;
}

//��Ԫ��������
STDOutStream& operator<<(STDOutStream& os, const CEnterpriseInfo& entInfo)
{
	UINT ui = 0;
	for (; ui != entInfo.GetColCount() - 1; ui++)
	{
		os << entInfo.GetCellText(ui) << _T("��");
	}
	os << entInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CEnterpriseInfo& entInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			entInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}
