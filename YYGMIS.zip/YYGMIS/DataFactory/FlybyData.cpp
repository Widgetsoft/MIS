#include "stdafx.h"
#include "FlybyData.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace Database
{
	CString AFX_EXT_API Truncate(CString& strMyInput, UINT nWords)
	{
		CString strInput(strMyInput.Trim());
		CString strRet;
		if (strInput.GetLength() < (int)nWords)
		{
			strRet.Append(strInput);
		}
		else
		{
			strRet.Append(strInput.Mid(0, nWords - 1));
		}
		if (strRet.GetLength() < 0)
		{
			return strRet;
		}
		//ȫ��ת��Ϊ���
		TCHAR * atChar = new TCHAR[nWords];
		_tcscpy_s(atChar, nWords, strRet.GetBuffer());
		CString strFinalRet;
		for (int i = 0; i != _tcslen(atChar); i++)
		{
			UINT chTemp = atChar[i];
			if (chTemp == 12290)
			{
				strFinalRet.AppendChar(_T('.'));
			}
			else if (chTemp == 12288)
			{
				strFinalRet.AppendChar(_T(' '));
			}
			else if (chTemp >= 65281 && chTemp <= 65374)
			{
				TCHAR ch = chTemp - 65248;
				strFinalRet.AppendChar(ch);
			}
			else
			{
				strFinalRet.AppendChar(atChar[i]);
			}
		}
		delete[] atChar;
		return strFinalRet;
	}
}

using namespace Database;

CString CSortInfo::GetOrderBy() const
{
	if (m_strOrderStr.Compare(_T("")) == 0)
	{
		return CString("");
	}
	else
	{
		CString strRet;
		strRet.Append(_T(" ORDER BY "));
		strRet.Append(m_strOrderStr);
		if (m_bSortDirection != FALSE)
		{
			strRet.Append(_T(" ASC"));
		}
		else
		{
			strRet.Append(_T(" DESC"));
		}
		return strRet;
	}
}

BOOL CFlybyItem::IsNullGuid(LPCTSTR strID)
{
	GUID guidTest = GUID_NULL;
	LPOLESTR lpnullptrID = nullptr;
	StringFromIID(guidTest, &lpnullptrID);
	BOOL bRet = (_tcsicmp(lpnullptrID, strID) == 0);
	CoTaskMemFree(lpnullptrID);
	return bRet;
}

CString CFlybyItem::GetNullID()
{
	GUID guidTest = GUID_NULL;
	LPOLESTR lpnullptrID = nullptr;
	StringFromIID(guidTest, &lpnullptrID);
	CoTaskMemFree(lpnullptrID);
	return CString(lpnullptrID);
}

CString CFlybyItem::GenerateNewID()
{
	CString strRet;
	LPOLESTR lpNewID = nullptr;
	GUID newID = GUID_NULL;
	CoCreateGuid(&newID);
	if (newID != GUID_NULL)
	{
		StringFromIID(newID, &lpNewID);
		strRet.Append(lpNewID);
		CoTaskMemFree(lpNewID);
	}
	return strRet;
}

CString CFlybyItem::FormatDate(LPCTSTR strSource)
{
	COleDateTime dateRet;
	dateRet.ParseDateTime(strSource);
	return dateRet.Format(_T("%Y-%m-%d"));
}

CString CFlybyItem::FormatDateTime(LPCTSTR strSource)
{
	COleDateTime dateRet;
	dateRet.ParseDateTime(strSource);
	return dateRet.Format(_T("%Y-%m-%d %H:%M:%S"));
}

CString CFlybyItem::FormatDate(const CComVariant varSource) const
{
	COleDateTime dateRet(varSource.date);
	return dateRet.Format(VAR_DATEVALUEONLY);
}

CString CFlybyItem::FormatDateTime(const CComVariant varSource) const
{
	COleDateTime dateRet(varSource.date);
	return dateRet.Format();
}

CString CFlybyItem::FormatGUID(const GUID guidSource) const
{
	CString strRet;
	LPOLESTR strID = nullptr;
	StringFromIID(guidSource, &strID);
	if (strID != nullptr)
	{
		strRet.Format(_T("%s"), strID);
		CoTaskMemFree(strID);
	}
	return strRet;
}

//////////////////////////////////////////////////
//CFlybyData Member Functions

CFlybyData::~CFlybyData()
{
	ClearItems();
}

CFlybyItem* CFlybyData::GetItem(size_t setupId)
{
	if (setupId >= 0 && setupId < m_records.size())
	{
		return m_records.at(setupId);
	}
	return nullptr;
}

CFlybyItem* CFlybyData::GetItemByID(GUID setupId)
{
	Concurrency::concurrent_vector< CFlybyItem* >::iterator it =
		std::find_if(m_records.begin(), m_records.end(),
			[&](const CFlybyItem* pTemp) { return pTemp->GetItemID() == setupId; });
	if (it != m_records.end())
	{
		return *it;
	}
	else
	{
		return nullptr;
	}
}

CFlybyItem* CFlybyData::GetItemByID(const CString setupId)
{
	GUID id = GUID_NULL;
	LPOLESTR strTemp = setupId.AllocSysString();
	IIDFromString(strTemp, &id);
	return GetItemByID(id);
}

void CFlybyData::ClearItems()
{
	Concurrency::concurrent_vector< CFlybyItem* >::const_iterator it = m_records.cbegin();
	for (; it != m_records.cend(); it++)
	{
		CFlybyItem* pItem = *it;
		if (!m_bRefOnly)
		{
			delete pItem;
		}
	}
	m_records.clear();
}

void CFlybyData::AddItem(CFlybyItem* pItem)
{
	m_records.push_back(pItem);
}


BOOL CFlybyData::RemoveItem(UINT nIndex)
{
	BOOL bRet = FALSE;
	if (nIndex < m_records.size())
	{
		Concurrency::concurrent_vector< CFlybyItem* >::iterator it =
			m_records.begin() + nIndex;
		CFlybyItem* pItem = *it;
		Concurrency::concurrent_vector< CFlybyItem* >::size_type szCount = m_records.size() - 1;
		CFlybyItem* pItemEnd = *(m_records.begin() + szCount);
		std::remove_if(m_records.begin(), m_records.end(),
			[&](const CFlybyItem* pArgs)->bool { return _tcsicmp(pItem->GetCellText(0), pArgs->GetCellText(0)) == 0; });
		m_records.resize(szCount, pItemEnd);
		if (it != m_records.end())
		{
			if (!m_bRefOnly)
			{
				delete pItem;
			}
			bRet = TRUE;
		}
	}

	return bRet;
}

BOOL CFlybyData::DeepClone(CFlybyData* pVector)
{
	BOOL bRet = FALSE;
	if (pVector != nullptr)
	{
		for (int i = 0; i != this->m_records.size(); i++)
		{
			CFlybyItem* pItem = nullptr;
			this->m_records.at(i)->Clone(&pItem);
			pVector->AddItem(pItem);
		}
		bRet = TRUE;
	}
	return bRet;
}

BOOL CFlybyData::RevoveItem(FlybyItem::iterator it)
{
	BOOL bRet = FALSE;
	if (it != m_records.end())
	{
		CFlybyItem* pItem = *it;
		Concurrency::concurrent_vector< CFlybyItem* >::size_type szCount = m_records.size() - 1;
		CFlybyItem* pItemEnd = *(m_records.begin() + szCount);
		std::remove_if(m_records.begin(), m_records.end(),
			[&](const CFlybyItem* pArgs)->bool { return _tcsicmp(pItem->GetCellText(0), pArgs->GetCellText(0)) == 0; });
		m_records.resize(szCount, pItemEnd);
		if (!m_bRefOnly)
		{
			delete pItem;
		}
		bRet = TRUE;
	}

	return bRet;
}

BOOL CFlybyData::RemoveItem(CFlybyItem* pItem)
{
	BOOL bRet = FALSE;
	Concurrency::concurrent_vector< CFlybyItem* >::size_type szCount = m_records.size() - 1;
	CFlybyItem* pItemEnd = *(m_records.begin() + szCount);
	std::remove_if(m_records.begin(), m_records.end(),
		[&](const CFlybyItem* pArgs)->bool { return _tcsicmp(pItem->GetCellText(0), pArgs->GetCellText(0)) == 0; });
	m_records.resize(szCount, pItemEnd);
	if (!m_bRefOnly)
	{
		delete pItem;
	}
	bRet = TRUE;
	return bRet;
}

void CFlybyData::CustomColumnSort(int nCol, bool bAscending)
{
	if (m_records.size() < 1)
	{
		return;
	}
	std::sort(m_records.begin(), m_records.end(),
		[&](const CFlybyItem* elem1, const CFlybyItem* elem2)->bool
	{
		int nRet = 0;
		if (!(elem1->GetCellText(nCol).IsEmpty() &&
			elem2->GetCellText(nCol).IsEmpty()))
		{
			nRet = elem1->GetCellText(nCol).CompareNoCase(elem2->GetCellText(nCol));
			nRet = bAscending ? nRet : -nRet;
		}

		return (nRet < 0) ? true : false;
	});
}

size_t CFlybyData::ParallelFind(const Concurrency::concurrent_vector<CFlybyItem*> records, size_t nStart, size_t nEnd,
	const CString& strKeyWords, BOOL bAllWordsMatch) const
{
	size_t nRet = -1;
	if (nStart > nEnd)
	{
		for (size_t n = nStart; n != nEnd; n--)
		{
			Concurrency::structured_task_group tasks;
			tasks.run_and_wait([&]() {
				UINT uiStart = 0, uiEnd = records.at(n)->GetColCount() - 1;
				Concurrency::parallel_for(uiStart, uiEnd, [&](UINT ni) {
					if (bAllWordsMatch)
					{
						if (_tcsicmp(records.at(n)->GetCellText(ni), strKeyWords) == 0)
						{
							nRet = n;
							tasks.cancel();
						}
					}
					else
					{
						if (_tcsstr(records.at(n)->GetCellText(ni), strKeyWords) != nullptr)
						{
							nRet = n;
							tasks.cancel();
						}
					}
				});
			});
			if (nRet != -1)
			{
				break;
			}
		}
	}
	else
	{
		Concurrency::structured_task_group tasks;
		tasks.run_and_wait(
			[&] {
			Concurrency::parallel_for(nStart, nEnd, [&](size_t n)
			{
				UINT uiStart = 0, uiEnd = records.at(n)->GetColCount() - 1;
				Concurrency::parallel_for(uiStart, uiEnd, [&](size_t ni) {
					if (bAllWordsMatch)
					{
						if (_tcsicmp(records.at(n)->GetCellText((int)ni), strKeyWords) == 0)
						{
							nRet = n;
							tasks.cancel();
						}
					}
					else
					{
						if (_tcsstr(records.at(n)->GetCellText((int)ni), strKeyWords) != nullptr)
						{
							nRet = n;
							tasks.cancel();
						}
					}
				});
			});
		});
	}
	return nRet;
}

size_t CFlybyData::CustomFindItem(LPCTSTR strKeyWords, size_t iStart, BOOL bBackward, BOOL bAllWordsMatch)
{
	if (_tcslen(strKeyWords) < 1 && m_records.size() < 1)
	{
		return -1;
	}
	if (iStart < 0 || iStart >= m_records.size())
	{
		iStart = (bBackward ? m_records.size() : 0);
	}


	size_t nRet = -1;

	//��ʼ����
	if (bBackward) //��������
	{
		size_t nStart = iStart;
		size_t nEnd = -1;
		nRet = ParallelFind(m_records, nStart, nEnd, strKeyWords, bAllWordsMatch);
		if (nRet == -1)
		{
			nStart = m_records.size() - 1;
			nEnd = iStart - 1;
			nRet = ParallelFind(m_records, nStart, nEnd, strKeyWords, bAllWordsMatch);
		}
	}
	else //˳������
	{
		size_t nStart = iStart;
		size_t nEnd = m_records.size();
		nRet = ParallelFind(m_records, nStart, nEnd, strKeyWords, bAllWordsMatch);
		if (nRet == -1)
		{
			nStart = 0;
			nEnd = iStart;
			nRet = ParallelFind(m_records, nStart, nEnd, strKeyWords, bAllWordsMatch);
		}
	}

	return nRet;
}

BOOL CFlybyData::Filter(CFlybyData* pData, UINT colNum, CString strKey, BOOL bAllMatch, BOOL bClonePoint)
{
	if (colNum < 0 || (int)colNum >= GetColCount())
	{
		return FALSE;
	}
	if (pData == nullptr)
	{
		return FALSE;
	}
	if (this->GetCount() < 1)
	{
		return FALSE;
	}

	BOOL bSuccess = TRUE;

	pData->ClearItems();

	if (strKey.GetLength() < 1)
	{
		Concurrency::parallel_for_each(this->m_records.begin(), this->m_records.end(),
			[&](CFlybyItem* pItem) {
			if (bClonePoint)
			{
				CFlybyItem* pItem1 = nullptr;
				pItem->Clone(&pItem1);
				pData->AddItem(pItem1);
			}
			else
			{
				pData->AddItem(pItem);
			}
		});
	}
	else
	{
		if (bAllMatch)
		{
			Concurrency::parallel_for_each(this->m_records.begin(), this->m_records.end(),
				[&](CFlybyItem* pItem) {
				if (pItem->GetCellText(colNum).Compare(strKey) == 0)
				{
					if (bClonePoint)
					{
						CFlybyItem* pItem1 = nullptr;
						pItem->Clone(&pItem1);
						pData->AddItem(pItem1);
					}
					else
					{
						pData->AddItem(pItem);
					}
				}
			});
		}
		else
		{
			Concurrency::parallel_for_each(this->m_records.begin(), this->m_records.end(),
				[&](CFlybyItem* pItem) {
				if (pItem->GetCellText(colNum).Find(strKey) == -1)
				{
					if (bClonePoint)
					{
						CFlybyItem* pItem1 = nullptr;
						pItem->Clone(&pItem1);
						pData->AddItem(pItem1);
					}
					else
					{
						pData->AddItem(pItem);
					}
				}
			});
		}
	}

	bSuccess = pData->GetCount() > 0;

	return bSuccess;
}
