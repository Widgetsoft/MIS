#pragma once
namespace Database
{
	class AFX_EXT_CLASS CServiceInfo : public CFlybyItem
	{
	public:
		CServiceInfo();
		CServiceInfo(const CServiceInfo&);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 27; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return ServiceID; }

	public:
		BEGIN_COLUMN_MAP(CServiceInfo)
			COLUMN_ENTRY(1, ServiceID)
			COLUMN_ENTRY(2, ServiceCustomCode)
			COLUMN_ENTRY(3, ServiceName)
			COLUMN_ENTRY(4, ServiceType)
			COLUMN_ENTRY(5, ServiceSpec)
			COLUMN_ENTRY(6, ServiceUnit1)
			COLUMN_ENTRY(7, ServiceUnit2)
			COLUMN_ENTRY(8, Service1To2Rate)
			COLUMN_ENTRY(9, ServicePrice)
			COLUMN_ENTRY(10, EIName)
			COLUMN_ENTRY(11, IsTimeCount)
			COLUMN_ENTRY(12, IsDiscount)
			COLUMN_ENTRY(13, IsIntegral)
			COLUMN_ENTRY(14, AsGift)
			COLUMN_ENTRY(15, IsUsing)
			COLUMN_ENTRY(16, ServiceMemo)
			COLUMN_ENTRY(17, JM)

			COLUMN_ENTRY(18, CreateDate)
			COLUMN_ENTRY(19, ModifyDate)
			COLUMN_ENTRY(20, CreatedUser)
			COLUMN_ENTRY(21, ModifierUser)

			COLUMN_ENTRY(22, EIID)
			COLUMN_ENTRY(23, TypeID)
			COLUMN_ENTRY(24, SpecID)
			COLUMN_ENTRY(25, UnitID1)
			COLUMN_ENTRY(26, UnitID2)
			COLUMN_ENTRY(27, compID)
		END_COLUMN_MAP()

	private:
		GUID ServiceID;
		OLECHAR ServiceCustomCode[40];
		OLECHAR ServiceName[60];
		OLECHAR ServiceType[40];
		OLECHAR ServiceSpec[40];
		OLECHAR ServiceUnit1[40];
		OLECHAR ServiceUnit2[40];
		double Service1To2Rate;
		double ServicePrice;
		OLECHAR EIName[60];
		BOOL IsTimeCount;
		BOOL IsDiscount;
		BOOL IsIntegral;
		BOOL AsGift;
		BOOL IsUsing;
		OLECHAR ServiceMemo[255];
		OLECHAR JM[60];

		CComVariant CreateDate;
		CComVariant ModifyDate;
		GUID CreatedUser;
		GUID ModifierUser;

		GUID EIID;
		GUID TypeID;
		GUID SpecID;
		GUID UnitID1;
		GUID UnitID2;
		GUID compID;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CServiceInfo& ProdInfo);
		friend STDInStream& operator >> (STDInStream& is, CServiceInfo& ProdInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CServiceInfo& ProdInfo);
	STDInStream& operator >> (STDInStream& is, CServiceInfo& ProdInfo);

	class AFX_EXT_CLASS CServiceInfoVector : public CFlybyData
	{
	public:
		CServiceInfoVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewServiceInfo");
		}

	public:
		inline virtual int GetColCount() const
		{
			return CServiceInfo().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CServiceInfo().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CServiceInfo>(new CServiceInfo()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA