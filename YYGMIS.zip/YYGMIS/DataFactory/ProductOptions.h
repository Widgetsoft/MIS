#pragma once

namespace Database
{
	class AFX_EXT_CLASS CProductOptions : public CFlybyItem
	{
	public:
		CProductOptions();
		CProductOptions(const CProductOptions& input);

	public:
		virtual CString GetCellText(UINT nCol) const;
		virtual CString GetColumnName(UINT nCol) const;
		virtual BOOL SetCellText(UINT nCol, const CString& strText);
		virtual void Clone(CFlybyItem** ppOutObj);

	public:
		inline virtual UINT GetColCount() const { return 10; }
		inline virtual DataState GetState() const { return State; }
		inline virtual void SetState(const DataState state) { State = state; }
		inline virtual GUID GetItemID() const { return POID; }
	public:
		BEGIN_COLUMN_MAP(CProductOptions)
			COLUMN_ENTRY(1, POID)
			COLUMN_ENTRY(2, PSCategory)
			COLUMN_ENTRY(3, POName)
			COLUMN_ENTRY(4, PODescription)
			COLUMN_ENTRY(5, POMemo)
			COLUMN_ENTRY(6, POJM)
			COLUMN_ENTRY(7, CreateDate)
			COLUMN_ENTRY(8, ModifyDate)
			COLUMN_ENTRY(9, CreatedUser)
			COLUMN_ENTRY(10, ModifierUser)
		END_COLUMN_MAP()

	private:
		GUID POID;
		OLECHAR POName[40];
		OLECHAR PODescription[100];
		OLECHAR POMemo[120];
		OLECHAR PSCategory[20];

		OLECHAR POJM[40];

		CComVariant CreateDate;
		CComVariant ModifyDate;

		GUID CreatedUser;
		GUID ModifierUser;

		DataState State;
	public:
		friend STDOutStream& operator<<(STDOutStream& os, const CProductOptions& itemInfo);
		friend STDInStream& operator >> (STDInStream& is, CProductOptions& itemInfo);
	};

	STDOutStream& operator<<(STDOutStream& os, const CProductOptions& itemInfo);
	STDInStream& operator >> (STDInStream& is, CProductOptions& itemInfo);

	class AFX_EXT_CLASS CProductOptionsVector : public CFlybyData
	{
	public:
		CProductOptionsVector(BOOL bRefOnly = FALSE)
		{
			m_bRefOnly = bRefOnly;
			m_strBindTable = _T("tsw_viewProductOptions");
		}
	public:
		inline virtual int GetColCount() const
		{
			return CProductOptions().GetColCount();
		}

		inline virtual CString GetColTitle(UINT nCol) const
		{
			return CProductOptions().GetColumnName(nCol);
		}

		inline virtual CFlybyItem* NewItem() { return std::auto_ptr<CProductOptions>(new CProductOptions()).release(); }
	};
}
#undef AFX_DATA
#define AFX_DATA