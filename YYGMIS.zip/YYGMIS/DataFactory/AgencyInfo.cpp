#include "stdafx.h"
#include "FlybyData.h"
#include "AgencyInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


using namespace Database;

CAgencyInfo::CAgencyInfo(void)
{
	CoCreateGuid(&deptID);
	ocscpy_s(deptName, _countof(deptName), OLESTR(""));
	ocscpy_s(compName, _countof(compName), OLESTR(""));
	ocscpy_s(deptChief, _countof(deptChief), OLESTR(""));
	ocscpy_s(deptPhoneNum, _countof(deptPhoneNum), OLESTR(""));
	ocscpy_s(detpFaxNum, _countof(detpFaxNum), OLESTR(""));
	ocscpy_s(deptEmail, _countof(deptEmail), OLESTR(""));
	ocscpy_s(deptPostCode, _countof(deptPostCode), OLESTR(""));
	ocscpy_s(deptAddress, _countof(deptAddress), OLESTR(""));
	IsUsing = TRUE;
	ocscpy_s(Memo, _countof(Memo), OLESTR(""));
	ocscpy_s(JM, _countof(JM), OLESTR(""));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	CreateDate.vt = VT_DATE;
	CreateDate.date = timeNow.m_dt;

	ModifyDate.vt = VT_DATE;
	ModifyDate.date = timeNow.m_dt;

	CreatedUser = GUID_NULL;
	ModifierUser = GUID_NULL;
	compID = GUID_NULL;

	State = Initial;
}


CAgencyInfo::CAgencyInfo(const CAgencyInfo& input)
{
	for (int i = 0; i != input.GetColCount(); i++)
	{
		SetCellText(i, input.GetCellText(i));
	}
	SetState(input.GetState());
}

void CAgencyInfo::Clone(CFlybyItem** ppOutObj)
{
	if (ppOutObj != nullptr)
	{
		*ppOutObj = new CAgencyInfo(*this);
	}
}

CString CAgencyInfo::GetCellText(UINT nCol) const
{
	CString strRet;
	GUID idRet = cgIDTest;
	switch (nCol)
	{
	case 1:
		strRet.Format(_T("%s"), deptName);
		break;
	case 2:
		strRet.Format(_T("%s"), compName);
		break;
	case 3:
		strRet.Format(_T("%s"), deptChief);
		break;
	case 4:
		strRet.Format(_T("%s"), deptPhoneNum);
		break;
	case 5:
		strRet.Format(_T("%s"), detpFaxNum);
		break;
	case 6:
		strRet.Format(_T("%s"), deptEmail);
		break;
	case 7:
		strRet.Format(_T("%s"), deptPostCode);
		break;
	case 8:
		strRet.Format(_T("%s"), deptAddress);
		break;
	case 9:
		strRet.Format(_T("%s"), IsUsing ? _T("����") : _T("ͣ��"));
		break;
	case 10:
		strRet.Format(_T("%s"), Memo);
		break;
	case 11:
		strRet.Format(_T("%s"), JM);
		break;
	case 12:
		strRet = __super::FormatDateTime(CreateDate);
		break;
	case 13:
		strRet = __super::FormatDateTime(ModifyDate);
		break;
	case 0:
		idRet = deptID;
		break;
	case 14:
		idRet = CreatedUser;
		break;
	case 15:
		idRet = ModifierUser;
		break;
	case 16:
		idRet = compID;
		break;
	}
	if (idRet != cgIDTest)
	{
		strRet = __super::FormatGUID(idRet);
	}
	return strRet;
}

CString CAgencyInfo::GetColumnName(UINT nCol) const
{
	CString strRet;
	switch (nCol)
	{
	case 0:
		strRet.Format(_T("%s"), _T("���ű���"));
		break;
	case 1:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 2:
		strRet.Format(_T("%s"), _T("������˾"));
		break;
	case 3:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 4:
		strRet.Format(_T("%s"), _T("�绰����"));
		break;
	case 5:
		strRet.Format(_T("%s"), _T("�������"));
		break;
	case 6:
		strRet.Format(_T("%s"), _T("���ʵ�ַ"));
		break;
	case 7:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 8:
		strRet.Format(_T("%s"), _T("���ŵ�ַ"));
		break;
	case 9:
		strRet.Format(_T("%s"), _T("����״̬"));
		break;
	case 10:
		strRet.Format(_T("%s"), _T("��ע"));
		break;
	case 11:
		strRet.Format(_T("%s"), _T("����"));
		break;
	case 12:
		strRet.Format(_T("%s"), _T("��������"));
		break;
	case 13:
		strRet.Format(_T("%s"), _T("�޸�����"));
		break;
	case 14:
		strRet.Format(_T("%s"), _T("������"));
		break;
	case 15:
		strRet.Format(_T("%s"), _T("�޸���"));
		break;
	case 16:
		strRet.Format(_T("%s"), _T("��˾����"));
		break;
	}

	return strRet;
}

BOOL CAgencyInfo::SetCellText(UINT nCol, const CString& strText)
{
	CString strTemp(strText);
	BOOL bRet = TRUE;
	GUID idTemp = GUID_NULL;
	BOOL bTemp = FALSE;
	COleDateTime dtTemp;
	if (nCol == 0 || (nCol >= 14 && nCol <= 16))
	{
		LPOLESTR strID = strTemp.AllocSysString();
		bRet = SUCCEEDED(IIDFromString(strID, &idTemp));
		if (!bRet)
		{
			return bRet;
		}
	}
	if (nCol == 9)
	{
		bTemp = (strTemp.CompareNoCase(_T("����")) == 0 || strTemp.Compare(_T("1")) == 0);
	}
	if (nCol == 12 || nCol == 13)
	{
		bRet = dtTemp.ParseDateTime(strTemp);
		if (!bRet)
		{
			return bRet;
		}
	}

	switch (nCol)
	{
	case 0:
		deptID = idTemp;
		break;
	case 1:
		_tcscpy_s(deptName, _countof(deptName), Truncate(strTemp, _countof(deptName) + 1));
		break;
	case 2:
		_tcscpy_s(compName, _countof(compName), Truncate(strTemp, _countof(compName) + 1));
		break;
	case 3:
		_tcscpy_s(deptChief, _countof(deptChief), Truncate(strTemp, _countof(deptChief) + 1));
		break;
	case 4:
		_tcscpy_s(deptPhoneNum, _countof(deptPhoneNum), Truncate(strTemp, _countof(deptPhoneNum) + 1));
		break;
	case 5:
		_tcscpy_s(detpFaxNum, _countof(detpFaxNum), Truncate(strTemp, _countof(detpFaxNum) + 1));
		break;
	case 6:
		_tcscpy_s(deptEmail, _countof(deptEmail), Truncate(strTemp, _countof(deptEmail) + 1));
		break;
	case 7:
		_tcscpy_s(deptPostCode, _countof(deptPostCode), Truncate(strTemp, _countof(deptPostCode) + 1));
		break;
	case 8:
		_tcscpy_s(deptAddress, _countof(deptAddress), Truncate(strTemp, _countof(deptAddress) + 1));
		break;
	case 9:
		IsUsing = bTemp;
		break;
	case 10:
		_tcscpy_s(Memo, _countof(Memo), Truncate(strTemp, _countof(Memo) + 1));
		break;
	case 11:
		_tcscpy_s(JM, _countof(JM), Truncate(strTemp, _countof(JM) + 1));
		break;
	case 12:
		CreateDate.date = dtTemp;
		break;
	case 13:
		ModifyDate.date = dtTemp;
		break;
	case 14:
		CreatedUser = idTemp;
		break;
	case 15:
		ModifierUser = idTemp;
		break;
	case 16:
		compID = idTemp;
		break;
	}
	return bRet;
}

STDOutStream& operator<<(STDOutStream& os, const CAgencyInfo& agenInfo)
{
	UINT ui = 0;
	for (; ui != agenInfo.GetColCount() - 1; ui++)
	{
		os << agenInfo.GetCellText(ui) << _T("��");
	}
	os << agenInfo.GetCellText(ui);
	return os;
}

STDInStream& operator >> (STDInStream& is, CAgencyInfo& agenInfo)
{
	OLECHAR arStr[8000];
	is.getline(arStr, 8000);
	StringVector vectRet;
	if (_tcslen(arStr) > 0)
	{
		Split(arStr, _T("��"), &vectRet);
		for (int i = 0; i != vectRet.size(); i++)
		{
			agenInfo.SetCellText(i, vectRet[i]);
		}
	}
	return is;
}