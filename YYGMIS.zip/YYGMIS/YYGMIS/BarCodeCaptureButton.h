#pragma once

// CBarCodeCaptureButton ����Ŀ��
#define ID_SALE_AT_BUTTON 23013

namespace UI
{
	namespace Business
	{
		class CBarCodeCaptureButton : public CMFCToolBarComboBoxButton
		{
			DECLARE_SERIAL(CBarCodeCaptureButton)
		public:
			CBarCodeCaptureButton()
				: CMFCToolBarComboBoxButton(ID_SALE_AT_BUTTON, GetCmdMgr()->GetCmdImage(ID_SALE_AT), CBS_DROPDOWN)
			{

			}

		public:
			static BOOL HasFocus()
			{
				return m_bHasFocus;
			}

		protected:
			static BOOL m_bHasFocus;

			//Overrides
		protected:
			virtual BOOL NotifyCommand(int iNotifyCode);
		};
	}
}