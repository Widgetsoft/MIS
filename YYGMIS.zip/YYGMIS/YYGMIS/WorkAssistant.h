#pragma once
namespace Business
{
	namespace Core
	{
		enum EnumUpdateSync
		{
			enumSupplyCustomer = 0x123,
			enumAgency,
			enumOperator,
			enumWarehouse,
			enumAmount,
			enumTickits
		};



		class CWorkAssistant
		{
		public:
			CWorkAssistant();
			~CWorkAssistant();

		public:
			inline CString GetDateSeg() const { return CString(tcsYear); }
			UINT GetCurrentIndex(const DataPattern::EnumBusinessType enumType, 
				LPCTSTR lpctstrColName, LPCTSTR lpctstrTableName) const;

		public: //Ĭ�Ϲ��ߺ���
			static CString GetTickitPrefix(const DataPattern::EnumBusinessType enumType);

			//Ĭ�ϼ��ػ���غ���
			static void NormalComboBoxProxy(CComboBox& cmbTarget, Database::CFlybyItem* pAssumeObject = nullptr,
				std::shared_ptr<DataPattern::CTickitsData> spData = nullptr, size_t szPage = 0,
				const UINT uiCol = -1, const UINT uiCol1 = -1, const BOOL bResetItems = FALSE,
				LPCTSTR lpcszTargetID = nullptr);

			//����ѡ�������
			static void LoadComboNormalData(std::shared_ptr<DataPattern::CTickitsData> spData, 
				CComboBox& cmbTarget, GenerialPattern::CItemData* pAddItem, size_t szPage = 0,
				const BOOL bUpdateItem = FALSE, const UINT uiCol = -1, const UINT uiCol1 = -1);
			//�Զ����ѡ������
			static void QIFilterOptions(std::shared_ptr<DataPattern::CTickitsData> spData, 
				LPCTSTR lpcszQuery, CComboBox& cmbTarget, LPCTSTR strText, size_t szPage = 0, BOOL bAddNullItem = FALSE );
			//��֤ѡ��ֵ�ĺϷ���
			static GenerialPattern::CItemData* QIValidateOptions(std::shared_ptr<DataPattern::CTickitsData> spData, CComboBox& cmbTarget, 
				const UINT uiCol, const UINT uiCol1, size_t szPage = 0);

			//Ĭ�ϼ�����Ͽ����������
			static void ComboLoadAllItems(LPCTSTR lpcszQuery, CComboBox& cmbTarget, 
				GenerialPattern::CItemData* pFeedback, LPCTSTR lpszNormalID = nullptr,
				BOOL bContainsNULLItem = FALSE);

		protected:
			TCHAR tcsYear[9];
		};
	}
}

