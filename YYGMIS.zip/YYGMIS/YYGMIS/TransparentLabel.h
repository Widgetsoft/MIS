#pragma once

namespace UI
{
	namespace Control
	{
		// CTransparentLabel

		class CTransparentLabel : public CStatic
		{
			DECLARE_DYNAMIC(CTransparentLabel)

		public:
			CTransparentLabel();
			virtual ~CTransparentLabel();

		protected:
			DECLARE_MESSAGE_MAP()
		public:
			afx_msg HBRUSH CtlColor(CDC* /*pDC*/, UINT /*nCtlColor*/);
		};
	}
}

