#pragma once
namespace BasicInfo
{
	// CServiceInfoDoc �ĵ�

	class CServiceInfoDoc : public CDocument
	{
		DECLARE_DYNCREATE(CServiceInfoDoc)

	public:
		CServiceInfoDoc();
		virtual ~CServiceInfoDoc();
	public:
		Database::CServiceInfoVector m_vector;
		Database::CServiceInfoVector m_vectNewItems;
		Database::CServiceInfoVector m_vectModItems;
		Database::CServiceInfoVector m_vectDelItems;

	public:
#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}
