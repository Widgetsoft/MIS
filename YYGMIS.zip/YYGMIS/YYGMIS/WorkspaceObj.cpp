#include "stdafx.h"
#include "WorkspaceObj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CWorkspaceObj::CWorkspaceObj(const CString& strName, const UINT uiCmd,
	const int iIconIndex, const UINT uiDefaultNewAction) :
	m_strName(strName), m_uiCmd(uiCmd), m_iIconIndex(iIconIndex),
	m_uiDefaultNewAction(uiDefaultNewAction)
{
}


CWorkspaceObj::~CWorkspaceObj(void)
{
}
