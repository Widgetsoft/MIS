#pragma once

#include "TransparentLabel.h"

namespace Business
{
	//namespace DataPattern
	//{
	//	class CTickitsData;
	//}
	// CDataProcessDlg �Ի���

	class CDataProcessDlg : public CDialogEx
	{
		friend class CDataLoadSaveThread;

		DECLARE_DYNAMIC(CDataProcessDlg)

	public:
		CDataProcessDlg(std::shared_ptr<DataPattern::CTickitsData> spDatas, DataPattern::EnumBusinessType enumTickType,
			std::shared_ptr<GenerialPattern::CItemData> spItemKeys = NULL, 
			CWnd* pParent = NULL, BOOL bLoadOnly = FALSE, DataPattern::EnumBusinessType enumSourceTickType = DataPattern::enumUnknown
			, std::shared_ptr<DataPattern::CTickitsData> spOldTickitsData = NULL);   // ��׼���캯��
		virtual ~CDataProcessDlg();

		// �Ի�������
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_GENERAL_DP_DLG };
#endif

	public:
		//��������
		void Start();
		BOOL m_bOK;

	private:
		UI::Control::CTransparentLabel m_label1;

		std::shared_ptr<DataPattern::CTickitsData> m_spTickitsData;
		std::shared_ptr<DataPattern::CTickitsData> m_spOldTickitsData;

		CMutex m_mutex;					//ͬ����
		std::shared_ptr<GenerialPattern::CItemData> m_spItemKeys;

		CProgressCtrl m_progressTotal;
		CProgressCtrl m_progressSub;
		CDataLoadSaveThread* m_threadWorker;
		BOOL m_bLoadOnly;

		DataPattern::EnumBusinessType m_enumTickType;
		DataPattern::EnumBusinessType m_enumSourceTickType;

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		virtual BOOL OnInitDialog();
		afx_msg void OnClose();
		virtual INT_PTR DoModal();
		afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	};
}
