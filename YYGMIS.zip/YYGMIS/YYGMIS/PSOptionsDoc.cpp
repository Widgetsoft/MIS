// PSOptionsDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "PSOptionsDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPSOptionsDoc

IMPLEMENT_DYNCREATE(CPSOptionsDoc, CDocument)

CPSOptionsDoc::CPSOptionsDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CPSOptionsDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("��Ʒ������ѡ��ά��"));
	return TRUE;
}

CPSOptionsDoc::~CPSOptionsDoc()
{
}


BEGIN_MESSAGE_MAP(CPSOptionsDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CPSOptionsDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CPSOptionsDoc::OnFileSave)
END_MESSAGE_MAP()


// CPSOptionsDoc ���

#ifdef _DEBUG
void CPSOptionsDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CPSOptionsDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CPSOptionsDoc ���л�

void CPSOptionsDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CPSOptionsDoc ����


BOOL CPSOptionsDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CPSOptionsDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CPSOptionsDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabProductOptions(POID, PSCategory, POName, PODescription, POMemo, POJM, CreateDate, ModifyDate, CreatedUser, ModifierUser) VALUES('%s', '%s', '%s', '%s', '%s', '%s', DATETIME('now','localtime'), DATETIME('now','localtime'), '%s', '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 3),
			m_vectNewItems.GetCellText(i, 4),
			m_vectNewItems.GetCellText(i, 5),
			m_vectNewItems.GetCellText(i, 8),
			m_vectNewItems.GetCellText(i, 9));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabProductOptions SET PSCategory = '%s', POName = '%s', PODescription = '%s', POMemo = '%s', POJM = '%s', ModifyDate = DATETIME('now','localtime'), ModifierUser = '%s' WHERE POID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 3),
			m_vectModItems.GetCellText(i, 4),
			m_vectModItems.GetCellText(i, 5),
			m_vectModItems.GetCellText(i, 9),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabProductOptions WHERE POID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_PSOPTION_CHANGED, NULL, NULL, TRUE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("��Ʒ������ѡ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
