#pragma once

namespace BasicInfo
{
	// CPSOptionsView ��ͼ

	class CPSOptionsView : public CView
	{
		DECLARE_DYNCREATE(CPSOptionsView)

	protected:
		CPSOptionsView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
		virtual ~CPSOptionsView();

	public:
		virtual void OnDraw(CDC* pDC);      // ��д�Ի��Ƹ���ͼ
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	public://����
		CPSOptionsDoc* GetDocument() const;

	private:
		CLocalDataGridView m_ListCtrl; //���ݿؼ�

	private:
		void LoadData();
		Concurrency::concurrent_vector<STDString> m_vectCategory;
		UINT_PTR m_uipPSOTimerID;

	protected:
		DECLARE_MESSAGE_MAP()
	public:
		afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
		afx_msg void OnSize(UINT nType, int cx, int cy);
		afx_msg void OnEditNewitem();
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnUpdateEditRefresh(CCmdUI *pCmdUI);
		afx_msg void OnEditRefresh();
		afx_msg void OnUpdateEditModify(CCmdUI *pCmdUI);
		afx_msg void OnEditModify();
		afx_msg void OnUpdateEditDelete(CCmdUI *pCmdUI);
		afx_msg void OnEditDelete();
		afx_msg void OnUpdateEditRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditRevsel();
		afx_msg void OnUpdateEditFind(CCmdUI *pCmdUI);
		afx_msg void OnEditFind();
		afx_msg LRESULT OnDataChanged(WPARAM wParam, LPARAM lParam);
		afx_msg void OnTimer(UINT_PTR nIDEvent);
	};
}

#ifndef _DEBUG
inline BasicInfo::CPSOptionsDoc* BasicInfo::CPSOptionsView::GetDocument() const
{
	return reinterpret_cast<CPSOptionsDoc*>(m_pDocument);
}
#endif