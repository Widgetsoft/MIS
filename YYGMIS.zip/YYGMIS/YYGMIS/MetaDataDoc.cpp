// MetaDataDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "MetaDataDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace BasicInfo;

// CMetaDataDoc

IMPLEMENT_DYNCREATE(CMetaDataDoc, CDocument)

CMetaDataDoc::CMetaDataDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{

}

BOOL CMetaDataDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("����ѡ�����ô���"));
	return TRUE;
}

CMetaDataDoc::~CMetaDataDoc()
{
}


BEGIN_MESSAGE_MAP(CMetaDataDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CMetaDataDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CMetaDataDoc::OnFileSave)
END_MESSAGE_MAP()


// CMetaDataDoc ���

#ifdef _DEBUG
void CMetaDataDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CMetaDataDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CMetaDataDoc ���л�

void CMetaDataDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CMetaDataDoc ����


BOOL CMetaDataDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CMetaDataDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CMetaDataDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabItemOptions(OptionID, OptionCategory, OptionName, OptionDescription, OptionMemo, OptionJM) VALUES('%s', '%s', '%s', '%s', '%s', '%s' );"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 3),
			m_vectNewItems.GetCellText(i, 4),
			m_vectNewItems.GetCellText(i, 5));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabItemOptions SET OptionCategory = '%s', OptionName = '%s', OptionDescription = '%s', OptionMemo = '%s', OptionJM = '%s' WHERE OptionID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 3),
			m_vectModItems.GetCellText(i, 4),
			m_vectModItems.GetCellText(i, 5),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabItemOptions WHERE OptionID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_METADATA_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("ͨ����Ϣ���ݱ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
