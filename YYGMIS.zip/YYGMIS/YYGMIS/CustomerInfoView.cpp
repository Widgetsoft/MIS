// CustomerInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "CustomerInfoDoc.h"
#include "LocalDataGridView.h"
#include "CustomerInfoView.h"
#include "SystemInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace BasicInfo;

#define ID_GRID_CUSTINFO 0x9006

// CCustomerInfoView

IMPLEMENT_DYNCREATE(CCustomerInfoView, CView)

CCustomerInfoView::CCustomerInfoView()
	:m_ListCtrl(IDR_POPUP_EDIT)
{
	m_uipCustInfoTimerID = -1;
}

CCustomerInfoView::~CCustomerInfoView()
{
}

BEGIN_MESSAGE_MAP(CCustomerInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CCustomerInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_CUSTINFO, &CCustomerInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CCustomerInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CCustomerInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CCustomerInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CCustomerInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CCustomerInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CCustomerInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CCustomerInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CCustomerInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CCustomerInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CCustomerInfoView::OnEditFind)
	ON_MESSAGE(WM_CUSTINFO_CHANGED, &CCustomerInfoView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CCustomerInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetCustomerInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 10)
			{
				if (strCellText.Compare(_T("δ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

// CCustomerInfoView ��ͼ

void CCustomerInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CCustomerInfoView ���

#ifdef _DEBUG
void CCustomerInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCustomerInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CCustomerInfoDoc* CCustomerInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCustomerInfoDoc)));
	return reinterpret_cast<CCustomerInfoDoc*>(m_pDocument);
}
#endif //_DEBUG


// CCustomerInfoView ��Ϣ��������


int CCustomerInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_CUSTINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;
	CGridColumnTraitCombo* pTraitCombo = nullptr;
	int idCat = 0;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 2:
		case 4:
		case 5:
		case 6:
		case 7:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 3:
			pTraitCombo = new CGridColumnTraitCombo();
			pTraitCombo->AddItem(idCat++, _T("����"));
			pTraitCombo->AddItem(idCat++, _T("��"));
			pTraitCombo->AddItem(idCat++, _T("Ů"));

			pTrait = pTraitCombo;
			break;
		case 10:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("δ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("�ѿ�"), true);
			pImageTrait->SetToggleSelection(true);
			pImageTrait->SetCellReadOnly();
			pTrait = pImageTrait;
			break;
		case 9:
			break;
		case 11:
			pTrait = new CGridColumnTraitDateTime();
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}


	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("�ͻ���Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CCustomerInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CCustomerInfoView::OnEditNewitem()
{
	Database::CCustomerInfo* pItem = new Database::CCustomerInfo();
	pItem->SetState(Database::NewItem);
	pItem->SetCellText(10, _T("0"));

	pItem->SetCellText(16, theApp.m_siInfo->m_strEntID);

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 10)
			{
				if (strCellText.Compare(_T("δ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CCustomerInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 2: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 9, tcsText);
				m_ListCtrl.SetItemText(nRow, 9, tcsText);
			}
		}
		break;
	case 3:
		if (pDispInfo->item.pszText != NULL)
		{
			if (_tcscmp(pDispInfo->item.pszText, _T("��")) == 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, nCol, _T("��"));
				m_ListCtrl.SetItemText(nRow, nCol, _T("��"));
			}
			else if (_tcscmp(pDispInfo->item.pszText, _T("Ů")) == 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, nCol, _T("Ů"));
				m_ListCtrl.SetItemText(nRow, nCol, _T("Ů"));
			}
			else
			{
				GetDocument()->m_vector.SetCellText(nRow, nCol, _T("����"));
				m_ListCtrl.SetItemText(nRow, nCol, _T("����"));
			}
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CCustomerInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCustomerInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CCustomerInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CCustomerInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCustomerInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CCustomerInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCustomerInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CCustomerInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CCustomerInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CCustomerInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CCustomerInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipCustInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipCustInfoTimerID);
		m_uipCustInfoTimerID = UINT(-1);
	}
	m_uipCustInfoTimerID = SetTimer(10, 1020, NULL);
	return 0L;
}

void CCustomerInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipCustInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipCustInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipCustInfoTimerID);
				m_uipCustInfoTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
