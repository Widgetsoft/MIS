#pragma once

namespace Business
{
	namespace Core
	{
		// CSaleServiceWork ����Ŀ��
		using DeleteTicketsVector = concurrency::concurrent_vector<std::shared_ptr<DataPattern::SCTicketIDGroupPure>>;

		class CSaleServiceWork : public CObject
		{
		public:
			CSaleServiceWork(Database::DataState enumDataState);
			virtual ~CSaleServiceWork();

		public:
			void InitializeDataSet(BOOL bCreateDate = TRUE, DataPattern::EnumBusinessType enumRequireBus = DataPattern::enumUnknown,
				LPCTSTR lpcszDateStart = nullptr, LPCTSTR lpcszDateEnd = nullptr);

			BOOL CreateNewTicketItem(LPCTSTR lpcszInitialID, DataPattern::EnumBusinessType enumBusinessType);

			std::tuple<double, double> FindOutDiscount() const;
			std::tuple<double, double, double> FindOutScoreAndCommission() const;
			void AutoCompletePayment();
			BOOL ReloadCurrentItem(BOOL bDetailsOnly = TRUE);

		public:
			//���ݼ�
			std::shared_ptr<DataPattern::CTickitsData> m_spDataSet;
			DeleteTicketsVector m_vectChangedItemBatch;

		public:
			//����ҵ������
			inline void SetBusinessType(const DataPattern::EnumBusinessType enumBusinessType) {
				m_enumCurrentTP = enumBusinessType;
			}

			//��ȡҵ������
			inline const DataPattern::EnumBusinessType GetBusinessType() const {
				return m_enumCurrentTP;
			}

		public:
			BOOL SendSynchronizationMessage(const CWnd* pWndLaunchSource, DataPattern::EnumBusinessType enumBusinessType,
				Database::DataState enumActionType, DataPattern::EnumObjectType ChangeObject, LPCTSTR lpcszObjectIDs,
				size_t szExtraSize, const PVOID pDataExtra) const;

		protected:
			void LoadMetaDataOptions(GenerialPattern::CItemsData* pRetValue);


			//��������
			DataPattern::EnumBusinessType m_enumCurrentTP;

		};
	}
}


