// InvBalPickupDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "LocalDataGridView.h"
#include "InvBalPickupDlg.h"
#include "afxdialogex.h"

using namespace Business;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CInvBalPickupDlg �Ի���

IMPLEMENT_DYNAMIC(CInvBalPickupDlg, CDialogEx)

CInvBalPickupDlg::CInvBalPickupDlg(Database::CInventoriesVector* pNewVector, std::vector<CString> vectNewItemIDs, CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_INVSEL_DLG, pParent),
	m_pNewVector(pNewVector),
	m_vectNewItemIDs(vectNewItemIDs),
	m_spAllItems( new Database::CInventoriesSelVector())
{
	_tcscpy_s(m_tcsTitle, MAX_PATH, _T("������ѡ�����ʼ��������Ŀ��Ȼ������ѡȡ����ť��"));

	m_Icons.SetImageSize(CSize(32, 32));
	m_Icons.Load(IDB_BUS_DICT);

	CMFCControlRendererInfo params(_T(""), CLR_DEFAULT, CRect(0, 0, 350, 60), CRect(83, 58, 266, 1), CRect(0, 0, 0, 0), CRect(0, 0, 0, 0), FALSE);

	params.m_uiBmpResID = IDB_HEADERPART_1;
	m_Pat[0].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_2;
	m_Pat[1].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_3;
	m_Pat[2].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_4;
	m_Pat[3].Create(params);

}

CInvBalPickupDlg::~CInvBalPickupDlg()
{
}

void CInvBalPickupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_INVSEL_GRID, m_ListCtrl);
}


BEGIN_MESSAGE_MAP(CInvBalPickupDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IDOK, &CInvBalPickupDlg::OnBnClickedOk)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_INVSEL_GRID, &CInvBalPickupDlg::OnLvnEndlabeledit)

	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CInvBalPickupDlg::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CInvBalPickupDlg::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CInvBalPickupDlg::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CInvBalPickupDlg::OnEditFind)
END_MESSAGE_MAP()


void CInvBalPickupDlg::LoadListItems()
{
	Database::CInventoriesSelVector vectTemp;
	LOCALEDB;
	CString strQuery;
	strQuery.Format(_T("%s"), _T("SELECT * FROM tsw_viewNullInventories ORDER BY �ⷿ, ��Ʒ����;"));
	pDataBase->GetInventoriesSel(strQuery, vectTemp);

	m_spAllItems->ClearItems();


	int nItem = 0;
	for (size_t rowId = 0; rowId < vectTemp.GetCount(); ++rowId)
	{
		//if(m_pVector->GetCellText(rowId, 0).c_str())
		//���û����Ӧ�Ŀⷿ����Ʒ
		if (m_vectNewItemIDs.size() > 0)
		{
			auto strID = vectTemp.GetCellText(rowId, 9);
			strID.Append(vectTemp.GetCellText(rowId, 10));
			auto itFound = std::find_if(m_vectNewItemIDs.begin(), m_vectNewItemIDs.end(),
				[&strID](const CString& strSourceID)->bool {
				return strSourceID.Compare(strID) == 0;
			});
			if (itFound != m_vectNewItemIDs.end())
			{
				continue; //����Ѿ����ӹ���������
			}
		}

		auto pNewItem = m_spAllItems->NewItem();
		for (int col = 0; col < (int)(vectTemp.GetColCount()); ++col)
		{
			pNewItem->SetCellText(col, vectTemp.GetCellText(rowId, col));
		}
		pNewItem->SetState(vectTemp.GetItem(rowId)->GetState());
		m_spAllItems->AddItem(pNewItem);

		//��˳��ֵ
		nItem = m_ListCtrl.InsertItem(++nItem, vectTemp.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);

		for (int col = 0; col < (int)(vectTemp.GetColCount()) - 4; ++col)
		{
			int nCellCol = col + 1;	 // +1 because of hidden column
			auto strCellText = vectTemp.GetCellText(rowId, nCellCol);
			if (nCellCol == 1)
			{
				if (strCellText.Compare(_T("���ѡ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
}

// CInvBalPickupDlg ��Ϣ��������


BOOL CInvBalPickupDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	m_ListCtrl.SetContextMenu(IDR_POPUP_MINI);
	m_ListCtrl.SetVector(m_spAllItems.get());

	// Create and attach image list
	m_ImageList1.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList1);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList1, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage *pImageTrait = nullptr;

	for (int col = 0; col < (int)(m_spAllItems->GetColCount()) - 4; ++col)
	{
		//�����ڲ�����
		auto title = m_spAllItems->GetColTitle(col + 1);

		CGridColumnTrait* pTrait = nullptr;
		switch (col + 1)
		{
		case 1:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("���ѡ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("��ѡ��"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		default:
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��Ʒ�������(ѡȡ)"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	LoadListItems();
	// �������е�δ��ʼ������Ŀ

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}


void CInvBalPickupDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CRect rectClient;
	GetClientRect(&rectClient);

	CDrawingManager dm(dc);
	COLORREF clrFill = afxGlobalData.clrBarFace;
	CMFCControlRenderer* pRenderer = NULL;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_OFF_2007_BLUE:
		pRenderer = &m_Pat[1];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_BLACK:
		pRenderer = &m_Pat[2];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_SILVER:
		pRenderer = &m_Pat[0];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_AQUA:
		pRenderer = &m_Pat[3];
		break;
	default:
		pRenderer = &m_Pat[1];
		break;
	}
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialogEx::OnPaint()

	CRect rectHeader(0, 0, rectClient.right, 80);

	if (pRenderer != NULL)
	{

		pRenderer->Draw(&dc, rectHeader);
	}
	else
	{
		dm.FillGradient(rectHeader, dc.GetPixel(rectHeader.left, rectHeader.bottom), clrFill);
	}

	rectHeader.bottom -= 10;

	CRect rectIcon = rectHeader;
	rectIcon.left += 20;
	rectIcon.right = rectIcon.left + 32;

	m_Icons.DrawEx(&dc, rectIcon, 0, CMFCToolBarImages::ImageAlignHorzLeft, CMFCToolBarImages::ImageAlignVertCenter);

	CRect rectText = rectHeader;
	rectText.left = rectIcon.right + 10;
	rectText.right -= 20;

	CFont* pOldFont = dc.SelectObject(&afxGlobalData.fontBold);
	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(afxGlobalData.clrBarText);

	UINT uiFlags = DT_SINGLELINE | DT_VCENTER;

	CRect rectTextCalc = rectText;
	dc.DrawText(m_tcsTitle, rectTextCalc, uiFlags | DT_CALCRECT);

	if (rectTextCalc.right > rectText.right)
	{
		rectText.DeflateRect(0, 10);
		uiFlags = DT_WORDBREAK;
	}

	dc.DrawText(m_tcsTitle, rectText, uiFlags);

	dc.SelectObject(pOldFont);
}


BOOL CInvBalPickupDlg::OnEraseBkgnd(CDC* pDC)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	CDrawingManager dm(*pDC);
	dm.FillGradient(rcClient, RGB(236, 246, 237), RGB(255, 255, 255), TRUE);
	return TRUE;
}

void CInvBalPickupDlg::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 1:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			m_spAllItems->SetCellText(nRow, nCol, tcsText);
		}
		break;
	default:
		break;
	}
	*pResult = 0;
}

void CInvBalPickupDlg::OnBnClickedOk()
{
	//��ʼ�����Ѿ�ѡ������Ŀ
	for each (auto iter in *m_spAllItems)
	{
		if (iter->GetCellText(1).Compare(_T("��ѡ��")) == 0)
		{
			auto pNewItem = m_pNewVector->NewItem();
			pNewItem->SetState(Database::NewItem);
			for (int i = 2; i != iter->GetColCount(); i++)
			{
				pNewItem->SetCellText(i - 1, iter->GetCellText(i));
			}
			m_pNewVector->AddItem(pNewItem);
		}
	}
	CDialogEx::OnOK();
}


void CInvBalPickupDlg::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_spAllItems->GetCount() > 0);
}


void CInvBalPickupDlg::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CInvBalPickupDlg::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_spAllItems->GetCount() > 0);
}


void CInvBalPickupDlg::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}
