#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"

using namespace Business::DataPattern;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// CTickitsItem
CTickitsItem::CTickitsItem(const EnumBusinessType oprateType, Database::CFlybyItem* pItem,
	Database::CFlybyData* pItemDetails, const EnumBusinessType SourceType)
	: m_oprateType(oprateType), m_spItem(pItem)
	, m_spItemDetails(pItemDetails), m_SourceType(SourceType)
{

}

CTickitsItem::~CTickitsItem()
{
}

std::shared_ptr<Database::CFlybyItem> CTickitsItem::GetItem() const
{
	return m_spItem;
}

std::shared_ptr<Database::CFlybyData> CTickitsItem::GetItemDetails() const
{
	return m_spItemDetails;
}

void CTickitsItem::AssignItem(std::shared_ptr<Database::CFlybyItem> spItem,
	std::shared_ptr<Database::CFlybyData> spItemDetails)
{	
	m_spItem.swap(spItem);
	m_spItemDetails.swap(spItemDetails);
}

///////////////////////////////////////////////////////////////////
//CTickitMap

CTickitMap::~CTickitMap()
{
}

STDString CTickitMap::GetCurrentItemKey() const
{
	if (m_pCurrentItem != nullptr)
	{
		return m_vectKeys.at(m_szIndex);
	}
	return _T("");
}

void CTickitMap::PushbackItem(STDString strKey, std::shared_ptr<CTickitsItem> spItem)
{
	auto nSize = m_vectKeys.size();
	if (this->find(strKey) == this->end())
	{
		if (nSize != 0)
		{
			nSize = nSize - 1;
		}
		this->m_vectKeys.push_back(STDString(strKey));
		this->insert(CTickitMap::value_type(strKey, spItem));
	}
}

void CTickitMap::DeleteItem(STDString strKey)
{
	auto szIndex = m_vectKeys.size() - 1;
	STDString strLeast = m_vectKeys[szIndex];
	std::remove_if(m_vectKeys.begin(), m_vectKeys.end(), [&](STDString str1)->bool {
		return strKey.compare(str1) == 0;
	});
	m_vectKeys.resize(szIndex, strLeast);

	auto itFind = find(strKey);
	auto szCount = this->size() - 1;
	if (itFind != end())
	{
		erase(itFind);
	}
	if (m_szIndex != 0)
	{
		m_szIndex--;
		MoveToRecord(m_szIndex);
	}
	else
	{
		m_pCurrentItem = nullptr;
	}
	
}

BOOL CTickitMap::IsExistsRecord(const size_t uiIndex) const
{
	return (uiIndex < m_vectKeys.size() && uiIndex >= 0);
}

BOOL CTickitMap::IsExistsRecord(const STDString uiIndex) const
{
	return find(uiIndex) != end();
}

std::shared_ptr<CTickitsItem> CTickitMap::GetItemByIndex(UINT nIndex) const
{
	if (nIndex >= 0 && nIndex < m_vectKeys.size())
	{
		STDString strKey = m_vectKeys.at(nIndex);
		auto itFound = this->find(strKey);
		if (itFound != end())
		{
			return itFound->second;
		}
	}

	return NULL;
}

size_t CTickitMap::DetermininIndex(const STDString strKey)
{
	Concurrency::structured_task_group group;
	size_t szCount = m_vectKeys.size(), szStart = 0;
	size_t nFoundIndex = -1;
	group.run_and_wait([&]() {
		Concurrency::parallel_for(szStart, szCount, [&](const size_t nIndex)->void {
			if (m_vectKeys.at(nIndex).compare(strKey) == 0)
			{
				nFoundIndex = nIndex;
				group.cancel();
			}
		});
	});
	return nFoundIndex;
}

BOOL CTickitMap::CurrentRecordBySourceID(const STDString strRefKey, UINT nRefCol)
{
	if (this->size() < 1)
	{
		return FALSE;
	}

	auto strKey = GetItemIDBySourceID(strRefKey, nRefCol);

	BOOL bRet = MoveToRecord(strKey);

	return bRet;
}


STDString CTickitMap::GetItemIDBySourceID(const STDString strRefKey, UINT nRefCol)
{
	STDString strRet;

	if (this->size() < 1)
	{
		return strRet;
	}

	Concurrency::structured_task_group group;

	if (nRefCol != -1)
	{
		//�ȼ������м�¼
		group.run_and_wait([&]() {
			concurrency::parallel_for_each(begin(), end(),
				[&group, &strRet, strRefKey, nRefCol](const std::pair<STDString, std::shared_ptr<CTickitsItem>> pSource) {
				if (pSource.second->GetItem()->GetCellText(nRefCol).Compare(strRefKey.c_str()) == 0)
				{
					strRet.clear();
					strRet.append(pSource.first.c_str());
					group.cancel();
				}
			});
		});
	}
	else
	{
		group.run_and_wait([&]() {
			concurrency::parallel_for_each(begin(), end(),
				[&group, &strRet, strRefKey](const std::pair<STDString, std::shared_ptr<CTickitsItem>> pSource) {
				Concurrency::structured_task_group group1;
				group1.run_and_wait([&]() {
					UINT nStart = 0;
					concurrency::parallel_for(nStart, pSource.second->GetItem()->GetColCount(),
						[pSource, &group1, &strRet, strRefKey](auto nCol) {
						if (pSource.second->GetItem()->GetCellText(nCol).Compare(strRefKey.c_str()) == 0)
						{
							strRet.clear();
							strRet.append(pSource.first.c_str());
							group1.cancel();
						}
					});
				});
				if (strRet.size() > 0)
				{
					group.cancel();
				}
			});
		});
	}

	return strRet;
}

BOOL CTickitMap::First()
{
	BOOL bRet = FALSE;
	if (m_vectKeys.size() > 0)
	{
		STDString strKey = m_vectKeys.at(0);
		auto itFind = find(strKey);
		if (itFind != end())
		{
			m_pCurrentItem = itFind->second.get();
			bRet = TRUE;
			m_szIndex = 0;
		}
	}
	return bRet;
}

BOOL CTickitMap::Previous()
{
	BOOL bRet = FALSE;
	if (m_pCurrentItem != nullptr )
	{
		auto nIndex = m_szIndex;
		if (nIndex > 0)
		{
			nIndex--;
			m_szIndex--;
			CTickitMap::iterator itFind =
				find(m_vectKeys.at(nIndex));
			if (itFind != end())
			{
				m_pCurrentItem = itFind->second.get();
				bRet = TRUE;
			}
		}

	}
	return bRet;
}

BOOL CTickitMap::Next()
{
	BOOL bRet = FALSE;
	if (m_pCurrentItem != nullptr)
	{
		STDString strKey = m_pCurrentItem->GetItem()->GetCellText(0);
		auto nIndex = m_szIndex;
		if (nIndex < m_vectKeys.size() - 1)
		{
			nIndex++;
			m_szIndex++;
			CTickitMap::iterator itFind =
				find(m_vectKeys.at(nIndex));
			if (itFind != end())
			{
				m_pCurrentItem = itFind->second.get();
				bRet = TRUE;
			}
		}

	}
	return bRet;
}

BOOL CTickitMap::Last()
{
	BOOL bRet = FALSE;
	if (m_vectKeys.size() > 0)
	{
		STDString strKey = m_vectKeys.at(m_vectKeys.size() - 1 );
		auto itFind = find(strKey);
		if (itFind != end())
		{
			m_pCurrentItem = itFind->second.get();
			bRet = TRUE;
			m_szIndex = m_vectKeys.size() - 1;
		}
	}
	return bRet;
}

BOOL CTickitMap::MoveToRecord(const size_t uiIndex)
{
	BOOL bRet = FALSE;
	if (uiIndex >= 0 && uiIndex < m_vectKeys.size())
	{
		auto itFind = this->find(m_vectKeys[uiIndex]);
		if (itFind != end())
		{
			this->m_pCurrentItem = itFind->second.get();
			bRet = TRUE;
		}
	}
	return bRet;
}

void CTickitMap::SetCurrentIndex(const size_t cnIndex)
{
	m_szIndex = cnIndex;
	MoveToRecord(cnIndex);
}

BOOL CTickitMap::MoveToRecord(const STDString strIndex)
{
	BOOL bRet = FALSE;
	auto itFind = this->find(strIndex);
	if (itFind != this->end())
	{
		this->m_pCurrentItem = itFind->second.get();
		bRet = TRUE;
	}
	return bRet;
}
///////////////////////////////////////////////////////////////////
//CTickitsData
BOOL CTickitsData::IsExistsPage(const size_t nPage) const
{
	return (vectTickits.find(nPage) != vectTickits.end());
}

std::shared_ptr<CTickitMap> CTickitsData::GetPage(const size_t nPage) const
{
	auto it = vectTickits.find(nPage);
	if (it == vectTickits.end())
	{
		return NULL;
	}
	return it->second;
}

BOOL CTickitsData::IsExistsDataItem(const size_t nPage, LPCTSTR lpcszMainItemKey)
{
	BOOL bExists = FALSE;
	if (IsExistsPage(nPage))
	{
		auto pPage = GetPage(nPage);
		CTickitMap::iterator itFind = pPage->find(STDString(lpcszMainItemKey));
		return (itFind != pPage->end());
	}
	return bExists;
}

std::shared_ptr<CTickitsItem> CTickitsData::GetDataItem(const size_t nPage, LPCTSTR lpcszMainItemKey)
{
	auto pPage = GetPage(nPage);
	CTickitMap::iterator itFind = pPage->find(STDString(lpcszMainItemKey));
	if (itFind == pPage->end())
	{
		return NULL;
	}

	return itFind->second;
}

void CTickitsData::AddDataItem(const size_t nPage, LPCTSTR lpcszMainItemKey, Database::CFlybyItem* pItem,
	Database::CFlybyData* pItemDetails, EnumBusinessType oprateType, EnumBusinessType SourceType)
{
	if (IsExistsDataItem(nPage, lpcszMainItemKey))
	{
		auto spDataItem = GetDataItem(nPage, lpcszMainItemKey);
		spDataItem->AssignItem(std::shared_ptr<Database::CFlybyItem>(pItem), std::shared_ptr<Database::CFlybyData>(pItemDetails));
	}
	else
	{
		vectTickits.insert(TickitsMap::value_type(nPage, std::shared_ptr<CTickitMap>(new CTickitMap())));
		auto ptPage = GetPage(nPage);
		ptPage->PushbackItem(STDString(lpcszMainItemKey),
			std::shared_ptr<CTickitsItem>(new CTickitsItem(oprateType, pItem, pItemDetails, SourceType)));
	}
}

std::shared_ptr<Database::CFlybyItem> CTickitsData::GetDataItemItem(const size_t nPage, LPCTSTR lpcszMainItemKey)
{
	if (IsExistsDataItem(nPage, lpcszMainItemKey))
	{
		auto pDataItem = GetDataItem(nPage, lpcszMainItemKey);
		return pDataItem->GetItem();
	}
	return NULL;
}

std::shared_ptr<Database::CFlybyData> CTickitsData::GetDataItemValues(const size_t nPage, LPCTSTR lpcszMainItemKey)
{
	if (IsExistsDataItem(nPage, lpcszMainItemKey))
	{
		auto pDataItem = GetDataItem(nPage, lpcszMainItemKey);
		return pDataItem->GetItemDetails();
	}
	return NULL;
}

BOOL CTickitsData::AddDataItemValue(const size_t nPage, LPCTSTR lpcszMainItemKey,
	Database::CFlybyItem* pItemValue)
{
	if (IsExistsDataItem(nPage, lpcszMainItemKey))
	{
		auto pDataItem = GetDataItem(nPage, lpcszMainItemKey);
		if (pDataItem->GetItemDetails() != NULL)
		{
			pDataItem->GetItemDetails()->AddItem(pItemValue);
			return TRUE;
		}
	}
	return FALSE;
}


BOOL CTickitsData::IteratorKeys(const size_t nPage, Concurrency::concurrent_vector<STDString>& Keys)
{
	BOOL bSucc = FALSE;
	if (IsExistsPage(nPage))
	{
		auto pPage = GetPage(nPage);

		Concurrency::parallel_for_each(pPage->begin(), pPage->end(),
			[&bSucc, &Keys](const CTickitMap::value_type& args)
		{
			Keys.push_back(STDString(args.first));
			bSucc = TRUE;
		});
	}
	return bSucc;
}

BOOL CTickitsData::GetCurrentFlybyData(const size_t nPage, PVOID* ppObj, const BOOL bGetKey)
{
	BOOL bSucc = FALSE;
	if (IsExistsPage(nPage))
	{
		auto pPage = GetPage(nPage);
		if (!pPage->IsCurrentTickitsItemNULL())
		{
			if (bGetKey)
			{
				*ppObj = pPage->GetCurrentTickitsItem()->GetItem().get();
				bSucc = TRUE;
			}
			else
			{
				*ppObj = pPage->GetCurrentTickitsItem()->GetItemDetails().get();
				bSucc = TRUE;
			}
		}
	}
	return bSucc;
}

void FillVectorStub(CString strQuery, EnumBusinessType enumBusType, 
	concurrency::concurrent_vector<SCTicketIDGroup> &vectObject)
{
	LOCALEDB;
	Database::PStrVector* pRetTable = nullptr;
	if (pDataBase->NormalQuery(strQuery, (PVOID*)&pRetTable) && pRetTable != nullptr)
	{
		if (pRetTable->size() > 0)
		{
			for (auto it : *pRetTable)
			{
				SCTicketIDGroup item;
				ZeroMemory(&item, sizeof(SCTicketIDGroup));
				//��������
				item.enumBusinessType = enumBusType;
				//�������
				_tcscpy_s(item.MainID, _countof(item.MainID), it->at(0));
				_tcscpy_s(item.PaymentID, _countof(item.PaymentID), it->at(1));
				_tcscpy_s(item.StockOutID, _countof(item.StockOutID), it->at(2));
				COleDateTime dateTemp;
				dateTemp.ParseDateTime(it->at(3));
				item.CreateTime = dateTemp;
				dateTemp.ParseDateTime(it->at(4));
				item.BusinessTime = dateTemp;
				vectObject.push_back(item);
			}
		}
		delete pRetTable;
	}
}

concurrency::concurrent_vector<SCTicketIDGroup> CTickitsData::GetAllTicketsIDs(BOOL bLoadTickets, CTickitsData* pVector,
	BOOL bCreateDate, EnumBusinessType enumRequireBus, LPCTSTR lpcszDateStart, LPCTSTR lpcszDateEnd)
{
	concurrency::concurrent_vector<SCTicketIDGroup> retVector;
	COleDateTime TimeStart, TimeEnd, TimeNow = COleDateTime::GetCurrentTime();
	COleDateTimeSpan TimePeriod;

	BOOL bNotRequireDate = FALSE;

	if (!(lpcszDateStart == nullptr || _tcslen(lpcszDateStart) < 1) &&
		!(lpcszDateEnd == nullptr || _tcslen(lpcszDateEnd) < 1))
	{ //ֱ�ӽ�����ʼ���ںͽ�������
		TimeStart.ParseDateTime(lpcszDateStart);
		TimeEnd.ParseDateTime(lpcszDateEnd);
	}
	else
	{
		int nTemp = 0, nTemp1 = 0;
		switch (theApp.m_uiBusinessLoadPeriod)
		{
		case 0: //��������
			TimeStart.SetDateTime(TimeNow.GetYear(), TimeNow.GetMonth(), TimeNow.GetDay(), 0, 0, 0);
			TimeEnd.SetDateTime(TimeNow.GetYear(), TimeNow.GetMonth(), TimeNow.GetDay(), 23, 59, 59);
			break;
		case 1: //���3������
			TimePeriod.SetDateTimeSpan(2, 23, 59, 59);
			TimeEnd.SetDateTime(TimeNow.GetYear(), TimeNow.GetMonth(), TimeNow.GetDay(), 23, 59, 59);
			TimeStart = TimeEnd - TimePeriod;
			break;
		case 2: //��������
			nTemp = TimeNow.GetDayOfWeek();
			TimePeriod.SetDateTimeSpan(nTemp - 1, 23, 59, 59);
			TimeEnd.SetDateTime(TimeNow.GetYear(), TimeNow.GetMonth(), TimeNow.GetDay(), 23, 59, 59);
			TimeStart = TimeEnd - TimePeriod;
			break;
		case 3: //���15������
			TimePeriod.SetDateTimeSpan(14, 23, 59, 59);
			TimeEnd.SetDateTime(TimeNow.GetYear(), TimeNow.GetMonth(), TimeNow.GetDay(), 23, 59, 59);
			TimeStart = TimeEnd - TimePeriod;
			break;
		case 4: //��������
			nTemp = TimeNow.GetDay();
			TimePeriod.SetDateTimeSpan(nTemp - 1, 23, 59, 59);
			TimeEnd.SetDateTime(TimeNow.GetYear(), TimeNow.GetMonth(), TimeNow.GetDay(), 23, 59, 59);
			TimeStart = TimeEnd - TimePeriod;
			break;
		case 5: //��������
			nTemp = TimeNow.GetMonth();
			if (nTemp >= 1 && nTemp <= 3)
			{
				//��һ����
				TimeStart.SetDateTime(TimeNow.GetYear(), 1, 1, 0, 0, 0);
				TimeEnd.SetDateTime(TimeNow.GetYear(), 3, 31, 23, 59, 59);
			}
			else if (nTemp >= 4 && nTemp <= 6)
			{
				//�ڶ�����
				TimeStart.SetDateTime(TimeNow.GetYear(), 4, 1, 0, 0, 0);
				TimeEnd.SetDateTime(TimeNow.GetYear(), 6, 30, 23, 59, 59);
			}
			else if (nTemp >= 7 && nTemp <= 9)
			{
				//��������
				TimeStart.SetDateTime(TimeNow.GetYear(), 7, 1, 0, 0, 0);
				TimeEnd.SetDateTime(TimeNow.GetYear(), 9, 30, 23, 59, 59);
			}
			else if (nTemp >= 10 && nTemp <= 12)
			{
				//���ļ���
				TimeStart.SetDateTime(TimeNow.GetYear(), 10, 1, 0, 0, 0);
				TimeEnd.SetDateTime(TimeNow.GetYear(), 12, 31, 23, 59, 59);
			}
			break;
		case 6: //����������
			nTemp = TimeNow.GetMonth();
			if (nTemp < 7)
			{
				//�ϰ���
				TimeStart.SetDateTime(TimeNow.GetYear(), 1, 1, 0, 0, 0);
				TimeEnd.SetDateTime(TimeNow.GetYear(), 6, 30, 23, 59, 59);
			}
			else
			{
				//�ϰ���
				TimeStart.SetDateTime(TimeNow.GetYear(), 7, 1, 0, 0, 0);
				TimeEnd.SetDateTime(TimeNow.GetYear(), 12, 31, 23, 59, 59);
			}
			break;
		case 7: //��������
			TimeStart.SetDateTime(TimeNow.GetYear(), 1, 1, 0, 0, 0);
			TimeEnd.SetDateTime(TimeNow.GetYear(), 12, 31, 23, 59, 59);
			break;
		case 8:
			bNotRequireDate = TRUE;
			break;
		}
	}
	CString strQuery1, strQuery2;
	strQuery1.Append(_T("SELECT A.SalesID ��������, B.PayID �������, C.StockID ���ⵥ���, A.CreateDate ��������, A.SalesDate �������� FROM (tsw_tabSalesFlow A INNER JOIN tsw_tabPaymentFlow B ON A.SalesID LIKE B.sourceID) INNER JOIN tsw_tabStockFlow C ON A.SalesID LIKE C.StockSourceID"));
	if (bNotRequireDate)
	{
		strQuery1.Append(_T(" ORDER BY A.CreateDate;"));
	}
	else
	{
		if (bCreateDate)
		{
			strQuery1.AppendFormat(_T(" WHERE A.CreateDate BETWEEN '%s' AND '%s' ORDER BY A.CreateDate;"), 
				Database::CFlybyItem::FormatDateTime(TimeStart.Format()), Database::CFlybyItem::FormatDateTime(TimeEnd.Format()));
		}
		else
		{
			strQuery1.AppendFormat(_T(" WHERE A.SalesDate BETWEEN '%s' AND '%s' ORDER BY A.SalesDate;"), 
				Database::CFlybyItem::FormatDateTime(TimeStart.Format()), Database::CFlybyItem::FormatDateTime(TimeEnd.Format()));
		}
	}
	strQuery2.Append(_T("SELECT A.SvcID ��������, B.PayID �������, '' ���ⵥ���, A.CreateDate ��������, A.ServiceDate �������� FROM tsw_tabServiceFlow A INNER JOIN tsw_tabPaymentFlow B ON A.SvcID LIKE B.sourceID"));
	if (bNotRequireDate)
	{
		strQuery2.Append(_T(" ORDER BY A.CreateDate;"));
	}
	else
	{
		if (bCreateDate)
		{
			strQuery2.AppendFormat(_T(" WHERE A.CreateDate BETWEEN '%s' AND '%s' ORDER BY A.CreateDate;"), 
				Database::CFlybyItem::FormatDateTime(TimeStart.Format()), Database::CFlybyItem::FormatDateTime(TimeEnd.Format()));
		}
		else
		{
			strQuery2.AppendFormat(_T(" WHERE A.SalesDate BETWEEN '%s' AND '%s' ORDER BY A.SalesDate;"), 
				Database::CFlybyItem::FormatDateTime(TimeStart.Format()), Database::CFlybyItem::FormatDateTime(TimeEnd.Format()));
		}
	}
	LOCALEDB;
	if (enumRequireBus == enumSalesTikits)
	{
		FillVectorStub(strQuery1, enumSalesTikits, retVector);
	}
	else if (enumRequireBus == enumServiceTikits)
	{
		FillVectorStub(strQuery2, enumServiceTikits, retVector);
	}
	else if (enumRequireBus == enumUnknown)
	{
		FillVectorStub(strQuery1, enumSalesTikits, retVector);
		FillVectorStub(strQuery2, enumServiceTikits, retVector);
		if (retVector.size() > 0)
		{
			BOOL bSortbyCreateDate = bCreateDate;
			Concurrency::parallel_sort(retVector.begin(), retVector.end(), [bSortbyCreateDate](auto left, auto right)->BOOL {
				if (bSortbyCreateDate)
				{
					return left.CreateTime < right.CreateTime;
				}
				else
				{
					return left.BusinessTime < right.BusinessTime;
				}
			});
		}
	}

	if (bLoadTickets && pVector != nullptr)
	{
		if (retVector.size() > 0)
		{
			for (auto it : retVector)
			{
				//��ʼ������������
				Database::CFlybyItem* pNewMainItem = nullptr;
				Database::CFlybyData* pNewMainItemDetails = nullptr;

				Database::CFlybyItem* pNewPaymentItem = nullptr;
				Database::CFlybyData* pNewPaymentItemDetails = nullptr;

				Database::CFlybyItem* pNewStockItem = nullptr;
				Database::CFlybyData* pNewStockItemDetails = nullptr;

				if (it.enumBusinessType == enumSalesTikits)
				{
					//���ز���������
					Database::CSalesFlowVector saleVector;
					strQuery1.Format(_T("SELECT * FROM %s WHERE ���۱��� LIKE '%s'"),
						saleVector.m_strBindTable, it.MainID);
					pDataBase->GetSalesFlow(strQuery1, saleVector);
					saleVector.GetItem(0)->Clone(&pNewMainItem);
					Database::CSalesFlowDetailsVector* pDetails =
						std::auto_ptr<Database::CSalesFlowDetailsVector>(new Database::CSalesFlowDetailsVector()).release();
					strQuery1.Format(_T("SELECT * FROM %s WHERE �ܵ����� LIKE '%s'"),
						pDetails->m_strBindTable, it.MainID);
					pDataBase->GetSalesFlowDetails(strQuery1, *pDetails);
					pNewMainItemDetails = pDetails;

					Database::CStockFlowVector stockVector;
					strQuery1.Format(_T("SELECT * FROM %s WHERE �ڲ����� LIKE '%s'"),
						stockVector.m_strBindTable, it.StockOutID);
					pDataBase->GetStockFlow(strQuery1, stockVector);
					stockVector.GetItem(0)->Clone(&pNewStockItem);
					Database::CStockFlowDetailsVector* pStockDetails =
						std::auto_ptr<Database::CStockFlowDetailsVector>(new Database::CStockFlowDetailsVector()).release();;
					strQuery1.Format(_T("SELECT * FROM %s WHERE ������ LIKE '%s'"),
						pStockDetails->m_strBindTable, it.StockOutID);
					pDataBase->GetStockFlowDetails(strQuery1, *pStockDetails);
					pNewStockItemDetails = pStockDetails;
				}
				else
				{
					//���ز���������
					Database::CServiceFlowVector svcVector;
					strQuery1.Format(_T("SELECT * FROM %s WHERE ������� LIKE '%s'"),
						svcVector.m_strBindTable, it.MainID);
					pDataBase->GetServiceFlow(strQuery1, svcVector);
					svcVector.GetItem(0)->Clone(&pNewMainItem);
					Database::CServiceFlowDetailsVector* pDetails =
						std::auto_ptr<Database::CServiceFlowDetailsVector>(new Database::CServiceFlowDetailsVector()).release();
					strQuery1.Format(_T("SELECT * FROM %s WHERE �ܵ����� LIKE '%s'"),
						pDetails->m_strBindTable, it.MainID);
					pDataBase->GetServiceFlowDetails(strQuery1, *pDetails);
					pNewMainItemDetails = pDetails;
				}

				//ͳһ���������¼
				Database::CPaymentFlowVector paymentVector;
				strQuery1.Format(_T("SELECT * FROM %s WHERE �ڲ����� LIKE '%s'"),
					paymentVector.m_strBindTable, it.PaymentID);
				pDataBase->GetPaymentFlow(strQuery1, paymentVector);
				paymentVector.GetItem(0)->Clone(&pNewPaymentItem);
				Database::CPaymentFlowDetailsVector* pPaymentDetails =
					std::auto_ptr<Database::CPaymentFlowDetailsVector>(new Database::CPaymentFlowDetailsVector()).release();
				strQuery1.Format(_T("SELECT * FROM %s WHERE �������� LIKE '%s'"),
					pPaymentDetails->m_strBindTable, it.PaymentID);
				pDataBase->GetPaymentFlowDetails(strQuery1, *pPaymentDetails);
				pNewPaymentItemDetails = pPaymentDetails;

				pVector->AddDataItem(0, it.MainID, pNewMainItem, pNewMainItemDetails, it.enumBusinessType);
				pVector->AddDataItem(1, it.PaymentID, pNewPaymentItem, pNewPaymentItemDetails, enumReceivableTickets, it.enumBusinessType);

				if (it.enumBusinessType == enumSalesTikits)
				{
					pVector->AddDataItem(2, it.StockOutID, pNewStockItem, pNewStockItemDetails, enumStoreOut, it.enumBusinessType);
				}
			}
		}
	}

	return retVector;
}
