// CEquipmentInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "EquipmentInfoDoc.h"
#include "LocalDataGridView.h"
#include "EquipmentInfoView.h"
#include "SystemInfo.h"

using namespace BasicInfo;
#define ID_GRID_EQUIPINFO 0x9012

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CEquipmentInfoView

IMPLEMENT_DYNCREATE(CEquipmentInfoView, CView)

CEquipmentInfoView::CEquipmentInfoView()
	:m_ListCtrl( IDR_POPUP_EDIT )
{
	m_uipTimerID = -1;
}

CEquipmentInfoView::~CEquipmentInfoView()
{
}

BEGIN_MESSAGE_MAP(CEquipmentInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CEquipmentInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_EQUIPINFO, &CEquipmentInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CEquipmentInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CEquipmentInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CEquipmentInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CEquipmentInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CEquipmentInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CEquipmentInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CEquipmentInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CEquipmentInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CEquipmentInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CEquipmentInfoView::OnEditFind)
	ON_MESSAGE(WM_EQUIPINFO_CHANGED, &CEquipmentInfoView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CEquipmentInfoView ��ͼ

void CEquipmentInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CEquipmentInfoView ���

#ifdef _DEBUG
void CEquipmentInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CEquipmentInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif

CEquipmentInfoDoc* CEquipmentInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEquipmentInfoDoc)));
	return reinterpret_cast<CEquipmentInfoDoc*>(m_pDocument);
}

#endif //_DEBUG

void CEquipmentInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetEquipmentInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 5)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("����")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

// CEquipmentInfoView ��Ϣ��������


int CEquipmentInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_EQUIPINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 2:
		case 3:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 5:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("һ����"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 6:
			pTrait = new CGridColumnTraitDateTime();
			break;
		case 11:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("����"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("��æ"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 7:
		case 10:
		case 12:
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("�����豸��Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CEquipmentInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CEquipmentInfoView::OnEditNewitem()
{
	Database::CEquipmentInfo* pItem = new Database::CEquipmentInfo();
	pItem->SetState(Database::NewItem);


	//���õ�ǰ��¼�û�
	pItem->SetCellText(16, theApp.m_siInfo->m_strUserInnerID);
	pItem->SetCellText(17, theApp.m_siInfo->m_strUserInnerID);
	pItem->SetCellText(18, theApp.m_siInfo->m_strEntID);

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 5)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("����")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CEquipmentInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 2: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 7, tcsText);
				m_ListCtrl.SetItemText(nRow, 7, tcsText);
			}
		}
		break;
	case 8:
	case 9:
	case 10:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	case 13:
		if (pDispInfo->item.pszText != NULL)
		{
			int nTemp = { 0 };
			nTemp = _ttoi(pDispInfo->item.pszText);
			CString strTemp;
			strTemp.Format(_T("%i"), nTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CEquipmentInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CEquipmentInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CEquipmentInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CEquipmentInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CEquipmentInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CEquipmentInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CEquipmentInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CEquipmentInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CEquipmentInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CEquipmentInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CEquipmentInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipTimerID != UINT(-1))
	{
		KillTimer(m_uipTimerID);
		m_uipTimerID = UINT(-1);
	}
	m_uipTimerID = SetTimer(33, 1033, NULL);
	return 0L;
}


void CEquipmentInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipTimerID != UINT(-1))
			{
				KillTimer(m_uipTimerID);
				m_uipTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
