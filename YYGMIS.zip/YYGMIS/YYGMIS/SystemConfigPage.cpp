// SystemConfigPage.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "SystemConfigPage.h"
#include "afxdialogex.h"

using namespace UI;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSystemConfigPage �Ի���

IMPLEMENT_DYNAMIC(CSystemConfigPage, CMFCPropertyPage)

CSystemConfigPage::CSystemConfigPage()
	: CMFCPropertyPage(IDD_PROP_SYSTEM)
{

}

CSystemConfigPage::~CSystemConfigPage()
{
}

void CSystemConfigPage::DoDataExchange(CDataExchange* pDX)
{
	CMFCPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSystemConfigPage, CMFCPropertyPage)
	ON_EN_UPDATE(IDC_REGISTER_CODE, &CSystemConfigPage::OnRegisterKeyUpdate)
	ON_EN_UPDATE(IDC_PROD_INTRATE, &CSystemConfigPage::OnProdRateUpdate)
	ON_EN_UPDATE(IDC_SVC_INTRATE, &CSystemConfigPage::OnSvcRateUpdate)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DT_START, &CSystemConfigPage::OnDtnStartDatetimechange)
	ON_BN_CLICKED(IDC_CHK_INIT, &CSystemConfigPage::OnBnClickedInitialChk)
	ON_CBN_SELCHANGE(IDC_CMB_LOADINTV, &CSystemConfigPage::OnCbnSelchangeCmbLoadintv)
END_MESSAGE_MAP()


// CSystemConfigPage ��Ϣ��������


BOOL CSystemConfigPage::OnInitDialog()
{
	CMFCPropertyPage::OnInitDialog();

	CWnd* pWndParent = this->GetParent();

	ASSERT(pWndParent != NULL && pWndParent->IsKindOf(RUNTIME_CLASS(CSystemConfigSheet)));

	CSystemConfigSheet* pSheet = reinterpret_cast<CSystemConfigSheet*>(pWndParent);
	m_pParentItem = pSheet->m_pVector;

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s"), m_pParentItem->m_strBindTable);
		BOOL bSuccess = pDataBase->GetSystemInfo(strQuery, *m_pParentItem);
		if (bSuccess == TRUE && m_pParentItem->GetCount() > 0)
		{
			//��������
			SetDlgItemText(IDC_SYSID, m_pParentItem->GetCellText(0, 0));
			if (theApp.m_bRegistered)
			{
				((CEdit*)GetDlgItem(IDC_REGISTER_CODE))->SetReadOnly();
				SetDlgItemText(IDC_REQUEST_CODE, _T("��ע��"));
				SetDlgItemText(IDC_REGISTER_CODE, _T("�������Ȩ"));
			}
			else
			{
				CString strTemp, strRequest;
				strTemp.Format(_T("%s@%s"), m_pParentItem->GetCellText(0, 1), m_pParentItem->GetCellText(0, 2));
				Helper::CToolkits::EncryptionAES256((PTSTR)(LPCTSTR)strTemp, theApp.m_strToken, strRequest);
				SetDlgItemText(IDC_REQUEST_CODE, strRequest);
			}
			SetDlgItemText(IDC_PROD_INTRATE, m_pParentItem->GetCellText(0, 5));
			SetDlgItemText(IDC_SVC_INTRATE, m_pParentItem->GetCellText(0, 6));
			COleDateTime dtStartTime;
			dtStartTime.ParseDateTime(m_pParentItem->GetCellText(0, 7));
			CDateTimeCtrl* pItemControl = reinterpret_cast<CDateTimeCtrl*>(GetDlgItem(IDC_DT_START));
			SYSTEMTIME sysTime;
			dtStartTime.GetAsSystemTime(sysTime);
			pItemControl->SetTime(&sysTime);

			UINT uiSelItem = _ttoi(m_pParentItem->GetCellText(0, 8));
			CComboBox* pComboBox = reinterpret_cast<CComboBox*>(GetDlgItem(IDC_CMB_LOADINTV));
			pComboBox->SetCurSel(uiSelItem);
		}
	}

	CButton* pChkIsChecked = reinterpret_cast<CButton*>(GetDlgItem(IDC_CHK_INIT));
	pChkIsChecked->SetCheck(theApp.m_bInitialized);
	if (theApp.m_bInitialized)
	{
		pChkIsChecked->EnableWindow(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void CSystemConfigPage::OnRegisterKeyUpdate()
{
	CString strRK;
	GetDlgItemText(IDC_REGISTER_CODE, strRK);
	auto pItem = m_pParentItem->GetItem(0);
	pItem->SetCellText(3, strRK);
}

void CSystemConfigPage::OnProdRateUpdate()
{
	CString strTemp;
	GetDlgItemText(IDC_PROD_INTRATE, strTemp);
	auto pItem = m_pParentItem->GetItem(0);
	pItem->SetCellText(5, strTemp);
	//SetDlgItemText(IDC_PROD_INTRATE, pItem->GetCellText(5));
}

void CSystemConfigPage::OnSvcRateUpdate()
{
	CString strTemp;
	GetDlgItemText(IDC_SVC_INTRATE, strTemp);
	auto pItem = m_pParentItem->GetItem(0);
	pItem->SetCellText(6, strTemp);
	//SetDlgItemText(IDC_SVC_INTRATE, pItem->GetCellText(6));
}

void CSystemConfigPage::OnDtnStartDatetimechange(NMHDR *pNMHDR, LRESULT *pResult)
{
	auto pItem = m_pParentItem->GetItem(0);
	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
	COleDateTime tempDate(pDTChange->st);
	pItem->SetCellText(7, tempDate.Format());
}

void CSystemConfigPage::OnBnClickedInitialChk()
{
	auto pItem = m_pParentItem->GetItem(0);
	BOOL bInitialized = IsDlgButtonChecked(IDC_CHK_INIT);
	if (bInitialized)
	{
		pItem->SetCellText(4, _T("�����"));
	}
	else
	{
		pItem->SetCellText(4, _T("δ���"));
	}
}

void CSystemConfigPage::OnCbnSelchangeCmbLoadintv()
{
	CComboBox* pComboBox = reinterpret_cast<CComboBox*>(GetDlgItem(IDC_CMB_LOADINTV));
	auto nCurSel = pComboBox->GetCurSel();
	if (nCurSel == CB_ERR)
	{
		nCurSel = 0;
	}
	CString str;
	str.Format(_T("%i"), nCurSel);
	auto pItem = m_pParentItem->GetItem(0);
	pItem->SetCellText(8, str);
}

/////////////////////////////////////////////////////////////////////////
//CSystemConfigSheet��

CSystemConfigSheet::~CSystemConfigSheet()
{
	delete m_pVector;
}

IMPLEMENT_DYNAMIC(CSystemConfigSheet, CMFCPropertySheet)

CSystemConfigSheet::CSystemConfigSheet(CWnd* pWndParent, UINT nSelectedPage)
	:CMFCPropertySheet(_T("ϵͳѡ������"), pWndParent, nSelectedPage), m_pVector( new Database::CYYGMISSystemInfoVector())
{
	m_Icons.SetImageSize(CSize(32, 32));
	m_Icons.Load(IDB_SYS_CONFIG);

	CMFCControlRendererInfo params(_T(""), CLR_DEFAULT, CRect(0, 0, 350, 60), CRect(83, 58, 266, 1), CRect(0, 0, 0, 0), CRect(0, 0, 0, 0), FALSE);

	params.m_uiBmpResID = IDB_HEADERPART_1;
	m_Pat[0].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_2;
	m_Pat[1].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_3;
	m_Pat[2].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_4;
	m_Pat[3].Create(params);
}



BEGIN_MESSAGE_MAP(CSystemConfigSheet, CMFCPropertySheet)
END_MESSAGE_MAP()


// CSystemConfigPage ��Ϣ��������

BOOL CSystemConfigSheet::OnInitDialog()
{
	BOOL bRes = CMFCPropertySheet::OnInitDialog();

	// Ensure that the Options dialog is fully visible on screen
	CRect rectDialog;

	GetWindowRect(&rectDialog);

	int cxScreen = GetSystemMetrics(SM_CXSCREEN);
	int cyScreen = GetSystemMetrics(SM_CYMAXIMIZED) - (GetSystemMetrics(SM_CYSCREEN) - GetSystemMetrics(SM_CYMAXIMIZED));

	if ((rectDialog.left < 0) || (rectDialog.top < 0))
	{
		SetWindowPos(NULL, rectDialog.left < 0 ? 0 : rectDialog.left, rectDialog.top < 0 ? 0 : rectDialog.top, 0, 0, SWP_NOSIZE);
	}
	else if ((rectDialog.right > cxScreen) || (rectDialog.bottom > cyScreen))
	{
		SetWindowPos(NULL, rectDialog.right > cxScreen ? cxScreen - rectDialog.Width() : rectDialog.left, rectDialog.bottom > cyScreen ? cyScreen - rectDialog.Height() : rectDialog.top, 0, 0, SWP_NOSIZE);
	}

	//����ϵ�кż�¼
	

	return bRes;
}

void CSystemConfigSheet::OnDrawPageHeader(CDC* pDC, int nPage, CRect rectHeader)
{
	CSize sizeIcon = m_Icons.GetImageSize();
	CDrawingManager dm(*pDC);

	COLORREF clrFill = afxGlobalData.clrBarFace;
	CMFCControlRenderer* pRenderer = NULL;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_OFF_2007_BLUE:
		pRenderer = &m_Pat[1];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_BLACK:
		pRenderer = &m_Pat[2];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_SILVER:
		pRenderer = &m_Pat[0];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_AQUA:
		pRenderer = &m_Pat[3];
		break;
	default:
		if (theApp.m_bHiColorIcons)
		{
			pRenderer = &m_Pat[1];
		}
		break;
	}

	if (pRenderer != NULL)
	{
		pRenderer->Draw(pDC, rectHeader);
	}
	else
	{
		dm.FillGradient(rectHeader, pDC->GetPixel(rectHeader.left, rectHeader.bottom), clrFill);
	}

	rectHeader.bottom -= 10;

	CRect rectIcon = rectHeader;
	rectIcon.left += 20;
	rectIcon.right = rectIcon.left + sizeIcon.cx;

	m_Icons.DrawEx(pDC, rectIcon, nPage, CMFCToolBarImages::ImageAlignHorzLeft, CMFCToolBarImages::ImageAlignVertCenter);

	CString strText;

	switch (nPage)
	{
	case 0:
		strText = _T("����һЩ���Ĺ���");
		break;

	case 1:
		strText = _T("�Զ����ݷ��ʹ������ͼ��̿�ݼ�");
		break;

	case 2:
		strText = _T("��ϵ����, ���ܹ������������ڹ��ڷ������Ϣ");
		break;
	}

	CRect rectText = rectHeader;
	rectText.left = rectIcon.right + 10;
	rectText.right -= 20;

	CFont* pOldFont = pDC->SelectObject(&afxGlobalData.fontBold);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(afxGlobalData.clrBarText);

	UINT uiFlags = DT_SINGLELINE | DT_VCENTER;

	CRect rectTextCalc = rectText;
	pDC->DrawText(strText, rectTextCalc, uiFlags | DT_CALCRECT);

	if (rectTextCalc.right > rectText.right)
	{
		rectText.DeflateRect(0, 10);
		uiFlags = DT_WORDBREAK;
	}

	pDC->DrawText(strText, rectText, uiFlags);

	pDC->SelectObject(pOldFont);
}

BOOL CSystemConfigSheet::OnCommand(WPARAM wParam, LPARAM lParam)
{
	if ((UINT)wParam == IDOK)
	{
		//����Ƿ�ı���ϵͳ������
		if (m_pVector->GetCount() > 0)
		{
			BOOL bIsRegister = theApp.m_bRegistered;			
			theApp.m_bRegistered = theApp.SystemPassGate(m_pVector->GetItem(0));
			if (theApp.m_bRegistered)
			{
				if (!bIsRegister)
				{
					MessageBox(_T("����ע��ɹ���лл����֧�֣�"), _T("����ע����Ϣ"), MB_OK | MB_ICONINFORMATION);
				}
				else
				{
					MessageBox(_T("ϵͳ���ñ���ɹ���"), _T("ϵͳ���ñ��֪ͨ"), MB_OK | MB_ICONINFORMATION);
				}
			}
		}
	}

	return CMFCPropertySheet::OnCommand(wParam, lParam);
}

