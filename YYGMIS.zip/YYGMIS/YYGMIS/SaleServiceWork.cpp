// SaleServiceWork.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "WorkAssistant.h"
#include "SaleServiceWork.h"
#include "SaleFrame.h"
#include "SystemInfo.h"

using namespace Business;
using namespace Business::Core;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSaleServiceWork

CSaleServiceWork::CSaleServiceWork(Database::DataState enumDataState)
	:m_spDataSet( new DataPattern::CTickitsData(enumDataState)),
	m_enumCurrentTP( DataPattern::enumUnknown )
{
}

CSaleServiceWork::~CSaleServiceWork()
{
}

// CSaleServiceWork ��Ա����

void CSaleServiceWork::LoadMetaDataOptions(GenerialPattern::CItemsData* pRetValue)
{
	CString strQuery;
	strQuery.Append(_T("SELECT deptID, deptName FROM tsw_tabAgencyInfo LIMIT 1;"));
	LOCALEDB;
	GenerialPattern::CItemData* pRow1 = nullptr, *pRow2 = nullptr, *pRow3 = nullptr;
	if (pDataBase->NormalGetItemData(strQuery, &pRow1) && pRow1 != nullptr)
	{
		if (pRow1->size() > 0)
		{
			pRetValue->AddItemData(0, pRow1); 
		}
	}
	strQuery.Empty();
	strQuery.Append(_T("SELECT WSPID, WSPName FROM tsw_tabWareHouseSalePointInfo LIMIT 1;"));
	if (pDataBase->NormalGetItemData(strQuery, &pRow2) && pRow2 != nullptr)
	{
		if (pRow2->size() > 0)
		{
			pRetValue->AddItemData(1, pRow2);
		}
	}

	auto nullID = Database::CFlybyItem::GetNullID();

	if (nullID.Compare(theApp.m_siInfo->m_strUserInnerID) == 0)
	{
		strQuery.Empty();
		strQuery.Append(_T("SELECT EID, EName FROM tsw_tabStaffInfo LIMIT 1;"));
		if (pDataBase->NormalGetItemData(strQuery, &pRow3) && pRow3 != nullptr)
		{
			if (pRow3->size() > 0)
			{
				pRetValue->AddItemData(2, pRow3);
			}
		}
	}
	else
	{
		std::auto_ptr<GenerialPattern::CItemData> apExecutor(new GenerialPattern::CItemData());
		apExecutor->AddRange(theApp.m_siInfo->m_strUserInnerID, theApp.m_siInfo->m_strUserName);
		pRetValue->AddItemData(2, apExecutor.release());
	}

	std::auto_ptr<GenerialPattern::CItemData> apCustomer(new GenerialPattern::CItemData());
	apCustomer->AddRange(nullID, _T(""), nullptr);
	pRetValue->AddItemData(3, apCustomer.release());
}

std::tuple<double, double> CSaleServiceWork::FindOutDiscount() const
{
	auto spTicketsData = m_spDataSet;
	auto pCurrentDataItem = spTicketsData->GetPage(0)->GetCurrentTickitsItem()->GetItem();
	double dblSaleRate{ 0 }, dblServiceRate = { 0 };
	CString strQuery;
	strQuery.Format(_T("SELECT B.SalesRate �����ۿ�, B.ServiceRate �����ۿ� FROM tsw_tabCardInfo A INNER JOIN tsw_tabCardVIPTypes B ON A.CTID LIKE B.CTID WHERE A.custID LIKE '%s';"),
		pCurrentDataItem->GetCellText(13));
	GenerialPattern::CItemData* pDataRow = nullptr;
	LOCALEDB;
	if (pDataBase->NormalGetItemData(strQuery, &pDataRow) && pDataRow != nullptr)
	{
		if (pDataRow->size() > 0)
		{
			TCHAR* tcsStop = nullptr;
			dblSaleRate = _tcstod(pDataRow->at(0).c_str(), &tcsStop);
			tcsStop = nullptr;
			dblServiceRate = _tcstod(pDataRow->at(1).c_str(), &tcsStop);
		}
		delete pDataRow;
	}
	return std::make_tuple(dblSaleRate, dblServiceRate);
}

std::tuple<double, double, double> CSaleServiceWork::FindOutScoreAndCommission() const
{
	double dblSaleScoreRate = { 0 }, dblSvcScoreRate = { 0 }, dblCommissionRate = { 0 };

	auto spTicketsData = m_spDataSet;
	auto pCurrentDataItem = spTicketsData->GetPage(0)->GetCurrentTickitsItem()->GetItem();
	CString strQuery;
	strQuery.Format(_T("SELECT ProdScoreRate ���� FROM tsw_tabSystemInfo LIMIT 1;SELECT SvsScoreRate ���� FROM tsw_tabSystemInfo LIMIT 1; SELECT ESalary ���� FROM tsw_tabStaffInfo WHERE EID LIKE '%s';"),
		pCurrentDataItem->GetCellText(11));
	GenerialPattern::CItemsData* pDataTable = nullptr;
	LOCALEDB;
	if (pDataBase->NormalGetItemsData(strQuery, &pDataTable, TRUE) && pDataTable != nullptr)
	{
		if (pDataTable->GetSize() > 0)
		{
			TCHAR* tcsStop = nullptr;
			dblSaleScoreRate = _tcstod(pDataTable->GetItemData(0)->at(0).c_str(), &tcsStop);
			tcsStop = nullptr;
			dblSvcScoreRate = _tcstod(pDataTable->GetItemData(1)->at(0).c_str(), &tcsStop);
			tcsStop = nullptr;
			if (pDataTable->GetSize() > 2)
			{
				if (pDataTable->GetItemData(2)->size() > 0)
				{
					dblCommissionRate = _tcstod(pDataTable->GetItemData(2)->at(0).c_str(), &tcsStop);
				}
			}
		}
		delete pDataTable;
	}

	return std::make_tuple(dblSaleScoreRate, dblSvcScoreRate, dblCommissionRate);
}

void CSaleServiceWork::AutoCompletePayment()
{
	auto pDataSet = m_spDataSet;
	auto enumCurrentType = m_enumCurrentTP;
	auto pNewItemDetials = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();
	//�������
	double dblDiscount = { 0 }, dblAmount = { 0 };
	concurrency::parallel_for_each(pNewItemDetials->begin(), pNewItemDetials->end(),
		[enumCurrentType, &dblDiscount, &dblAmount](auto spInput) {
		TCHAR* tcsStopTemp = nullptr, *tcsStopTemp1 = nullptr;
		//�ۼƽ��
		dblAmount += _tcstod(spInput->GetCellText(4), &tcsStopTemp) *
			_tcstod(spInput->GetCellText(5), &tcsStopTemp1);
		tcsStopTemp = nullptr;
		if (enumCurrentType == DataPattern::enumSalesTikits)
		{
			//�ۼ��ۿ�
			dblDiscount += _tcstod(spInput->GetCellText(7), &tcsStopTemp);
		}
		else
		{
			dblDiscount += _tcstod(spInput->GetCellText(9), &tcsStopTemp);
		}
	});

	//���޸����¼�����Զ��������Ѽ�¼
	CString strTemp;
	auto spPayement = pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
	strTemp.Format(_T("%.2f"), dblDiscount);
	spPayement->SetCellText(7, strTemp);
	strTemp.Format(_T("%.2f"), dblAmount);
	spPayement->SetCellText(8, strTemp);
}

BOOL CSaleServiceWork::ReloadCurrentItem(BOOL bDetailsOnly)
{
	std::vector<STDString> vectItemsIDs;
	auto pDataItem = m_spDataSet->GetPage(0);
	auto strMainItemID = pDataItem->GetCurrentItemKey();
	vectItemsIDs.push_back(strMainItemID);
	if (m_spDataSet->GetPage(1)->CurrentRecordBySourceID(strMainItemID))
	{
		vectItemsIDs.push_back(m_spDataSet->GetPage(1)->GetCurrentItemKey());
	}
	if (m_enumCurrentTP == DataPattern::enumSalesTikits)
	{
		if (m_spDataSet->GetPage(2)->CurrentRecordBySourceID(strMainItemID))
		{
			vectItemsIDs.push_back(m_spDataSet->GetPage(2)->GetCurrentItemKey());
		}
	}

	LOCALEDB;
	CString strQuery;
	if (!bDetailsOnly)
	{
		if (m_spDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState()
			== Database::NewItem)
		{
			return FALSE;
		}
		//��ʼ��������
		if (m_enumCurrentTP == DataPattern::enumSalesTikits)
		{
			Database::CSalesFlowVector sfv;
			strQuery.Empty();
			strQuery.AppendFormat(_T("SELECT * FROM tsw_viewSalesFlow WHERE ���۱��� LIKE '%s' LIMIT 1;"),
				vectItemsIDs.at(0).c_str());
			if (pDataBase->GetSalesFlow(strQuery, sfv) && sfv.GetCount() > 0)
			{
				auto pMainTemp = m_spDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				for (UINT uiIndex = 0; uiIndex != pMainTemp->GetColCount(); uiIndex++)
				{
					pMainTemp->SetCellText(uiIndex, sfv.GetCellText(0, uiIndex));
				}
			}
		}
		else
		{
			Database::CServiceFlowVector sfv;
			strQuery.Empty();
			strQuery.AppendFormat(_T("SELECT * FROM tsw_viewServiceFlow WHERE ������� LIKE '%s' LIMIT 1;"),
				vectItemsIDs.at(0).c_str());
			if (pDataBase->GetServiceFlow(strQuery, sfv) && sfv.GetCount() > 0)
			{
				auto pMainTemp = m_spDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				for (UINT uiIndex = 0; uiIndex != pMainTemp->GetColCount(); uiIndex++)
				{
					pMainTemp->SetCellText(uiIndex, sfv.GetCellText(0, uiIndex));
				}
			}
		}

		//���ظ��
		Database::CPaymentFlowVector pfv;
		strQuery.Empty();
		strQuery.AppendFormat(_T("SELECT * FROM tsw_viewPaymentFlow WHERE �ڲ����� LIKE '%s' LIMIT 1;"),
			vectItemsIDs.at(1).c_str());
		if (pDataBase->GetPaymentFlow(strQuery, pfv) && pfv.GetCount() > 0)
		{
			auto pMainTemp = m_spDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
			for (UINT uiIndex = 0; uiIndex != pMainTemp->GetColCount(); uiIndex++)
			{
				pMainTemp->SetCellText(uiIndex, pfv.GetCellText(0, uiIndex));
			}
		}

		//���ؿ������
		if (m_enumCurrentTP == DataPattern::enumSalesTikits)
		{
			Database::CStockFlowVector sfv;
			strQuery.Empty();
			strQuery.AppendFormat(_T("SELECT * FROM tsw_viewStockFlow WHERE �ڲ����� LIKE '%s' LIMIT 1;"),
				vectItemsIDs.at(2).c_str());
			if (pDataBase->GetStockFlow(strQuery, sfv) && sfv.GetCount() > 0)
			{
				auto pMainTemp = m_spDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItem();
				for (UINT uiIndex = 0; uiIndex != pMainTemp->GetColCount(); uiIndex++)
				{
					pMainTemp->SetCellText(uiIndex, sfv.GetCellText(0, uiIndex));
				}
			}
		}
	}

	//���������굥
	if (m_enumCurrentTP == DataPattern::enumSalesTikits)
	{
		auto spVector = m_spDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();
		strQuery.Format(_T("SELECT * FROM tsw_viewSalesFlowDetails WHERE �ܵ����� LIKE '%s'"),
			vectItemsIDs.at(0).c_str());
		auto pTargetVector = reinterpret_cast<Database::CSalesFlowDetailsVector*>(spVector.get());
		pDataBase->GetSalesFlowDetails(strQuery, *pTargetVector);
	}
	else
	{
		auto spVector = m_spDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();
		strQuery.Format(_T("SELECT * FROM tsw_viewServiceDetails WHERE �ܵ����� LIKE '%s'"),
			vectItemsIDs.at(0).c_str());
		auto pTargetVector = reinterpret_cast<Database::CServiceFlowDetailsVector*>(spVector.get());
		pDataBase->GetServiceFlowDetails(strQuery, *pTargetVector);
	}

	auto spVector1 = m_spDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItemDetails();
	strQuery.Format(_T("SELECT * FROM tsw_viewPaymentDetails WHERE �������� LIKE '%s'"),
		vectItemsIDs.at(1).c_str());
	auto pTargetVector1 = reinterpret_cast<Database::CPaymentFlowDetailsVector*>(spVector1.get());
	pDataBase->GetPaymentFlowDetails(strQuery, *pTargetVector1);

	if (m_enumCurrentTP == DataPattern::enumSalesTikits)
	{
		auto spVector = m_spDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItemDetails();
		strQuery.Format(_T("SELECT * FROM tsw_viewStockFlowDetails WHERE ������ LIKE '%s'"),
			vectItemsIDs.at(2).c_str());
		auto pTargetVector = reinterpret_cast<Database::CStockFlowDetailsVector*>(spVector.get());
		pDataBase->GetStockFlowDetails(strQuery, *pTargetVector);
	}

	return TRUE;
}

void CSaleServiceWork::InitializeDataSet(BOOL bCreateDate, DataPattern::EnumBusinessType enumRequireBus,
	LPCTSTR lpcszDateStart, LPCTSTR lpcszDateEnd)
{
	DataPattern::CTickitsData::GetAllTicketsIDs(TRUE, m_spDataSet.get(),
		bCreateDate, enumRequireBus, lpcszDateStart, lpcszDateEnd);
}

BOOL CSaleServiceWork::SendSynchronizationMessage(const CWnd* pWndLaunchSource, DataPattern::EnumBusinessType enumBusinessType,
	Database::DataState enumActionType, DataPattern::EnumObjectType ChangeObject, LPCTSTR lpcszObjectIDs,
	size_t szExtraSize, const PVOID pDataExtra) const
{


	std::shared_ptr<Business::DataPattern::PSChangeParameter> spConstructArgs(
		new Business::DataPattern::PSChangeParameter());
	if (pWndLaunchSource != nullptr)
	{
		spConstructArgs->pLaunchSource = const_cast<CWnd*>(pWndLaunchSource);
	}
	else 
	{
		spConstructArgs->pLaunchSource = nullptr;
	}
	spConstructArgs->enumBusinessType = enumBusinessType;

	spConstructArgs->enumActionType = enumActionType;
	spConstructArgs->ChangeObject = ChangeObject;

	if (lpcszObjectIDs == nullptr || _tcslen(lpcszObjectIDs) < 1)
	{
		_tcscpy_s(spConstructArgs->ObjectIDs, _countof(spConstructArgs->ObjectIDs), _T(""));
	}
	else
	{
		_tcscpy_s(spConstructArgs->ObjectIDs, _countof(spConstructArgs->ObjectIDs), lpcszObjectIDs);
	}

	spConstructArgs->nExtraSize = szExtraSize;
	spConstructArgs->pDataExtra = pDataExtra;

	return theApp.SendLocalMsg(WM_SALSVC_CREATE_MSG, NULL, (LPARAM)(spConstructArgs.get()));
}

#pragma region �����µ���
BOOL CSaleServiceWork::CreateNewTicketItem(LPCTSTR lpcszInitialID,
	DataPattern::EnumBusinessType enumBusinessType)
{
	//ͨ����Ϣ������
	BOOL bSucc = FALSE;

	//У����������
	auto pDataSet = m_spDataSet;
	BOOL bRequireNewItem = TRUE;

	BOOL bFoundObject = FALSE; //�Ƿ��ҵ�����
	Database::CFlybyItem* pNewDetailItem = nullptr;
	LOCALEDB;
	//��ʼ��𵥾�����
	if (lpcszInitialID != nullptr && _tcslen(lpcszInitialID) > 0)
	{
		Database::CProductInfoVector prodVector;
		CString strTempQuery;
		strTempQuery.Format(_T("SELECT * FROM tsw_viewProductInfo WHERE ��Ʒ���� LIKE '%s' OR ���� LIKE '%s' LIMIT 1;"),
			lpcszInitialID, lpcszInitialID);
		if (pDataBase->GetProductInfo(strTempQuery, prodVector))
		{
			if (prodVector.GetCount() > 0)
			{
				bFoundObject = TRUE;
				enumBusinessType = DataPattern::enumSalesTikits;
				prodVector.GetItem(0)->Clone(&pNewDetailItem);
			}
		}

		if (!bFoundObject)
		{
			Database::CServiceInfoVector ServVector;
			strTempQuery.Format(_T("SELECT * FROM tsw_viewServiceInfo WHERE �ڲ����� LIKE '%s' OR ���� LIKE '%s' LIMIT 1;"),
				lpcszInitialID, lpcszInitialID);
			if (pDataBase->GetServiceInfo(strTempQuery, ServVector))
			{
				if (ServVector.GetCount() > 0)
				{
					bFoundObject = TRUE;
					enumBusinessType = DataPattern::enumServiceTikits;
					ServVector.GetItem(0)->Clone(&pNewDetailItem);
				}
			}
		}
	}
	else
	{
		//���ص�һ����Ϣ
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			Database::CProductInfoVector prodVector;
			CString strTempQuery = _T("SELECT * FROM tsw_viewProductInfo LIMIT 1;");

			if (pDataBase->GetProductInfo(strTempQuery, prodVector))
			{
				if (prodVector.GetCount() > 0)
				{
					bFoundObject = TRUE;
					prodVector.GetItem(0)->Clone(&pNewDetailItem);
				}
			}
		}
		else
		{
			CString strTempQuery = _T("SELECT * FROM tsw_viewServiceInfo LIMIT 1;");
			Database::CServiceInfoVector ServVector;
			if (pDataBase->GetServiceInfo(strTempQuery, ServVector))
			{
				if (ServVector.GetCount() > 0)
				{
					bFoundObject = TRUE;
					ServVector.GetItem(0)->Clone(&pNewDetailItem);
				}
			}
		}
	}
	

	CSaleFrame* pMainWnd = dynamic_cast<CSaleFrame*>(theApp.GetMainWnd());

	if (!bFoundObject)
	{
		MessageBox(pMainWnd->GetSafeHwnd(), _T("ϵͳ�в������κβ�Ʒ�������Ϣ���������������Ϣ�����ԣ�"), _T("�¿���ʧ��"), MB_OK | MB_ICONEXCLAMATION);
		return bSucc;
	}

	if (pDataSet->IsExistsPage(0) && pDataSet->IsExistsPage(1))
	{
		if (!pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
		{
			if (pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetTickitsType() == enumBusinessType)
			{
				if (pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial)
				{
					bRequireNewItem = FALSE;
				}
			}
		}
	}

	//1����������
	if (bRequireNewItem)
	{
		std::shared_ptr<GenerialPattern::CItemsData> spMetadata(new GenerialPattern::CItemsData());
		LoadMetaDataOptions(spMetadata.get());

		//spMetadata->FindItem 

		if (!spMetadata->IsExistIndex(0))
		{
			MessageBox(pMainWnd->GetSafeHwnd(), _T("ϵͳ�в������κβ�����Ϣ���������������Ϣ�����ԣ�"), _T("�¿���ʧ��"), MB_OK | MB_ICONEXCLAMATION);
			return bSucc;
		}

		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			if (!spMetadata->IsExistIndex(1))
			{
				MessageBox(pMainWnd->GetSafeHwnd(), _T("ϵͳ�в������κοⷿ�����۵㣩��Ϣ���������������Ϣ�����ԣ�"), _T("�¿���ʧ��"), MB_OK | MB_ICONEXCLAMATION);
				return bSucc;
			}
		}

		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			if (!spMetadata->IsExistIndex(2))
			{
				MessageBox(pMainWnd->GetSafeHwnd(), _T("ϵͳ�в������κ�ҵ��Ա��Ϣ���������������Ϣ�����ԣ�"), _T("�¿���ʧ��"), MB_OK | MB_ICONEXCLAMATION);
				return bSucc;
			}
		}


		Database::CFlybyItem* pNewItem = nullptr;
		Database::CPaymentFlow* pPaymentItem = std::auto_ptr<Database::CPaymentFlow>(new Database::CPaymentFlow()).release();;
		Database::CStockFlow *pStockItem = nullptr; //������
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			pNewItem = std::auto_ptr<Database::CSalesFlow>(new Database::CSalesFlow()).release();
			pStockItem = std::auto_ptr<Database::CStockFlow>(new Database::CStockFlow()).release();
			pStockItem->SetCellText(1, _T("ϵͳ�Զ�����"));
			//�󶨳������
			pStockItem->SetCellText(19, pNewItem->GetCellText(0));
			//���ÿ�����
			pStockItem->SetCellText(11, _T("����"));
			//���ó���ⷿ
			auto pItemPair = spMetadata->GetItemData(1);
			pStockItem->SetCellText(20, pItemPair->at(0).c_str());
			pStockItem->SetCellText(4, pItemPair->at(1).c_str());

			//����ҵ��Ա
			pItemPair = spMetadata->GetItemData(2);
			pStockItem->SetCellText(18, pItemPair->at(0).c_str());
			pStockItem->SetCellText(3, pItemPair->at(1).c_str());

			//���ô�����
			pStockItem->SetCellText(15, pItemPair->at(0).c_str());

			pStockItem->SetState(Database::NewItem);

		}
		else
		{
			pNewItem = std::auto_ptr<Database::CServiceFlow>(new Database::CServiceFlow()).release();
		}
		pNewItem->SetCellText(1, _T("ϵͳ�Զ�����"));

		auto pItemPair = spMetadata->GetItemData(0);
		//�������ۡ�������
		pNewItem->SetCellText(10, pItemPair->at(0).c_str());
		pNewItem->SetCellText(3, pItemPair->at(1).c_str());
		//�����տ��
		pPaymentItem->SetCellText(23, pItemPair->at(0).c_str());
		pPaymentItem->SetCellText(3, pItemPair->at(1).c_str());
		
		//�������ۡ�����ҵ��Ա
		pItemPair = spMetadata->GetItemData(2);
		pNewItem->SetCellText(11, pItemPair->at(0).c_str());
		pNewItem->SetCellText(4, pItemPair->at(1).c_str());
		//�����տ���
		pPaymentItem->SetCellText(20, pItemPair->at(0).c_str());
		pPaymentItem->SetCellText(6, pItemPair->at(1).c_str());

		//�������ۡ����񵥴�����
		pNewItem->SetCellText(17, pItemPair->at(0).c_str());
		//�����տ������
		pPaymentItem->SetCellText(18, pItemPair->at(0).c_str());

		//�������ۡ����񵥿ͻ�
		pItemPair = spMetadata->GetItemData(3);
		pNewItem->SetCellText(13, pItemPair->at(0).c_str());
		pNewItem->SetCellText(5, pItemPair->at(1).c_str());

		//�����տ�ͻ�
		pPaymentItem->SetCellText(22, pItemPair->at(0).c_str());
		pPaymentItem->SetCellText(4, pItemPair->at(1).c_str());

		pNewItem->SetState(Database::NewItem);

		pPaymentItem->SetCellText(1, _T("ϵͳ�Զ�����"));
		//���տ����
		pPaymentItem->SetCellText(24, pNewItem->GetCellText(0));
		pPaymentItem->SetCellText(13, _T("Ӧ�տ�"));
		pPaymentItem->SetCellText(14, _T("�ͻ�"));

		//����״̬
		pPaymentItem->SetState(Database::NewItem);

		//��ʼ׷������
		//׷������

		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			std::auto_ptr<Database::CSalesFlowDetailsVector> apNewDetails(new Database::CSalesFlowDetailsVector());
			pDataSet->AddDataItem(0, pNewItem->GetCellText(0), pNewItem, apNewDetails.release(), enumBusinessType);
		}
		else
		{
			std::auto_ptr<Database::CServiceFlowDetailsVector> apNewDetails(new Database::CServiceFlowDetailsVector());
			pDataSet->AddDataItem(0, pNewItem->GetCellText(0), pNewItem, apNewDetails.release(), enumBusinessType);
		}
		//׷�Ӹ��
		std::auto_ptr<Database::CPaymentFlowDetailsVector> apNewRef1Details(new Database::CPaymentFlowDetailsVector());
		pDataSet->AddDataItem(1, pPaymentItem->GetCellText(0), pPaymentItem, apNewRef1Details.release(), DataPattern::enumReceivableTickets);
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			std::auto_ptr<Database::CStockFlowDetailsVector> apNewDetails(new Database::CStockFlowDetailsVector());
			pDataSet->AddDataItem(2, pStockItem->GetCellText(0), pStockItem, apNewDetails.release(), DataPattern::enumStoreOut, enumBusinessType);
		}
		//�ƶ�ָ�뵽���һ��
		pDataSet->GetPage(0)->Last();
		pDataSet->GetPage(1)->Last();
		//׷�ӳ��ⵥ
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			//�ƶ�ָ�뵽���һ��
			pDataSet->GetPage(2)->Last();
		}
	}

	//2�������굥
	auto pNewItemDetials = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();

	Database::CFlybyItem* pRealNewPSItem = nullptr;

	if (lpcszInitialID != nullptr && _tcslen(lpcszInitialID) > 0)
	{
		LPCTSTR lpcszTempID = lpcszInitialID;
		DataPattern::EnumBusinessType enumCurrentType = enumBusinessType;
		BOOL bProcessed = FALSE;

		//���Ҳ��ۼ�
		concurrency::parallel_for_each(pNewItemDetials->begin(), pNewItemDetials->end(),
			[lpcszTempID, enumCurrentType, &bProcessed, &pRealNewPSItem](auto spInput) {
			if (!bProcessed)
			{
				if (enumCurrentType == DataPattern::enumSalesTikits)
				{
					if (spInput->GetCellText(14).Compare(lpcszTempID) == 0)
					{
						pRealNewPSItem = spInput;
						bProcessed = TRUE;
					}
				}
				else
				{
					if (spInput->GetCellText(17).Compare(lpcszTempID) == 0)
					{
						pRealNewPSItem = spInput;
						bProcessed = TRUE;
					}
				}
			}
		});
		if (pRealNewPSItem->GetState() == Database::Initial)
		{
			pRealNewPSItem->SetState(Database::Modified);
		}

		//��������
		TCHAR* tcsStopTag = nullptr;
		double dblQuantity = _tcstod(pRealNewPSItem->GetCellText(5), &tcsStopTag) + 1;
		CString strTemp;
		strTemp.Format(_T("%.2f"), dblQuantity);
		pRealNewPSItem->SetCellText(5, strTemp);

		//�����ۿ�
		auto tupleRate = FindOutDiscount();

		//���������ⵥ
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			bProcessed = FALSE;
			auto pNewItemStockDetials = pDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItemDetails();
			Database::CFlybyItem *pNewStockItemS = nullptr;
			concurrency::parallel_for_each(pNewItemStockDetials->begin(), pNewItemStockDetials->end(),
				[lpcszTempID, &bProcessed, &pNewStockItemS](auto spInput) {
				if (!bProcessed)
				{
					if (spInput->GetCellText(9).Compare(lpcszTempID) == 0)
					{
						pNewStockItemS = spInput;
						bProcessed = TRUE;
					}
				}
			});
			pNewStockItemS->SetCellText(5, strTemp); //���³�������
			if (pNewStockItemS->GetState() == Database::Initial)
			{
				pNewStockItemS->SetState(Database::Modified);
			}
			//�����ۿ�
			double dblRate = std::get<0>(tupleRate);
			TCHAR* tcsStopTemp = nullptr, *tcsStopTemp1 = nullptr;
			double dblDiscount = _tcstod(pRealNewPSItem->GetCellText(4), &tcsStopTemp) *
				_tcstod(pRealNewPSItem->GetCellText(5), &tcsStopTemp1) * dblRate;
			strTemp.Format(_T(".2f"), dblDiscount);
			pRealNewPSItem->SetCellText(7, strTemp);
		}
		else
		{
			double dblRate = std::get<1>(tupleRate);
			TCHAR* tcsStopTemp = nullptr, *tcsStopTemp1 = nullptr;
			double dblDiscount = _tcstod(pRealNewPSItem->GetCellText(4), &tcsStopTemp) *
				_tcstod(pRealNewPSItem->GetCellText(5), &tcsStopTemp1) * dblRate;
			strTemp.Format(_T(".2f"), dblDiscount);
			pRealNewPSItem->SetCellText(9, strTemp);
		}
	}
	else
	{
		auto spParentNewItem = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
		auto spStockParentNewItem = pDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItem();

		Database::CStockFlowDetails* pNewStockDetails = nullptr;
		//������ζ������¼�¼
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			pRealNewPSItem = std::auto_ptr<Database::CSalesFlowDetails>(new Database::CSalesFlowDetails()).release();
			pNewStockDetails = std::auto_ptr<Database::CStockFlowDetails>(new Database::CStockFlowDetails()).release();
			//�������۵���Ʒ���
			pRealNewPSItem->SetCellText(14, pNewDetailItem->GetCellText(0));
			//�������۵��ϼ�����
			pRealNewPSItem->SetCellText(15, spParentNewItem->GetCellText(0));
			//���ÿ�浥��Ʒ���
			pNewStockDetails->SetCellText(9, pNewDetailItem->GetCellText(0));
			//���ÿ�浥�ϼ�����
			pNewStockDetails->SetCellText(10, spStockParentNewItem->GetCellText(0));
		}
		else
		{
			pRealNewPSItem = std::auto_ptr<Database::CServiceFlowDetails>(new Database::CServiceFlowDetails()).release();
			//���÷��񵥷�����
			pRealNewPSItem->SetCellText(17, pNewDetailItem->GetCellText(0));
			//���÷����ϼ�����
			pRealNewPSItem->SetCellText(18, spParentNewItem->GetCellText(0));
		}
		CString strTempT;
		strTempT.Format(_T("%s(%s)"), pNewDetailItem->GetCellText(2), pNewDetailItem->GetCellText(1));
		pRealNewPSItem->SetCellText(1, strTempT);
		pRealNewPSItem->SetCellText(2, pNewDetailItem->GetCellText(3));
		pRealNewPSItem->SetCellText(3, pNewDetailItem->GetCellText(4));
		pRealNewPSItem->SetCellText(5, _T("1")); //���ۡ���������

												 //

		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			pNewStockDetails->SetCellText(1, strTempT);
			pNewStockDetails->SetCellText(2, pNewDetailItem->GetCellText(3));
			pNewStockDetails->SetCellText(3, pNewDetailItem->GetCellText(4));
			pNewStockDetails->SetCellText(4, pNewDetailItem->GetCellText(10));
			pRealNewPSItem->SetCellText(4, pNewDetailItem->GetCellText(11)); //�۸�

			pNewStockDetails->SetCellText(5, _T("1")); //�������
			pNewStockDetails->SetCellText(6, pNewDetailItem->GetCellText(5)); //��������λ

			pRealNewPSItem->SetCellText(6, pNewDetailItem->GetCellText(5)); //������λ
																			//�����

			TCHAR *tcsStop1 = nullptr, *tcsStop2 = nullptr;
			double dblAmount = _tcstod(pNewStockDetails->GetCellText(4),
				&tcsStop1) * _tcstod(pNewStockDetails->GetCellText(5), &tcsStop1);
			strTempT.Format(_T("%.2f"), dblAmount);
			pNewStockDetails->SetCellText(7, strTempT); //���ý��
		}
		else
		{
			pRealNewPSItem->SetCellText(4, pNewDetailItem->GetCellText(8)); //�۸�
			if (pNewDetailItem->GetCellText(10).Compare(_T("��ʱ")) == 0 &&
				pNewDetailItem->GetCellText(5).Find(_T("ʱ")) != -1)
			{
				COleDateTime dateStart = COleDateTime::GetCurrentTime();
				COleDateTimeSpan DTS1Hour;
				DTS1Hour.SetDateTimeSpan(0, 1, 0, 0);
				COleDateTime dateEnd = dateStart + DTS1Hour;
				pRealNewPSItem->SetCellText(6, dateStart.Format());
				pRealNewPSItem->SetCellText(7, dateEnd.Format());
			}

			pRealNewPSItem->SetCellText(8, pNewDetailItem->GetCellText(5)); //������λ
			pRealNewPSItem->SetCellText(14, pNewDetailItem->GetCellText(10)); //���ü�ʱ��־
		}

		TCHAR *tcsStopT1 = nullptr, *tcsStopT2 = nullptr;
		double dblAmount = _tcstod(pRealNewPSItem->GetCellText(4),
			&tcsStopT1) * _tcstod(pRealNewPSItem->GetCellText(5), &tcsStopT2);
		strTempT.Format(_T("%.2f"), dblAmount);
		auto rateTulpe = FindOutDiscount();
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			//���õ�λת����
			pRealNewPSItem->SetCellText(13, pNewDetailItem->GetCellText(7));
			//���Ÿ��ݿͻ�����̽��Ĭ�ϴ�����Ϣ
			pRealNewPSItem->SetCellText(8, strTempT);
			double dRealDiscount = std::get<0>(rateTulpe) * dblAmount;
			strTempT.Format(_T("%.2f"), dRealDiscount);
			pRealNewPSItem->SetCellText(7, strTempT);
			dblAmount -= dRealDiscount;
			strTempT.Format(_T("%.2f"), dblAmount);
			pRealNewPSItem->SetCellText(9, strTempT);
		}
		else
		{
			//���õ�λת����
			pRealNewPSItem->SetCellText(16, pNewDetailItem->GetCellText(7));
			pRealNewPSItem->SetCellText(10, strTempT);
			//���õ�λת����
			pRealNewPSItem->SetCellText(13, pNewDetailItem->GetCellText(7));
			double dRealDiscount = std::get<1>(rateTulpe) * dblAmount;
			strTempT.Format(_T("%.2f"), dRealDiscount);
			pRealNewPSItem->SetCellText(9, strTempT);
			dblAmount -= dRealDiscount;
			strTempT.Format(_T("%.2f"), dblAmount);
			pRealNewPSItem->SetCellText(11, strTempT);
		}

		//����Ĭ�ϻ��ֺ�Ӷ��
		auto tupleSC = FindOutScoreAndCommission();
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			double dblScore = dblAmount * std::get<0>(tupleSC);
			double dblCommission = dblAmount *  std::get<2>(tupleSC);
			//1�����û���
			strTempT.Format(_T("%.2f"), dblScore);
			pRealNewPSItem->SetCellText(10, strTempT);
			//2������Ӷ��
			strTempT.Format(_T("%.2f"), dblCommission);
			pRealNewPSItem->SetCellText(11, strTempT);
		}
		else
		{
			double dblScore = dblAmount * std::get<1>(tupleSC);
			double dblCommission = dblAmount *  std::get<2>(tupleSC);
			//1�����û���
			strTempT.Format(_T("%.2f"), dblScore);
			pRealNewPSItem->SetCellText(12, strTempT);
			//2������Ӷ��
			strTempT.Format(_T("%.2f"), dblCommission);
			pRealNewPSItem->SetCellText(13, strTempT);
		}
		pRealNewPSItem->SetState(Database::NewItem);
		//׷�����۵�
		pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails()->AddItem(pRealNewPSItem);
		if (enumBusinessType == DataPattern::enumSalesTikits)
		{
			//׷�ӳ��ⵥ
			pNewStockDetails->SetState(Database::NewItem);
			pDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItemDetails()->AddItem(pNewStockDetails);
		}
	}

	bSucc = TRUE;
	//�л���ǰ״̬
	auto enumInitialState = m_enumCurrentTP;
	m_enumCurrentTP = enumBusinessType;

	return bSucc;
}
#pragma endregion