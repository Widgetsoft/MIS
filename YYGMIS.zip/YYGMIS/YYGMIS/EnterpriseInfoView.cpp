// EnterpriseInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "EnterpriseInfoDoc.h"
#include "LocalDataGridView.h"
#include "EnterpriseInfoView.h"

using namespace BasicInfo;

#define ID_GRID_ENTERPRISEINFO 0x9001

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CEnterpriseInfoView

IMPLEMENT_DYNCREATE(CEnterpriseInfoView, CView)

CEnterpriseInfoView::CEnterpriseInfoView()
	:m_ListCtrl(IDR_POPUP_EDIT)
{
	m_uipEntInfoTimerID = -1;
}

CEnterpriseInfoView::~CEnterpriseInfoView()
{
}

BEGIN_MESSAGE_MAP(CEnterpriseInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CEnterpriseInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_ENTERPRISEINFO, &CEnterpriseInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CEnterpriseInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CEnterpriseInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CEnterpriseInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CEnterpriseInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CEnterpriseInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CEnterpriseInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CEnterpriseInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CEnterpriseInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CEnterpriseInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CEnterpriseInfoView::OnEditFind)
	ON_MESSAGE(WM_ENTINFO_CHANGED, &CEnterpriseInfoView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CEnterpriseInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetEnterpriseInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 3; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

// CEnterpriseInfoView ��ͼ

void CEnterpriseInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CEnterpriseInfoView ���

#ifdef _DEBUG
void CEnterpriseInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CEnterpriseInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CEnterpriseInfoDoc* CEnterpriseInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEnterpriseInfoDoc)));
	return reinterpret_cast<CEnterpriseInfoDoc*>(m_pDocument);
}
#endif //_DEBUG


// CEnterpriseInfoView ��Ϣ��������


int CEnterpriseInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_ENTERPRISEINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 3; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 1:
		case 2:
		case 4:
		case 8:
		case 10:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 11:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("ͣ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("����"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 12:
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}


	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��ҵ��Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CEnterpriseInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CEnterpriseInfoView::OnEditNewitem()
{
	Database::CEnterpriseInfo* pItem = new Database::CEnterpriseInfo();
	pItem->SetState(Database::NewItem);
	pItem->SetCellText(11, _T("1"));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	pItem->SetCellText(13, timeNow.Format());
	pItem->SetCellText(14, timeNow.Format());

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 3; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CEnterpriseInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 1: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 12, tcsText);
				m_ListCtrl.SetItemText(nRow, 12, tcsText);
			}
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}



void CEnterpriseInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CEnterpriseInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CEnterpriseInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CEnterpriseInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CEnterpriseInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CEnterpriseInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CEnterpriseInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CEnterpriseInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CEnterpriseInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CEnterpriseInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CEnterpriseInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipEntInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipEntInfoTimerID);
		m_uipEntInfoTimerID = UINT(-1);
	}
	m_uipEntInfoTimerID = SetTimer(2, 1002, NULL);
	return 0L;
}

void CEnterpriseInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipEntInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipEntInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipEntInfoTimerID);
				m_uipEntInfoTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
