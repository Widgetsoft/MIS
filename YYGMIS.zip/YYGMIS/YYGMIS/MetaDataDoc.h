#pragma once

namespace BasicInfo
{
	// CMetaDataDoc �ĵ�

	class CMetaDataDoc : public CDocument
	{
		DECLARE_DYNCREATE(CMetaDataDoc)

	public:
		CMetaDataDoc();
		virtual ~CMetaDataDoc();
#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	public:
		Database::CItemOptionsVector m_vector;
		Database::CItemOptionsVector m_vectNewItems;
		Database::CItemOptionsVector m_vectModItems;
		Database::CItemOptionsVector m_vectDelItems;

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}
