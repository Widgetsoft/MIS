#pragma once

namespace Business
{

	// CSaleDoc �ĵ�

	class CSaleDoc : public CDocument
	{
		DECLARE_DYNCREATE(CSaleDoc)

	public:
		CSaleDoc();
		virtual ~CSaleDoc();
#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	public:
		const std::shared_ptr<DataPattern::CTickitsData>& GetDataset() const;
		void LoadAllDataSet(BOOL bSendLoadMsg = FALSE, BOOL bCreateDate = TRUE, DataPattern::EnumBusinessType enumRequireBus = DataPattern::enumUnknown,
			LPCTSTR lpcszDateStart = nullptr, LPCTSTR lpcszDateEnd = nullptr) const;
		std::tuple<double, double> FindOutDiscount() const;
		std::tuple<double, double, double> FindOutScoreAndCommission() const;
		void AutoCompletePayment() const;
		BOOL SendSynchronizationMessage(const CWnd* pWndLaunchSource, DataPattern::EnumBusinessType enumBusinessType,
			Database::DataState enumActionType, DataPattern::EnumObjectType ChangeObject, LPCTSTR lpcszObjectIDs,
			size_t szExtraSize, const PVOID pDataExtra) const;

		BOOL CreateNewTicketItem(LPCTSTR lpcszInitialID, DataPattern::EnumBusinessType enumBusinessType);
		BOOL ReloadCurrentItem(BOOL bDetailsOnly);

	protected:
		virtual BOOL OnNewDocument();

	private:
		BOOL ModifiedItemEntityEntry(std::shared_ptr<DataPattern::SCTicketIDGroupPure> spModItem) const;

		DECLARE_MESSAGE_MAP()
	public:
		virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
		afx_msg void OnSaleNew();
		afx_msg void OnUpdateSaleModify(CCmdUI *pCmdUI);
		afx_msg void OnSaleModify();
		afx_msg void OnUpdateSaleDelete(CCmdUI *pCmdUI);
		afx_msg void OnSaleDelete();
		afx_msg void OnUpdateSaleSave(CCmdUI *pCmdUI);
		afx_msg void OnSaleSave();
	};
}
