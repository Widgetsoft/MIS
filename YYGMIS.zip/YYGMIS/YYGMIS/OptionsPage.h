#pragma once

namespace UI
{
	namespace Business
	{
		// COptionsPage �Ի���

		class COptionsPage : public CMFCPropertyPage
		{
			DECLARE_DYNAMIC(COptionsPage)

		public:
			COptionsPage();
			virtual ~COptionsPage();

			// �Ի�������
#ifdef AFX_DESIGN_TIME
			enum { IDD = IDD_PROPPAGE_SALE };
#endif

		protected:
			virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

			DECLARE_MESSAGE_MAP()
		};
	}
}
