// StaffInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "StaffInfoDoc.h"
#include "LocalDataGridView.h"
#include "StaffInfoView.h"
#include "StaffPWDChange.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace BasicInfo;

#define ID_GRID_STAFFINFO 0x9005

// CStaffInfoView

IMPLEMENT_DYNCREATE(CStaffInfoView, CView)

CStaffInfoView::CStaffInfoView()
	:m_ListCtrl(IDR_POPUP_STAFF),
	m_spDeptDatas(new GenerialPattern::CItemsData()),
	m_spTitles(new GenerialPattern::CItemsData()),
	m_spDuty(new GenerialPattern::CItemsData()),
	m_spDegree(new GenerialPattern::CItemsData())
{
	m_uipDeptInfoTimerID = -1;
	m_uipStaffInfoTimerID = -1;
	m_uipMetaTimerID = -1;
}

CStaffInfoView::~CStaffInfoView()
{
}

BEGIN_MESSAGE_MAP(CStaffInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CStaffInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_STAFFINFO, &CStaffInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CStaffInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CStaffInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CStaffInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CStaffInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CStaffInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CStaffInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CStaffInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CStaffInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CStaffInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CStaffInfoView::OnEditFind)
	ON_MESSAGE(WM_METADATA_CHANGED, &CStaffInfoView::OnOptInfoDataChanged)
	ON_MESSAGE(WM_AGCINFO_CHANGED, &CStaffInfoView::OnDeptInfoDataChanged)
	ON_MESSAGE(WM_STAFFINFO_CHANGED, &CStaffInfoView::OnDataChanged)
	ON_WM_TIMER()
	ON_UPDATE_COMMAND_UI(ID_FILE_STAFF_PWD, &CStaffInfoView::OnUpdateFileStaffPwd)
	ON_COMMAND(ID_FILE_STAFF_PWD, &CStaffInfoView::OnFileStaffPwd)
END_MESSAGE_MAP()


// CStaffInfoView ��ͼ

void CStaffInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}

void CStaffInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetStaffInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 9; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 25)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol >= 18 && nCellCol <= 24)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

void CStaffInfoView::LoadDeptInfoes()
{
	m_spDeptDatas->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(2));

	ASSERT(pComboTrait != NULL);
	pComboTrait->ClearFixedItems();


	LOCALEDB;
	GenerialPattern::CItemsData* pTempTable = nullptr;

	if (pDataBase != NULL &&  pDataBase->NormalGetItemsData(_T("SELECT deptID, deptName, deptChief, deptPhoneNum, detpFaxNum, deptEmail, deptAddress, Memo, JM FROM tsw_tabAgencyInfo WHERE IsUsing = 1;"), &pTempTable))
	{
		int i = 0;
		for each (auto item in *pTempTable)
		{
			pComboTrait->AddItem(i, item.second->at(1).c_str());
			auto pData1 = new GenerialPattern::CItemData();
			pData1->AddRange(item.second->at(0).c_str(),
				item.second->at(1).c_str(),
				item.second->at(2).c_str(),
				item.second->at(3).c_str(),
				item.second->at(4).c_str(),
				item.second->at(5).c_str(),
				item.second->at(6).c_str(),
				item.second->at(7).c_str(),
				item.second->at(8).c_str(),
				NULL);
			m_spDeptDatas->AddItemData(i, pData1);
			i++;
		}
		delete pTempTable;
	}

	const size_t itemCount = GetDocument()->m_vector.GetCount();
	for (int j = 0; j != itemCount; j++)
	{
		m_ListCtrl.SetItemText(j, 2, GetDocument()->m_vector.GetCellText(j, 2));
	}

	m_ListCtrl.RedrawItems(0, (int)(itemCount - 1));
}

void CStaffInfoView::LoadMetaData()
{
	Database::CItemOptionsVector vectOption1, vectOption2, vectOption3;

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s WHERE ѡ��� LIKE 'רҵְ��'"), vectOption1.m_strBindTable);
		pDataBase->GetItemOptions(strQuery, vectOption1);
		strQuery.Format(_T("SELECT * FROM %s WHERE ѡ��� LIKE '������λ'"), vectOption2.m_strBindTable);
		pDataBase->GetItemOptions(strQuery, vectOption2);
		strQuery.Format(_T("SELECT * FROM %s WHERE ѡ��� LIKE '�Ļ��̶�'"), vectOption3.m_strBindTable);
		pDataBase->GetItemOptions(strQuery, vectOption3);
	}

	m_spTitles->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(4));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption1.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption1.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption1.GetCellText(i, 0),
			vectOption1.GetCellText(i, 2),
			vectOption1.GetCellText(i, 5),
			vectOption1.GetCellText(i, 3),
			vectOption1.GetCellText(i, 4),
			vectOption1.GetCellText(i, 1), NULL);
		m_spTitles->AddItemData(i, pData);
	}

	m_spDuty->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(5));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption2.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption2.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption2.GetCellText(i, 0),
			vectOption2.GetCellText(i, 2),
			vectOption2.GetCellText(i, 5),
			vectOption2.GetCellText(i, 3),
			vectOption2.GetCellText(i, 4),
			vectOption2.GetCellText(i, 1), NULL);
		m_spDuty->AddItemData(i, pData);
	}

	m_spDegree->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(7));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption3.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption3.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption3.GetCellText(i, 0),
			vectOption3.GetCellText(i, 2),
			vectOption3.GetCellText(i, 5),
			vectOption3.GetCellText(i, 3),
			vectOption3.GetCellText(i, 4),
			vectOption3.GetCellText(i, 1), NULL);
		m_spDegree->AddItemData(i, pData);
	}
}

// CStaffInfoView ���

#ifdef _DEBUG
void CStaffInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CStaffInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif

CStaffInfoDoc* CStaffInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CStaffInfoDoc)));
	return reinterpret_cast<CStaffInfoDoc*>(m_pDocument);
}
#endif //_DEBUG


// CStaffInfoView ��Ϣ��������


int CStaffInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_STAFFINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;
	CGridColumnTraitCombo* pTraitCombo = nullptr;
	int idCat = 0;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 9; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;

		switch (col + 1)
		{
		case 2:
		case 4:
		case 5:
		case 7:
			pTrait = new CGridColumnTraitCombo();
			break;
		case 8:
			pTrait = new CGridColumnTraitDateTime();
			break;
		case 3:
			pTraitCombo = new CGridColumnTraitCombo();
			pTraitCombo->AddItem(idCat++, _T("����"));
			pTraitCombo->AddItem(idCat++, _T("��"));
			pTraitCombo->AddItem(idCat++, _T("Ů"));

			m_vectSex.push_back(_T("����"));
			m_vectSex.push_back(_T("��"));
			m_vectSex.push_back(_T("Ů"));
			pTrait = pTraitCombo;
			break;
		case 11:
		case 13:
		case 14:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("����"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 25:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("ͣ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("����"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 15:
		case 17:
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	LoadData();
	LoadDeptInfoes();
	LoadMetaData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("ְԱ������Ϣ"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CStaffInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CStaffInfoView::OnEditNewitem()
{
	if (m_spDeptDatas->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κε�ǰ������Ϣ���޷�����ִ�иò�����"), _T("����ְ����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_spTitles->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ�ְ����Ϣ���޷�����ִ�иò�����"), _T("����ְ����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_spDuty->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ�ְ����Ϣ���޷�����ִ�иò�����"), _T("����ְ����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_spDegree->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ�ѧ����Ϣ���޷�����ִ�иò�����"), _T("����ְ����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	Database::CStaffInfo* pItem = new Database::CStaffInfo();
	pItem->SetState(Database::NewItem);

	//1������ѡ��Ĭ��ֵ
	auto pOptionItem = m_spDeptDatas->GetItemData(0);
	pItem->SetCellText(33, pOptionItem->at(0).c_str());
	pItem->SetCellText(2, pOptionItem->at(1).c_str());

	pOptionItem = m_spTitles->GetItemData(0);
	pItem->SetCellText(28, pOptionItem->at(0).c_str());
	pItem->SetCellText(4, pOptionItem->at(1).c_str());

	pOptionItem = m_spDuty->GetItemData(0);
	pItem->SetCellText(29, pOptionItem->at(0).c_str());
	pItem->SetCellText(5, pOptionItem->at(1).c_str());

	pOptionItem = m_spDegree->GetItemData(0);
	pItem->SetCellText(30, pOptionItem->at(0).c_str());
	pItem->SetCellText(7, pOptionItem->at(1).c_str());


	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 9; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 25)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol >= 18 && nCellCol <= 24)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CStaffInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 1: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 15, tcsText);
				m_ListCtrl.SetItemText(nRow, 15, tcsText);
			}
		}
		break;
	case 2:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spDeptDatas, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 33, varPair.first.c_str());
		}
		break;
	case 3:
		if (pDispInfo->item.pszText != NULL)
		{
			if (_tcscmp(pDispInfo->item.pszText, _T("��")) == 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, nCol, _T("��"));
				m_ListCtrl.SetItemText(nRow, nCol, _T("��"));
			}
			else if(_tcscmp(pDispInfo->item.pszText, _T("Ů")) == 0 )
			{
				GetDocument()->m_vector.SetCellText(nRow, nCol, _T("Ů"));
				m_ListCtrl.SetItemText(nRow, nCol, _T("Ů"));
			}
			else
			{
				GetDocument()->m_vector.SetCellText(nRow, nCol, _T("����"));
				m_ListCtrl.SetItemText(nRow, nCol, _T("����"));
			}
		}
		break;
	case 4:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spTitles, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 28, varPair.first.c_str());
		}
		break;
	case 5:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spDuty, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 29, varPair.first.c_str());
		}
		break;
	case 7:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spDegree, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 30, varPair.first.c_str());
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CStaffInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CStaffInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CStaffInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CStaffInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CStaffInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CStaffInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CStaffInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CStaffInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CStaffInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CStaffInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CStaffInfoView::OnOptInfoDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipMetaTimerID != UINT(-1))
	{
		KillTimer(m_uipMetaTimerID);
		m_uipMetaTimerID = UINT(-1);
	}
	m_uipMetaTimerID = SetTimer(7, 1007, NULL);
	return 0L;
}

LRESULT CStaffInfoView::OnDeptInfoDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipDeptInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipDeptInfoTimerID);
		m_uipDeptInfoTimerID = UINT(-1);
	}
	m_uipDeptInfoTimerID = SetTimer(8, 1008, NULL);
	return 0L;
}

LRESULT CStaffInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipStaffInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipStaffInfoTimerID);
		m_uipStaffInfoTimerID = UINT(-1);
	}
	m_uipStaffInfoTimerID = SetTimer(9, 1009, NULL);
	return 0L;
}

void CStaffInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipMetaTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipMetaTimerID != UINT(-1))
			{
				KillTimer(m_uipMetaTimerID);
				m_uipMetaTimerID = UINT(-1);
			}
			LoadMetaData(); //���¼��������б�
			LoadData();
		}
	}
	else if (m_uipDeptInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipDeptInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipDeptInfoTimerID);
				m_uipDeptInfoTimerID = UINT(-1);
			}
			LoadDeptInfoes();
			LoadData(); //���¼��������б�
		}
	}
	else if (m_uipStaffInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipStaffInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipStaffInfoTimerID);
				m_uipStaffInfoTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}


void CStaffInfoView::OnUpdateFileStaffPwd(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(FALSE);
	if (pos != nullptr)
	{
		int nItem = m_ListCtrl.GetNextSelectedItem(pos);
		if (GetDocument()->m_vector.GetItem(nItem)->GetState() != Database::NewItem)
		{
			pCmdUI->Enable();
		}
	}
	
}


void CStaffInfoView::OnFileStaffPwd()
{

	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	if (pos != nullptr)
	{
		int nItem = m_ListCtrl.GetNextSelectedItem(pos);
		auto pItem = reinterpret_cast<Database::CStaffInfo*>(GetDocument()->m_vector.GetItem(nItem));
		if (pItem->GetState() != Database::NewItem)
		{
			std::shared_ptr<CStaffPWDChange> spDlg(new CStaffPWDChange(pItem));
			spDlg->DoModal();

			if (spDlg->m_bOK)
			{
				MessageBox(_T("�����޸ĳɹ��������������������룡"), _T("������ʾ"), MB_OK | MB_ICONINFORMATION);
			}
		}
	}
}
