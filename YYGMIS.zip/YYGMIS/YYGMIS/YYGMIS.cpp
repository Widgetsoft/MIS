// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���  
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�  
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ������� 
// http://go.microsoft.com/fwlink/?LinkId=238214��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// YYGMIS.cpp : ����Ӧ�ó��������Ϊ��
//

#include "stdafx.h"
#include "afxwinappex.h"
#include "afxdialogex.h"
#include "YYGMIS.h"
#include "MainFrm.h"

#include "SystemInfo.h"

#include "ChildFrm.h"
#include "YYGMISDoc.h"
#include "YYGMISView.h"

#include "LocalDataGridView.h"

#include "MetaDataDoc.h"
#include "MetaDataView.h"

#include "EnterpriseInfoDoc.h"
#include "EnterpriseInfoView.h"

#include "AgencyInfoDoc.h"
#include "AgencyInfoView.h"

#include "WSPDoc.h"
#include "WSPView.h"

#include "StaffInfoDoc.h"
#include "StaffInfoView.h"

#include "CustomerInfoDoc.h"
#include "CustomerInfoView.h"

#include "CardVIPTypeDoc.h"
#include "CardVIPTypeView.h"

#include "CardInfoDoc.h"
#include "CardInfoView.h"

#include "CardUIRecordDoc.h"
#include "CardUIRecordView.h"

#include "PSOptionsDoc.h"
#include "PSOptionsView.h"

#include "ProductInfoDoc.h"
#include "ProductInfoView.h"

#include "EquipmentInfoDoc.h"
#include "EquipmentInfoView.h"

#include "ServiceInfoDoc.h"
#include "ServiceInfoView.h"

#include "CertificationDlg.h"

#include "InventoryDoc.h"
#include "InventoryView.h"

#include "TickitsData.h"
#include "SaleServiceWork.h"
#include "SaleFrame.h"
#include "SaleDoc.h"
#include "SaleView.h"
#include "PaymentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CYYGMISApp

BEGIN_MESSAGE_MAP(CYYGMISApp, CWinAppEx)
	ON_COMMAND(ID_APP_ABOUT, &CYYGMISApp::OnAppAbout)
	// �����ļ��ı�׼�ĵ�����
	ON_COMMAND(ID_FILE_NEW, &CWinAppEx::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, &CWinAppEx::OnFileOpen)
	// ��׼��ӡ��������
	ON_COMMAND(ID_FILE_PRINT_SETUP, &CWinAppEx::OnFilePrintSetup)
	ON_COMMAND(ID_DEBUG_SQLITE, &CYYGMISApp::OnDebugSqlite)
	ON_COMMAND(ID_FILE_OPTIONS, &CYYGMISApp::OnFileOptions)
	ON_COMMAND(ID_FILE_ENTINFO, &CYYGMISApp::OnFileEntinfo)
	ON_COMMAND(ID_FILE_AGENCY, &CYYGMISApp::OnFileAgency)
	ON_COMMAND(ID_FILE_WAREHOUSE, &CYYGMISApp::OnFileWarehouse)
	ON_COMMAND(ID_FILE_STAFF, &CYYGMISApp::OnFileStaff)
	ON_COMMAND(ID_FILE_CUSTOMER, &CYYGMISApp::OnFileCustomer)
	ON_COMMAND(ID_FILE_VIPCARDTYPE, &CYYGMISApp::OnFileVipcardtype)
	ON_COMMAND(ID_FILE_CARDINFO, &CYYGMISApp::OnFileCardInfo)
	ON_COMMAND(ID_FILE_CUSCORERECORD, &CYYGMISApp::OnFileCuscorerecord)
	ON_COMMAND(ID_FILE_PSOPTIONS, &CYYGMISApp::OnFilePsoptions)
	ON_COMMAND(ID_FILE_PRODUCTINFO, &CYYGMISApp::OnFileProductinfo)
	ON_COMMAND(ID_FILE_EQUIPMENT, &CYYGMISApp::OnFileEquipment)
	ON_COMMAND(ID_FILE_SERVICEINFO, &CYYGMISApp::OnFileServiceinfo)
	ON_COMMAND(ID_DEBUG_LICENSE, &CYYGMISApp::OnDebugLicense)
	ON_COMMAND(ID_BUSINESS_BALANCE, &CYYGMISApp::OnBusinessBalance)
	ON_COMMAND(ID_BUSINESS_SALES, &CYYGMISApp::OnBusinessSales)
END_MESSAGE_MAP()


// CYYGMISApp ����

CYYGMISApp::CYYGMISApp()
{
	m_uiBusinessLoadPeriod = 0;
	m_bRealExit = FALSE;
	m_currentFrame = MainFrame;
	m_bInitialized = FALSE;
	m_bHiColorIcons = TRUE;
	_tcscpy_s(m_strDBPath, MAX_PATH * 2, _T(""));
	_tcscpy_s(m_strToken, _countof(m_strToken), _T("?151257!138|96."));
	m_siInfo = nullptr;
	// ֧����������������
	m_dwRestartManagerSupportFlags = AFX_RESTART_MANAGER_SUPPORT_ALL_ASPECTS;
#ifdef _MANAGED
	// ���Ӧ�ó��������ù�����������ʱ֧��(/clr)�����ģ���: 
	//     1) �����д˸������ã�������������������֧�ֲ�������������
	//     2) ��������Ŀ�У������밴������˳���� System.Windows.Forms �������á�
	System::Windows::Forms::Application::SetUnhandledExceptionMode(System::Windows::Forms::UnhandledExceptionMode::ThrowException);
#endif

	// TODO: ������Ӧ�ó��� ID �ַ����滻ΪΨһ�� ID �ַ�����������ַ�����ʽ
	//Ϊ CompanyName.ProductName.SubProduct.VersionInformation
	SetAppID(_T("YYGMIS.AppID.NoVersion"));

	// TODO: �ڴ˴����ӹ�����룬
	// ��������Ҫ�ĳ�ʼ�������� InitInstance ��
}

// Ψһ��һ�� CYYGMISApp ����

CYYGMISApp theApp;


// CYYGMISApp ��ʼ��

BOOL CYYGMISApp::InitInstance()
{
	// ���һ�������� Windows XP �ϵ�Ӧ�ó����嵥ָ��Ҫ
	// ʹ�� ComCtl32.dll �汾 6 ����߰汾�����ÿ��ӻ���ʽ��
	//����Ҫ InitCommonControlsEx()��  ���򣬽��޷��������ڡ�
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// ��������Ϊ��������Ҫ��Ӧ�ó�����ʹ�õ�
	// �����ؼ��ࡣ
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();


	// ��ʼ�� OLE ��
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	EnableTaskbarInteraction();

	// ʹ�� RichEdit �ؼ���Ҫ AfxInitRichEdit2()	
	AfxInitRichEdit2();

	// ��׼��ʼ��
	// ���δʹ����Щ���ܲ�ϣ����С
	// ���տ�ִ���ļ��Ĵ�С����Ӧ�Ƴ�����
	// ����Ҫ���ض���ʼ������
	// �������ڴ洢���õ�ע�����
	// TODO: Ӧ�ʵ��޸ĸ��ַ�����
	// �����޸�Ϊ��˾����֯��
	SetRegistryKey(_T("Ӧ�ó��������ɵı���Ӧ�ó���"));
	LoadStdProfileSettings(0);  // ���ر�׼ INI �ļ�ѡ��(���� MRU)


	InitContextMenuManager();
	InitShellManager();

	InitKeyboardManager();

	InitTooltipManager();
	CMFCToolTipInfo ttParams;
	ttParams.m_bVislManagerTheme = TRUE;
	theApp.GetTooltipManager()->SetTooltipParams(AFX_TOOLTIP_TYPE_ALL,
		RUNTIME_CLASS(CMFCToolTipCtrl), &ttParams);



	TCHAR szPath2[MAX_PATH];
	GetModuleFileName(NULL, szPath2, _MAX_PATH);
	Concurrency::concurrent_vector<STDString> argsPaths;
	Helper::CToolkits::Split(szPath2, _T("\\"), &argsPaths);
	CString strDBPath;
	for (int i = 0; i != argsPaths.size() - 1; i++)
	{
		argsPaths[i].append(_T("\\"));
		strDBPath.Append(argsPaths[i].c_str());
	}
	strDBPath.Replace(_T('\\'), _T('/'));
	//CSpashDlg splash;
	//splash.Create();
	//splash.ShowWindow(SW_SHOW);
	//splash.UpdateWindow();

	STDString strMyUpdate(strDBPath);
	strMyUpdate.append(_T("pj.dict"));

	Helper::CToolkits::m_strPathPJJMFile.clear();
	Helper::CToolkits::m_strPathPJJMFile.append(strMyUpdate.c_str());

	strDBPath.Append(_T("YYGMIS.yyg"));
	_tcscpy_s(m_strDBPath, MAX_PATH * 2, strDBPath);

	m_bRegistered = SystemPassGate();

	//��ʼ��¼
	m_siInfo = new CSystemInfo(TRUE);

	// ע��Ӧ�ó�����ĵ�ģ�塣  �ĵ�ģ��
	// �������ĵ�����ܴ��ں���ͼ֮�������
	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(IDR_MyTYPE,
		RUNTIME_CLASS(CYYGMISDoc),
		RUNTIME_CLASS(CChildFrame), // �Զ��� MDI �ӿ��
		RUNTIME_CLASS(CYYGMISView));
	if (!pDocTemplate)
		return FALSE;

	CMultiDocTemplate* pDocSaleTemp;
	pDocSaleTemp = new CMultiDocTemplate(IDR_SALEFRAME,
		RUNTIME_CLASS(Business::CSaleDoc),
		RUNTIME_CLASS(CChildFrame), // �Զ��� MDI �ӿ��
		RUNTIME_CLASS(Business::CSaleView));

	if (!pDocSaleTemp)
		return FALSE;

	AddDocTemplate(pDocTemplate);
	m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("StartPage"), pDocTemplate));

	AddDocTemplate(pDocSaleTemp);
	m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("SalePage"), pDocSaleTemp));

	// ������ MDI ��ܴ���
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame || !pMainFrame->LoadFrame(IDR_MAINFRAME))
	{
		delete pMainFrame;
		return FALSE;
	}

	m_pMainWnd = pMainFrame;

	m_lstMainFrames.AddTail(pMainFrame);


	// �������к�׺ʱ�ŵ��� DragAcceptFiles
	//  �� MDI Ӧ�ó����У���Ӧ������ m_pMainWnd ֮����������
	// ������/��
	m_pMainWnd->DragAcceptFiles();

	// ������׼ shell ���DDE�����ļ�������������
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// ���á�DDE ִ�С�
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);


	// ��������������ָ�������  ���
	// �� /RegServer��/Register��/Unregserver �� /Unregister ����Ӧ�ó����򷵻� FALSE��
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	// �������ѳ�ʼ���������ʾ����������и���

	pMainFrame->ShowWindow(SW_SHOWMAXIMIZED);
	pMainFrame->UpdateWindow();



	return TRUE;
}

int CYYGMISApp::ExitInstance()
{
	//TODO: �������������ӵĸ�����Դ

	AfxOleTerm(FALSE);

	if (m_siInfo != nullptr)
	{
		delete m_siInfo;
	}

	return CWinAppEx::ExitInstance(); 
}

void CYYGMISApp::RealOpenDocument(STDString strTemplateName, UINT uiMessageID, LPARAM lParam)
{
	auto it = m_mdtTemplate.find(strTemplateName);
	if (it == m_mdtTemplate.end())
	{
		if (_tcscmp(_T("StartPage"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(CYYGMISDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(CYYGMISView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("StartPage"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("SalePage"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_SALEFRAME, RUNTIME_CLASS(Business::CSaleDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(Business::CSaleView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("SalePage"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("SalePayment"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_SALEFRAME, RUNTIME_CLASS(Business::CSaleDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(Business::CPaymentView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("SalePayment"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("Metadata"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CMetaDataDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CMetaDataView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("Metadata"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("EnterpriseInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CEnterpriseInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CEnterpriseInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("EnterpriseInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("AgencyInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CAgencyInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CAgencyInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("AgencyInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("WarehouseInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CWSPDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CWSPView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("WarehouseInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("StaffInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CStaffInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CStaffInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("StaffInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("CustomerInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CCustomerInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CCustomerInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("CustomerInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("CardVIPType"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CCardVIPTypeDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CCardVIPTypeView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("CardVIPType"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("CardInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CCardInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CCardInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("CardInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("CardUIRecord"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CCardUIRecordDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CCardUIRecordView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("CardUIRecord"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("ProductServiceOption"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CPSOptionsDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CPSOptionsView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("ProductServiceOption"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("ProductInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CProductInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CProductInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("ProductInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("EquipmentInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CEquipmentInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CEquipmentInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("EquipmentInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("ServiceInfo"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(BasicInfo::CServiceInfoDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(BasicInfo::CServiceInfoView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("ServiceInfo"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
		else if (_tcscmp(_T("BusinessBalance"), strTemplateName.c_str()) == 0)
		{
			CMultiDocTemplate* pmdtTemp = nullptr;
			MyAddDocument(&pmdtTemp, IDR_MyTYPE, RUNTIME_CLASS(Business::CInventoryDoc),
				RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(Business::CInventoryView));
			m_mdtTemplate.insert(std::unordered_map<STDString, CMultiDocTemplate*>::value_type(_T("BusinessBalance"), pmdtTemp));
			CustomOpenDocument(pmdtTemp, uiMessageID, lParam);
		}
	}
	else
	{
		CustomOpenDocument(it->second, uiMessageID, lParam);
	}
}

BOOL CYYGMISApp::MyAddDocument(CMultiDocTemplate** pArgDoc, UINT nIDResource, CRuntimeClass* pDocClass,
	CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass)
{
	*pArgDoc = std::auto_ptr<CMultiDocTemplate>(new  CMultiDocTemplate(nIDResource,
		pDocClass,
		pFrameClass, // �Զ��� MDI �ӿ��
		pViewClass)).release();
	if (!pArgDoc)
		return FALSE;
	AddDocTemplate(*pArgDoc);
	return TRUE;
}

void CYYGMISApp::CustomOpenDocument(CMultiDocTemplate* pTmpl, UINT uiMessageID, LPARAM lParam)
{
	ASSERT_VALID(pTmpl);

	CMainFrame* pMainFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT_VALID(pMainFrame);

	POSITION pos = pTmpl->GetFirstDocPosition();
	if (pos == NULL)
	{
		CDocument* pDoc1 = pTmpl->OpenDocumentFile(NULL);
		if (uiMessageID != 0UL)
		{
			//Ϊ�˷���֪ͨ��������ͼ
			pos = pDoc1->GetFirstViewPosition();
			ASSERT(pos != NULL);

			CView* pView = pDoc1->GetNextView(pos);
			ASSERT_VALID(pView);

			CFrameWnd* pFrame = pView->GetParentFrame();
			ASSERT_VALID(pFrame);

			::SendMessage(pView->GetSafeHwnd(), uiMessageID, NULL, lParam);
		}
		return;
	}

	CDocument* pDoc = pTmpl->GetNextDoc(pos);
	ASSERT_VALID(pDoc);

	pos = pDoc->GetFirstViewPosition();
	ASSERT(pos != NULL);

	CView* pView = pDoc->GetNextView(pos);
	ASSERT_VALID(pView);

	CFrameWnd* pFrame = pView->GetParentFrame();
	ASSERT_VALID(pFrame);

	if (uiMessageID != 0UL)
	{
		::SendMessage(pView->GetSafeHwnd(), uiMessageID, NULL, lParam);
	}

	::SendMessage(pMainFrame->m_hWndMDIClient, WM_MDIACTIVATE, (WPARAM)pFrame->GetSafeHwnd(), NULL);
}

void CYYGMISApp::SendMessageToView(STDString strTemplateName, UINT uiMessageID, LPARAM lParam)
{
	RealOpenDocument(strTemplateName, uiMessageID, lParam);
}

BOOL CYYGMISApp::SendMsgTool(CMultiDocTemplate* pTmpl, DWORD dwMsgID, WPARAM wParam, LPARAM lParam)
{
	ASSERT_VALID(pTmpl);
	POSITION pos = pTmpl->GetFirstDocPosition();
	if (pos != NULL)
	{
		CDocument* pDoc = pTmpl->GetNextDoc(pos);
		ASSERT(pDoc);

		pos = pDoc->GetFirstViewPosition();
		ASSERT(pos != NULL);

		CView* pView = pDoc->GetNextView(pos);
		ASSERT_VALID(pView);

		SendMessage(pView->GetSafeHwnd(), dwMsgID, wParam, lParam);
		return TRUE;
	}

	return FALSE;
}

void CYYGMISApp::OpenSalesWindow(int SalesType, LPCTSTR lpcszItemID)
{
	//�����Զ��л������ݵ���Ĺ���
	theApp.SaveState();

	Business::CSaleFrame *pSaleFrame = nullptr;

	//��ʼ��������������
	for (auto pos = m_lstMainFrames.GetHeadPosition(); pos != nullptr;)
	{
		CMDIFrameWndEx* pMainFrame = reinterpret_cast<CMDIFrameWndEx*>(m_lstMainFrames.GetNext(pos));
		if (pMainFrame != nullptr && pMainFrame->IsKindOf(RUNTIME_CLASS(Business::CSaleFrame)))
		{
			pSaleFrame = reinterpret_cast<Business::CSaleFrame*>(pMainFrame);
			break;
		}
	}

	if (pSaleFrame == nullptr)
	{
		pSaleFrame = new Business::CSaleFrame();
		pSaleFrame->LoadFrame(IDR_SALEFRAME);
		m_lstMainFrames.AddTail(pSaleFrame);
	}

	theApp.SetActiveFrame(CYYGMISApp::SaleFrame);
	theApp.m_pMainWnd = pSaleFrame;

	Business::DataPattern::EnumBusinessType enumBusType;
	if (SalesType == Business::DataPattern::enumSalesTikits)
	{
		enumBusType = Business::DataPattern::enumSalesTikits;
	}
	else
	{
		enumBusType = Business::DataPattern::enumServiceTikits;
	}

	std::shared_ptr<Business::DataPattern::PSChangeParameter> spConstructArgs(
		new Business::DataPattern::PSChangeParameter());

	spConstructArgs->enumBusinessType = enumBusType;
	spConstructArgs->ChangeObject = Business::DataPattern::enumAllControl;
	spConstructArgs->enumActionType = Database::NewItem;
	spConstructArgs->pLaunchSource = nullptr;
	spConstructArgs->nExtraSize = 0;
	spConstructArgs->pDataExtra = nullptr;

	if (lpcszItemID == nullptr || _tcslen(lpcszItemID) == 0)
	{
		_tcscpy_s(spConstructArgs->ObjectIDs, _countof(spConstructArgs->ObjectIDs), _T(""));
	}
	else
	{
		_tcscpy_s(spConstructArgs->ObjectIDs, _countof(spConstructArgs->ObjectIDs), lpcszItemID);
	}

	if (pSaleFrame->m_bMainWndHide)
	{
		if (lpcszItemID != nullptr && _tcslen(lpcszItemID) > 0)
		{
			RealOpenDocument(_T("SalePayment"), WM_SALSVC_CREATE_MSG, (LPARAM)(spConstructArgs.get()));
			RealOpenDocument(_T("SalePage"), WM_SALSVC_CREATE_MSG, (LPARAM)(spConstructArgs.get()));
		}
		else
		{
			RealOpenDocument(_T("SalePayment"));
			RealOpenDocument(_T("SalePage"));
		}
	}
	else
	{
		RealOpenDocument(_T("SalePayment"), WM_SALSVC_CREATE_MSG, (LPARAM)(spConstructArgs.get()));
		RealOpenDocument(_T("SalePage"), WM_SALSVC_CREATE_MSG, (LPARAM)(spConstructArgs.get()));
	}

	theApp.m_pMainWnd->ShowWindow(SW_SHOWMAXIMIZED);
	theApp.m_pMainWnd->UpdateWindow();
	theApp.m_pMainWnd->SetForegroundWindow(); //����㴰������ʾ
}

// �������ݱ��֪ͨ
BOOL CYYGMISApp::SendLocalMsg(DWORD msgID, WPARAM wParam, LPARAM lParam, BOOL bNotifySelf)
{
	BOOL bSuccessed = FALSE;
	
	switch (msgID)
	{
	case WM_METADATA_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("Metadata"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("StaffInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_ENTINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("EnterpriseInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("AgencyInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
			it = m_mdtTemplate.find(_T("WarehouseInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_AGCINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("AgencyInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("StaffInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_WSPINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("WarehouseInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("BusinessBalance"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_STAFFINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("StaffInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_CUSTINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("CustomerInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("CardInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("CardUIRecord"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_CVIPTINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("CardVIPType"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("CardInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("CardUIRecord"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_CARDTINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("CardInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("CardUIRecord"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_CUIRINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("CardUIRecord"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_PSOPTION_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("ProductServiceOption"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("ProductInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("ServiceInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("BusinessBalance"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_PRODINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("ProductInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("BusinessBalance"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_EQUIPINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("EquipmentInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		{
			auto it = m_mdtTemplate.find(_T("ServiceInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_SVCINFO_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("ServiceInfo"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_PRODBAL_CHANGED:
		if (bNotifySelf)
		{
			auto it = m_mdtTemplate.find(_T("BusinessBalance"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
			}
		}
		break;
	case WM_SALSVC_CREATE_MSG:
		{
			auto it = m_mdtTemplate.find(_T("SalePage"));
			if (it != m_mdtTemplate.end())
			{
				bSuccessed = SendMsgTool(it->second, msgID, wParam, lParam);
				it = m_mdtTemplate.find(_T("SalePayment"));
				if (it != m_mdtTemplate.end())
				{
					bSuccessed = bSuccessed && SendMsgTool(it->second, msgID, wParam, lParam);
				}
				else
				{
					Business::DataPattern::PPSChangeParameter pParam =
						reinterpret_cast<Business::DataPattern::PPSChangeParameter>(lParam);
					OpenSalesWindow(pParam->enumBusinessType, pParam->ObjectIDs);
					bSuccessed = TRUE;
				}
			}
			else
			{
				Business::DataPattern::PPSChangeParameter pParam =
					reinterpret_cast<Business::DataPattern::PPSChangeParameter>(lParam);
				OpenSalesWindow(pParam->enumBusinessType, pParam->ObjectIDs);
				bSuccessed = TRUE;
			}
		}
		break;
	}
	return bSuccessed; 
}


// CYYGMISApp ��Ϣ��������


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

// �������жԻ����Ӧ�ó�������
void CYYGMISApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

BOOL CYYGMISApp::SystemPassGate(Database::CFlybyItem* pInputItem)
{
	BOOL bRegistered = FALSE;
	CString strFinalProof, strFinalTS, strFinalCode;
	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		std::shared_ptr<Database::CYYGMISSystemInfoVector> spVector(new Database::CYYGMISSystemInfoVector());
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s"), spVector->m_strBindTable);
		BOOL bSuccess = pDataBase->GetSystemInfo(strQuery, *spVector);
		if (bSuccess == TRUE)
		{
			if (pInputItem == nullptr)
			{
				if (spVector->GetCount() > 0)
				{
					strFinalProof.Append(spVector->GetCellText(0, 1));
					strFinalTS.Append(spVector->GetCellText(0, 2));
					strFinalCode.Append(spVector->GetCellText(0, 3));
					m_bInitialized = (spVector->GetCellText(0, 4).Compare(_T("�����")) == 0);
					m_uiBusinessLoadPeriod = _ttoi(spVector->GetCellText(0, 8));
				}
				else
				{
					//����һ���¼�¼
					std::shared_ptr<Database::CYYGMISSystemInfo> spNewItem(new Database::CYYGMISSystemInfo());
					strQuery.Format(_T("INSERT INTO tsw_tabSystemInfo(SYSID, SystemProof, TimeStamp, FinalCode, IsInitialized, ProdScoreRate, SvsScoreRate, StartDate, LoadPeriod) VALUES('%s', '%s', '%s', '%s', %s, %s, %s, '%s', %s);"),
						spNewItem->GetCellText(0),
						spNewItem->GetCellText(1),
						spNewItem->GetCellText(2),
						spNewItem->GetCellText(3),
						(spNewItem->GetCellText(4).Compare(_T("�����")) == 0) ? _T("1") : _T("0"),
						spNewItem->GetCellText(5),
						spNewItem->GetCellText(6),
						spNewItem->GetCellText(7),
						spNewItem->GetCellText(7));
					if (pDataBase->ExecuteNonQuery(strQuery))
					{
						//ִ����֤
						strFinalProof.Append(spNewItem->GetCellText(1));
						strFinalTS.Append(spNewItem->GetCellText(2));
						strFinalCode.Append(spNewItem->GetCellText(3));
					}
				}
			}
			else
			{
				//ִ�и��²���֤
				if (m_bRegistered)
				{
					strQuery.Format(_T("UPDATE tsw_tabSystemInfo SET IsInitialized = %s, ProdScoreRate = %s, SvsScoreRate = %s, StartDate = '%s', LoadPeriod = %s WHERE SYSID = '%s';"),
						(pInputItem->GetCellText(4).Compare(_T("�����")) == 0) ? _T("1") : _T("0"),
						pInputItem->GetCellText(5),
						pInputItem->GetCellText(6),
						pInputItem->GetCellText(7),
						pInputItem->GetCellText(8),
						pInputItem->GetCellText(0));
				}
				else
				{
					strQuery.Format(_T("UPDATE tsw_tabSystemInfo SET FinalCode = '%s', IsInitialized = %s, ProdScoreRate = %s, SvsScoreRate = %s, StartDate = '%s', LoadPeriod = %s WHERE SYSID = '%s';"),
						pInputItem->GetCellText(3),
						(pInputItem->GetCellText(4).Compare(_T("�����")) == 0) ? _T("1") : _T("0"),
						pInputItem->GetCellText(5),
						pInputItem->GetCellText(6),
						pInputItem->GetCellText(7),
						pInputItem->GetCellText(8),
						pInputItem->GetCellText(0));
				}
				if (pDataBase->ExecuteNonQuery(strQuery))
				{
					//ִ����֤
					strFinalProof.Append(pInputItem->GetCellText(1));
					strFinalTS.Append(pInputItem->GetCellText(2));
					strFinalCode.Append(pInputItem->GetCellText(3));
					m_bInitialized = (pInputItem->GetCellText(4).Compare(_T("�����")) == 0);
					m_uiBusinessLoadPeriod = _ttoi(pInputItem->GetCellText(8));
				}
			}
		}
	}

	if (!m_bRegistered)
	{
		CString strFinalContent;
		//ִֻ����֤
		KeyChecksum(strFinalProof, strFinalTS, strFinalContent);
		bRegistered = (strFinalContent.Compare(strFinalCode) == 0);
		m_bRegistered = bRegistered;
	}
	else
	{
		bRegistered = TRUE;
	}

	return bRegistered;
}

void CYYGMISApp::RequestRealExit()
{
	for (auto pos = m_lstMainFrames.GetHeadPosition(); pos != nullptr;)
	{
		CMDIFrameWndEx* pMainFrame = reinterpret_cast<CMDIFrameWndEx*>(m_lstMainFrames.GetNext(pos));
		if (pMainFrame != nullptr && pMainFrame->IsKindOf(RUNTIME_CLASS(Business::CSaleFrame)))
		{
			theApp.m_bRealExit = TRUE;
			SendMessage(pMainFrame->GetSafeHwnd(), WM_CLOSE, NULL, NULL);
			//pMainFrame->SendMessage(  )
			break;
		}
	}
}

void CYYGMISApp::SetActiveFrame(YYGMIS_FRAME frame)
{
	CString strOldRegPath = GetRegSectionPath();

	// Save user tools:
	if (GetUserToolsManager() != NULL)
	{
		GetUserToolsManager()->SaveState(GetRegSectionPath());
	}

	switch (frame)
	{
	case MainFrame:
		SetRegistryBase(_T("Settings"));
		m_currentFrame = MainFrame;
		break;

	case SaleFrame:
		SetRegistryBase(_T("Sale Settings"));
		m_currentFrame = SaleFrame;
		break;

	default:
		ASSERT(FALSE);
	}

	// Load user tools:
	if (GetUserToolsManager() != NULL)
	{
		GetUserToolsManager()->LoadState(strOldRegPath);
	}
}

// CYYGMISApp �Զ������/���淽��

void CYYGMISApp::PreLoadState()
{
	BOOL bNameValid;
	CString strName;
	bNameValid = strName.LoadString(IDS_EDIT_MENU);
	ASSERT(bNameValid);
	GetContextMenuManager()->AddMenu(strName, IDR_POPUP_EDIT);

	GetContextMenuManager()->AddMenu(_T("ְ����Ϣ������"), IDR_POPUP_STAFF);
	GetContextMenuManager()->AddMenu(_T("ҵ����������"), IDR_POPUP_BUSINESS);
	GetContextMenuManager()->AddMenu(_T("������������"), IDR_POPUP_BUSINESS_INV);
	GetContextMenuManager()->AddMenu(_T("��Ա��������"), IDR_POPUP_CUIR);
	GetContextMenuManager()->AddMenu(_T("����������"), IDR_POPUP_MINI);
	GetContextMenuManager()->AddMenu(_T("ͨ��������"), IDR_POPUP_NORMAL);
	GetContextMenuManager()->AddMenu(_T("����ҵ��������"), IDR_POPUP_SALE_EDIT);

}

void CYYGMISApp::LoadCustomState()
{
}

void CYYGMISApp::SaveCustomState()
{
}

// CYYGMISApp ��Ϣ��������



#include "SQLiteDebug.h"

void CYYGMISApp::OnDebugSqlite()
{
	std::shared_ptr<CSQLiteDebug> spDlg(new CSQLiteDebug());
	spDlg->DoModal();
}


void CYYGMISApp::OnFileOptions()
{
	RealOpenDocument(_T("Metadata"));
}


void CYYGMISApp::OnFileEntinfo()
{
	RealOpenDocument(_T("EnterpriseInfo"));
}


void CYYGMISApp::OnFileAgency()
{
	RealOpenDocument(_T("AgencyInfo"));
}



void CYYGMISApp::OnFileWarehouse()
{
	RealOpenDocument(_T("WarehouseInfo"));
}


void CYYGMISApp::OnFileStaff()
{
	RealOpenDocument(_T("StaffInfo"));
}


void CYYGMISApp::OnFileCustomer()
{
	RealOpenDocument(_T("CustomerInfo"));
}


void CYYGMISApp::OnFileVipcardtype()
{
	RealOpenDocument(_T("CardVIPType"));
}


void CYYGMISApp::OnFileCardInfo()
{
	RealOpenDocument(_T("CardInfo"));
}


void CYYGMISApp::OnFileCuscorerecord()
{
	RealOpenDocument(_T("CardUIRecord"));
}


void CYYGMISApp::OnFilePsoptions()
{
	RealOpenDocument(_T("ProductServiceOption"));
}


void CYYGMISApp::OnFileProductinfo()
{
	RealOpenDocument(_T("ProductInfo"));
}

void CYYGMISApp::OnFileEquipment()
{
	RealOpenDocument(_T("EquipmentInfo"));
}


void CYYGMISApp::OnFileServiceinfo()
{
	RealOpenDocument(_T("ServiceInfo"));
}


void CYYGMISApp::OnDebugLicense()
{
	std::shared_ptr<CCertificationDlg> spLicense(new CCertificationDlg());
	spLicense->DoModal();
}


void CYYGMISApp::OnBusinessBalance()
{
	RealOpenDocument(_T("BusinessBalance"));
}

void CYYGMISApp::OnBusinessSales()
{
	OpenSalesWindow(Business::DataPattern::enumSalesTikits, nullptr);
}
