// InventoryDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "InventoryDoc.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
// CInventoryDoc

IMPLEMENT_DYNCREATE(CInventoryDoc, CDocument)

CInventoryDoc::CInventoryDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CInventoryDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("�����Ʒ���鿴"));
	return TRUE;
}

CInventoryDoc::~CInventoryDoc()
{
}


BEGIN_MESSAGE_MAP(CInventoryDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CInventoryDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CInventoryDoc::OnFileSave)
END_MESSAGE_MAP()


// CInventoryDoc ���

#ifdef _DEBUG
void CInventoryDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CInventoryDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CInventoryDoc ���л�

void CInventoryDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CInventoryDoc ����


BOOL CInventoryDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CInventoryDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CInventoryDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabInventories(InvID, StockQuantity, WSPID, ProdID) VALUES('%s', %s, '%s', '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 7),
			m_vectNewItems.GetCellText(i, 8),
			m_vectNewItems.GetCellText(i, 9));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabInventories SET StockQuantity = %s, WSPID = '%s', ProdID = '%s' WHERE InvID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 7),
			m_vectModItems.GetCellText(i, 8),
			m_vectModItems.GetCellText(i, 9),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabInventories WHERE InvID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_PRODBAL_CHANGED, NULL, NULL, TRUE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("�����Ʒ����ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
