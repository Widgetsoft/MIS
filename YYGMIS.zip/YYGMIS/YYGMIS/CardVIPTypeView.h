#pragma once

namespace BasicInfo
{
	// CCardVIPTypeView ��ͼ

	class CCardVIPTypeView : public CView
	{
		DECLARE_DYNCREATE(CCardVIPTypeView)

	protected:
		CCardVIPTypeView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
		virtual ~CCardVIPTypeView();

	private:
		CLocalDataGridView m_ListCtrl; //���ݿؼ�

	private:
		void LoadData();
		UINT_PTR m_uipCVIPTTimerID;

	public://����
		CCardVIPTypeDoc* GetDocument() const;

	public:
		virtual void OnDraw(CDC* pDC);      // ��д�Ի��Ƹ���ͼ
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		DECLARE_MESSAGE_MAP()
	public:
		afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
		afx_msg void OnSize(UINT nType, int cx, int cy);
		afx_msg void OnEditNewitem();
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnUpdateEditRefresh(CCmdUI *pCmdUI);
		afx_msg void OnEditRefresh();
		afx_msg void OnUpdateEditModify(CCmdUI *pCmdUI);
		afx_msg void OnEditModify();
		afx_msg void OnUpdateEditDelete(CCmdUI *pCmdUI);
		afx_msg void OnEditDelete();
		afx_msg void OnUpdateEditRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditRevsel();
		afx_msg void OnUpdateEditFind(CCmdUI *pCmdUI);
		afx_msg void OnEditFind();
		LRESULT OnDataChanged(WPARAM wParam, LPARAM lParam);
		afx_msg void OnTimer(UINT_PTR nIDEvent);
	};
}

#ifndef _DEBUG
inline BasicInfo::CCardVIPTypeDoc* BasicInfo::CCardVIPTypeView::GetDocument() const
{
	return reinterpret_cast<CCardVIPTypeDoc*>(m_pDocument);
}
#endif