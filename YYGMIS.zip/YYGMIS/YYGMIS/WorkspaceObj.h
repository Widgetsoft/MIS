#pragma once
class CWorkspaceObj :
	public CObject
{
public:
	CWorkspaceObj(const CString& strName, const UINT uiCmd, const int iIconIndex, const UINT uiDefaultNewAction);
	virtual ~CWorkspaceObj(void);

	const CString m_strName;
	const UINT m_uiCmd;
	const int m_iIconIndex;
	const UINT m_uiDefaultNewAction;
};