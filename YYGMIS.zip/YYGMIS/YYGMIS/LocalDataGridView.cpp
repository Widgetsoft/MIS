#include "stdafx.h"
#include "YYGMIS.h"
#include "LocalDataGridView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CLocalDataGridView::CLocalDataGridView(UINT uiContextMenu) noexcept
	: m_pVector(NULL), m_pFRDlg(NULL)
{
	m_nFoundIndex = 0;
	if (uiContextMenu == -1)
	{
		//m_uiContextMenuID = IDR_POPUP_EDIT;
	}
	else
	{
		m_uiContextMenuID = uiContextMenu;
	}
}


CLocalDataGridView::~CLocalDataGridView(void)
{
}

BEGIN_MESSAGE_MAP(CLocalDataGridView, CGridListCtrlGroups)
	ON_NOTIFY_REFLECT(LVN_ODFINDITEM, &CLocalDataGridView::OnLvnOdfinditem)
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, &CLocalDataGridView::OnLvnGetdispinfo)
	ON_REGISTERED_MESSAGE(WM_FINDREPLACE, &CLocalDataGridView::OnFindReplace)
END_MESSAGE_MAP()

void CLocalDataGridView::OnContextMenuGrid(CWnd* pWnd, CPoint point)
{
#ifndef SHARED_HANDLERS
	if (!m_bHeaderContextMode)
	{
		theApp.GetContextMenuManager()->ShowPopupMenu(m_uiContextMenuID, point.x, point.y, GetParent(), TRUE);
	}
#endif
}

void CLocalDataGridView::OnContextMenuCell(CWnd* pWnd, CPoint point, int nRow, int nCol)
{
#ifndef SHARED_HANDLERS
	if (!m_bHeaderContextMode)
	{
		theApp.GetContextMenuManager()->ShowPopupMenu(m_uiContextMenuID, point.x, point.y, GetParent(), TRUE);
	}
#endif
}

CString CLocalDataGridView::GetItemText(int nItem, int nSubItem) const
{

	if (!(GetStyle() & LVS_OWNERDATA))
	{
		return __super::GetItemText(nItem, nSubItem);
	}
	else
	{
		//ִ���Զ��巵��
		if (m_pVector != NULL)
		{
			return m_pVector->GetCellText(nItem, nSubItem);
		}
		else
		{
			return CString(_T(""));
		}
	}
}

int CLocalDataGridView::GetItemText(int nItem, int nSubItem, LPTSTR lpszText, int nLen) const
{
	if (!(GetStyle() & LVS_OWNERDATA))
	{
		return __super::GetItemText(nItem, nSubItem, lpszText, nLen);
	}
	else
	{
		//ִ���Զ��巵��
		if (m_pVector != NULL)
		{
			CString strTemp = m_pVector->GetCellText(nItem, nSubItem);
			if (nLen <= strTemp.GetLength())
			{
				_tcscpy_s(lpszText, nLen, strTemp);
				return strTemp.GetLength();
			}
			else
			{
				lpszText = NULL;
				return -1;
			}
		}
		else
		{
			lpszText = NULL;
			return -1;
		}
	}
}

BOOL CLocalDataGridView::SetItemText(int nItem, int nSubItem, LPCTSTR lpszText)
{
	if (!(GetStyle() & LVS_OWNERDATA))
	{
		return __super::SetItemText(nItem, nSubItem, lpszText);
	}
	else
	{
		return FALSE;
	}
}

int CLocalDataGridView::GetItemCount() const
{
	if (!(GetStyle() & LVS_OWNERDATA))
	{
		return CListCtrl::GetItemCount();
	}
	else
	{
		return (int)(m_pVector->GetCount());
	}
}

bool CLocalDataGridView::SortColumn(int nCol, bool bAscending)
{
	if (!(GetStyle() & LVS_OWNERDATA))
	{
		return __super::SortColumn(nCol, bAscending);
	}
	try
	{
		if (m_pVector != NULL && m_pVector->GetCount() > 0)
		{
			m_pVector->CustomColumnSort(nCol, bAscending);
			this->RedrawItems(0, (int)(m_pVector->GetCount() - 1));
		}
	}
	catch (...)
	{
	}
	return true;
}

void CLocalDataGridView::RefreshData()
{
	if ((GetStyle() & LVS_OWNERDATA))
	{
		this->ClearSelections();
		this->SetItemCountEx((int)(m_pVector->GetCount()));
		this->RedrawItems(0, (int)(m_pVector->GetCount() - 1));
	}
}

//��ʼģ������
void CLocalDataGridView::OnLvnOdfinditem(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLVFINDITEM pFindInfo = reinterpret_cast<LPNMLVFINDITEM>(pNMHDR);
	LVFINDINFO findItem = pFindInfo->lvfi;
	auto strInitial = findItem.psz;
	BOOL bBackward = (findItem.vkDirection == VK_UP);
	BOOL bAllWordsMatch = (BOOL)(findItem.lParam);
	if (m_pVector != NULL)
	{
		*pResult = m_pVector->CustomFindItem(strInitial, pFindInfo->iStart, bBackward, bAllWordsMatch);
	}
}

//------------------------------------------------------------------------
//! Performs custom drawing of the CListCtrl using CGridColumnTrait
//!
//! @param nRow The index of the row
//! @param nCol The index of the column
//! @param pLVCD Pointer to NMLVCUSTOMDRAW structure
//! @param pResult Modification to the drawing stage (CDRF_NEWFONT, etc.)
//------------------------------------------------------------------------
void CLocalDataGridView::OnCustomDrawCell(int nRow, int nCol, NMLVCUSTOMDRAW* pLVCD, LRESULT* pResult)
{
	if (m_pVector != NULL)
	{
		pLVCD->clrText = m_pVector->GetCellColor(nRow, nCol);
	}

	__super::OnCustomDrawCell(nRow, nCol, pLVCD, pResult);
}

void CLocalDataGridView::OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	BeginWaitCursor();
	TRY
	{
		if (pDispInfo->item.mask & LVIF_TEXT)
		{
			UINT nRow = pDispInfo->item.iItem;
			UINT nCol = pDispInfo->item.iSubItem + 1;

			auto pAuto = m_pVector;
			if (nCol != 0)
			{
				_tcscpy_s(pDispInfo->item.pszText, MAX_PATH, pAuto->GetCellText(nRow, nCol - 1));
			}
		}
	}
		CATCH_ALL(e)
	{

	}
	END_CATCH_ALL

	EndWaitCursor();
	//}
	*pResult = 0;
}

int CLocalDataGridView::OnClickEditStart(int nRow, int nCol, CPoint pt, bool bDblClick)
{
	Database::DataState state = m_pVector->GetItem(nRow)->GetState();

	if (state != Database::Modified && state != Database::NewItem)
	{
		return 0;
	}

	return __super::OnClickEditStart(nRow, nCol, pt, bDblClick);

}

// ������е�ѡ����
void CLocalDataGridView::ClearSelections(void)
{
	POSITION pos = this->GetFirstSelectedItemPosition();
	while (pos)
	{
		int nItem = this->GetNextSelectedItem(pos);
		this->SelectRow(nItem, false);
	}
}

void CLocalDataGridView::ReverseSelect()
{
	for (int i = 0; i != GetItemCount(); i++)
	{
		if (GetItemState(i, LVIS_SELECTED) != LVIS_SELECTED)
		{
			SetItemState(i, LVIS_SELECTED, LVIS_SELECTED);
		}
		else
		{
			SetItemState(i, 0, LVIS_SELECTED);
		}
	}
}

BOOL CLocalDataGridView::LocalModify(Database::CFlybyData* pModifyVector,
	UINT uiRestrictCol, UINT uiTargetRestrictCol,
	UINT uiModUserCol,
	LPCTSTR lpctszModUserID)
{
	BOOL bModified = FALSE;
	// �༭����
	Concurrency::concurrent_vector< int > vectID;
	POSITION pos = GetFirstSelectedItemPosition();
	while (pos)
	{
		int nItem = GetNextSelectedItem(pos);
		vectID.push_back(nItem);
	}

	for (Concurrency::concurrent_vector< int >::const_iterator constIT = vectID.begin();
	constIT != vectID.end(); constIT++)
	{
		auto pItem = m_pVector->GetItem(*constIT);
		Database::DataState state = pItem->GetState();
		if (state == Database::Initial)
		{
			pItem->SetState(Database::Modified);
			if (uiModUserCol != UINT(-1))
			{
				pItem->SetCellText(uiModUserCol, lpctszModUserID);
			}

			if (uiRestrictCol != UINT(-1))
			{
				auto pRestrictSrc = pItem->GetCellText(uiRestrictCol);
				if (pRestrictSrc.Find(_T("ͣ��")) != -1)
				{
					auto pRestrictTgt = this->GetCellColumnTrait(*constIT, uiTargetRestrictCol);
					pRestrictTgt->SetCellReadOnly();
				}
			}

			if (pModifyVector != NULL)
			{
				pModifyVector->AddItem(pItem);
			}
			bModified = TRUE;
		}
	}
	//this->RefreshData();
	return bModified;
}

BOOL CLocalDataGridView::LocalModify_If(Database::CFlybyData* pModifyVector,
	std::function<BOOL(const Database::CFlybyItem*)> MatchFunction)
{
	BOOL bModified = FALSE;
	// �༭����
	Concurrency::concurrent_vector< int > vectID;
	POSITION pos = GetFirstSelectedItemPosition();
	while (pos)
	{
		int nItem = GetNextSelectedItem(pos);
		vectID.push_back(nItem);
	}

	for (Concurrency::concurrent_vector< int >::const_iterator constIT = vectID.begin();
	constIT != vectID.end(); constIT++)
	{
		auto pItem = m_pVector->GetItem(*constIT);
		Database::DataState state = pItem->GetState();
		if (state == Database::Initial)
		{
			if (MatchFunction(pItem))
			{
				pItem->SetState(Database::Modified);
				if (pModifyVector != NULL)
				{
					pModifyVector->AddItem(pItem);
				}
				bModified = TRUE;
			}
		}
	}

	return bModified;
}

#include <iostream>

BOOL CLocalDataGridView::LocalDelete(Database::CFlybyData* pDeleteVector, Database::CFlybyData* pNewVector,
	UINT uiSkipCol, LPCTSTR lpcstrFilter)
{
	BOOL bDeleted = FALSE;
	// ɾ������
	Concurrency::concurrent_vector< int > vectID;
	POSITION pos = GetFirstSelectedItemPosition();
	while (pos)
	{
		int nItem = GetNextSelectedItem(pos);
		BOOL bSkip = FALSE;
		if (uiSkipCol != UINT(-1) && lpcstrFilter != NULL)
		{
			if (m_pVector->GetItem(nItem)->GetCellText(uiSkipCol).Compare(lpcstrFilter)
				== 0)
			{
				bSkip = TRUE;
			}
		}
		if (!bSkip)
		{
			vectID.push_back(nItem);
		}
	}

	//std::sort( vectID.begin(), vectID.end(), std::greater<int>( ) );

	for (Concurrency::concurrent_vector< int >::const_reverse_iterator constIT = vectID.rbegin();
	constIT != vectID.rend(); constIT++)
	{
		auto pItem = m_pVector->GetItem(*constIT);
		Database::DataState state = pItem->GetState();
		if (state != Database::NewItem)
		{
			m_pVector->GetItem(*constIT)->SetState(Database::Deleted);
			Database::CFlybyItem* pPT = NULL;
			m_pVector->GetItem(*constIT)->Clone(&pPT);
			if (pDeleteVector != NULL)
			{
				pDeleteVector->AddItem(pPT);
			}
			auto pTemp = m_pVector->GetItem(*constIT);
			m_pVector->RemoveItem(pTemp);
			bDeleted = TRUE;
		}
		else
		{
			if (pNewVector != NULL)
			{
				pNewVector->RemoveItem(pItem);
			}
			m_pVector->RemoveItem(pItem);
			bDeleted = TRUE;
		}
		if (!(GetStyle() & LVS_OWNERDATA))
		{
			DeleteItem(*constIT);
		}
		else
		{
			this->RefreshData();
		}
	}

	return bDeleted;
}

BOOL CLocalDataGridView::LocalDelete_If(Database::CFlybyData* pDeleteVector,
	Database::CFlybyData* pNewVector,
	std::function<BOOL(const Database::CFlybyItem*)> MatchFunction)
{
	BOOL bDeleted = FALSE;
	// ɾ������
	Concurrency::concurrent_vector< int > vectID;
	POSITION pos = GetFirstSelectedItemPosition();
	while (pos)
	{
		int nItem = GetNextSelectedItem(pos);
		vectID.push_back(nItem);
	}

	for (Concurrency::concurrent_vector< int >::const_reverse_iterator constIT = vectID.rbegin();
	constIT != vectID.rend(); constIT++)
	{
		auto pItem = m_pVector->GetItem(*constIT);
		if (MatchFunction(pItem))
		{
			Database::DataState state = pItem->GetState();
			if (state != Database::NewItem)
			{
				m_pVector->GetItem(*constIT)->SetState(Database::Deleted);
				Database::CFlybyItem* pPT = NULL;
				m_pVector->GetItem(*constIT)->Clone(&pPT);
				if (pDeleteVector != NULL)
				{
					pDeleteVector->AddItem(pPT);
				}
				auto pTemp = m_pVector->GetItem(*constIT);
				m_pVector->RemoveItem(pTemp);
				bDeleted = TRUE;
			}
			else
			{
				if (pNewVector != NULL)
				{
					pNewVector->RemoveItem(pItem);
				}
				m_pVector->RemoveItem(pItem);
				bDeleted = TRUE;
			}
			if (!(GetStyle() & LVS_OWNERDATA))
			{
				DeleteItem(*constIT);
			}
			else
			{
				this->RefreshData();
			}
		}
	}
	return bDeleted;
}

// m_pFRDlg is a pointer to a class derived from CFindReplaceDialog 
// which defines variables used by the FINDREPLACE structure. 
// InitFindReplaceDlg creates a CFindReplaceDialog and initializes
// the m_fr with the data members from the derived class
void CLocalDataGridView::InitFindReplaceDlg()
{
	if (NULL == m_pFRDlg)
	{
		m_pFRDlg = new CFindReplaceDialog();  // Must be created on the heap

		m_pFRDlg->Create(TRUE, _T(""), _T(""), FR_DOWN, this);

		m_pFRDlg->m_fr.lStructSize = sizeof(FINDREPLACE);
		m_pFRDlg->m_fr.hwndOwner = this->m_hWnd;
		m_pFRDlg->CenterWindow();
	}

}

LRESULT CLocalDataGridView::OnFindReplace(WPARAM wparam, LPARAM lparam)
{
	UNREFERENCED_PARAMETER(wparam);

	CFindReplaceDialog *pDlg = CFindReplaceDialog::GetNotifier(lparam);

	if (NULL != pDlg)
	{
		// Use pDlg as a pointer to the existing FindReplace dlg to 
		// call CFindReplaceDialog member functions
		if (pDlg->IsTerminating())
		{
			//VERIFY(pDlg->DestroyWindow());
			//m_pFRDlg->DestroyWindow();
			m_pFRDlg = NULL;
			m_nFoundIndex = 0;
		}
		else if (pDlg->FindNext())
		{
			CString   csFindString;
			csFindString = pDlg->GetFindString();

			BOOL bCaseSens = pDlg->MatchCase();
			BOOL bWhole = pDlg->MatchWholeWord();
			BOOL bSearchDown = pDlg->SearchDown();

			this->ClearSelections();
			if (m_nFoundIndex == -1)
			{
				m_nFoundIndex = 0;
			}
			int nIndex = (int)(this->m_pVector->CustomFindItem((LPCTSTR)csFindString, m_nFoundIndex, !bSearchDown, bWhole));
			if (nIndex != -1)
			{
				ClearSelections();
				SetItemState(nIndex, LVIS_SELECTED, LVIS_SELECTED);
				EnsureVisible(nIndex, FALSE);
				m_nFoundIndex = nIndex;
				if (!bSearchDown)
				{
					if (m_nFoundIndex == 0)
					{
						m_nFoundIndex = this->m_pVector->GetCount() - 1;
					}
					else
					{
						m_nFoundIndex--;
					}
				}
				else
				{
					if (m_nFoundIndex == this->m_pVector->GetCount() - 1)
					{
						m_nFoundIndex = 0;
					}
					else
					{
						m_nFoundIndex++;
					}
				}
			}
			else
			{
				m_nFoundIndex = 0;
			}
		}
	}

	return 0;
}
