#include "stdafx.h"
#include "TransparentCheckbox.h"

using namespace UI::Control;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CTransparentCheckbox

IMPLEMENT_DYNAMIC(CTransparentCheckbox, CButton)

CTransparentCheckbox::CTransparentCheckbox()
{

}

CTransparentCheckbox::~CTransparentCheckbox()
{
}


BEGIN_MESSAGE_MAP(CTransparentCheckbox, CButton)
END_MESSAGE_MAP()



// CTransparentCheckbox ��Ϣ��������




void CTransparentCheckbox::PreSubclassWindow()
{
	SetWindowTheme(*this, _T(""), _T(""));

#pragma comment(lib, "UxTheme.lib")


	CButton::PreSubclassWindow();
}
