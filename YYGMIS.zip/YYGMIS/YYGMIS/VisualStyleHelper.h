#pragma once
namespace UI
{
	class VisualStyleHelper
	{
	public:
		static void DetermineCurrentThemeClr();
		static CBrush& GetBackgroundBr();
		static COLORREF GetBackgroundClr();
		static HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	private:

		static CBrush s_brBackground;
		static COLORREF s_clrBackground;
	};
}
