// DataLoadSaveThread.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "CommonWork.h"
#include "WorkAssistant.h"
#include "StoreWork.h"
#include "DataLoadSaveThread.h"
#include "DataProcessDlg.h"

using namespace Business;
//using namespace Business::DataPattern;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDataLoadSaveThread
IMPLEMENT_DYNCREATE(CDataLoadSaveThread, CWinThread)

CDataLoadSaveThread::CDataLoadSaveThread()
	:m_pOwner(NULL)
{
	m_bAutoDelete = FALSE;
}

CDataLoadSaveThread::~CDataLoadSaveThread()
{
}

BOOL CDataLoadSaveThread::InitInstance()
{
	// TODO:    �ڴ�ִ���������̳߳�ʼ��
	return TRUE;
}

int CDataLoadSaveThread::ExitInstance()
{
	// TODO:    �ڴ�ִ���������߳�����
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CDataLoadSaveThread, CWinThread)
END_MESSAGE_MAP()


// CDataLoadSaveThread ��Ϣ��������


int CDataLoadSaveThread::Run()
{
	CSingleLock sLock(&(m_pOwner->m_mutex));
	sLock.Lock();
	Sleep(10);
	Core::CCommonWork *pWork = NULL;
	m_pOwner->m_bOK = FALSE;
	switch (m_pOwner->m_enumTickType)
	{
	case DataPattern::enumStoreIn:
	case DataPattern::enumStoreOut:
		pWork = new Core::CStoreWork(m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd());
		break;
	case DataPattern::enumStoreLoss:
		//pWork = new Core::CLostWork(m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd());
		break;
	case DataPattern::enumServiceTikits:
		//pWork = new Core::CServiceWork(m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd());
		break;
	case DataPattern::enumReceivableTickets:
	case DataPattern::enumPayableTicket:
		//pWork = new Core::CPaymentWork(m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd());
		break;
	case DataPattern::enumPurchaseTickits:
		//pWork = new Core::CPurchaseWork(m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd());
		break;
	case DataPattern::enumSalesTikits:
		//pWork = new Core::CSalesWork(m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd());
		break;
	}
	if (pWork != NULL)
	{
		pWork->SetData(m_pOwner->m_spTickitsData);
		pWork->SetOldData(m_pOwner->m_spOldTickitsData);
		pWork->SetItemKeys(m_pOwner->m_spItemKeys);
		if (!m_pOwner->m_bLoadOnly)
		{
			if (m_pOwner->m_spTickitsData->GetInitialState() == Database::NewItem)
			{
				m_pOwner->m_bOK = pWork->SaveNew(m_pOwner->m_enumTickType);
			}
			//ִ��ɾ��
			else if (m_pOwner->m_spTickitsData->GetInitialState() == Database::Deleted)
			{
				m_pOwner->m_bOK = pWork->SaveDelete(m_pOwner->m_enumTickType);
			}
			//ִ���޸�
			else if (m_pOwner->m_spTickitsData->GetInitialState() == Database::Modified)
			{
				m_pOwner->m_bOK = pWork->SaveModify(m_pOwner->m_enumTickType);
			}
		}
		else
		{
			m_pOwner->m_bOK = pWork->ConstructBusinessData(m_pOwner->m_enumTickType, TRUE,
				m_pOwner->m_enumSourceTickType);
		}
		delete pWork;
	}
	sLock.Unlock();
	m_pOwner->PostMessage(WM_CLOSE, 0, 0L);
	return 0;//CWinThread::Run();
}
