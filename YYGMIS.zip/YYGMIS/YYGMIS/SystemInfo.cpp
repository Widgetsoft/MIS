#include "stdafx.h"
#include "YYGMIS.h"
#include "SystemInfo.h"

#ifdef _DENUG
#define new DEBUG_NEW
#endif

CSystemInfo::CSystemInfo(BOOL bAutoGrow)
	:m_bAutoGrow(bAutoGrow)
{
	_tcscpy_s(m_strEntID, _countof(m_strEntID), _T("{00000000-0000-0000-0000-000000000000}"));
	_tcscpy_s(m_strEntName, _countof(m_strEntName), _T(""));
	_tcscpy_s(m_strDeptID, _countof(m_strDeptID), _T("{00000000-0000-0000-0000-000000000000}"));
	_tcscpy_s(m_strDeptName, _countof(m_strDeptName), _T(""));
	_tcscpy_s(m_strUserInnerID, _countof(m_strUserInnerID), _T("{00000000-0000-0000-0000-000000000000}"));
	_tcscpy_s(m_strUserName, _countof(m_strUserName), _T(""));
	_tcscpy_s(m_strUserID, _countof(m_strUserID), _T(""));
	if (bAutoGrow)
	{
		//��ѯĬ�ϵ���ҵ����
		CString strQuery;
		strQuery.Append(_T("SELECT A.compID, A.compName, B.deptID, B.deptName, C.EID, C.EName, C.UID FROM (tsw_tabEnterpriseInfo A INNER JOIN tsw_tabAgencyInfo B ON A.IsUsing = 1 AND A.compID LIKE B.compID AND B.IsUsing = 1) INNER JOIN tsw_tabStaffInfo C ON C.EIsUsing = 1 AND B.deptID LIKE C.deptID;"));
		LOCALEDB;
		GenerialPattern::CItemsData* pDatas = nullptr;
		if (pDataBase->NormalGetItemsData(strQuery, &pDatas) && pDatas != nullptr
			&& pDatas->GetSize() > 0)
		{
			//�ſ��Լ���
			auto pItemData = pDatas->GetItemData(0);
			_tcscpy_s(m_strEntID, _countof(m_strEntID), pItemData->at(0).c_str());
			_tcscpy_s(m_strEntName, _countof(m_strEntName), pItemData->at(1).c_str());
			//��ʼ����Ĭ�ϲ���
			_tcscpy_s(m_strDeptID, _countof(m_strDeptID), pItemData->at(2).c_str());
			_tcscpy_s(m_strDeptName, _countof(m_strDeptName), pItemData->at(3).c_str());
			//��ʼ����Ĭ���û�
			_tcscpy_s(m_strUserInnerID, _countof(m_strUserInnerID), pItemData->at(4).c_str());
			_tcscpy_s(m_strUserName, _countof(m_strUserName), pItemData->at(5).c_str());
			_tcscpy_s(m_strUserID, _countof(m_strUserID), pItemData->at(6).c_str());
		}

	}
}


CSystemInfo::~CSystemInfo()
{
}
