// SaleServiceSaveThread.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "SaleServiceSaveThread.h"
#include "TickitsData.h"
#include "SaleServiceSaveDlg.h"
#include "SaleBatchSaveWorker.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSaleServiceSaveThread

IMPLEMENT_DYNCREATE(CSaleServiceSaveThread, CWinThread)

CSaleServiceSaveThread::CSaleServiceSaveThread()
	:m_pOwner(nullptr)
{
	m_bAutoDelete = FALSE;
}

CSaleServiceSaveThread::~CSaleServiceSaveThread()
{
}

BOOL CSaleServiceSaveThread::InitInstance()
{
	// TODO:    �ڴ�ִ���������̳߳�ʼ��
	return TRUE;
}

int CSaleServiceSaveThread::ExitInstance()
{
	// TODO:    �ڴ�ִ���������߳�����
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CSaleServiceSaveThread, CWinThread)
END_MESSAGE_MAP()


// CSaleServiceSaveThread ��Ϣ��������

int Business::CSaleServiceSaveThread::Run()
{
	// TODO: �ڴ�����ר�ô����/����û���
	//Core::CSaleBatchSaveWorker
	CSingleLock sLock(&(m_pOwner->m_mutex));
	sLock.Lock();
	m_pOwner->m_bOkExit = FALSE;
	m_pOwner->m_bOK = FALSE;
	std::shared_ptr<Core::CSaleBatchSaveWorker> spSave(new Core::CSaleBatchSaveWorker(
		m_pOwner->m_progressTotal, m_pOwner->m_progressSub, m_pOwner->GetSafeHwnd()));
	m_pOwner->m_bOK = spSave->ExecuteSaveBatch(m_pOwner->m_spDataItems, m_pOwner->m_vectEntity,
		m_pOwner->m_strFinalResult);
	m_pOwner->m_bOkExit = TRUE;
	m_pOwner->PostMessage(WM_CLOSE, 0, 0L);
	sLock.Unlock();
	return 0;
}
