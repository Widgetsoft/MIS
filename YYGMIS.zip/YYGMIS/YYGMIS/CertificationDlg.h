#pragma once

#include "TransparentLabel.h"

// CCertificationDlg �Ի���

class CCertificationDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCertificationDlg)

public:
	CCertificationDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CCertificationDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_GENERATE_DLG };
#endif
private:
	UI::Control::CTransparentLabel m_label1;
	UI::Control::CTransparentLabel m_label2;
	UI::Control::CTransparentLabel m_label3;

private:
	CMFCControlRenderer m_Pat[4];
	CMFCToolBarImages	m_Icons;
	CImageList			m_ImageList;
	TCHAR				m_tcsTitle[MAX_PATH];

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnBnClickedOk();
};
