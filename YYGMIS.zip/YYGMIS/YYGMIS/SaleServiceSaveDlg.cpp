// SaleServiceSaveDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "SaleServiceSaveDlg.h"
#include "afxdialogex.h"
#include "SaleBatchSaveWorker.h"
#include "SaleServiceSaveThread.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//#define TRANSPARENT_COLOR  RGB (200, 201, 202)

using namespace Business;
// CSaleServiceSaveDlg �Ի���

IMPLEMENT_DYNAMIC(CSaleServiceSaveDlg, CDialogEx)

CSaleServiceSaveDlg::CSaleServiceSaveDlg(std::shared_ptr<DataPattern::CTickitsData> spDataItems,
	concurrency::concurrent_vector<std::shared_ptr<DataPattern::SCTicketIDGroupPure>> vectEntity,
	CString& strFinalResult, CWnd* pParent /*=NULL*/)
	:m_spDataItems(spDataItems), m_vectEntity(vectEntity), m_strFinalResult(strFinalResult),
	m_mutex(), m_pWorkThread(nullptr), CDialogEx(IDD_SALESERVICE_SAVE_DLG, pParent)
{
	m_bOkExit = TRUE;
}

CSaleServiceSaveDlg::~CSaleServiceSaveDlg()
{
}

void CSaleServiceSaveDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SSS_LABEL1, m_label1);
	DDX_Control(pDX, IDC_PROGRESS1, m_progressTotal);
	DDX_Control(pDX, IDC_PROGRESS2, m_progressSub);
}


BEGIN_MESSAGE_MAP(CSaleServiceSaveDlg, CDialogEx)
	ON_WM_ERASEBKGND()
	ON_WM_CLOSE()
END_MESSAGE_MAP()

void CSaleServiceSaveDlg::StartUpWorkThread()
{
	m_pWorkThread = (CSaleServiceSaveThread*)AfxBeginThread(RUNTIME_CLASS(CSaleServiceSaveThread), THREAD_PRIORITY_NORMAL,
		0, CREATE_SUSPENDED);
	m_pWorkThread->SetOwner(this);
	m_pWorkThread->ResumeThread();
}

// CSaleServiceSaveDlg ��Ϣ��������

BOOL CSaleServiceSaveDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetWindowLong(this->GetSafeHwnd(), GWL_EXSTYLE,
		GetWindowLong(this->GetSafeHwnd(), GWL_EXSTYLE) | WS_EX_LAYERED);
	// Make this window 70% alpha
	::SetLayeredWindowAttributes(this->GetSafeHwnd(), 0, (255 * 70) / 100, LWA_ALPHA);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}


BOOL CSaleServiceSaveDlg::OnEraseBkgnd(CDC* pDC)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	CDrawingManager dm(*pDC);
	dm.FillGradient(rcClient, RGB(236, 246, 237), RGB(255, 255, 255), TRUE);
	return TRUE;
}


INT_PTR CSaleServiceSaveDlg::DoModal()
{
	StartUpWorkThread();

	return CDialogEx::DoModal();
}


void CSaleServiceSaveDlg::OnClose()
{
	if (!m_bOkExit)
	{
		return;
	}

	if (m_pWorkThread != nullptr)
	{
		delete m_pWorkThread;
	}

	CDialogEx::OnClose();
}
