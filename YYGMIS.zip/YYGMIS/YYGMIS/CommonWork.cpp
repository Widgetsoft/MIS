#include "stdafx.h"
#include "TickitsData.h"
#include "CommonWork.h"
#include "YYGMIS.h"

using namespace Business::Core;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CCommonWork::CCommonWork(CProgressCtrl& progressTotal, CProgressCtrl& progressSub, HWND hParentWnd)
	:m_progressTotal(progressTotal), m_progressSub(progressSub), m_hWnd(hParentWnd)
{
	m_spData = NULL;
	m_spOldData = NULL;
	m_spKeys = NULL;
}


BOOL CCommonWork::ExecuteUpdate(LPCTSTR strUpdates)
{
	LOCALEDB;
	if (pDataBase && pDataBase->m_bDBOpened)
	{

		Concurrency::concurrent_vector< STDString > vectUpdates;
		Helper::CToolkits::Split(strUpdates, _T(";"), &vectUpdates);
		return pDataBase->ExecuteNonQueryBatch(&vectUpdates, TRUE);
	}
	return FALSE;
}

BOOL CCommonWork::QueryStockStatus(LPCTSTR lpcstrQuery,
	std::shared_ptr<Database::CDataFactory> spDataSource, CString& strFaildReason)
{
	BOOL bRet = FALSE;

	GenerialPattern::CItemData* pQueryItem = NULL;
	BOOL bQS = spDataSource->NormalGetItemData(lpcstrQuery, &pQueryItem);
	if (bQS)
	{
		//��֤ʣ����
		int nCount = _ttoi(pQueryItem->at(0).c_str());
		if (nCount <= 0)
		{
			strFaildReason.Format(_T("������Ʒ��������㣬�������ݱ��治�ɹ���"));
		}
		else
		{
			bRet = TRUE;
		}
		delete pQueryItem;
		pQueryItem = NULL;
	}
	return bRet;
}

BOOL CCommonWork::QueryVaryStatus(LPCTSTR lpcstrQuery, LPCTSTR lpcstrKey1, LPCTSTR lpcstrKey2,
	double dblAmount, Database::CDataFactory* pDataSource, CString& strFaildReason)
{
	BOOL bRet = FALSE;
	GenerialPattern::CItemsData* pQueryItems = NULL;
	BOOL bQS = pDataSource->NormalGetItemsData(lpcstrQuery, &pQueryItems, TRUE);
	if (bQS)
	{
		double dblQuantity1 = 0, dblQuantity2 = 0, dblBalance = 0;
		if (pQueryItems->GetItemData(0)->size() > 0 && !pQueryItems->GetItemData(0)->at(0).empty())
		{
			TCHAR* tcsStop = nullptr;
			dblQuantity1 = _tcstod(pQueryItems->GetItemData(0)->at(0).c_str(), &tcsStop);
			if (pQueryItems->GetItemData(1)->size() > 0 && !pQueryItems->GetItemData(1)->at(0).empty())
			{
				TCHAR* tcsStop1 = nullptr;
				dblQuantity2 = _tcstod(pQueryItems->GetItemData(1)->at(0).c_str(), &tcsStop1);
			}
			dblBalance = dblQuantity1 - dblQuantity2 - dblAmount;
			if (dblBalance >= 0)
			{
				bRet = TRUE;
			}
			else
			{
				strFaildReason.Format(_T("����%s������%s�����������ݱ��治�ɹ���"),
					lpcstrKey1, lpcstrKey2);
			}
		}
		else
		{
			strFaildReason.Format(_T("����ϵͳ�в�����%s��¼���������ݱ��治�ɹ���"),
				lpcstrKey2);
		}
		delete  pQueryItems;
		pQueryItems = NULL;
	}
	return bRet;
}

