#pragma once
namespace Business
{
	namespace Core
	{
		using QuantityData = std::unordered_map<STDString, double>;
		using ProdIDAndPrice = std::unordered_map< STDString, CString>;
		using UniqueProduct = std::unordered_map< STDString, Database::CFlybyItem*>;

		class CStoreWork : public CCommonWork
		{
		public:
			CStoreWork(CProgressCtrl& progressTotal, CProgressCtrl& progressSub, HWND hParentWnd);
			virtual ~CStoreWork();
		public:
			virtual BOOL ConstructBusinessData(DataPattern::EnumBusinessType enumType, BOOL bBatch = TRUE,
				DataPattern::EnumBusinessType enumSourceType = DataPattern::enumUnknown);	//����ҵ������
			//����ҵ������
			virtual BOOL SaveNew(DataPattern::EnumBusinessType enumType);	
			//�޶�ҵ������
			virtual BOOL SaveModify(DataPattern::EnumBusinessType enumType);
			//ɾ��ҵ������
			virtual BOOL SaveDelete(DataPattern::EnumBusinessType enumType);

		private:
			BOOL SQLStoreNew(CString& strUpdate, CString& strErrorMessage, DataPattern::EnumBusinessType enumType);
			BOOL SQLStoreBackNew(CString& strUpdate, CString& strErrorMessage, DataPattern::EnumBusinessType enumType);
			BOOL SQLStoreModify(PVOID pvData, CString& strUpdates, const QuantityData StoreInit);
			void ReverseCalcuTotal(PVOID pvData, QuantityData& StoreInit, DataPattern::EnumBusinessType enumType);
			void CalcuTotal(PVOID pvData, QuantityData& StoreInit, DataPattern::EnumBusinessType enumType, BOOL bReverse = FALSE);
			BOOL UniformValidate(PVOID pvData, const QuantityData StoreInit, CString &strFaildReason, DataPattern::EnumBusinessType enumType);
		};
	}
}
