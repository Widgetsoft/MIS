// MetaDataView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "MetaDataDoc.h"
#include "LocalDataGridView.h"
#include "MetaDataView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
// CMetaDataView

using namespace BasicInfo;

#define ID_GRID_OPTIONS 0x9000

IMPLEMENT_DYNCREATE(CMetaDataView, CView)

CMetaDataView::CMetaDataView()
	:m_ListCtrl(IDR_POPUP_EDIT)
{
	m_uipMetaTimerID = -1;
}

CMetaDataView::~CMetaDataView()
{
}

BEGIN_MESSAGE_MAP(CMetaDataView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CMetaDataView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_OPTIONS, &CMetaDataView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CMetaDataView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CMetaDataView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CMetaDataView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CMetaDataView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CMetaDataView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CMetaDataView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CMetaDataView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CMetaDataView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CMetaDataView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CMetaDataView::OnEditFind)
	ON_MESSAGE(WM_METADATA_CHANGED, &CMetaDataView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CMetaDataView ��ͼ

void CMetaDataView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CMetaDataView ���

#ifdef _DEBUG
void CMetaDataView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CMetaDataView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif

CMetaDataDoc* CMetaDataView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMetaDataDoc)));
	return (CMetaDataDoc*)m_pDocument;
}

#endif //_DEBUG



void CMetaDataView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetItemOptions(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 1; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}


// CMetaDataView ��Ϣ��������


int CMetaDataView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_OPTIONS);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 1; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 1://ѡ���
		{
			CGridColumnTraitCombo* pComboTrait = new CGridColumnTraitCombo();
			int idCat = 0;
			pComboTrait->AddItem(idCat++, _T("רҵְ��"));
			pComboTrait->AddItem(idCat++, _T("������λ"));
			pComboTrait->AddItem(idCat++, _T("�Ļ��̶�"));
			pComboTrait->AddItem(idCat++, _T("����Ƭ��"));
			pComboTrait->AddItem(idCat++, _T("���㷽ʽ"));
			pComboTrait->AddItem(idCat++, _T("����ȯ����"));

			m_vectCategory.push_back(_T("רҵְ��"));
			m_vectCategory.push_back(_T("������λ"));
			m_vectCategory.push_back(_T("�Ļ��̶�"));
			m_vectCategory.push_back(_T("����Ƭ��"));
			m_vectCategory.push_back(_T("���㷽ʽ"));
			m_vectCategory.push_back(_T("����ȯ����"));

			pTrait = pComboTrait;
		}
		break;
		case 2:
		case 3:
		case 4:
			pTrait = new CGridColumnTraitEdit;
			break;
		default:
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}


	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("����ѡ������"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CMetaDataView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}

void CMetaDataView::OnEditNewitem()
{
	Database::CItemOptions* pItemOpion = new Database::CItemOptions();
	pItemOpion->SetState(Database::NewItem);
	pItemOpion->SetCellText(1, _T("רҵְ��"));
	GetDocument()->m_vector.AddItem(pItemOpion);
	GetDocument()->m_vectNewItems.AddItem(pItemOpion);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 1; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CMetaDataView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 2: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 5, tcsText);
				m_ListCtrl.SetItemText(nRow, 5, tcsText);
			}
		}
		break;
	case 1:	//������������
		if (pDispInfo->item.pszText != NULL)
		{
			auto strFindText = GenerialPattern::CItemData::ParallelFind(m_vectCategory,
				pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strFindText.c_str());
			m_ListCtrl.SetItemText(nRow, nCol, GetDocument()->m_vector.GetCellText(nRow, nCol));
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CMetaDataView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CMetaDataView::OnEditRefresh()
{
	this->LoadData();
}



void CMetaDataView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CMetaDataView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CMetaDataView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CMetaDataView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CMetaDataView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CMetaDataView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CMetaDataView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CMetaDataView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CMetaDataView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipMetaTimerID != UINT(-1))
	{
		KillTimer(m_uipMetaTimerID);
		m_uipMetaTimerID = UINT(-1);
	}
	m_uipMetaTimerID = SetTimer(1, 1001, NULL);
	return 0L;
}

void CMetaDataView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipMetaTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipMetaTimerID != UINT(-1))
			{
				KillTimer(m_uipMetaTimerID);
				m_uipMetaTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
