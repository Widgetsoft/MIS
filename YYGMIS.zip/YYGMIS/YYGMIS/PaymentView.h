#pragma once

namespace Business
{
	// CPaymentView ������ͼ

	class CPaymentView : public CFormView
	{
		DECLARE_DYNCREATE(CPaymentView)

	protected:
		CPaymentView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
		virtual ~CPaymentView();

	public:
		CSaleDoc* GetDocument() const;

	private: //˽�����ݳ�Ա
		CLocalDataGridView m_ListCtrl;

		CComboBox	m_cmbDepartment;
		CComboBox	m_cmbExecuter;

		CDateTimeCtrl	m_dateBusiness;
		CImageList		m_ImageList;
		std::shared_ptr<GenerialPattern::CItemsData> m_spListPayment;

		DataPattern::EnumBusinessType m_enumDetailsType;

		BOOL m_bTitleInitialize;

	private:
		//�ı��ǩ
		void ToggleControls(BOOL bEnableInput = TRUE, BOOL bReloadOptions = FALSE);
		void ReloadPaymentWay();

		void LoadTicketTitle();
		void ReLoadTableTitle();
		void ReloadTableData();

		//����ͳһ�ϼ�
		void ColculateTotalSum();

	public:
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_PAYMENTVIEW };
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		virtual void OnInitialUpdate();
		afx_msg void OnBnClickedPaymentCard();
		afx_msg LRESULT OnPaymentChanged(WPARAM wParam, LPARAM lParam);
		afx_msg void OnExecuteManCloseup();
		afx_msg void OnDepartmentCloseup();
		afx_msg void OnPaymentDateTimeChanged(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnCheckOutClick();
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnUpdateEditSdNewitem(CCmdUI *pCmdUI);
		afx_msg void OnEditSdNewitem();
		afx_msg void OnUpdateEditSdModify(CCmdUI *pCmdUI);
		afx_msg void OnEditSdModify();
		afx_msg void OnUpdateEditSdDelete(CCmdUI *pCmdUI);
		afx_msg void OnEditSdDelete();
		afx_msg void OnUpdateEditSdRefresh(CCmdUI *pCmdUI);
		afx_msg void OnEditSdRefresh();
		afx_msg void OnUpdateEditSdRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditSdRevsel();
		afx_msg void OnUpdateEditSdFind(CCmdUI *pCmdUI);
		afx_msg void OnEditSdFind();
		afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	};
}


#ifndef _DEBUG
inline Business::CSaleDoc* Business::CPaymentView::GetDocument() const
{
	return reinterpret_cast<CSaleDoc*>(m_pDocument);
}
#endif