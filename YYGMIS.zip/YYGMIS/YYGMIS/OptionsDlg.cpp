// OptionsDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "OptionsDlg.h"
#include "OptionsPage.h"

using namespace UI::Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// COptionsDlg

IMPLEMENT_DYNAMIC(COptionsDlg, CMFCPropertySheet)

COptionsDlg::COptionsDlg(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CMFCPropertySheet(pszCaption, pParentWnd, iSelectPage),
	m_pPage11( new COptionsPage())
{
	SetLook(CMFCPropertySheet::PropSheetLook_Tree, 150 /* Tree control width */);
	SetIconsList(IDB_OPTIONSIMAGES, 16 /* Image width */);

	CMFCPropertySheetCategoryInfo* pCat1 = AddTreeCategory(_T("Environment"), 0, 1);

	AddPageToTree(pCat1, m_pPage11, -1, 2);
	//AddPageToTree(pCat1, &m_Page12, -1, 2);

/*	CMFCPropertySheetCategoryInfo* pCat2 = AddTreeCategory(_T("Source Control"), 0, 1);

	AddPageToTree(pCat2, &m_Page21, -1, 2);
	AddPageToTree(pCat2, &m_Page22, -1, 2)*/;

}

COptionsDlg::~COptionsDlg()
{
	delete m_pPage11;
}



BEGIN_MESSAGE_MAP(COptionsDlg, CMFCPropertySheet)
END_MESSAGE_MAP()



// COptionsDlg ��Ϣ��������


