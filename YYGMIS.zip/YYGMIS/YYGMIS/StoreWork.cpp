#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "CommonWork.h"
#include "StoreWork.h"
#include "SystemInfo.h"
#include "WorkAssistant.h"

#include <ppl.h>

using namespace Business;
using namespace Business::Core;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CStoreWork::CStoreWork(CProgressCtrl& progressTotal, CProgressCtrl& progressSub, HWND hParentWnd)
	: CCommonWork(progressTotal, progressSub, hParentWnd)
{
}


CStoreWork::~CStoreWork()
{
}

BOOL CStoreWork::ConstructBusinessData(DataPattern::EnumBusinessType enumType, BOOL bBatch,
	DataPattern::EnumBusinessType enumSourceType)
{
	BOOL bRet = FALSE;

	//�Ϸ�����֤
	if (m_spKeys == nullptr || m_spKeys->size() < 0 )
	{
		return bRet;
	}

	LOCALEDB;
	CString strQuery;

	int nPhaseCount = m_spKeys->size();
	m_progressTotal.SetStep(10);
	m_progressTotal.SetPos(0);
	m_progressTotal.SetRange32(0, nPhaseCount * 10);
	for (int nIncre = 0; nIncre != nPhaseCount; nIncre++)
	{
		//1����������¼
		Database::CStockFlowVector vecStore;
		strQuery.Format(_T("SELECT * FROM tsw_viewStockFlow WHERE �ڲ����� LIKE '%s'"),
			m_spKeys->at(nIncre));
		bRet = pDataBase->GetStockFlow(strQuery, vecStore);
		if (!bRet || vecStore.GetCount() < 1)
		{
			return bRet;
		}


		//2�������굥����
		Database::CStockFlowDetailsVector* pVectDetails = new Database::CStockFlowDetailsVector();
		strQuery.Format(_T("SELECT * FROM tsw_viewStockFlowDetails WHERE ������ LIKE '%s'"),
			m_spKeys->at(nIncre));

		bRet = pDataBase->GetStockFlowDetails(strQuery, *pVectDetails);
		vecStore.GetItem(0)->SetCellText(16, theApp.m_siInfo->m_strUserInnerID);

		Database::CFlybyItem* pDataItemReal = NULL;

		vecStore.GetItem(0)->Clone(&pDataItemReal);
		pDataItemReal->SetState(m_spData->GetInitialState());

		double dblTotalQuantity = { 0 }, dblTotalAmount = { 0 };

		concurrency::parallel_for_each(pVectDetails->begin(), pVectDetails->end(), [&dblTotalQuantity, &dblTotalAmount](const Database::CFlybyItem* pInput) {
			TCHAR* tcsStop = nullptr;
			double dblPrice = { 0 }, dblQuantity = { 0 }, dblAmount = { 0 };
			dblPrice = _tcstod(pInput->GetCellText(4), &tcsStop);
			tcsStop = nullptr;
			dblQuantity = _tcstod(pInput->GetCellText(5), &tcsStop);
			dblAmount = dblPrice * dblQuantity;
			dblTotalQuantity += dblQuantity;
			dblTotalAmount += dblAmount;
		});

		CString strQuantity, strAmount;
		strQuantity.Format(_T(".2f"), dblTotalQuantity);
		strAmount.Format(_T(".2f"), dblTotalAmount);

		pDataItemReal->SetCellText(6, strQuantity);
		pDataItemReal->SetCellText(7, strAmount);

		m_spData->AddDataItem(0, pDataItemReal->GetCellText(0),
			pDataItemReal, pVectDetails, enumType, enumSourceType);

		if (m_spOldData != NULL)
		{
			//2.5������ԭʼ��¼
			Database::CFlybyItem* pDataItemInital = NULL;
			vecStore.GetItem(0)->Clone(&pDataItemInital);
			pDataItemInital->SetCellText(6, strQuantity);
			pDataItemInital->SetCellText(7, strAmount);
			Database::CStockFlowDetailsVector* vectTickDetailsInitial = new Database::CStockFlowDetailsVector();
			pVectDetails->DeepClone(vectTickDetailsInitial);
			m_spOldData->AddDataItem(0, pDataItemInital->GetCellText(0),
				pDataItemInital, vectTickDetailsInitial, enumType, enumSourceType);
		}
		m_progressTotal.StepIt();
	}
	if (nPhaseCount > 0)
	{
		m_spData->GetPage(0)->SetCurrentIndex(0);
	}
	m_progressTotal.SetPos(nPhaseCount * 10);
	return TRUE;
}

BOOL CStoreWork::SaveNew(DataPattern::EnumBusinessType enumType)
{
	QuantityData StoreInit;
	CString strUpdate;
	CString strMessage;
	CString strPromptTitle;
	BOOL bSuccess = TRUE;

	m_progressTotal.SetRange32(10, 50);
	m_progressTotal.SetStep(10);
	m_progressTotal.SetPos(10);
	// 1�� ��ǰ���㣨��ǰ )
	// 2�� ���ɸ������	
	m_progressTotal.StepIt();
	switch (enumType)
	{
	case DataPattern::enumStoreIn:
		strPromptTitle = _T("��ⵥ����ʧ��");
		bSuccess = SQLStoreNew(strUpdate, strMessage, enumType);
		break;
	case DataPattern::enumStoreOut:
		strPromptTitle = _T("���ⵥ����ʧ��");
		bSuccess = SQLStoreBackNew(strUpdate, strMessage, enumType);
		break;
	}
	if (!bSuccess)
	{
		MessageBox(m_hWnd, strMessage, strPromptTitle, MB_OK | MB_ICONEXCLAMATION);
		return bSuccess;
	}
	// 3�� ͳһ���㣨ȷ�ϣ�
	if (bSuccess)
	{
		m_progressTotal.StepIt();
		CalcuTotal(m_spData.get(), StoreInit, enumType);
	}

	// 4�� ͳһ��֤
	m_progressTotal.StepIt();
	if (bSuccess)
	{
		bSuccess = UniformValidate(m_spData.get(), StoreInit, strMessage, enumType);
		if (!bSuccess)
		{
			MessageBox(m_hWnd, strMessage, strPromptTitle, MB_OK | MB_ICONEXCLAMATION);
			return bSuccess;
		}
	}
	// 5�� ͳһ����
	if (bSuccess)
	{
		m_progressTotal.StepIt();
		bSuccess = ExecuteUpdate(strUpdate);
	}

	return bSuccess;
}

BOOL CStoreWork::SaveModify(DataPattern::EnumBusinessType enumType)
{
	QuantityData StoreInit;
	CString strUpdate;
	CString strMessage;
	CString strPromptTitle;
	BOOL bSuccess = TRUE;

	m_progressTotal.SetRange32(10, 50);
	m_progressTotal.SetStep(10);
	// 1�� ��ǰ���㣨��ǰ )
	ReverseCalcuTotal(m_spOldData.get(), StoreInit, enumType);
	m_progressTotal.StepIt();
	// 2�� ���ɸ������	
	switch (enumType)
	{
	case DataPattern::enumStoreIn:
		strPromptTitle = _T("��ⵥ�޸�ʧ��");
		break;
	case DataPattern::enumStoreOut:
		strPromptTitle = _T("���ⵥ�޸�ʧ��");
		break;
	}
	if (bSuccess)
	{
		bSuccess = SQLStoreModify(m_spOldData.get(), strUpdate, StoreInit);
		m_progressTotal.StepIt();
	}
	if (bSuccess)
	{
		//3��ͳһ����
		CalcuTotal(m_spData.get(), StoreInit, enumType);
		m_progressTotal.StepIt();
		//4��ͳһ��֤
		bSuccess = UniformValidate(m_spData.get(), StoreInit, strMessage, enumType);
		m_progressTotal.StepIt();
		if (!bSuccess)
		{
			MessageBox(m_hWnd, strMessage, strPromptTitle, MB_OK | MB_ICONEXCLAMATION);
			return bSuccess;
		}
	}
	//5�����ɸ������
	if (bSuccess)
		switch (enumType)
		{
		case DataPattern::enumStoreIn:
			bSuccess = SQLStoreNew(strUpdate, strMessage, enumType);
			break;
		case DataPattern::enumStoreOut:
			bSuccess = SQLStoreBackNew(strUpdate, strMessage, enumType);
			break;
		}
	//6��ִ�����ո���
	if (bSuccess)
	{
		m_progressTotal.StepIt();
		bSuccess = ExecuteUpdate(strUpdate);
	}

	return bSuccess;
}

BOOL CStoreWork::SaveDelete(DataPattern::EnumBusinessType enumType)
{
	QuantityData StoreInit;
	CString strUpdate;
	CString strMessage;
	CString strPromptTitle;
	BOOL bSuccess = TRUE;

	m_progressTotal.SetRange32(10, 50);
	m_progressTotal.SetStep(10);
	// 1�� ��ǰ���㣨��ǰ )
	ReverseCalcuTotal(m_spOldData.get(), StoreInit, enumType);
	m_progressTotal.StepIt();
	// 2�� ���ɸ������	
	switch (enumType)
	{
	case DataPattern::enumStoreIn:
		strPromptTitle = _T("��ⵥɾ��ʧ��");
		break;
	case DataPattern::enumStoreOut:
		strPromptTitle = _T("���ⵥɾ��ʧ��");
		break;
	}
	if (bSuccess)
	{
		bSuccess = SQLStoreModify(m_spOldData.get(), strUpdate, StoreInit);
		m_progressTotal.StepIt();
	}

	if (bSuccess)
	{
		bSuccess = UniformValidate(m_spData.get(), StoreInit, strMessage, enumType);
		m_progressTotal.StepIt();
		if (!bSuccess)
		{
			MessageBox(m_hWnd, strMessage, strPromptTitle, MB_OK | MB_ICONEXCLAMATION);
			return bSuccess;
		}
	}
	//5��ִ�����ո���
	if (bSuccess)
	{
		m_progressTotal.StepIt();
		bSuccess = ExecuteUpdate(strUpdate);
	}

	return bSuccess;
}

BOOL CStoreWork::SQLStoreNew(CString& strUpdate, CString& strErrorMessage, DataPattern::EnumBusinessType enumType)
{
	BOOL bRet = FALSE;
	int nRows = m_spData->GetPage(0)->GetItemsCount();


	m_progressSub.SetRange32(0, nRows * 10);
	m_progressSub.SetStep(10);
	m_progressSub.SetPos(10);

	CWorkAssistant Assistance;
	UINT uiCurrentNum = Assistance.GetCurrentIndex(enumType, _T("StockCustomID"), _T("tsw_tabStockFlow"));

	for (int i = 0; i != nRows; i++)
	{
		m_progressSub.StepIt();
		COleDateTime dateTime = COleDateTime::GetCurrentTime();
		CString strGroupID = Database::CFlybyItem::GenerateNewID();

		auto pInnerItem = m_spData->GetPage(0)->GetItemByIndex(i)->GetItem();
		auto pInnerDetails = m_spData->GetPage(0)->GetItemByIndex(i)->GetItemDetails();

		//1����������¼
		const size_t szDetails = pInnerDetails->GetCount();
		if (szDetails < 1)
		{
			strErrorMessage.Append(_T("����¼�����ⵥ�굥��Ŀ����Ϊ�㣡"));
			return bRet;
		}

		TCHAR *tcsStop = nullptr;
		double dblTestX = _tcstod(pInnerItem->GetCellText(6), &tcsStop);
		if (dblTestX <= .0)
		{
			strErrorMessage.Append(_T("����¼�����ⵥ���ڲ��Ϸ��ļ�¼������Ϊ�㣩��"));
			return bRet;
		}

		//��ʼ����������
		CString strInnerKey;
		BOOL bChecked = pInnerItem->GetCellText(8) == _T("�����");

		if (pInnerItem->GetCellText(1).CompareNoCase(_T("ϵͳ�Զ�����")) == 0
			|| pInnerItem->GetCellText(1).IsEmpty())
		{
			strInnerKey.Format(_T("%s%s%05d"), CWorkAssistant::GetTickitPrefix(enumType),
				Assistance.GetDateSeg(), uiCurrentNum++);
			pInnerItem->SetCellText(1, strInnerKey);
		}

		strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlow( StockID, StockCustomID, StockDate, StockManID, WSPID, StockDescripion, IsCheckOut, CheckOutDate, CheckoutManID, Memo, IsStockIn, CreateDate, ModifyDate, CreatedUser, ModifierUser, StockSourceID) VALUES ( '%s', '%s', '%s', '%s', '%s', '%s', %s, '%s', '%s', '%s', %s, DATETIME('now','localtime'), '%s', '%s', '%s', '%s' );"),
			pInnerItem->GetCellText(0),
			pInnerItem->GetCellText(1),
			pInnerItem->GetCellText(2),
			pInnerItem->GetCellText(18),
			pInnerItem->GetCellText(20),
			pInnerItem->GetCellText(5),
			bChecked,
			pInnerItem->GetCellText(14),
			pInnerItem->GetCellText(17),
			pInnerItem->GetCellText(10),
			pInnerItem->GetCellText(11) == _T("���"),
			Database::CFlybyItem::FormatDateTime(pInnerItem->GetCellText(13)),
			theApp.m_siInfo->m_strUserInnerID,
			theApp.m_siInfo->m_strUserInnerID,
			pInnerItem->GetCellText(19));
		for (size_t ii = 0; ii != szDetails; ii++)
		{
			strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlowDetails( SDID, Price, Quantity, Memo, ProdID, StockID ) VALUES ('%s', %s, %s, '%s', '%s', '%s');"),
				pInnerDetails->GetCellText(ii, 0),
				pInnerDetails->GetCellText(ii, 4),
				pInnerDetails->GetCellText(ii, 5),
				pInnerDetails->GetCellText(ii, 8),
				pInnerDetails->GetCellText(ii, 9),
				pInnerDetails->GetCellText(ii, 10));
			//���¸ò�Ʒ�Ŀ����
			strUpdate.AppendFormat(_T("INSERT OR IGNORE INTO tsw_tabInventories(InvID, WSPID, ProdID) VALUES('%s', '%s', '%s');"),
				Database::CFlybyItem::GenerateNewID(),
				pInnerItem->GetCellText(20),
				pInnerDetails->GetCellText(ii, 9));
			strUpdate.AppendFormat(_T("UPDATE tsw_tabInventories SET StockQuantity = StockQuantity + %s WHERE WSPID LIKE '%s' AND ProdID LIKE '%s';"),
				pInnerDetails->GetCellText(ii, 5),
				pInnerItem->GetCellText(20),
				pInnerDetails->GetCellText(ii, 9));
		}

	}

	return TRUE;
}

BOOL CStoreWork::SQLStoreBackNew(CString& strUpdate, CString& strErrorMessage, DataPattern::EnumBusinessType enumType)
{
	BOOL bRet = FALSE;
	int nRows = m_spData->GetPage(0)->GetItemsCount();

	m_progressSub.SetRange32(0, nRows * 10);
	m_progressSub.SetStep(10);
	m_progressSub.SetPos(10);

	CWorkAssistant Assistance;
	UINT uiCurrentNum = Assistance.GetCurrentIndex(enumType, _T("StockCustomID"), _T("tsw_tabStockFlow"));

	for (int i = 0; i != nRows; i++)
	{
		m_progressSub.StepIt();
		COleDateTime dateTime = COleDateTime::GetCurrentTime();

		auto pInnerItem = m_spData->GetPage(0)->GetItemByIndex(i)->GetItem();
		auto pInnerDetails = m_spData->GetPage(0)->GetItemByIndex(i)->GetItemDetails();
		//1����������¼
		const size_t szDetails = pInnerDetails->GetCount();
		if (szDetails < 1)
		{
			strErrorMessage.Append(_T("����¼��ĳ��ⵥ�굥��Ŀ����Ϊ�㣡"));
			return bRet;
		}

		TCHAR *tcsStop = nullptr;
		double dblTestX = _tcstod(pInnerItem->GetCellText(6), &tcsStop);
		if (dblTestX <= .0)
		{
			strErrorMessage.Append(_T("����¼��ĳ��ⵥ���ڲ��Ϸ��ļ�¼������Ϊ�㣩��"));
			return bRet;
		}

		//��ʼ����������
		CString strInnerKey;
		BOOL bChecked = pInnerItem->GetCellText(8) == _T("�����");
		if (pInnerItem->GetCellText(1).CompareNoCase(_T("ϵͳ�Զ�����")) == 0
			|| pInnerItem->GetCellText(1).IsEmpty())
		{
			strInnerKey.Format(_T("%s%s%05d"), CWorkAssistant::GetTickitPrefix(enumType), Assistance.GetDateSeg(), uiCurrentNum++);
			pInnerItem->SetCellText(1, strInnerKey);
		}

		strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlow( StockID, StockCustomID, StockDate, StockManID, WSPID, StockDescripion, IsCheckOut, CheckOutDate, CheckoutManID, Memo, IsStockIn, CreateDate, ModifyDate, CreatedUser, ModifierUser, StockSourceID) VALUES ( '%s', '%s', '%s', '%s', '%s', '%s', %s, '%s', '%s', '%s', %s, DATETIME('now','localtime'), '%s', '%s', '%s', '%s' );"),
			pInnerItem->GetCellText(0),
			pInnerItem->GetCellText(1),
			pInnerItem->GetCellText(2),
			pInnerItem->GetCellText(18),
			pInnerItem->GetCellText(20),
			pInnerItem->GetCellText(5),
			bChecked,
			pInnerItem->GetCellText(14),
			pInnerItem->GetCellText(17),
			pInnerItem->GetCellText(10),
			pInnerItem->GetCellText(11) == _T("���"),
			Database::CFlybyItem::FormatDateTime(pInnerItem->GetCellText(13)),
			theApp.m_siInfo->m_strUserInnerID,
			theApp.m_siInfo->m_strUserInnerID,
			pInnerItem->GetCellText(19));
		for (size_t ii = 0; ii != szDetails; ii++)
		{
			strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlowDetails( SDID, Price, Quantity, Memo, ProdID, StockID ) VALUES ('%s', %s, %s, '%s', '%s', '%s');"),
				pInnerDetails->GetCellText(ii, 0),
				pInnerDetails->GetCellText(ii, 4),
				pInnerDetails->GetCellText(ii, 5),
				pInnerDetails->GetCellText(ii, 8),
				pInnerDetails->GetCellText(ii, 9),
				pInnerDetails->GetCellText(ii, 10));
			//���¸ò�Ʒ�Ŀ����
			strUpdate.AppendFormat(_T("INSERT OR IGNORE INTO tsw_tabInventories(InvID, WSPID, ProdID) VALUES('%s', '%s', '%s');"),
				Database::CFlybyItem::GenerateNewID(),
				pInnerItem->GetCellText(20),
				pInnerDetails->GetCellText(ii, 9));
			strUpdate.AppendFormat(_T("UPDATE tsw_tabInventories SET StockQuantity = StockQuantity - %s WHERE WSPID LIKE '%s' AND ProdID LIKE '%s';"),
				pInnerDetails->GetCellText(ii, 5),
				pInnerItem->GetCellText(20),
				pInnerDetails->GetCellText(ii, 9));
		}

	}
	return TRUE;
}

BOOL CStoreWork::SQLStoreModify(PVOID pvData, CString& strUpdates, const QuantityData StoreInit)
{
	DataPattern::CTickitsData* pData = reinterpret_cast<DataPattern::CTickitsData*>(pvData);
	if (pData == NULL)
	{
		return FALSE;
	}
	int nRows = pData->GetPage(0)->GetItemsCount();
	m_progressSub.SetRange32(0, nRows * 10);
	m_progressSub.SetStep(10);
	m_progressSub.SetPos(0);
	for (int i = 0; i != nRows; i++)
	{
		auto pItem0 = pData->GetPage(0)->GetItemByIndex(i);
		if (!(pItem0->GetItem()->GetCellText(1).IsEmpty()))
		{
			strUpdates.AppendFormat(_T("DELETE FROM tsw_tabStockFlowDetails WHERE StockID LIKE '%s';DELETE FROM tsw_tabStockFlow WHERE StockID LIKE '%s';"),
				pItem0->GetItem()->GetCellText(0), pItem0->GetItem()->GetCellText(0));
		}
		m_progressSub.StepIt();
	}

	//���¿���������
	for (auto pIter = StoreInit.begin(); pIter != StoreInit.end(); pIter++)
	{
		const auto val = *pIter;
		//�����ӿ�� : ��ʽ���ֿ�@��Ʒ����
		STDString strValue(val.first);
		Concurrency::concurrent_vector<STDString> vectWHPROD;
		Helper::CToolkits::Split(strValue.c_str(), _T("@"), &vectWHPROD);
		if (vectWHPROD.size() > 0)
		{
			strUpdates.AppendFormat(_T("UPDATE tsw_tabInventories SET StockQuantity = StockQuantity + %.2f WHERE WSPID LIKE '%s' AND ProdID LIKE '%s';"),
				val.second, vectWHPROD.at(0).c_str(), vectWHPROD.at(1).c_str());
		}
	}
	m_progressSub.SetPos(nRows * 10);
	return TRUE;
}

void CStoreWork::ReverseCalcuTotal(PVOID pvData, QuantityData& StoreInit, DataPattern::EnumBusinessType enumType)
{
	CalcuTotal(pvData, StoreInit, enumType, TRUE);
}

void CStoreWork::CalcuTotal(PVOID pvData, QuantityData& StoreInit, DataPattern::EnumBusinessType enumType, BOOL bReverse)
{
	DataPattern::CTickitsData* pData = reinterpret_cast<DataPattern::CTickitsData*>(pvData);
	if (pData == nullptr)
	{
		return;
	}

	UINT uiCount = pData->GetPage(0)->GetItemsCount();
	for (UINT ui = 0; ui != uiCount; ui++)
	{
		auto pItem = pData->GetPage(0)->GetItemByIndex(ui)->GetItem();
		auto pItemData = pData->GetPage(0)->GetItemByIndex(ui)->GetItemDetails();

		for (auto iter : *pItemData)
		{
			STDString strKey(pItem->GetCellText(20));
			strKey.append(_T("@"));
			strKey.append(iter->GetCellText(9));
			QuantityData::iterator itFind =
				StoreInit.find(strKey);
			double fCurAmount = { 0 };
			TCHAR* tcsStop = nullptr;
			if (enumType == DataPattern::enumStoreIn)
			{
				fCurAmount = _tcstod(iter->GetCellText(5), &tcsStop);  //��ȡ����

			}
			else
			{
				fCurAmount = -_tcstod(iter->GetCellText(5), &tcsStop);
			}
			if (bReverse) //�������
			{
				fCurAmount = -fCurAmount;
			}
			if (itFind == StoreInit.end())
			{
				StoreInit.insert(QuantityData::value_type(strKey, fCurAmount));
			}
			else
			{
				itFind->second += fCurAmount;
			}
		}
	}
}

BOOL CStoreWork::UniformValidate(PVOID pvData, const QuantityData StoreInit, CString &strFaildReason, DataPattern::EnumBusinessType enumType)
{
	BOOL bRet = FALSE;
	DataPattern::CTickitsData* pData = reinterpret_cast<DataPattern::CTickitsData*>(pvData);
	if (pData == nullptr)
	{
		return bRet;
	}
	LOCALEDB;
	if (pDataBase == NULL || !pDataBase->m_bDBOpened)
	{
		return bRet;
	}

	CString strTemp;
	switch (enumType)
	{
	case DataPattern::enumStoreIn:	//�����֤����װ�����֤����ʵû�б�Ҫ��
		for (auto iter = StoreInit.begin(); iter != StoreInit.end(); iter++)
		{
			const auto constIT = *iter;
			double dblTest = constIT.second;
			//�ⷿ@Ʒ��
			Concurrency::concurrent_vector<STDString> vectItems;
			Helper::CToolkits::Split(constIT.first.c_str(), _T("@"), &vectItems);
			if (vectItems.size() > 0)
			{
				strTemp.Format(_T("SELECT COUNT(*) FROM tsw_tabInventories WHERE WSPID LIKE '%s' AND ProdID LIKE '%s' AND (StockQuantity + %f >= 0)"),
					vectItems.at(0).c_str(), vectItems.at(1).c_str(), dblTest);
				if (!QueryStockStatus(strTemp, pDataBase, strFaildReason))
				{
					//�����ѹΣ��������ڼ�¼����Ϊ��
					strTemp.Format(_T("SELECT COUNT(*) FROM tsw_tabInventories WHERE WSPID LIKE '%s' AND ProdID LIKE '%s'"),
						vectItems.at(0).c_str(), vectItems.at(1).c_str());
					if (!QueryStockStatus(strTemp, pDataBase, strFaildReason))
					{
						bRet = TRUE;
					}
					else
					{
						bRet = FALSE;
						break;
					}
				}
				else
				{
					bRet = TRUE;
				}
			}
		}
		break;
	case DataPattern::enumStoreOut:	//������֤
		for (auto iter = StoreInit.begin(); iter != StoreInit.end(); iter++)
		{
			const auto constIT = *iter;
			double dblTest =abs(constIT.second);
			//�ⷿ@Ʒ��
			Concurrency::concurrent_vector<STDString> vectItems;
			Helper::CToolkits::Split(constIT.first.c_str(), _T("@"), &vectItems);
			if (vectItems.size() > 0)
			{
				strTemp.Format(_T("SELECT COUNT(*) FROM tsw_tabInventories WHERE WSPID LIKE '%s' AND ProdID LIKE '%s' AND (StockQuantity - %f >= 0)"),
					vectItems.at(0).c_str(), vectItems.at(1).c_str(), dblTest);
				if (!QueryStockStatus(strTemp, pDataBase, strFaildReason))
				{
					//��ʱ����
					bRet = FALSE;
					break;
				}
				else
				{
					bRet = TRUE;
				}
			}
		}
		break;
	}
	return bRet;
}