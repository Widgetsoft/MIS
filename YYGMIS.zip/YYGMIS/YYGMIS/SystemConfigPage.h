#pragma once

namespace UI
{
	// CSystemConfigPage �Ի���

	class CSystemConfigPage : public CMFCPropertyPage
	{
		DECLARE_DYNAMIC(CSystemConfigPage)

	public:
		CSystemConfigPage();
		virtual ~CSystemConfigPage();

		// �Ի�������
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_PROP_SYSTEM };
#endif

	private:
		Database::CYYGMISSystemInfoVector* m_pParentItem;

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
		afx_msg void OnRegisterKeyUpdate();
		afx_msg void OnProdRateUpdate();
		afx_msg void OnSvcRateUpdate();
		afx_msg void OnDtnStartDatetimechange(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnBnClickedInitialChk();

	public:
		virtual BOOL OnInitDialog();
		afx_msg void OnCbnSelchangeCmbLoadintv();
	};

	class CSystemConfigSheet : public CMFCPropertySheet
	{
		DECLARE_DYNAMIC(CSystemConfigSheet)
	public:
		CSystemConfigSheet(CWnd* pWndParent, UINT nSelectedPage = 0);
		virtual ~CSystemConfigSheet();

		DECLARE_MESSAGE_MAP()
	public:
		virtual BOOL OnInitDialog();

	public:
		Database::CYYGMISSystemInfoVector* m_pVector;

	protected:
		virtual void OnDrawPageHeader(CDC* pDC, int nPage, CRect rectHeader);

		CMFCToolBarImages m_Icons;
		CMFCControlRenderer m_Pat[4];
		virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	};
}
