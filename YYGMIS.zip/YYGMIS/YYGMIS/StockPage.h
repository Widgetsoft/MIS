#pragma once

namespace Business
{
	// CStockPage �Ի���

	class CStockPage : public CMFCPropertyPage
	{
		DECLARE_DYNAMIC(CStockPage)

	public:
		CStockPage();
		virtual ~CStockPage();

		// �Ի�������
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_PROP_STOCK };
#endif
	private:
		CLocalDataGridView m_ListCtrl;
		std::shared_ptr<DataPattern::CTickitsData> m_spData;
		GenerialPattern::CItemsData m_mapProd;

		CComboBox	m_cmbWarehouse;
		CComboBox	m_cmbExecuter;
		CDateTimeCtrl	m_dateStore;

	protected:
		void LoadProductCat();
		void CreateStoreRecord();

		void LoadTicketDetails();

		void LoadData();

		void ReloadDetails();
		void ColculateSum(const UINT uiRow);
		void ColculateTotalSum();

	private:
		DataPattern::EnumBusinessType m_enumTickType;
		DataPattern::EnumBusinessType m_enumSourceTickType;

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		virtual BOOL OnInitDialog();
		afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

		afx_msg void OnDescriptionChanged();
		afx_msg void OnMemoChanged();
		afx_msg void OnWarehouseEditUpdate();
		afx_msg void OnWarehouseCloseup();
		afx_msg void OnExecuteManEditUpdate();
		afx_msg void OnExecuteManCloseup();
		afx_msg void OnStoreDateTimeChanged(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnCheckOutClick();
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnUpdateEditNewitem(CCmdUI *pCmdUI);
		afx_msg void OnEditNewitem();
		afx_msg void OnUpdateEditModify(CCmdUI *pCmdUI);
		afx_msg void OnEditModify();
		afx_msg void OnUpdateEditDelete(CCmdUI *pCmdUI);
		afx_msg void OnEditDelete();
		afx_msg void OnUpdateEditRefresh(CCmdUI *pCmdUI);
		afx_msg void OnEditRefresh();
		afx_msg void OnUpdateEditRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditRevsel();
		afx_msg void OnUpdateEditFind(CCmdUI *pCmdUI);
		afx_msg void OnEditFind();
		virtual BOOL PreTranslateMessage(MSG* pMsg);
	};
}
