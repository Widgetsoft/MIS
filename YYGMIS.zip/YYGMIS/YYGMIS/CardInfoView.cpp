// CardInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "CardInfoDoc.h"
#include "LocalDataGridView.h"
#include "CardInfoView.h"
#include "SystemInfo.h"

using namespace BasicInfo;
#define ID_GRID_CARDINFO 0x9008

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CCardInfoView

IMPLEMENT_DYNCREATE(CCardInfoView, CView)

CCardInfoView::CCardInfoView()
	:m_ListCtrl( IDR_POPUP_EDIT ),
	m_spCustDatas( new GenerialPattern::CItemsData()),
	m_spCVIPTDatas(new GenerialPattern::CItemsData())
{
	m_uipCustInfoTimerID = -1;
	m_uipCVIPTTimerID = -1;
	m_uipCardInfoTimerID = -1;
}

CCardInfoView::~CCardInfoView()
{
}

BEGIN_MESSAGE_MAP(CCardInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CCardInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_CARDINFO, &CCardInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CCardInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CCardInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CCardInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CCardInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CCardInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CCardInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CCardInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CCardInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CCardInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CCardInfoView::OnEditFind)
	ON_MESSAGE( WM_CVIPTINFO_CHANGED, &CCardInfoView::OnCVIPTChanged)
	ON_MESSAGE(WM_CUSTINFO_CHANGED, &CCardInfoView::OnCustChanged)
	ON_MESSAGE(WM_CARDTINFO_CHANGED, &CCardInfoView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CCardInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetCardInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 5)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

void CCardInfoView::LoadCVIPTypes()
{
	m_spCVIPTDatas->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(4));

	ASSERT(pComboTrait != NULL);
	pComboTrait->ClearFixedItems();


	LOCALEDB;
	GenerialPattern::CItemsData* pTempTable = nullptr;

	if (pDataBase != NULL &&  pDataBase->NormalGetItemsData(_T("SELECT CTID, CTName || '(' || CTCustomCode || ')' ����, CTMemo FROM tsw_tabCardVIPTypes;"), &pTempTable))
	{
		int i = 0;
		for each (auto item in *pTempTable)
		{
			pComboTrait->AddItem(i, item.second->at(1).c_str());
			auto pData1 = new GenerialPattern::CItemData();
			pData1->AddRange(item.second->at(0).c_str(),
				item.second->at(1).c_str(),
				item.second->at(2).c_str(),
				NULL);
			m_spCVIPTDatas->AddItemData(i, pData1);
			i++;
		}
		delete pTempTable;
	}

	const size_t itemCount = GetDocument()->m_vector.GetCount();
	for (int j = 0; j != itemCount; j++)
	{
		m_ListCtrl.SetItemText(j, 4, GetDocument()->m_vector.GetCellText(j, 4));
	}

	m_ListCtrl.RedrawItems(0, (int)(itemCount - 1));
}

void CCardInfoView::LoadCustomerInfoes()
{
	m_spCustDatas->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(3));

	ASSERT(pComboTrait != NULL);
	pComboTrait->ClearFixedItems();


	LOCALEDB;
	GenerialPattern::CItemsData* pTempTable = nullptr;

	if (pDataBase != NULL &&  pDataBase->NormalGetItemsData(_T("SELECT custID, CustomerName || '(' || custCustomID || ')' CustomerName, CustomerPN, CustomerPrefer, CustomerMemo, ContactAddress, JM FROM tsw_tabCustomerInfo;"), &pTempTable))
	{
		int i = 0;
		for each (auto item in *pTempTable)
		{
			pComboTrait->AddItem(i, item.second->at(1).c_str());
			auto pData1 = new GenerialPattern::CItemData();
			pData1->AddRange(item.second->at(0).c_str(),
				item.second->at(1).c_str(),
				item.second->at(2).c_str(),
				item.second->at(3).c_str(),
				item.second->at(4).c_str(),
				item.second->at(5).c_str(),
				item.second->at(6).c_str(),
				NULL);
			m_spCustDatas->AddItemData(i, pData1);
			i++;
		}
		delete pTempTable;
	}

	const size_t itemCount = GetDocument()->m_vector.GetCount();
	for (int j = 0; j != itemCount; j++)
	{
		m_ListCtrl.SetItemText(j, 3, GetDocument()->m_vector.GetCellText(j, 3));
	}

	m_ListCtrl.RedrawItems(0, (int)(itemCount - 1));
}


// CCardInfoView ��ͼ

void CCardInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CCardInfoView ���

#ifdef _DEBUG
void CCardInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCardInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CCardInfoDoc* CCardInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCardInfoDoc)));
	return reinterpret_cast<CCardInfoDoc*>(m_pDocument);
}
#endif //_DEBUG


// CCardInfoView ��Ϣ��������


int CCardInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_CARDINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 3:
		case 4:
			pTrait = new CGridColumnTraitCombo();
			break;
		case 1:
		case 2:
		case 8:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 5:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("����ʹ��"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	LoadData();
	LoadCVIPTypes();
	LoadCustomerInfoes();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��Ա����Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CCardInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CCardInfoView::OnEditNewitem()
{
	if (m_spCustDatas->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κοͻ���Ϣ���޷�����ִ�иò�����"), _T("������Ա����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_spCVIPTDatas->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κλ�Ա��������Ϣ���޷�����ִ�иò�����"), _T("������Ա����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	Database::CCardInfo* pItem = new Database::CCardInfo();
	pItem->SetState(Database::NewItem);

	//1������ѡ��Ĭ��ֵ
	auto pOptionItem = m_spCustDatas->GetItemData(0);
	pItem->SetCellText(13, pOptionItem->at(0).c_str());
	pItem->SetCellText(3, pOptionItem->at(1).c_str());

	pOptionItem = m_spCVIPTDatas->GetItemData(0);
	pItem->SetCellText(12, pOptionItem->at(0).c_str());
	pItem->SetCellText(4, pOptionItem->at(1).c_str());

	pItem->SetCellText(5, _T("1"));

	//���õ�ǰ��¼�û�
	pItem->SetCellText(11, theApp.m_siInfo->m_strUserInnerID);

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 5)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CCardInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 6:
	case 7:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.3f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CCardInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCardInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CCardInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CCardInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCardInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CCardInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCardInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CCardInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CCardInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CCardInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CCardInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipCardInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipCardInfoTimerID);
		m_uipCardInfoTimerID = UINT(-1);
	}
	m_uipCardInfoTimerID = SetTimer(22, 1022, NULL);
	return 0L;
}

LRESULT CCardInfoView::OnCustChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipCustInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipCustInfoTimerID);
		m_uipCustInfoTimerID = UINT(-1);
	}
	m_uipCustInfoTimerID = SetTimer(23, 1023, NULL);
	return 0L;
}

LRESULT CCardInfoView::OnCVIPTChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipCVIPTTimerID != UINT(-1))
	{
		KillTimer(m_uipCVIPTTimerID);
		m_uipCVIPTTimerID = UINT(-1);
	}
	m_uipCVIPTTimerID = SetTimer(24, 1024, NULL);
	return 0L;
}



void CCardInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipCVIPTTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipCVIPTTimerID != UINT(-1))
			{
				KillTimer(m_uipCVIPTTimerID);
				m_uipCVIPTTimerID = UINT(-1);
			}
			LoadCVIPTypes();
			LoadData(); //���¼��������б�
		}
	}
	else if (m_uipCustInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipCustInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipCustInfoTimerID);
				m_uipCustInfoTimerID = UINT(-1);
			}
			LoadCustomerInfoes();
			LoadData(); //���¼��������б�
		}
	}
	else if (m_uipCardInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipCardInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipCardInfoTimerID);
				m_uipCardInfoTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}
	CView::OnTimer(nIDEvent);
}
