#pragma once
#include "TransparentLabel.h"
namespace Business
{
	// CSaleServiceSaveDlg �Ի���

	class CSaleServiceSaveDlg : public CDialogEx
	{
		friend class CSaleServiceSaveThread;

		DECLARE_DYNAMIC(CSaleServiceSaveDlg)

	public:
		CSaleServiceSaveDlg(std::shared_ptr<DataPattern::CTickitsData>, concurrency::concurrent_vector<std::shared_ptr<DataPattern::SCTicketIDGroupPure>>,
			CString&, CWnd* pParent = NULL);   // ��׼���캯��
		virtual ~CSaleServiceSaveDlg();

		// �Ի�������
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_SALESERVICE_SAVE_DLG };
#endif

	private:
		std::shared_ptr<DataPattern::CTickitsData> m_spDataItems;
		concurrency::concurrent_vector<std::shared_ptr<DataPattern::SCTicketIDGroupPure>> m_vectEntity;
		CString& m_strFinalResult;
		UI::Control::CTransparentLabel m_label1;
		CMutex m_mutex;					//ͬ����

		CProgressCtrl m_progressTotal;
		CProgressCtrl m_progressSub;

		CSaleServiceSaveThread* m_pWorkThread;

		BOOL m_bOkExit;

	private:
		void StartUpWorkThread();

	public:
		BOOL	 m_bOK;


	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		virtual BOOL OnInitDialog();
		afx_msg BOOL OnEraseBkgnd(CDC* pDC);
		virtual INT_PTR DoModal();
		afx_msg void OnClose();
	};
}