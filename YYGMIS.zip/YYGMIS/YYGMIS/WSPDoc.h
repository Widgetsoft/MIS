#pragma once

namespace BasicInfo
{
	// CWSPDoc �ĵ�

	class CWSPDoc : public CDocument
	{
		DECLARE_DYNCREATE(CWSPDoc)

	public:
		CWSPDoc();
		virtual ~CWSPDoc();

	public:
		Database::CWareHouseSalePointVector m_vector;
		Database::CWareHouseSalePointVector m_vectNewItems;
		Database::CWareHouseSalePointVector m_vectModItems;
		Database::CWareHouseSalePointVector m_vectDelItems;

	public:

#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}
