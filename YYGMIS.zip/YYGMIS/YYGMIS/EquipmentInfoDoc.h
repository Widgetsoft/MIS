#pragma once

namespace BasicInfo
{
	// CEquipmentInfoDoc �ĵ�

	class CEquipmentInfoDoc : public CDocument
	{
		DECLARE_DYNCREATE(CEquipmentInfoDoc)

	public:
		CEquipmentInfoDoc();
		virtual ~CEquipmentInfoDoc();

	public:
		Database::CEquipmentInfoVector m_vector;
		Database::CEquipmentInfoVector m_vectNewItems;
		Database::CEquipmentInfoVector m_vectModItems;
		Database::CEquipmentInfoVector m_vectDelItems;

	public:
#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}