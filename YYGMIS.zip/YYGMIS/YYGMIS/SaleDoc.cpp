// SaleDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "SaleServiceWork.h"
#include "SaleFrame.h"
#include "SaleDoc.h"
//#include "SaleBatchSaveWorker.h"
#include "SaleServiceSaveDlg.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSaleDoc

IMPLEMENT_DYNCREATE(CSaleDoc, CDocument)

CSaleDoc::CSaleDoc()
{
}

BOOL CSaleDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}

CSaleDoc::~CSaleDoc()
{
}

BOOL CSaleDoc::ModifiedItemEntityEntry(std::shared_ptr<DataPattern::SCTicketIDGroupPure> spModItem) const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	//�����Ƿ������ͬ����Ŀ 
	BOOL bExistsEntity = FALSE;
	concurrency::structured_task_group tg;
	auto& vectorObject = pCurrentParent->m_pWorker->m_vectChangedItemBatch;
	tg.run_and_wait([spModItem, &vectorObject, &bExistsEntity, &tg]() {
		concurrency::parallel_for_each(vectorObject.begin(),
			vectorObject.end(), [spModItem, &vectorObject, &bExistsEntity, &tg](auto& pEntity) {
			if (_tcscmp(pEntity->MainID, spModItem->MainID) == 0)
			{
				bExistsEntity = TRUE;
				pEntity->enumBusinessType = spModItem->enumBusinessType;
				pEntity->CurrentState = spModItem->CurrentState;
				_tcscpy_s(pEntity->MainID, _countof(pEntity->MainID), spModItem->MainID);
				_tcscpy_s(pEntity->PaymentID, _countof(pEntity->PaymentID), spModItem->PaymentID);
				_tcscpy_s(pEntity->StockOutID, _countof(pEntity->StockOutID), spModItem->StockOutID);
				//pEntity->ModifyTime = spModItem->ModifyTime; //���޸ı��ʱ��
				tg.cancel();
			}
		});
	});

	return bExistsEntity;
}


BEGIN_MESSAGE_MAP(CSaleDoc, CDocument)
	ON_COMMAND(ID_SALE_NEW, &CSaleDoc::OnSaleNew)
	ON_UPDATE_COMMAND_UI(ID_SALE_MODIFY, &CSaleDoc::OnUpdateSaleModify)
	ON_COMMAND(ID_SALE_MODIFY, &CSaleDoc::OnSaleModify)
	ON_UPDATE_COMMAND_UI(ID_SALE_DELETE, &CSaleDoc::OnUpdateSaleDelete)
	ON_COMMAND(ID_SALE_DELETE, &CSaleDoc::OnSaleDelete)
	ON_UPDATE_COMMAND_UI(ID_SALE_SAVE, &CSaleDoc::OnUpdateSaleSave)
	ON_COMMAND(ID_SALE_SAVE, &CSaleDoc::OnSaleSave)
END_MESSAGE_MAP()


// CSaleDoc ���

#ifdef _DEBUG
void CSaleDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CSaleDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CSaleDoc ���л�

void CSaleDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif

void CSaleDoc::LoadAllDataSet(BOOL bSendLoadMsg, BOOL bCreateDate, DataPattern::EnumBusinessType enumRequireBus,
	LPCTSTR lpcszDateStart, LPCTSTR lpcszDateEnd) const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;
	pDateSet->SetBusinessType(enumRequireBus); //�л���������
	pDateSet->InitializeDataSet(bCreateDate, enumRequireBus, lpcszDateStart, lpcszDateEnd);
	pDateSet->m_vectChangedItemBatch.clear();
	if (pDateSet->m_spDataSet->IsExistsPage(0))
	{
		//�л����ۡ�����
		pDateSet->m_spDataSet->GetPage(0)->Last();
		auto strRefID = pDateSet->m_spDataSet->GetPage(0)->GetCurrentItemKey();
		if (pDateSet->m_spDataSet->IsExistsPage(1))
		{
			//�л���ǰ���
			pDateSet->m_spDataSet->GetPage(1)->CurrentRecordBySourceID(strRefID);
		}
		if (enumRequireBus == DataPattern::enumSalesTikits)
		{
			if (pDateSet->m_spDataSet->IsExistsPage(2))
			{
				//�л���ǰ�ⷿ
				pDateSet->m_spDataSet->GetPage(2)->CurrentRecordBySourceID(strRefID);
			}
		}
	}
	if (bSendLoadMsg)
	{
		//����֪ͨ
		Database::DataState enumDataState = Database::Initial;
		if (pDateSet->m_spDataSet->IsExistsPage(0) &&
			!(pDateSet->m_spDataSet->GetPage(0)->IsCurrentTickitsItemNULL()))
		{
			enumDataState = pDateSet->m_spDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
		}
		SendSynchronizationMessage(nullptr, pDateSet->GetBusinessType(),
			enumDataState, Business::DataPattern::enumAllControl, nullptr, 0, nullptr);
	}
}

std::tuple<double, double> CSaleDoc::FindOutDiscount() const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;
	return pDateSet->FindOutDiscount();
}

std::tuple<double, double, double> CSaleDoc::FindOutScoreAndCommission() const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;
	return pDateSet->FindOutScoreAndCommission();
}

void CSaleDoc::AutoCompletePayment() const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;
	pDateSet->AutoCompletePayment();
}

BOOL CSaleDoc::CreateNewTicketItem(LPCTSTR lpcszInitialID, DataPattern::EnumBusinessType enumBusinessType)
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;

	return pDateSet->CreateNewTicketItem(lpcszInitialID, enumBusinessType);
}

BOOL CSaleDoc::SendSynchronizationMessage(const CWnd* pWndLaunchSource, DataPattern::EnumBusinessType enumBusinessType,
	Database::DataState enumActionType, DataPattern::EnumObjectType ChangeObject, LPCTSTR lpcszObjectIDs,
	size_t szExtraSize, const PVOID pDataExtra) const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;
	return pDateSet->SendSynchronizationMessage(pWndLaunchSource,
		enumBusinessType, enumActionType, ChangeObject, lpcszObjectIDs, szExtraSize, pDataExtra);
}

BOOL CSaleDoc::ReloadCurrentItem(BOOL bDetailsOnly)
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDateSet = pCurrentParent->m_pWorker;
	return pDateSet->ReloadCurrentItem(bDetailsOnly);
}

// CSaleDoc ����

const std::shared_ptr<DataPattern::CTickitsData>& CSaleDoc::GetDataset() const
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	return pCurrentParent->m_pWorker->m_spDataSet;
}

BOOL CSaleDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;	

	// TODO:  �ڴ�������ר�õĴ�������
	return TRUE;
}



void CSaleDoc::OnSaleNew()
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pWorker = pCurrentParent->m_pWorker;

	auto bCreateSucc = pWorker->CreateNewTicketItem(nullptr, pWorker->GetBusinessType());
	auto pDataSet = pWorker->m_spDataSet;
	if (bCreateSucc)
	{
		//�Ǽ�����������
		auto pItemMainItem = pWorker->m_spDataSet->GetPage(0)->GetCurrentTickitsItem();
		if (pDataSet->GetPage(1)->CurrentRecordBySourceID((LPCTSTR)(pItemMainItem->GetItem()->GetCellText(0))))
		{
			std::shared_ptr<DataPattern::SCTicketIDGroupPure> spNewItem(new DataPattern::SCTicketIDGroupPure());

			spNewItem->enumBusinessType = pItemMainItem->GetTickitsType();
			spNewItem->CurrentState = Database::NewItem; //�޸�Ϊ������־
			auto pPaymentItem = pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
			_tcscpy_s(spNewItem->StockOutID, _countof(spNewItem->StockOutID), _T(""));
			if (pItemMainItem->GetTickitsType() == DataPattern::enumSalesTikits)
			{
				if (pDataSet->GetPage(2)->CurrentRecordBySourceID((LPCTSTR)(pItemMainItem->GetItem()->GetCellText(0))))
				{
					auto pStockItem = pDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItem();
					_tcscpy_s(spNewItem->StockOutID, _countof(spNewItem->StockOutID), pStockItem->GetCellText(0));
				}
			}
			_tcscpy_s(spNewItem->MainID, _countof(spNewItem->MainID), pItemMainItem->GetItem()->GetCellText(0));
			_tcscpy_s(spNewItem->PaymentID, _countof(spNewItem->PaymentID), pPaymentItem->GetCellText(0));
			spNewItem->ModifyTime = COleDateTime::GetCurrentTime(); //��������ʱ��

			//��ʼ���������б�
			auto bExistsEntity = ModifiedItemEntityEntry(spNewItem);

			if (!bExistsEntity)
			{
				pCurrentParent->m_pWorker->m_vectChangedItemBatch.push_back(spNewItem);
			}
		}

		//�Զ�����Ӧ����
		pWorker->AutoCompletePayment();

		//����֪ͨ
		SendSynchronizationMessage(nullptr, pWorker->GetBusinessType(), Database::NewItem,
			Business::DataPattern::enumAllControl, nullptr, 0, nullptr);
	}
}


void CSaleDoc::OnUpdateSaleModify(CCmdUI *pCmdUI)
{
	auto pDataSet = GetDataset();
	pCmdUI->Enable(FALSE);
	//δ��˲������޸�
	if (pDataSet->IsExistsPage(0))
	{
		if (!pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
		{
			auto pItemMainItem = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
			if (pItemMainItem->GetState() == Database::Initial)
			{
				if (pItemMainItem->GetCellText(6).Compare(_T("�����")) != 0)
				{
					pCmdUI->Enable(TRUE);
				}
			}
		}
	}
}

void CSaleDoc::OnSaleModify()
{
	
	auto pDataSet = GetDataset();
	auto pItemMainItem = pDataSet->GetPage(0)->GetCurrentTickitsItem();

	if (pDataSet->GetPage(1)->CurrentRecordBySourceID((LPCTSTR)(pItemMainItem->GetItem()->GetCellText(0))))
	{
		CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());

		std::shared_ptr<DataPattern::SCTicketIDGroupPure> spModItem(new DataPattern::SCTicketIDGroupPure());
		spModItem->enumBusinessType = pItemMainItem->GetTickitsType();
		spModItem->CurrentState = Database::Modified; //�޸�Ϊ�޸ı�־
		pItemMainItem->GetItem()->SetState(Database::Modified);
		auto pPaymentItem = pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
		pPaymentItem->SetState(Database::Modified);
		_tcscpy_s(spModItem->StockOutID, _countof(spModItem->StockOutID), _T(""));
		if (pItemMainItem->GetTickitsType() == DataPattern::enumSalesTikits)
		{
			if (pDataSet->GetPage(2)->CurrentRecordBySourceID((LPCTSTR)(pItemMainItem->GetItem()->GetCellText(0))))
			{
				auto pStockItem = pDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItem();
				pStockItem->SetState(Database::Modified);
				_tcscpy_s(spModItem->StockOutID, _countof(spModItem->StockOutID), pStockItem->GetCellText(0));
			}
		}
		_tcscpy_s(spModItem->MainID, _countof(spModItem->MainID), pItemMainItem->GetItem()->GetCellText(0));
		_tcscpy_s(spModItem->PaymentID, _countof(spModItem->PaymentID), pPaymentItem->GetCellText(0));
		spModItem->ModifyTime = COleDateTime::GetCurrentTime(); //�����޸�ʱ��


		auto bExistsEntity = ModifiedItemEntityEntry(spModItem);

		if (!bExistsEntity)
		{
			pCurrentParent->m_pWorker->m_vectChangedItemBatch.push_back(spModItem);
		}

		//�����Ƿ��Ѿ����ڴ�ID
		SendSynchronizationMessage(nullptr, pItemMainItem->GetTickitsType(), Database::Modified,
			Business::DataPattern::enumAllControl, nullptr, 0, nullptr);
	}
}

void CSaleDoc::OnUpdateSaleDelete(CCmdUI *pCmdUI)
{
	auto pDataSet = GetDataset();
	pCmdUI->Enable(FALSE);
	//δ��˲������޸�
	if (pDataSet->IsExistsPage(0))
	{
		if (!pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
		{
			auto pItemMainItem = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
			if (pItemMainItem->GetState() == Database::Initial)
			{
				if (pItemMainItem->GetCellText(6).Compare(_T("�����")) != 0)
				{
					pCmdUI->Enable(TRUE);
				}
			}
			else
			{
				pCmdUI->Enable(TRUE);
			}
		}
	}
}


void CSaleDoc::OnSaleDelete()
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	auto pDataSet = GetDataset();
	auto pItemMainItem = pDataSet->GetPage(0)->GetCurrentTickitsItem();

	if (pDataSet->GetPage(1)->CurrentRecordBySourceID((LPCTSTR)(pItemMainItem->GetItem()->GetCellText(0))))
	{
		std::shared_ptr<DataPattern::SCTicketIDGroupPure> spDelItem(new DataPattern::SCTicketIDGroupPure());
		auto pPaymentItem = pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
		spDelItem->enumBusinessType = pItemMainItem->GetTickitsType();
		_tcscpy_s(spDelItem->MainID, _countof(spDelItem->MainID), pItemMainItem->GetItem()->GetCellText(0));
		_tcscpy_s(spDelItem->PaymentID, _countof(spDelItem->PaymentID), pPaymentItem->GetCellText(0));
		_tcscpy_s(spDelItem->StockOutID, _countof(spDelItem->StockOutID), _T(""));
		if (pItemMainItem->GetTickitsType() == DataPattern::enumSalesTikits)
		{
			if (pDataSet->GetPage(2)->CurrentRecordBySourceID((LPCTSTR)(pItemMainItem->GetItem()->GetCellText(0))))
			{
				auto pStockItem = pDataSet->GetPage(2)->GetCurrentTickitsItem()->GetItem();
				_tcscpy_s(spDelItem->StockOutID, _countof(spDelItem->StockOutID), pStockItem->GetCellText(0));
			}
		}
		//����״̬
		spDelItem->CurrentState = Database::Deleted;
		//����ʱ��
		spDelItem->ModifyTime = COleDateTime::GetCurrentTime();
		if (pItemMainItem->GetItem()->GetState() != Database::NewItem)
		{
			auto bExistsEntity = ModifiedItemEntityEntry(spDelItem);

			if (!bExistsEntity)
			{
				pCurrentParent->m_pWorker->m_vectChangedItemBatch.push_back(spDelItem);
			}
		}
		else
		{
			//�������б����޳�
			auto szIndex = pCurrentParent->m_pWorker->m_vectChangedItemBatch.size() - 1;
			auto pItemLeast = pCurrentParent->m_pWorker->m_vectChangedItemBatch[szIndex];

			auto strMainID = spDelItem->MainID;
			std::remove_if(pCurrentParent->m_pWorker->m_vectChangedItemBatch.begin(), 
				pCurrentParent->m_pWorker->m_vectChangedItemBatch.end(), [&](auto pItem)->bool {
				return _tcscmp(pItem->MainID, strMainID) == 0;
			});
			if (szIndex != pCurrentParent->m_pWorker->m_vectChangedItemBatch.size() - 1)
			{
				//���´�����С
				pCurrentParent->m_pWorker->m_vectChangedItemBatch.resize(szIndex, pItemLeast);
			}
		}

		auto nInitSize = pDataSet->GetPage(0)->GetItemsCount();

		//��ʼִ��ɾ�����ݹ���
		if (_tcslen(spDelItem->StockOutID) > 0)
		{
			pDataSet->GetPage(2)->DeleteItem(spDelItem->StockOutID);
		}

		pDataSet->GetPage(1)->DeleteItem(spDelItem->PaymentID);

		if (pDataSet->GetPage(0)->GetItemsCount() > 1)
		{
			pDataSet->GetPage(0)->DeleteItem(spDelItem->MainID);
		}

		if (nInitSize == 1)
		{
			pDataSet->ResetAllItems();
		}

		SendSynchronizationMessage(nullptr, pItemMainItem->GetTickitsType(), Database::Deleted,
			Business::DataPattern::enumAllControl, nullptr, 0, nullptr);
	}
}


void CSaleDoc::OnUpdateSaleSave(CCmdUI *pCmdUI)
{
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	pCmdUI->Enable(pCurrentParent->m_pWorker->m_vectChangedItemBatch.size() > 0);
}


void CSaleDoc::OnSaleSave()
{
	CString strResult;
	CSaleFrame* pCurrentParent = reinterpret_cast<CSaleFrame*>(AfxGetMainWnd());
	std::shared_ptr<CSaleServiceSaveDlg> pDlg(new CSaleServiceSaveDlg(pCurrentParent->m_pWorker->m_spDataSet,
		pCurrentParent->m_pWorker->m_vectChangedItemBatch, strResult, pCurrentParent));
	
	pDlg->DoModal();

	if (pDlg->m_bOK)
	{
		LoadAllDataSet(TRUE, TRUE, pCurrentParent->m_pWorker->GetBusinessType());
	}
	else
	{
		int i = 0;
	}
}
