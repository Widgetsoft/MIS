// ServiceInfoDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "ServiceInfoDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CServiceInfoDoc

IMPLEMENT_DYNCREATE(CServiceInfoDoc, CDocument)

CServiceInfoDoc::CServiceInfoDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CServiceInfoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("�����ײ�ά��"));
	return TRUE;
}

CServiceInfoDoc::~CServiceInfoDoc()
{
}


BEGIN_MESSAGE_MAP(CServiceInfoDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CServiceInfoDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CServiceInfoDoc::OnFileSave)
END_MESSAGE_MAP()


// CServiceInfoDoc ���

#ifdef _DEBUG
void CServiceInfoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CServiceInfoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CServiceInfoDoc ���л�

void CServiceInfoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CServiceInfoDoc ����


BOOL CServiceInfoDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CServiceInfoDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CServiceInfoDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabServiceInfo(ServiceID, ServiceCustomCode, ServiceName, ServiceType, ServiceSpec, ServiceUnit1, ServiceUnit2, Service1To2Rate, ServicePrice, EIID, IsTimeCount, IsDiscount, IsIntegral, AsGift, IsUsing, ServiceMemo, JM, CreateDate, ModifyDate, CreatedUser, ModifierUser, compID) VALUES('%s', '%s', '%s', '%s', '%s', '%s', '%s', %s, %s, '%s', %s, %s, %s, %s, %s, '%s', '%s', DATETIME('now', 'localtime'), DATETIME('now', 'localtime'), '%s', '%s', '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 22),
			m_vectNewItems.GetCellText(i, 23),
			m_vectNewItems.GetCellText(i, 24),
			m_vectNewItems.GetCellText(i, 25),
			m_vectNewItems.GetCellText(i, 7),
			m_vectNewItems.GetCellText(i, 8),
			m_vectNewItems.GetCellText(i, 21),
			(m_vectNewItems.GetCellText(i, 10).Compare(_T("��ʱ")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 11).Compare(_T("�ɴ���")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 12).Compare(_T("�ɻ���")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 13).Compare(_T("������")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 14).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			m_vectNewItems.GetCellText(i, 15),
			m_vectNewItems.GetCellText(i, 16),
			m_vectNewItems.GetCellText(i, 19),
			m_vectNewItems.GetCellText(i, 20),
			m_vectNewItems.GetCellText(i, 26));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabServiceInfo SET ServiceCustomCode = '%s', ServiceName = '%s', ServiceType = '%s', ServiceSpec = '%s', ServiceUnit1 = '%s', ServiceUnit2 = '%s', Service1To2Rate = %s, ServicePrice = %s, EIID = '%s', IsTimeCount = %s, IsDiscount = %s, IsIntegral = %s, AsGift = %s, IsUsing = %s, ServiceMemo = '%s', JM = '%s', ModifyDate = DATETIME('now', 'localtime'), ModifierUser = '%s', compID = '%s' WHERE ServiceID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 22),
			m_vectModItems.GetCellText(i, 23),
			m_vectModItems.GetCellText(i, 24),
			m_vectModItems.GetCellText(i, 25),
			m_vectModItems.GetCellText(i, 7),
			m_vectModItems.GetCellText(i, 8),
			m_vectModItems.GetCellText(i, 21),
			(m_vectModItems.GetCellText(i, 10).Compare(_T("��ʱ")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 11).Compare(_T("�ɴ���")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 12).Compare(_T("�ɻ���")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 13).Compare(_T("������")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 14).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			m_vectModItems.GetCellText(i, 15),
			m_vectModItems.GetCellText(i, 16),
			m_vectModItems.GetCellText(i, 20),
			m_vectModItems.GetCellText(i, 26),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabServiceInfo WHERE ServiceID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_SVCINFO_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("�����ײ���Ϣ���ݱ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
