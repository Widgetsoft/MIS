// ProductInfoDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "ProductInfoDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CProductInfoDoc

IMPLEMENT_DYNCREATE(CProductInfoDoc, CDocument)

CProductInfoDoc::CProductInfoDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CProductInfoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("��Ʒ��Ϣά��"));
	return TRUE;
}

CProductInfoDoc::~CProductInfoDoc()
{
}


BEGIN_MESSAGE_MAP(CProductInfoDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CProductInfoDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CProductInfoDoc::OnFileSave)
END_MESSAGE_MAP()


// CProductInfoDoc ���

#ifdef _DEBUG
void CProductInfoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CProductInfoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CProductInfoDoc ���л�

void CProductInfoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CProductInfoDoc ����


BOOL CProductInfoDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CProductInfoDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CProductInfoDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabProductInfo(ProdID, ProdName, ProdCustomID, ProductType, ProductSpec, ProductUnit1, ProductUnit2, Prod1To2Rate, ProductLife, SafeStorage, ProdPurchasePrice, ProdSalesPrice, ProductFirm, ProdDescription, IsDiscount, IsIntegral, AsGift, JM, CreateDate, ModifyDate, CreatedUser, ModifierUser) VALUES('%s', '%s', '%s', '%s', '%s', '%s', '%s', %s, %s, %s, %s, %s, '%s', '%s', %s, %s, %s, '%s', DATETIME('now', 'localtime'), DATETIME('now', 'localtime'), '%s', '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 22),
			m_vectNewItems.GetCellText(i, 23),
			m_vectNewItems.GetCellText(i, 24),
			m_vectNewItems.GetCellText(i, 25),
			m_vectNewItems.GetCellText(i, 7),
			m_vectNewItems.GetCellText(i, 8),
			m_vectNewItems.GetCellText(i, 9),
			m_vectNewItems.GetCellText(i, 10),
			m_vectNewItems.GetCellText(i, 11),
			m_vectNewItems.GetCellText(i, 12),
			m_vectNewItems.GetCellText(i, 13),
			(m_vectNewItems.GetCellText(i, 14).Compare(_T("�ɴ���")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 15).Compare(_T("�ɻ���")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 16).Compare(_T("������")) == 0) ? _T("1") : _T("0"),
			m_vectNewItems.GetCellText(i, 17),
			m_vectNewItems.GetCellText(i, 20),
			m_vectNewItems.GetCellText(i, 21));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabProductInfo SET ProdName = '%s', ProdCustomID = '%s', ProductType = '%s', ProductSpec = '%s', ProductUnit1 = '%s', ProductUnit2 = '%s', Prod1To2Rate = %s, ProductLife = %s, SafeStorage = %s, ProdPurchasePrice = %s, ProdSalesPrice = %s, ProductFirm = '%s', ProdDescription = '%s', IsDiscount = %s, IsIntegral = %s, AsGift = %s, JM = '%s', ModifyDate =DATETIME('now', 'localtime'), ModifierUser = '%s'  WHERE ProdID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 22),
			m_vectModItems.GetCellText(i, 23),
			m_vectModItems.GetCellText(i, 24),
			m_vectModItems.GetCellText(i, 25),
			m_vectModItems.GetCellText(i, 7),
			m_vectModItems.GetCellText(i, 8),
			m_vectModItems.GetCellText(i, 9),
			m_vectModItems.GetCellText(i, 10),
			m_vectModItems.GetCellText(i, 11),
			m_vectModItems.GetCellText(i, 12),
			m_vectModItems.GetCellText(i, 13),
			(m_vectModItems.GetCellText(i, 14).Compare(_T("�ɴ���")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 15).Compare(_T("�ɻ���")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 16).Compare(_T("������")) == 0) ? _T("1") : _T("0"),
			m_vectModItems.GetCellText(i, 17),
			m_vectModItems.GetCellText(i, 21),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabProductInfo WHERE ProdID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_PRODINFO_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("��Ʒ��Ϣ���ݱ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
