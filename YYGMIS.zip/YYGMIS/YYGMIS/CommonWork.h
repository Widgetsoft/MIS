#pragma once
namespace Business
{
	namespace Core
	{
		class CCommonWork
		{
		public:
			CCommonWork(CProgressCtrl& progressTotal, CProgressCtrl& progressSub, HWND hParentWnd);
		public:
			virtual BOOL ConstructBusinessData(DataPattern::EnumBusinessType enumType, BOOL bBatch = TRUE,
				DataPattern::EnumBusinessType enumSourceType = DataPattern::enumUnknown) = 0;	//����ҵ������
			virtual BOOL SaveNew(DataPattern::EnumBusinessType enumType) = 0;					//����ҵ������
			virtual BOOL SaveModify(DataPattern::EnumBusinessType enumType) = 0;				//�޶�ҵ������
			virtual BOOL SaveDelete(DataPattern::EnumBusinessType enumType) = 0;				//ɾ��ҵ������
		protected:
			BOOL ExecuteUpdate(LPCTSTR strUpdates);
			BOOL QueryStockStatus(LPCTSTR lpcstrQuery, std::shared_ptr<Database::CDataFactory> spDataSource, CString& strFaildReason);
			BOOL QueryVaryStatus(LPCTSTR lpcstrQuery, LPCTSTR lpcstrKey1, LPCTSTR lpcstrKey2, double dblAmount, Database::CDataFactory* pDataSource, CString& strFaildReason);
			//��������
		public:
			inline void SetData(std::shared_ptr<DataPattern::CTickitsData> spData) { if (m_spData == nullptr) m_spData = spData; else m_spData.swap(spData); }
			inline void SetOldData(std::shared_ptr<DataPattern::CTickitsData> spOldData) { if (m_spOldData == nullptr) m_spOldData = spOldData; else m_spOldData.swap(spOldData); }
			inline void SetItemKeys(std::shared_ptr<GenerialPattern::CItemData> spKeys) { if (m_spKeys == nullptr) m_spKeys = spKeys; else m_spKeys.swap(spKeys); }


		protected:
			HWND m_hWnd;
			std::shared_ptr<DataPattern::CTickitsData> m_spData;
			std::shared_ptr<DataPattern::CTickitsData> m_spOldData;
			std::shared_ptr<GenerialPattern::CItemData> m_spKeys;
			CProgressCtrl& m_progressTotal;
			CProgressCtrl& m_progressSub;
		};
	}
}

