// OptionsPage.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "OptionsPage.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace UI::Business;

// COptionsPage �Ի���

IMPLEMENT_DYNAMIC(COptionsPage, CMFCPropertyPage)

COptionsPage::COptionsPage()
	: CMFCPropertyPage(IDD_PROPPAGE_SALE)
{

}

COptionsPage::~COptionsPage()
{
}

void COptionsPage::DoDataExchange(CDataExchange* pDX)
{
	CMFCPropertyPage::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(COptionsPage, CMFCPropertyPage)
END_MESSAGE_MAP()


// COptionsPage ��Ϣ��������
