// CardInfoDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "CardInfoDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CCardInfoDoc

IMPLEMENT_DYNCREATE(CCardInfoDoc, CDocument)

CCardInfoDoc::CCardInfoDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CCardInfoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("��Ա��ά��"));
	return TRUE;
}

CCardInfoDoc::~CCardInfoDoc()
{
}


BEGIN_MESSAGE_MAP(CCardInfoDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CCardInfoDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CCardInfoDoc::OnFileSave)
END_MESSAGE_MAP()


// CCardInfoDoc ���

#ifdef _DEBUG
void CCardInfoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CCardInfoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CCardInfoDoc ���л�

void CCardInfoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CCardInfoDoc ����


BOOL CCardInfoDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CCardInfoDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CCardInfoDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabCardInfo(CardID, CardNumber, CardName, custID, CTID, IsUsing, AutoGrowPeriod, AutoGrowScore, CardMemo, CreateDate, ModifyDate, CreatedUser) VALUES('%s', '%s', '%s', '%s', '%s', %s, %s, %s, '%s', DATETIME('now','localtime'), DATETIME('now','localtime'), '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 13),
			m_vectNewItems.GetCellText(i, 12),
			(m_vectNewItems.GetCellText(i, 5).Compare(_T("����ʹ��")) == 0) ? _T("1") : _T("0"),
			m_vectNewItems.GetCellText(i, 6),
			m_vectNewItems.GetCellText(i, 7),
			m_vectNewItems.GetCellText(i, 8),
			m_vectNewItems.GetCellText(i, 11));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabCardInfo SET CardNumber = '%s', CardName = '%s', custID = '%s', CTID = '%s', IsUsing = %s, AutoGrowPeriod = %s, AutoGrowScore = '%s', CardMemo = '%s', ModifyDate = DATETIME('now','localtime')  WHERE CardID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 13),
			m_vectModItems.GetCellText(i, 12),
			(m_vectModItems.GetCellText(i, 5).Compare(_T("����ʹ��")) == 0) ? _T("1") : _T("0"),
			m_vectModItems.GetCellText(i, 6),
			m_vectModItems.GetCellText(i, 7),
			m_vectModItems.GetCellText(i, 8),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabCardInfo WHERE CardID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_CARDTINFO_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("��Ա����Ϣ���ݱ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
