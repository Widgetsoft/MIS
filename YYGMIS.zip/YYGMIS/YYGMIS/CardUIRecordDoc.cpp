// CardUIRecordDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "CardUIRecordDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CCardUIRecordDoc

IMPLEMENT_DYNCREATE(CCardUIRecordDoc, CDocument)

CCardUIRecordDoc::CCardUIRecordDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CCardUIRecordDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("��Ա�����Ѽ�����"));
	return TRUE;
}

CCardUIRecordDoc::~CCardUIRecordDoc()
{
}


BEGIN_MESSAGE_MAP(CCardUIRecordDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CCardUIRecordDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CCardUIRecordDoc::OnFileSave)
END_MESSAGE_MAP()


// CCardUIRecordDoc ���

#ifdef _DEBUG
void CCardUIRecordDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CCardUIRecordDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CCardUIRecordDoc ���л�

void CCardUIRecordDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CCardUIRecordDoc ����


BOOL CCardUIRecordDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CCardUIRecordDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CCardUIRecordDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabCardUIRecord(CUIRID, CardID, Summary, Debit, Credit, RealMoney, TableDate, TableUser, CurrentRate, SourceID, CreditRecordType) VALUES('%s', '%s', '%s', %s, %s, %s,  DATETIME('now','localtime'), '%s', '%s', '%s', %s);"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 13),
			m_vectNewItems.GetCellText(i, 3),
			m_vectNewItems.GetCellText(i, 4),
			m_vectNewItems.GetCellText(i, 5),
			m_vectNewItems.GetCellText(i, 6),
			m_vectNewItems.GetCellText(i, 7),
			m_vectNewItems.GetCellText(i, 12),
			m_vectNewItems.GetCellText(i, 9),
			(m_vectNewItems.GetCellText(i, 10).Compare(_T("����¼")) == 0) ? _T("1") : _T("0"),
			m_vectNewItems.GetCellText(i, 11));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabCardUIRecord SET Summary = '%s', Debit = %s, Credit = %s, RealMoney = %s, CurrentRate = %s  WHERE CUIRID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 3),
			m_vectModItems.GetCellText(i, 4),
			m_vectModItems.GetCellText(i, 5),
			m_vectModItems.GetCellText(i, 6),
			m_vectModItems.GetCellText(i, 9),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabCardUIRecord WHERE CUIRID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_CUIRINFO_CHANGED, NULL, NULL, TRUE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("��Ա����ֵ����ּ�¼����ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
