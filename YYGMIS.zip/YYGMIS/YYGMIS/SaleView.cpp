// SaleView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "SaleDoc.h"
#include "LocalDataGridView.h"
#include "SaleView.h"
#include "WorkAssistant.h"
#include "SystemInfo.h"
#include "VisualStyleHelper.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSaleView

IMPLEMENT_DYNCREATE(CSaleView, CFormView)

CSaleView::CSaleView()
	: CFormView(IDD_SALEVIEW),
	m_lstCurrentProd(new GenerialPattern::CItemsData()),
	m_lstCurrentSvs(new GenerialPattern::CItemsData())
{
	m_bDataLoaded = FALSE;
}

CSaleView::~CSaleView()
{
}

void CSaleView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SALE_DETAILS, m_ListCtrl);
	DDX_Control(pDX, IDC_SALE_DEPT, m_cmbDepartment);
	DDX_Control(pDX, IDC_SALE_WH, m_cmbWarehouse);
	DDX_Control(pDX, IDC_SALE_BUSINESSMAN, m_cmbExecuter);
	DDX_Control(pDX, IDC_SALE_CUSTOMER, m_cmbCustomer);
	DDX_Control(pDX, IDC_SALE_DATE, m_dateBusiness);

}

void CSaleView::ChangeLabels(BOOL bEnableInput, BOOL bReloadOptions)
{
	GetDlgItem(IDC_SALE_WH)->EnableWindow(FALSE);
	if (m_enumDetailsType == DataPattern::enumServiceTikits)
	{
		//���ۿⷿ:
		GetDlgItem(IDC_SALE_LABEL2)->SetWindowText(_T("������:"));
		GetDlgItem(IDC_SALE_LABEL3)->SetWindowText(_T("��������:"));
		GetDlgItem(IDC_SALE_LABEL4)->SetWindowText(_T("��������:"));
		GetDlgItem(IDC_SALE_LABEL8)->SetWindowText(_T("����ͳ��:"));
	}
	else
	{
		GetDlgItem(IDC_SALE_LABEL2)->SetWindowText(_T("���۲���:"));
		GetDlgItem(IDC_SALE_LABEL3)->SetWindowText(_T("����ⷿ:"));
		if (bEnableInput)
		{
			GetDlgItem(IDC_SALE_WH)->EnableWindow(TRUE);
		}
		GetDlgItem(IDC_SALE_LABEL4)->SetWindowText(_T("��������:"));
		GetDlgItem(IDC_SALE_LABEL8)->SetWindowText(_T("����ͳ��:"));
	}

	GetDlgItem(IDC_SALE_DEPT)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_SALE_DATE)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_SALE_BUSINESSMAN)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_SALE_CUSTOMER)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_SALE_CHECKOUT)->EnableWindow(bEnableInput);

	CEdit* pEdit = reinterpret_cast<CEdit*>(GetDlgItem(IDC_SALE_MEMO));
	pEdit->SetReadOnly(!bEnableInput);

	if (bReloadOptions)
	{
		GenerialPattern::CItemData tempDeptData, tempWarehouse, tempStaffData, tempCustData;

		//��������|������
		CString strQuery;
		strQuery.Append(_T("SELECT deptID, deptName FROM tsw_tabAgencyInfo;"));
		Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbDepartment, &tempDeptData);

		strQuery.Empty();
		strQuery.Append(_T("SELECT WSPID, WSPName FROM tsw_tabWareHouseSalePointInfo;"));
		Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbWarehouse, &tempWarehouse);

		strQuery.Empty();
		strQuery.Append(_T("SELECT EID, EName FROM tsw_tabStaffInfo;"));
		Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbExecuter, &tempStaffData, theApp.m_siInfo->m_strUserInnerID);

		//���ؿͻ���Ϣ
		strQuery.Empty();
		strQuery.Append(_T("SELECT custID, CustomerName FROM tsw_tabCustomerInfo;"));
		Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbCustomer, &tempCustData, nullptr, TRUE);
	}

}

void CSaleView::LoadTicketTitle()
{
	SetDlgItemText(IDC_SALE_NO, _T(""));
	SetDlgItemText(IDC_SALE_MEMO, _T(""));
	SetDlgItemText(IDC_SALE_SUM, _T(""));
	CheckDlgButton(IDC_SALE_CHECKOUT, FALSE);

	auto pItemData = GetDocument()->GetDataset();

	if ( !pItemData->IsExistsPage(0) || !pItemData->IsExistsPage(1))
	{
		//���������ݣ����ü���
		ChangeLabels(FALSE);
		return;
	}

	auto InitialTicketsType = m_enumDetailsType;


	m_enumDetailsType = pItemData->GetPage(0)->GetCurrentTickitsItem()->GetTickitsType();

	//���ۼ�¼����
	auto pRealSaleItem = pItemData->GetPage(0)->GetCurrentTickitsItem()->GetItem();

	//�����Զ�����
	SetDlgItemText(IDC_SALE_NO, pRealSaleItem->GetCellText(1));
	//����ҵ������
	COleDateTime dateTemp;
	dateTemp.ParseDateTime(pRealSaleItem->GetCellText(2));
	SYSTEMTIME sysTime;
	dateTemp.GetAsSystemTime(sysTime);
	m_dateBusiness.SetTime(sysTime);

	//���ط�����
	if (!Database::CFlybyItem::IsNullGuid(pRealSaleItem->GetCellText(10)))
	{
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(pRealSaleItem->GetCellText(10), pRealSaleItem->GetCellText(3), NULL);
		Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbDepartment, apItem.release());
	}

	if (m_enumDetailsType == DataPattern::enumSalesTikits)
	{
		//���ؿⷿ
		auto pItem = pItemData->GetPage(2)->GetCurrentTickitsItem()->GetItem();

		if (!Database::CFlybyItem::IsNullGuid(pItem->GetCellText(20)))
		{
			std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
			apItem->AddRange(pItem->GetCellText(20), pItem->GetCellText(4), NULL);
			Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbWarehouse, apItem.release());
		}
	}

	//����ҵ����Ա
	if (!Database::CFlybyItem::IsNullGuid(pRealSaleItem->GetCellText(11)))
	{
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(pRealSaleItem->GetCellText(11), pRealSaleItem->GetCellText(4), NULL);
		Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbExecuter, apItem.release());
	}

	//���ؿͻ���Ϣ
	if (!Database::CFlybyItem::IsNullGuid(pRealSaleItem->GetCellText(13)))
	{
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(pRealSaleItem->GetCellText(13), pRealSaleItem->GetCellText(5), NULL);
		Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbCustomer, apItem.release());
	}

	SetDlgItemText(IDC_SALE_MEMO, pRealSaleItem->GetCellText(9));

	CheckDlgButton(IDC_SALE_CHECKOUT, 
		pRealSaleItem->GetCellText(6).Compare(_T("�����")) == 0);

	BOOL bLabelChanged = m_enumDetailsType != InitialTicketsType;

	ChangeLabels( pItemData->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial, bLabelChanged);
	if (bLabelChanged)
	{
		ReLoadTableTitle();
	}
}

void CSaleView::ColculateSum(const UINT uiRow)
{
	auto pItemData = GetDocument()->GetDataset();

	//���ۼ�¼����
	auto pRealSaleItem = pItemData->GetPage(0)->GetCurrentTickitsItem();

	auto pProdFlow = pRealSaleItem->GetItemDetails();

	TCHAR* tcsStop = nullptr, *tcsStop1 = nullptr;

	double dblTemp1 = { 0 }, dblTemp2 = { 0 };

	dblTemp1 = _tcstod(pProdFlow->GetCellText(uiRow, 4), &tcsStop);
	dblTemp2 = _tcstod(pProdFlow->GetCellText(uiRow, 5), &tcsStop1);

	double dblAmount = dblTemp1 * dblTemp2;

	CString strTemp;
	strTemp.Format(_T("%.2f"), dblAmount);
	CString strQuery;
	if (m_enumDetailsType == DataPattern::enumSalesTikits)
	{
		//�������
		pProdFlow->SetCellText(uiRow, 8, strTemp);
		m_ListCtrl.SetItemText(uiRow, 8, strTemp);
		//����Ӧ�����
		tcsStop = nullptr;
		double dblRealAmount = dblAmount - _tcstod(pProdFlow->GetCellText(uiRow, 7), &tcsStop);
		strTemp.Format(_T("%.2f"), dblRealAmount);
		pProdFlow->SetCellText(uiRow, 9, strTemp);
		m_ListCtrl.SetItemText(uiRow, 9, strTemp);
	}
	else
	{
		//�������
		pProdFlow->SetCellText(uiRow, 10, strTemp);
		m_ListCtrl.SetItemText(uiRow, 10, strTemp);
		double dblRealAmount = dblAmount - _tcstod(pProdFlow->GetCellText(uiRow, 9), &tcsStop);
		strTemp.Format(_T("%.2f"), dblRealAmount);
		pProdFlow->SetCellText(uiRow, 11, strTemp);
		m_ListCtrl.SetItemText(uiRow, 11, strTemp);
	}

	double dblScoreAmount = { 0 };
	double dblCommissionRate = { 0 };
	auto tuple = GetDocument()->FindOutScoreAndCommission();

	if (m_enumDetailsType == DataPattern::enumSalesTikits)
	{
		dblScoreAmount = std::get<0>(tuple);
		dblCommissionRate = std::get<2>(tuple);
		dblScoreAmount *= dblAmount;
		dblCommissionRate *= dblAmount;

		strTemp.Format(_T("%.2f"), dblScoreAmount);
		pProdFlow->SetCellText(uiRow, 10, strTemp);
		m_ListCtrl.SetItemText(uiRow, 10, strTemp);
		strTemp.Format(_T("%.2f"), dblCommissionRate);
		pProdFlow->SetCellText(uiRow, 11, strTemp);
		m_ListCtrl.SetItemText(uiRow, 11, strTemp);
	}
	else
	{
		dblScoreAmount = std::get<1>(tuple);
		dblCommissionRate = std::get<2>(tuple);
		dblScoreAmount *= dblAmount;
		dblCommissionRate *= dblAmount;
		strTemp.Format(_T("%.2f"), dblScoreAmount);
		pProdFlow->SetCellText(uiRow, 12, strTemp);
		m_ListCtrl.SetItemText(uiRow, 12, strTemp);
		strTemp.Format(_T("%.2f"), dblCommissionRate);
		pProdFlow->SetCellText(uiRow, 13, strTemp);
		m_ListCtrl.SetItemText(uiRow, 13, strTemp);
	}
}

void CSaleView::ColculateTotalSum()
{
	auto pItemData = GetDocument()->GetDataset();

	//���ۼ�¼����
	auto pRealSaleItem = pItemData->GetPage(0)->GetCurrentTickitsItem();

	auto pItem = pRealSaleItem->GetItem();
	auto  pProdFlow = pRealSaleItem->GetItemDetails();


	double dblQuantity = { 0 }, dblAmount = { 0 }, dblDiscount = { 0 };
	int nCount = pProdFlow->GetCount();

	auto enumTicket = m_enumDetailsType;

	Concurrency::parallel_for(0, nCount, [enumTicket, pProdFlow, &dblQuantity, &dblAmount, &dblDiscount](const int i) {
		TCHAR *tcsTemp = nullptr;
		dblQuantity += _tcstod(pProdFlow->GetCellText(i, 5), &tcsTemp);
		tcsTemp = nullptr;
		if (enumTicket == DataPattern::enumSalesTikits)
		{
			dblDiscount += _tcstod(pProdFlow->GetCellText(i, 7), &tcsTemp);
			tcsTemp = nullptr;
			dblAmount += _tcstod(pProdFlow->GetCellText(i, 9), &tcsTemp);
		}
		else
		{
			dblDiscount += _tcstod(pProdFlow->GetCellText(i, 9), &tcsTemp);
			tcsTemp = nullptr;
			dblAmount += _tcstod(pProdFlow->GetCellText(i, 11), &tcsTemp);
		}
	});

	CString strTemp;
	strTemp.Format(_T("%.2f"), dblQuantity);
	pItem->SetCellText(6, strTemp);
	strTemp.Format(_T("%.2f"), dblAmount);
	pItem->SetCellText(7, strTemp);

	CString strSummary;
	strSummary.Format(_T("����:%.2f; Ӧ�����:%.2f�������Ż�:%.2f����"),
		dblQuantity, dblAmount, dblDiscount);
	SetDlgItemText(IDC_SALE_SUM, strSummary);
}

void CSaleView::ReLoadTableTitle()
{
	m_ListCtrl.DeleteAllItems();
	for (int n = m_ListCtrl.GetColumnCount() - 1; n != -1; n--)
	{
		m_ListCtrl.DeleteColumn(n);
	}


	auto nColumnsCount = 0;
	Database::CFlybyData* spDetails = nullptr;
	if (m_enumDetailsType == DataPattern::enumSalesTikits)
	{
		spDetails = new Database::CSalesFlowDetailsVector();
		nColumnsCount = spDetails->GetColCount() - 4;
	}
	else if (m_enumDetailsType == DataPattern::enumServiceTikits)
	{
		spDetails = new Database::CServiceFlowDetailsVector();
		nColumnsCount = spDetails->GetColCount() - 5;
	}
	else
	{
		return;
	}

	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	int nCurrentCol = 0;
	for (int n = 0; n != nColumnsCount; n++)
	{
		nCurrentCol = n + 1;
		const CString& title = spDetails->GetColTitle(nCurrentCol);
		CGridColumnTrait* pTrait = NULL;
		switch (nCurrentCol)
		{
		case 1: //������ѡ��Ϊ�˼ӿ�����ٶ�
			pTrait = new CGridColumnTraitCombo;
			break;
		case 4:
		case 5:
		case 12:
			pTrait = new CGridColumnTraitEdit;
			break;
		case 6:
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				pTrait = new CGridColumnTraitDateTime();
			}
			break;
		case 7:
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				pTrait = new CGridColumnTraitDateTime();
			}
			else
			{
				pTrait = new CGridColumnTraitEdit;
			}
			break;
		case 8:
			if (m_enumDetailsType == DataPattern::enumSalesTikits)
			{
				pTrait = new CGridColumnTraitEdit;
			}
			break;
		case 9:
		case 13:
		case 14:
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				pTrait = new CGridColumnTraitEdit;
			}
			break;
		case 10:
		case 11:
			if (m_enumDetailsType == DataPattern::enumSalesTikits)
			{
				pTrait = new CGridColumnTraitEdit;
			}
			break;
		default:
			break;
		}
		m_ListCtrl.InsertColumnTrait(nCurrentCol, title, LVCFMT_LEFT, 100, n, pTrait);

	}
	delete spDetails;
}

void CSaleView::ReloadTableData()
{
	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(0) && !pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
	{
		auto pItemDetails = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();
		m_ListCtrl.SetVector(pItemDetails.get());
		Database::CFlybyData* pDetailsData = pItemDetails.get();

		m_ListCtrl.DeleteAllItems();

		auto nColumnsCount = 0;
		if (m_enumDetailsType == DataPattern::enumSalesTikits)
		{
			nColumnsCount = pDetailsData->GetColCount() - 4;
		}
		else
		{
			nColumnsCount = pDetailsData->GetColCount() - 5;
		}

		// Insert data into list-control by copying from datamodel
		int nItem = 0;
		for (size_t rowId = 0; rowId != pDetailsData->GetCount(); ++rowId)
		{
			nItem = m_ListCtrl.InsertItem(++nItem, pDetailsData->GetCellText(rowId, 1));
			m_ListCtrl.SetItemData(nItem, rowId);
			for (int col = 0; col < nColumnsCount; ++col)
			{
				int nCellCol = col + 1;	// +1 because of hidden column
				const CString& strCellText = pDetailsData->GetCellText(rowId, nCellCol);
				m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
			}
		}

		ColculateTotalSum();
	}
}


//691366

BEGIN_MESSAGE_MAP(CSaleView, CFormView)
	ON_MESSAGE(WM_SALSVC_CREATE_MSG, OnSalesChanged)
	ON_EN_CHANGE(IDC_SALE_MEMO, OnMemoChanged)
	ON_CBN_CLOSEUP(IDC_SALE_WH, OnWarehouseCloseup)
	ON_CBN_CLOSEUP(IDC_SALE_BUSINESSMAN, OnExecuteManCloseup)
	ON_CBN_CLOSEUP(IDC_SALE_DEPT, OnDepartmentCloseup)
	ON_CBN_EDITUPDATE(IDC_SALE_CUSTOMER, OnCustomerEditUpdate)
	ON_CBN_CLOSEUP(IDC_SALE_CUSTOMER, OnCustomerCloseup)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_SALE_DATE, OnSaleDateTimeChanged)
	ON_BN_CLICKED(IDC_SALE_CHECKOUT, OnCheckOutClick)
	ON_NOTIFY(LVN_BEGINLABELEDIT, IDC_SALE_DETAILS, OnBeginLabelEdit)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_SALE_DETAILS, OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_NEWITEM, &CSaleView::OnUpdateEditSdNewitem)
	ON_COMMAND(ID_EDIT_SD_NEWITEM, &CSaleView::OnEditSdNewitem)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_MODIFY, &CSaleView::OnUpdateEditSdModify)
	ON_COMMAND(ID_EDIT_SD_MODIFY, &CSaleView::OnEditSdModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_DELETE, &CSaleView::OnUpdateEditSdDelete)
	ON_COMMAND(ID_EDIT_SD_DELETE, &CSaleView::OnEditSdDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_REFRESH, &CSaleView::OnUpdateEditSdRefresh)
	ON_COMMAND(ID_EDIT_SD_REFRESH, &CSaleView::OnEditSdRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_REVSEL, &CSaleView::OnUpdateEditSdRevsel)
	ON_COMMAND(ID_EDIT_SD_REVSEL, &CSaleView::OnEditSdRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_FIND, &CSaleView::OnUpdateEditSdFind)
	ON_COMMAND(ID_EDIT_SD_FIND, &CSaleView::OnEditSdFind)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CSaleView ���

#ifdef _DEBUG
void CSaleView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CSaleView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc); //GetDoucment()->SetTitle()
}
#endif
CSaleDoc* CSaleView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSaleDoc)));
	return reinterpret_cast<CSaleDoc*>(m_pDocument);
}
#endif //_DEBUG


// CSaleView ��Ϣ��������

void CSaleView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	GetDocument()->SetTitle(_T("���ۡ����񴰿�"));

	// Give better margin to editors
	m_ListCtrl.SetContextMenu(IDR_POPUP_SALE_EDIT);
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("���ۼ����񿪵�����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);
}

LRESULT CSaleView::OnSalesChanged(WPARAM wParam, LPARAM lParam)
{
	auto enumInitial = m_enumDetailsType;
	DataPattern::PPSChangeParameter pSenderParameter =
		reinterpret_cast<DataPattern::PPSChangeParameter>(lParam);
	if (pSenderParameter != nullptr)
	{
		BOOL bSelfMsg = pSenderParameter->pLaunchSource != nullptr &&
			pSenderParameter->pLaunchSource->IsKindOf(RUNTIME_CLASS(CSaleView));

		if (bSelfMsg)
		{
			return 0L;
		}

		//���µ�ǰ��������
		m_enumDetailsType = pSenderParameter->enumBusinessType;

		//δ������ǰ�ļ�¼�����Զ����أ�������һ��
		if (!m_bDataLoaded)
		{
			m_bDataLoaded = TRUE;
			GetDocument()->LoadAllDataSet( TRUE, TRUE, m_enumDetailsType);
			//����֪ͨ����������
			ChangeLabels(FALSE, TRUE);
			return 0L;
		}

		//��ʼ�������������
		if ((pSenderParameter->enumActionType == Database::NewItem) &&
			(pSenderParameter->nExtraSize > 0))
		{
			//�����BSTR����
			BSTR bstrArgsIDs = reinterpret_cast<BSTR>(pSenderParameter->pDataExtra);
			if (bstrArgsIDs != nullptr)
			{
				GetDocument()->CreateNewTicketItem(bstrArgsIDs, m_enumDetailsType);
				return 0L;
			}
		}

		switch (pSenderParameter->ChangeObject)
		{
		case DataPattern::enumAllControl:
			LoadTicketTitle();
			if (enumInitial != m_enumDetailsType || m_ListCtrl.GetColumnCount() < 1)
			{
				ReLoadTableTitle();
			}
			ReloadTableData();
			break;
		case DataPattern::enumListCtrl:
			if (enumInitial != m_enumDetailsType || m_ListCtrl.GetColumnCount() < 1)
			{
				ReLoadTableTitle();
			}
			ReloadTableData();
			break;
		case DataPattern::enumTextBox:
			if (_tcscmp(_T("IDC_SALE_SUM"), pSenderParameter->ObjectIDs) == 0)
			{
				ColculateTotalSum();
			}
			else if (_tcscmp(_T("IDC_SALE_MEMO"), pSenderParameter->ObjectIDs) == 0)
			{
				//���±�ע
				auto pSaleItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				SetDlgItemText(IDC_SALE_MEMO, pSaleItem->GetCellText(9));
			}
			break;
		case DataPattern::enumDataTimePick:
			if (_tcscmp(_T("IDC_SALE_DATE"), pSenderParameter->ObjectIDs) == 0)
			{
				//�������ڴ���
				auto pSaleItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				COleDateTime dateTemp;
				dateTemp.ParseDateTime(pSaleItem->GetCellText(2));
				SYSTEMTIME sysTime;
				dateTemp.GetAsSystemTime(sysTime);
				m_dateBusiness.SetTime(sysTime);
			}
			break;
		case DataPattern::enumComboBox:
			if (_tcscmp(_T("IDC_SALE_DEPT"), pSenderParameter->ObjectIDs) == 0)
			{
				//������Ϣ����
				auto pItemData = GetDocument()->GetDataset();
				auto pSaleItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				if (!Database::CFlybyItem::IsNullGuid(pSaleItem->GetCellText(10)))
				{
					std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
					apItem->AddRange(pSaleItem->GetCellText(10), pSaleItem->GetCellText(3), NULL);
					Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbDepartment, apItem.release(), 0);
				}

			}
			else if (_tcscmp(_T("IDC_SALE_CUSTOMER"), pSenderParameter->ObjectIDs) == 0)
			{
				//�ͻ�����
				auto pItemData = GetDocument()->GetDataset();
				auto pSaleItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				if (!Database::CFlybyItem::IsNullGuid(pSaleItem->GetCellText(13)))
				{
					std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
					apItem->AddRange(pSaleItem->GetCellText(13), pSaleItem->GetCellText(5), NULL);
					Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbCustomer, apItem.release());
				}
			}
			else if ( m_enumDetailsType == DataPattern::enumSalesTikits &&
				_tcscmp(_T("IDC_SALE_WH"), pSenderParameter->ObjectIDs) == 0)
			{
				//�տ��˴���
				auto pItemData = GetDocument()->GetDataset();
				auto pStockItem = GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem();
				if (!Database::CFlybyItem::IsNullGuid(pStockItem->GetCellText(20)))
				{
					std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
					apItem->AddRange(pStockItem->GetCellText(20), pStockItem->GetCellText(4), NULL);
					Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbWarehouse, apItem.release());
				}
			}
			else if (_tcscmp(_T("IDC_SALE_BUSINESSMAN"), pSenderParameter->ObjectIDs) == 0)
			{
				//�տ��˴���
				auto pItemData = GetDocument()->GetDataset();
				auto pSaleItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				if (!Database::CFlybyItem::IsNullGuid(pSaleItem->GetCellText(11)))
				{
					std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
					apItem->AddRange(pSaleItem->GetCellText(11), pSaleItem->GetCellText(4), NULL);
					Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbExecuter, apItem.release());
				}
			}
			break;
		case DataPattern::enumCheckBox:
			if (_tcscmp(_T("IDC_SALE_CHECKOUT"), pSenderParameter->ObjectIDs) == 0)
			{
				auto pSaleItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
				//���ؽ��׶���
				CheckDlgButton(IDC_SALE_CHECKOUT,
					pSaleItem->GetCellText(6).Compare(_T("�����")) == 0);
			}
			break;
		}
	}


	return 0L;
}

void CSaleView::OnWarehouseCloseup()
{
	auto pDataSet = GetDocument()->GetDataset();
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbWarehouse, nullptr, pDataSet, 2, 20, 4);
}

void CSaleView::OnExecuteManCloseup()
{
	auto pDataSet = GetDocument()->GetDataset();
	//�������ۼ�¼
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 0, 11, 4);
	//�������
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 1, 20, 6);
	if (m_enumDetailsType == DataPattern::enumSalesTikits)
	{
		//�����ⷿ
		Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 2, 18, 3);
	}

	auto pCurrentItem = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
	//���ͱ��֪ͨ�����
	GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
		Business::DataPattern::enumComboBox, _T("IDC_PAYMENT_MAN"), 0, nullptr);
}

void CSaleView::OnDepartmentCloseup()
{
	auto pDataSet = GetDocument()->GetDataset();
	//�������ۼ�¼
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 0, 23, 3);
	//�������
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 1, 20, 6);
	//���ͱ��֪ͨ�����
	auto pCurrentItem = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
	//���ͱ��֪ͨ�����
	GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
		Business::DataPattern::enumComboBox, _T("IDC_PAYMENT_DEPT"), 0, nullptr);
}

void CSaleView::OnCustomerEditUpdate()
{
	auto pDataSet = GetDocument()->GetDataset();
	CString strText;
	m_cmbCustomer.GetWindowText(strText);
	//strText = strText.Trim();
	//�������¼�������
	CString strQuery;
	strQuery.Format(_T("SELECT custID, CustomerName FROM tsw_tabCustomerInfo WHERE CustomerName LIKE '%%%s%%' OR custCustomID LIKE '%%%s%%' OR CustomerPN LIKE '%%%s%%' OR CustomerPrefer LIKE '%%%s%%' OR CustomerMemo LIKE '%%%s%%' OR ContactAddress LIKE '%%%s%%' OR JM LIKE '%%%s%%'"),
		strText, strText, strText, strText, strText, strText, strText.MakeUpper());
	Core::CWorkAssistant::QIFilterOptions(pDataSet, strQuery, m_cmbCustomer, strText, 0, TRUE);
}

void CSaleView::OnCustomerCloseup()
{
	auto pDataSet = GetDocument()->GetDataset();
	auto pFeedback = Core::CWorkAssistant::QIValidateOptions(pDataSet, m_cmbCustomer, 13, 5);
	
	if (pFeedback != nullptr)
	{
		auto pPaymentItem = pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
		pPaymentItem->SetCellText(22, pFeedback->at(0).c_str());
		pPaymentItem->SetCellText(4, pFeedback->at(1).c_str());

		//ע�����ÿ����¼�����ۿ۲�ͬ
		//����ע��յ�
		CString strNUllID;
		Helper::CToolkits::ConvertGUID(GUID_NULL, strNUllID);
		if (pFeedback->at(0).compare(strNUllID) != 0)
		{
			//���¼��ز������ۿۺͻ���
			int nCount = m_ListCtrl.GetItemCount();
			for (int i = 0; i != nCount; i++)
			{
				ColculateSum(i);
			}
			if (nCount > 0)
			{
				ColculateTotalSum();
				GetDocument()->AutoCompletePayment();
			}
		}

		//���ͱ��֪ͨ�����
		auto pCurrentItem = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem();
		//���ͱ��֪ͨ�����
		GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
			Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_OBJECT"), 0, nullptr);
	}
}

void CSaleView::OnSaleDateTimeChanged(NMHDR *pNMHDR, LRESULT *pResult)
{
	BOOL bEabled = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial;
	if (bEabled)
	{
		LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
		Database::CFlybyItem* pItem = NULL;
		BOOL bSucess = GetDocument()->GetDataset()->GetCurrentFlybyData(0, (PVOID*)&pItem);
		ASSERT(bSucess);
		if (pItem->GetState() != Database::Initial)
		{
			LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
			COleDateTime tempDate(pDTChange->st);
			pItem->SetCellText(2, tempDate.Format());
			//���ø�������
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(2, tempDate.Format());
			if (m_enumDetailsType == DataPattern::enumSalesTikits)
			{
				//���ó�������
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(2, tempDate.Format());
				//���ͱ��֪ͨ�����
			}
			//���ͱ��֪ͨ�����
			auto pCurrentItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
			//���ͱ��֪ͨ�����
			GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
				Business::DataPattern::enumDataTimePick, _T("IDC_PAYMENT_DATE"), 0, nullptr);
		}
	}
	*pResult = 0;
}

void CSaleView::OnCheckOutClick()
{
	BOOL bEabled = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial;
	if (bEabled)
	{
		BOOL bIsCheckout = IsDlgButtonChecked(IDC_SALE_CHECKOUT);
		GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(6, bIsCheckout ? _T("�����") : _T("δ���"));
		GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(11, bIsCheckout ? _T("�����") : _T("δ���"));
		GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(8, bIsCheckout ? _T("�����") : _T("δ���"));
		if (bIsCheckout)
		{
			//��������˺��������
			COleDateTime oleDateNow = COleDateTime::GetCurrentTime();
			CString strCheckoutData = oleDateNow.Format();
			//�������ۡ����񵥵����״̬
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(12, theApp.m_siInfo->m_strUserInnerID);
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(7, theApp.m_siInfo->m_strUserName);
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(16, strCheckoutData);
			//���������¼
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(21, theApp.m_siInfo->m_strUserInnerID);
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(12, theApp.m_siInfo->m_strUserName);
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(17, strCheckoutData);
			if (m_enumDetailsType == DataPattern::enumSalesTikits)
			{
				//��������������
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(17, theApp.m_siInfo->m_strUserInnerID);
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(9, theApp.m_siInfo->m_strUserName);
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(14, strCheckoutData);
			}
		}
	}

	//���ͱ��֪ͨ�����
	auto pCurrentItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
	//���ͱ��֪ͨ�����
	GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
		Business::DataPattern::enumCheckBox, _T("IDC_PAYMENT_CHECKOUT"), 0, nullptr);
}

void CSaleView::OnMemoChanged()
{
	Database::CFlybyItem* pItem = NULL;
	BOOL bSucess = GetDocument()->GetDataset()->GetCurrentFlybyData(0, (PVOID*)&pItem);
	if (bSucess && pItem->GetState() != Database::Initial)
	{
		CString strText;
		GetDlgItemText(IDC_SALE_MEMO, strText);
		pItem->SetCellText(9, strText);
	}
}

#pragma region �л���Ʒ��Ϣ
BOOL CSaleView::PSSelectAutoComplete(int nRow, int nCol, const CString strKeyword)
{
	BOOL bRet = FALSE;
	auto spDataset = GetDocument()->GetDataset();

	Database::CFlybyData* pProdFlow = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails().get();
	Database::CFlybyData* pStockFlow = nullptr;

	CString strPrevious;

	LOCALEDB;
	//�ȼ�������
	CString strQuery;
	BOOL bExactFound = FALSE;
	//�Ͽ����¼���
	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(1));

	//�������¼����б�����
	pComboTrait->ClearFixedItems();
	if (m_enumDetailsType == DataPattern::enumSalesTikits)
	{
		strPrevious = pProdFlow->GetCellText(nRow, 14);
		m_lstCurrentProd->ClearItemDatas();
		//��������ƥ�����Ŀ
		Database::CProductInfoVector prodTable;
		strQuery.Format(_T("SELECT * FROM %s WHERE ���� LIKE '%s'"), prodTable.m_strBindTable, strKeyword);
		if (pDataBase->GetProductInfo(strQuery, prodTable))
		{
			if (prodTable.GetCount() > 0)
			{
				bExactFound = TRUE;
			}
		}
		if (!bExactFound)
		{
			//���¿�ʼģ��ɸѡ
			strQuery.Format(_T("SELECT * FROM %s WHERE ��Ʒ���� LIKE '%%%s%%' OR ���� LIKE '%%%s%%' OR ��Ʒ���� LIKE '%%%s%%' OR ��Ʒ��� LIKE '%%%s%%' OR ��Ʒ��� LIKE '%%%s%%' OR ����λ LIKE '%%%s%%' OR ���ۼ� LIKE '%%%s%%';"),
				prodTable.m_strBindTable, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword);
			if (pDataBase->GetProductInfo(strQuery, prodTable))
			{
				if (prodTable.GetCount() > 0)
				{
					bExactFound = TRUE;
				}
			}
		}

		CString strTemp;
		
		GenerialPattern::CItemData* pNormalItem = nullptr;

		for (size_t nIndex = 0; nIndex != prodTable.GetCount(); nIndex++)
		{
			Database::CFlybyItem* pItem = prodTable.GetItem(nIndex);

			strTemp.Format(_T("%s(%s)"), pItem->GetCellText(2), pItem->GetCellText(1));
			std::auto_ptr<GenerialPattern::CItemData> apNewItem(new GenerialPattern::CItemData());
			apNewItem->AddRange(pItem->GetCellText(0), strTemp,
				pItem->GetCellText(3), pItem->GetCellText(4), pItem->GetCellText(11),
				pItem->GetCellText(5), pItem->GetCellText(7), pItem->GetCellText(10), nullptr);
			auto pItemTemp = apNewItem.release();
			if (nIndex == 0)
			{
				pNormalItem = pItemTemp;
			}
			m_lstCurrentProd->AddItemData(nIndex, pItemTemp);
			pComboTrait->AddItem(nIndex, strTemp);
		}

		if (pNormalItem != nullptr)
		{
			//�������ݲ����¼���
			pProdFlow->SetCellText(nRow, 14, pNormalItem->at(0).c_str());
			pProdFlow->SetCellText(nRow, 1, pNormalItem->at(1).c_str());
			pProdFlow->SetCellText(nRow, 2, pNormalItem->at(2).c_str());
			pProdFlow->SetCellText(nRow, 3, pNormalItem->at(3).c_str());
			pProdFlow->SetCellText(nRow, 4, pNormalItem->at(4).c_str());
			pProdFlow->SetCellText(nRow, 6, pNormalItem->at(5).c_str());
			pProdFlow->SetCellText(nRow, 13, pNormalItem->at(6).c_str());

			//ͬʱ��������Ŀ
			pStockFlow = GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItemDetails().get();
			pStockFlow->SetCellText(nRow, 9, pNormalItem->at(0).c_str());	//��Ʒ����
			pStockFlow->SetCellText(nRow, 1, pNormalItem->at(1).c_str());	//Ʒ��
			pStockFlow->SetCellText(nRow, 2, pNormalItem->at(2).c_str());	//���
			pStockFlow->SetCellText(nRow, 3, pNormalItem->at(3).c_str());	//���
			pStockFlow->SetCellText(nRow, 6, pNormalItem->at(4).c_str());	//������λ
			pStockFlow->SetCellText(nRow, 4, pNormalItem->at(7).c_str());	//��浥��


			m_ListCtrl.SetItemText(nRow, 1, pNormalItem->at(1).c_str());
			m_ListCtrl.SetItemText(nRow, 2, pNormalItem->at(2).c_str());
			m_ListCtrl.SetItemText(nRow, 3, pNormalItem->at(3).c_str());
			m_ListCtrl.SetItemText(nRow, 4, pNormalItem->at(4).c_str());
			m_ListCtrl.SetItemText(nRow, 6, pNormalItem->at(5).c_str());
			m_ListCtrl.SetItemText(nRow, 13, pNormalItem->at(6).c_str());
		}
		else
		{
			//���򷴵�
			m_ListCtrl.SetItemText(nRow, 1, pProdFlow->GetCellText(nRow, 1));
		}

		bRet = strPrevious.Compare(pProdFlow->GetCellText(nRow, 14)) != 0;
	}
	else
	{
		strPrevious = pProdFlow->GetCellText(nRow, 17);
		m_lstCurrentSvs->ClearItemDatas();
		//��������ƥ�����Ŀ
		Database::CServiceFlowVector svsTable;
		strQuery.Format(_T("SELECT * FROM %s WHERE ���� LIKE '%s'"), svsTable.m_strBindTable, strKeyword);
		if (pDataBase->GetServiceFlow(strQuery, svsTable))
		{
			if (svsTable.GetCount() > 0)
			{
				bExactFound = TRUE;
			}
		}
		if (!bExactFound)
		{
			//���¿�ʼģ��ɸѡ
			strQuery.Format(_T("SELECT * FROM %s WHERE �ײ����� LIKE '%%%s%%' OR ���� LIKE '%%%s%%' OR �����豸 LIKE '%%%s%%' OR �ײ����� LIKE '%%%s%%' OR �ײͼ��� LIKE '%%%s%%' OR �ײ����� LIKE '%%%s%%' OR �ײ͹�� LIKE '%%%s%%' OR �Ʒѵ�λ LIKE '%%%s%%' OR �ײͼ۸� LIKE '%%%s%%';"),
				svsTable.m_strBindTable, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword, strKeyword);
			if (pDataBase->GetServiceFlow(strQuery, svsTable))
			{
				if (svsTable.GetCount() > 0)
				{
					bExactFound = TRUE;
				}
			}
		}

		CString strTemp;

		GenerialPattern::CItemData* pNormalItem = nullptr;

		for (size_t nIndex = 0; nIndex != svsTable.GetCount(); nIndex++)
		{
			Database::CFlybyItem* pItem = svsTable.GetItem(nIndex);

			strTemp.Format(_T("%s(%s)"), pItem->GetCellText(2), pItem->GetCellText(1));
			std::auto_ptr<GenerialPattern::CItemData> apNewItem(new GenerialPattern::CItemData());
			apNewItem->AddRange(pItem->GetCellText(0), strTemp,
				pItem->GetCellText(3), pItem->GetCellText(4), pItem->GetCellText(8),
				pItem->GetCellText(5), pItem->GetCellText(7), nullptr);
			auto pItemTemp = apNewItem.release();
			if (nIndex == 0)
			{
				pNormalItem = pItemTemp;
			}
			m_lstCurrentSvs->AddItemData(nIndex, pItemTemp);
			pComboTrait->AddItem(nIndex, strTemp);
		}

		if (pNormalItem != nullptr)
		{
			//�������ݲ����¼���
			pProdFlow->SetCellText(nRow, 17, pNormalItem->at(0).c_str());
			pProdFlow->SetCellText(nRow, 1, pNormalItem->at(1).c_str());
			pProdFlow->SetCellText(nRow, 2, pNormalItem->at(2).c_str());
			pProdFlow->SetCellText(nRow, 3, pNormalItem->at(3).c_str());
			pProdFlow->SetCellText(nRow, 4, pNormalItem->at(4).c_str());
			pProdFlow->SetCellText(nRow, 8, pNormalItem->at(5).c_str());
			pProdFlow->SetCellText(nRow, 16, pNormalItem->at(6).c_str());

			m_ListCtrl.SetItemText(nRow, 1, pNormalItem->at(1).c_str());
			m_ListCtrl.SetItemText(nRow, 2, pNormalItem->at(2).c_str());
			m_ListCtrl.SetItemText(nRow, 3, pNormalItem->at(3).c_str());
			m_ListCtrl.SetItemText(nRow, 4, pNormalItem->at(4).c_str());
			m_ListCtrl.SetItemText(nRow, 8, pNormalItem->at(5).c_str());
			m_ListCtrl.SetItemText(nRow, 16, pNormalItem->at(6).c_str());
		}
		else
		{
			//���򷴵�
			m_ListCtrl.SetItemText(nRow, 1, pProdFlow->GetCellText(nRow, 1));
		}
		bRet = strPrevious.Compare(pProdFlow->GetCellText(nRow, 17)) != 0;
	}
	return bRet;
}
#pragma endregion

void CSaleView::OnBeginLabelEdit(NMHDR *pNMHDR, LRESULT *pResult)
{
	LV_DISPINFO* pDispInfo = reinterpret_cast<LV_DISPINFO*>(pNMHDR);
	int nCol = pDispInfo->item.iSubItem;
	int nRow = pDispInfo->item.iItem;

	auto pDataSet = GetDocument()->GetDataset();
	auto pMainItem = pDataSet->GetPage(0)->GetCurrentTickitsItem();

	if (pMainItem->GetItem()->GetState() == Database::Initial)
	{
		*pResult = 0;
		return;
	}

	if (nCol == 1)
	{
		//���Ҳ�Ʒ���
		Database::CFlybyData* pDetails = nullptr;
		BOOL bGetSucc = pDataSet->GetCurrentFlybyData(0, (void**)&pDetails, FALSE);
		if (bGetSucc)
		{
			//�Ͽ����¼���
			CGridColumnTraitCombo* pComboTrait =
				reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(1));
			//�������¼����б�����
			pComboTrait->ClearFixedItems();

			Database::CFlybyItem* pCurrentItem = pDetails->GetItem(nRow);
			if (m_enumDetailsType == DataPattern::enumSalesTikits)
			{
				//������з�������
				m_lstCurrentSvs->ClearItemDatas();

				//����б������Ƿ���ڵ�ǰ��
				auto pFoundDataItem = m_lstCurrentProd->FindItem1(pCurrentItem->GetCellText(14));

				if (pFoundDataItem == nullptr)
				{
					int nLastID = m_lstCurrentProd->GetSize();
					//���б��в����ڵ�ǰ��Ŀ�����ֶ�׷��
					std::auto_ptr<GenerialPattern::CItemData> apNewItem(new GenerialPattern::CItemData());
					apNewItem->AddRange(pCurrentItem->GetCellText(14), pCurrentItem->GetCellText(1),
						pCurrentItem->GetCellText(2), pCurrentItem->GetCellText(3), pCurrentItem->GetCellText(4),
						pCurrentItem->GetCellText(6), pCurrentItem->GetCellText(13), nullptr);
					m_lstCurrentProd->AddItemData(nLastID, apNewItem.release());
				}

				const size_t nItemsCount = m_lstCurrentProd->GetSize();
				for (size_t i = 0; i != nItemsCount; i++)
				{
					pComboTrait->AddItem(i, m_lstCurrentProd->GetItemData(i)->at(1).c_str());
				}

			}
			else
			{
				//����б������Ƿ���ڵ�ǰ��
				m_lstCurrentProd->ClearItemDatas();
				//����б������Ƿ���ڵ�ǰ��
				auto pFoundDataItem = m_lstCurrentSvs->FindItem1(pCurrentItem->GetCellText(17));
				if (pFoundDataItem == nullptr)
				{
					int nLastID = m_lstCurrentSvs->GetSize();
					//���б��в����ڵ�ǰ��Ŀ�����ֶ�׷��
					std::auto_ptr<GenerialPattern::CItemData> apNewItem(new GenerialPattern::CItemData());
					apNewItem->AddRange(pCurrentItem->GetCellText(17), pCurrentItem->GetCellText(1),
						pCurrentItem->GetCellText(2), pCurrentItem->GetCellText(3), pCurrentItem->GetCellText(4),
						pCurrentItem->GetCellText(8), pCurrentItem->GetCellText(16), nullptr);
					m_lstCurrentSvs->AddItemData(nLastID, apNewItem.release());
				}

				const size_t nItemsCount = m_lstCurrentSvs->GetSize();;
				for (size_t i = 0; i != nItemsCount; i++)
				{
					pComboTrait->AddItem(i, m_lstCurrentSvs->GetItemData(i)->at(1).c_str());
				}
			}
		}
	}


	if (m_enumDetailsType == DataPattern::enumServiceTikits)
	{
		auto pItemDatas = pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();
		
		BOOL bIsTimeCount = pItemDatas->GetCellText(nRow, 14).Compare(_T("��ʱ")) == 0;
		switch (nCol)
		{
		case 5:
		case 6:
		case 7:
			if (bIsTimeCount)
			{
				//��������
				auto pRestrictTgt = m_ListCtrl.GetCellColumnTrait(nRow, 5);
				pRestrictTgt->SetCellReadOnly(FALSE);
				//����ʱ��
				pRestrictTgt = m_ListCtrl.GetCellColumnTrait(nRow, 6);
				pRestrictTgt->SetCellReadOnly();
				pRestrictTgt = m_ListCtrl.GetCellColumnTrait(nRow, 7);
				pRestrictTgt->SetCellReadOnly();
			}
			else
			{
				//��������
				auto pRestrictTgt = m_ListCtrl.GetCellColumnTrait(nRow, 5);
				pRestrictTgt->SetCellReadOnly();
				//����ʱ��
				pRestrictTgt = m_ListCtrl.GetCellColumnTrait(nRow, 6);
				pRestrictTgt->SetCellReadOnly(FALSE);
				pRestrictTgt = m_ListCtrl.GetCellColumnTrait(nRow, 7);
				pRestrictTgt->SetCellReadOnly(FALSE);
			}
			break;
		}
	}
	*pResult = 0;
}

void CSaleView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	auto spDataset = GetDocument()->GetDataset();

	Database::CFlybyData* pProdFlow = NULL;
	BOOL bSuccess = spDataset->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);

	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;

	switch (nCol)
	{
	case 1:
		if (pDispInfo->item.pszText != NULL)
		{
			BOOL bItemChanged = PSSelectAutoComplete(nRow, nCol, pDispInfo->item.pszText);
			if (bItemChanged)
			{
				ColculateSum(nRow);
				ColculateTotalSum();
				GetDocument()->AutoCompletePayment();
				//֪ͨ���¼���
				auto Status = spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
				GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
					Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
			}
		}
		break;
	case 4:
		//����۸�
		if (pDispInfo->item.pszText != NULL)
		{
			CString strPrevious = pProdFlow->GetCellText(nRow, nCol);
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			dblTemp = abs(dblTemp); //ֻȡ����ֵ
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			pProdFlow->SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);

			if (strPrevious.Compare(strTemp) != 0)
			{
				ColculateSum(nRow);
				ColculateTotalSum();
				GetDocument()->AutoCompletePayment();
				//֪ͨ���¼���
				auto Status = spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
				GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
					Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
			}
		}
		break;
	case 5: //������ʱ��һ��Ҫע����³��ⵥ
		if (pDispInfo->item.pszText != NULL)
		{
			CString strPrevious = pProdFlow->GetCellText(nRow, nCol);

			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			dblTemp = abs(dblTemp); //ֻ��ȡ����ֵ
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			pProdFlow->SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
			if (strPrevious.Compare(strTemp) != 0)
			{
				//������������
				if (m_enumDetailsType == DataPattern::enumSalesTikits)
				{
					auto pStockoutFlow = GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItemDetails();
					pStockoutFlow->SetCellText(nRow, 5, strTemp);

					//���¼��������
					TCHAR *tcsStop1 = nullptr, *tcsStop2 = nullptr;
					dblTemp = _tcstod(pStockoutFlow->GetCellText(nRow, 4), &tcsStop1)
						* _tcstod(pStockoutFlow->GetCellText(nRow, 5), &tcsStop2);

					strTemp.Format(_T("%.2f"), dblTemp);
					pStockoutFlow->SetCellText(nRow, 7, strTemp);
				}

				ColculateSum(nRow);
				ColculateTotalSum();
				GetDocument()->AutoCompletePayment();
				//���ͱ��֪ͨ
				auto Status = spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
				GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
					Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
			}
		}
		break;
	case 6:
	case 7:
		if (pDispInfo->item.pszText != NULL)
		{
			//����ʼʱ��
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				if (pProdFlow->GetCellText(nRow, 14).Compare(_T("��ʱ")) == 0)
				{
					pProdFlow->SetCellText(nRow, nCol, pDispInfo->item.pszText);
					//���¼�������
					COleDateTime timeStart, timeEnd;
					timeStart.ParseDateTime(pDispInfo->item.pszText);
					timeEnd.ParseDateTime(pProdFlow->GetCellText(nRow, 7));
					COleDateTimeSpan timePeriod = timeEnd - timeStart;
					double dblHours = timePeriod.GetTotalHours();
					dblHours = abs(dblHours); //����ֵ

					CString strTemp;
					strTemp.Format(_T("%.2f"), dblHours);
					if (pProdFlow->GetCellText(nRow, 5).Compare(strTemp) != 0)
					{
						pProdFlow->SetCellText(nRow, 5, strTemp);
						m_ListCtrl.SetItemText(nRow, 5, strTemp);

						ColculateSum(nRow);
						ColculateTotalSum();
						GetDocument()->AutoCompletePayment();
						//����֪ͨ�������
						auto Status = spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
						GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
							Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
					}
				}
			}
			else
			{
				if (nCol == 7)
				{
					//���������ۿ�
					CString strPrevious = pProdFlow->GetCellText(nRow, nCol);
					double dblTemp = { 0 };
					TCHAR* ptstrStop = nullptr;
					dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
					dblTemp = abs(dblTemp); //ֻȡ����ֵ
					CString strTemp;
					strTemp.Format(_T("%.2f"), dblTemp);
					pProdFlow->SetCellText(nRow, nCol, strTemp);
					m_ListCtrl.SetItemText(nRow, nCol, strTemp);

					if (strPrevious.Compare(strTemp) != 0)
					{
						ColculateSum(nRow);
						ColculateTotalSum();
						GetDocument()->AutoCompletePayment();
						//����֪ͨ�������
						auto Status = spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
						GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
							Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
					}
				}
			}
		}
		break; //�����ۿ�
	case 9: //�����ۿ�
		if (pDispInfo->item.pszText != NULL)
		{
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				CString strPrevious = pProdFlow->GetCellText(nRow, nCol);
				double dblTemp = { 0 };
				TCHAR* ptstrStop = nullptr;
				dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
				dblTemp = abs(dblTemp); //ֻȡ����ֵ
				CString strTemp;
				strTemp.Format(_T("%.2f"), dblTemp);
				pProdFlow->SetCellText(nRow, nCol, strTemp);
				m_ListCtrl.SetItemText(nRow, nCol, strTemp);

				if (strPrevious.Compare(strTemp) != 0)
				{
					ColculateSum(nRow);
					ColculateTotalSum();
					GetDocument()->AutoCompletePayment();
					//����֪ͨ�������
					auto Status = spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
					GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
						Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
				}
			}
		}
		break;
	case 10:
	case 11:
		if (pDispInfo->item.pszText != NULL)
		{
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				//CString strPrevious = pProdFlow->GetCellText(nRow, nCol);
				double dblTemp = { 0 };
				TCHAR* ptstrStop = nullptr;
				dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
				dblTemp = abs(dblTemp); //ֻȡ����ֵ
				CString strTemp;
				strTemp.Format(_T("%.2f"), dblTemp);
				pProdFlow->SetCellText(nRow, nCol, strTemp);
				m_ListCtrl.SetItemText(nRow, nCol, strTemp);
			}
		}
		break;  //����Ӷ��
	case 12:
	case 13:
		if (pDispInfo->item.pszText != NULL)
		{
			if (m_enumDetailsType == DataPattern::enumServiceTikits)
			{
				//CString strPrevious = pProdFlow->GetCellText(nRow, nCol);
				double dblTemp = { 0 };
				TCHAR* ptstrStop = nullptr;
				dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
				dblTemp = abs(dblTemp); //ֻȡ����ֵ
				CString strTemp;
				strTemp.Format(_T("%.2f"), dblTemp);
				pProdFlow->SetCellText(nRow, nCol, strTemp);
				m_ListCtrl.SetItemText(nRow, nCol, strTemp);
				//������״̬
				//if (strPrevious.Compare(strTemp) != 0)
				//{
				//	ColculateSum(nRow);
				//	ColculateTotalSum();
				//	AutoCompletePayment();
				//}
			}
			else
			{
				if (nCol == 12)
				{
					//���⴦�����۱�ע
					TCHAR tcsText[MAX_PATH];
					_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
					pProdFlow->SetCellText(nRow, nCol, tcsText);
					ColculateSum(nRow);
				}
			}
		}
		break;
	default:	//���Ҳ�Ʒ��Ϣ
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			pProdFlow->SetCellText(nRow, nCol, tcsText);
			//ColculateSum(nRow);
		}
		break;
	}

	*pResult = 0;
}

void CSaleView::OnUpdateEditSdNewitem(CCmdUI *pCmdUI)
{
	BOOL bEnabled = FALSE;
	//�鿴��ǰ���ݵ�
	auto spDataset = GetDocument()->GetDataset();
	if (spDataset->IsExistsPage(0) && !(spDataset->GetPage(0)->IsCurrentTickitsItemNULL()))
	{
		if (spDataset->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() !=
			Database::Initial)
		{
			bEnabled = TRUE;
		}
	}
	pCmdUI->Enable(bEnabled);
}


void CSaleView::OnEditSdNewitem()
{
	//��������������Ŀ
	BOOL bSucc = GetDocument()->CreateNewTicketItem(nullptr, m_enumDetailsType);
	//��ʱ
	if (bSucc)
	{
		//ˢ������
		GetDocument()->AutoCompletePayment();
		//����ͬ����Ϣ
		auto Status = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
		GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
			Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
		ReloadTableData();
		ColculateTotalSum();
	}
}

void CSaleView::OnUpdateEditSdModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	BOOL bEnable = pos != nullptr;

	pCmdUI->Enable(FALSE);

	auto pDataSet = GetDocument()->GetDataset();
	if (bEnable && pDataSet->IsExistsPage(0) && !pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
	{
		if( pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial )
		{
			pCmdUI->Enable();
		}
	}
}

void CSaleView::OnEditSdModify()
{
	m_ListCtrl.LocalModify();
}



void CSaleView::OnUpdateEditSdDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	BOOL bEnable = pos != nullptr;

	pCmdUI->Enable(FALSE);

	auto pDataSet = GetDocument()->GetDataset();
	if (bEnable && pDataSet->IsExistsPage(0) && !pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
	{
		if (pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial)
		{
			pCmdUI->Enable();
		}
	}
}

void CSaleView::OnEditSdDelete()
{
	m_ListCtrl.LocalDelete();
	GetDocument()->AutoCompletePayment();
	auto Status = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState();
	GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, Status,
		Business::DataPattern::enumTextBox, _T("IDC_PAYMENT_SUM"), 0, nullptr);
	ColculateTotalSum();
}


void CSaleView::OnUpdateEditSdRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);

	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(0) && !pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
	{
		if (pDataSet->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial)
		{
			pCmdUI->Enable();
		}
	}
}


void CSaleView::OnEditSdRefresh()
{
	GetDocument()->ReloadCurrentItem(TRUE);
	GetDocument()->AutoCompletePayment();
	auto CurrentItem = GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem();
	GetDocument()->SendSynchronizationMessage(nullptr, m_enumDetailsType, CurrentItem->GetState(),
		Business::DataPattern::enumAllControl, nullptr, 0, nullptr);
}


void CSaleView::OnUpdateEditSdRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(0) && !pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
	{
		Database::CFlybyData* pProdFlow = NULL;
		BOOL bSuccess = pDataSet->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
		pCmdUI->Enable(pProdFlow->GetCount() > 0);
	}
}


void CSaleView::OnEditSdRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CSaleView::OnUpdateEditSdFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(0) && !pDataSet->GetPage(0)->IsCurrentTickitsItemNULL())
	{
		Database::CFlybyData* pProdFlow = NULL;
		BOOL bSuccess = pDataSet->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
		pCmdUI->Enable(pProdFlow->GetCount() > 0);
	}
}


void CSaleView::OnEditSdFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}


HBRUSH CSaleView::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	return UI::VisualStyleHelper::OnCtlColor(pDC, pWnd, nCtlColor);
}
