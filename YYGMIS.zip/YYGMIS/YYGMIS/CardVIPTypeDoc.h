#pragma once
namespace BasicInfo
{
	// CCardVIPTypeDoc �ĵ�

	class CCardVIPTypeDoc : public CDocument
	{
		DECLARE_DYNCREATE(CCardVIPTypeDoc)

	public:
		CCardVIPTypeDoc();
		virtual ~CCardVIPTypeDoc();

	public:
		Database::CCardVIPTypesVector m_vector;
		Database::CCardVIPTypesVector m_vectNewItems;
		Database::CCardVIPTypesVector m_vectModItems;
		Database::CCardVIPTypesVector m_vectDelItems;

#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}
