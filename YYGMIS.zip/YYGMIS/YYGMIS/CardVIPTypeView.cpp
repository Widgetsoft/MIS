// CardVIPTypeView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "CardVIPTypeDoc.h"
#include "LocalDataGridView.h"
#include "CardVIPTypeView.h"

using namespace BasicInfo;
#define ID_GRID_CVIPTINFO 0x9007

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CCardVIPTypeView

IMPLEMENT_DYNCREATE(CCardVIPTypeView, CView)

CCardVIPTypeView::CCardVIPTypeView()
	:m_ListCtrl(IDR_POPUP_EDIT)
{
	m_uipCVIPTTimerID = -1;
}

CCardVIPTypeView::~CCardVIPTypeView()
{
}

BEGIN_MESSAGE_MAP(CCardVIPTypeView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CCardVIPTypeView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_CVIPTINFO, &CCardVIPTypeView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CCardVIPTypeView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CCardVIPTypeView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CCardVIPTypeView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CCardVIPTypeView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CCardVIPTypeView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CCardVIPTypeView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CCardVIPTypeView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CCardVIPTypeView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CCardVIPTypeView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CCardVIPTypeView::OnEditFind)
	ON_MESSAGE(WM_CVIPTINFO_CHANGED, &CCardVIPTypeView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CCardVIPTypeView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetCardVIPTypes(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 1; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

// CCardVIPTypeView ��ͼ

void CCardVIPTypeView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CCardVIPTypeView ���

#ifdef _DEBUG
void CCardVIPTypeView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CCardVIPTypeView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CCardVIPTypeDoc* CCardVIPTypeView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCardVIPTypeDoc)));
	return reinterpret_cast<CCardVIPTypeDoc*>(m_pDocument);
}
#endif //_DEBUG


// CCardVIPTypeView ��Ϣ��������


int CCardVIPTypeView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_CVIPTINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 1; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 7:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}


	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��Ա�����ͱ���"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CCardVIPTypeView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CCardVIPTypeView::OnEditNewitem()
{
	Database::CCardVIPTypes* pItemOpion = new Database::CCardVIPTypes();
	pItemOpion->SetState(Database::NewItem);
	GetDocument()->m_vector.AddItem(pItemOpion);
	GetDocument()->m_vectNewItems.AddItem(pItemOpion);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 1; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CCardVIPTypeView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 3:	
	case 4:
	case 5:
	case 6:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.6f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}



void CCardVIPTypeView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCardVIPTypeView::OnEditRefresh()
{
	this->LoadData();
}


void CCardVIPTypeView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CCardVIPTypeView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCardVIPTypeView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CCardVIPTypeView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CCardVIPTypeView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CCardVIPTypeView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CCardVIPTypeView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CCardVIPTypeView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CCardVIPTypeView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipCVIPTTimerID != UINT(-1))
	{
		KillTimer(m_uipCVIPTTimerID);
		m_uipCVIPTTimerID = UINT(-1);
	}
	m_uipCVIPTTimerID = SetTimer(21, 1021, NULL);
	return 0L;
}



void CCardVIPTypeView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipCVIPTTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipCVIPTTimerID != UINT(-1))
			{
				KillTimer(m_uipCVIPTTimerID);
				m_uipCVIPTTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
