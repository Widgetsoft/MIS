// StaffPWDChange.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "StaffPWDChange.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace BasicInfo;

// CStaffPWDChange �Ի���

IMPLEMENT_DYNAMIC(CStaffPWDChange, CDialogEx)

CStaffPWDChange::CStaffPWDChange(Database::CStaffInfo* pUserObject, CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_STAFF_PWDDLG, pParent),
	m_pUserObject(pUserObject)
{
	_tcscpy_s(m_tcsTitle, MAX_PATH, _T("����������ȷ����Ϣ��ִ�������޸�"));

	m_Icons.SetImageSize(CSize(32, 32));
	m_Icons.Load(IDB_STAFF_PASSWORD);

	CMFCControlRendererInfo params(_T(""), CLR_DEFAULT, CRect(0, 0, 350, 60), CRect(83, 58, 266, 1), CRect(0, 0, 0, 0), CRect(0, 0, 0, 0), FALSE);

	params.m_uiBmpResID = IDB_HEADERPART_1;
	m_Pat[0].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_2;
	m_Pat[1].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_3;
	m_Pat[2].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_4;
	m_Pat[3].Create(params);
}

CStaffPWDChange::~CStaffPWDChange()
{
}

void CStaffPWDChange::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_STAFF_LABEL1, m_label1);
	DDX_Control(pDX, IDC_STAFF_LABEL2, m_label2);
	DDX_Control(pDX, IDC_STAFF_LABEL3, m_label3);
	DDX_Control(pDX, IDC_STAFF_LABEL4, m_label4);
}


BEGIN_MESSAGE_MAP(CStaffPWDChange, CDialogEx)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IDOK, &CStaffPWDChange::OnBnClickedOk)
END_MESSAGE_MAP()


// CStaffPWDChange ��Ϣ��������


void CStaffPWDChange::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CRect rectClient;
	GetClientRect(&rectClient);

	CDrawingManager dm(dc);
	COLORREF clrFill = afxGlobalData.clrBarFace;
	CMFCControlRenderer* pRenderer = NULL;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_OFF_2007_BLUE:
		pRenderer = &m_Pat[1];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_BLACK:
		pRenderer = &m_Pat[2];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_SILVER:
		pRenderer = &m_Pat[0];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_AQUA:
		pRenderer = &m_Pat[3];
		break;
	default:
		pRenderer = &m_Pat[1];
		break;
	}
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialogEx::OnPaint()

	CRect rectHeader(0, 0, rectClient.right, 80);

	if (pRenderer != NULL)
	{

		pRenderer->Draw(&dc, rectHeader);
	}
	else
	{
		dm.FillGradient(rectHeader, dc.GetPixel(rectHeader.left, rectHeader.bottom), clrFill);
	}

	//2
	rectHeader.bottom -= 10;

	CRect rectIcon = rectHeader;
	rectIcon.left += 20;
	rectIcon.right = rectIcon.left + 32;

	m_Icons.DrawEx(&dc, rectIcon, 0, CMFCToolBarImages::ImageAlignHorzLeft, CMFCToolBarImages::ImageAlignVertCenter);

	CRect rectText = rectHeader;
	rectText.left = rectIcon.right + 10;
	rectText.right -= 20;

	CFont* pOldFont = dc.SelectObject(&afxGlobalData.fontBold);
	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(afxGlobalData.clrBarText);

	UINT uiFlags = DT_SINGLELINE | DT_VCENTER;

	CRect rectTextCalc = rectText;
	dc.DrawText(m_tcsTitle, rectTextCalc, uiFlags | DT_CALCRECT);

	if (rectTextCalc.right > rectText.right)
	{
		rectText.DeflateRect(0, 10);
		uiFlags = DT_WORDBREAK;
	}

	dc.DrawText(m_tcsTitle, rectText, uiFlags);

	dc.SelectObject(pOldFont);
}


BOOL CStaffPWDChange::OnEraseBkgnd(CDC* pDC)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	CDrawingManager dm(*pDC);
	dm.FillGradient(rcClient, RGB(236, 246, 237), RGB(255, 255, 255), TRUE);
	return TRUE;
}


BOOL CStaffPWDChange::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	SetDlgItemText(IDC_STAFF_NAME, m_pUserObject->GetCellText(1));
	SetDlgItemText(IDC_STAFF_UID, m_pUserObject->GetCellText(16));

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void BasicInfo::CStaffPWDChange::OnBnClickedOk()
{
	m_bOK = FALSE;
	// ��ʼִ���ж�
	CString strOldPWD, strNewPWD;
	GetDlgItemText(IDC_STAFF_OLDPWD, strOldPWD);
	GetDlgItemText(IDC_STAFF_NEWPWD, strNewPWD);

	if (strOldPWD.GetLength() < 1 || strNewPWD.GetLength() < 1)
	{
		MessageBox(_T("������������붼������Ϊ��,����������ȷ����Ϣ�����ԣ�"), _T("�����޸Ĳ��ɹ�"), MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	CString strQuery;
	strQuery.Format(_T("SELECT EPassword FROM tsw_tabStaffInfo WHERE EID LIKE '%s';"), m_pUserObject->GetCellText(0));
	GenerialPattern::CItemData* pItemData = nullptr;
	LOCALEDB;
	if (pDataBase->NormalGetItemData(strQuery, &pItemData) &&
		pItemData != nullptr)
	{
		CString strSaltedOldPwd, strSaltedPwd;		
		Helper::CToolkits::EncryptionAES256((PTSTR)(LPCTSTR)strOldPWD, theApp.m_strToken, strSaltedOldPwd);
		if (strSaltedOldPwd.Compare(pItemData->at(0).c_str()) == 0)
		{
			//����������
			Helper::CToolkits::EncryptionAES256((PTSTR)(LPCTSTR)strNewPWD, theApp.m_strToken, strSaltedPwd);
			strQuery.Format(_T("UPDATE tsw_tabStaffInfo SET EPassword = '%s'  WHERE EID LIKE '%s';")
				, strSaltedPwd, m_pUserObject->GetCellText(0));
			if (pDataBase->ExecuteNonQuery(strQuery))
			{
				m_bOK = TRUE;
			}
			else
			{
				MessageBox(_T("�����޸�ʱ�����������Ժ����ԣ�"), _T("�����޸Ĳ��ɹ�"), MB_OK | MB_ICONEXCLAMATION);
				return;
			}
		}
		else
		{
			MessageBox(_T("��������ľ����벻��ȷ,����������ȷ����������ԣ�"), _T("�����޸Ĳ��ɹ�"), MB_OK | MB_ICONEXCLAMATION);
			return;
		}
	}
	else
	{
		MessageBox(_T("���ݿ��ѯ�������������ԣ�"), _T("�����޸Ĳ��ɹ�"), MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	CDialogEx::OnOK();
}