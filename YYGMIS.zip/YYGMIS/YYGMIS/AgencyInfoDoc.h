#pragma once

namespace BasicInfo
{
	// CAgencyInfoDoc �ĵ�

	class CAgencyInfoDoc : public CDocument
	{
		DECLARE_DYNCREATE(CAgencyInfoDoc)

	public:
		CAgencyInfoDoc();
		virtual ~CAgencyInfoDoc();

	public:
		Database::CAgencyInfoVector m_vector;
		Database::CAgencyInfoVector m_vectNewItems;
		Database::CAgencyInfoVector m_vectModItems;
		Database::CAgencyInfoVector m_vectDelItems;

	public:

#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}
