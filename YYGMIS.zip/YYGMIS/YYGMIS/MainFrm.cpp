// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���  
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�  
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ������� 
// http://go.microsoft.com/fwlink/?LinkId=238214��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// MainFrm.cpp : CMainFrame ���ʵ��
//

#include "stdafx.h"
#include "YYGMIS.h"

#include "MainFrm.h"
#include "WorkspaceObj.h"
#include "SystemConfigPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWndEx)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND(ID_WINDOW_MANAGER, &CMainFrame::OnWindowManager)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(ID_VIEW_CAPTION_BAR, &CMainFrame::OnViewCaptionBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CAPTION_BAR, &CMainFrame::OnUpdateViewCaptionBar)
	ON_COMMAND(ID_TOOLS_OPTIONS, &CMainFrame::OnOptions)
	ON_WM_ACTIVATE()
	ON_WM_CLOSE()
END_MESSAGE_MAP()

// CMainFrame ����/����

CMainFrame::CMainFrame()
{
	// TODO: �ڴ����ӳ�Ա��ʼ������
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_WINDOWS_7);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	CMDITabInfo mdiTabParams;
	mdiTabParams.m_style = CMFCTabCtrl::STYLE_3D_ONENOTE; // ����������ʽ...
	mdiTabParams.m_bActiveTabCloseButton = TRUE;      // ����Ϊ FALSE �Ὣ�رհ�ť������ѡ�������Ҳ�
	mdiTabParams.m_bTabIcons = FALSE;    // ����Ϊ TRUE ���� MDI ѡ��������ĵ�ͼ��
	mdiTabParams.m_bAutoColor = TRUE;    // ����Ϊ FALSE ������ MDI ѡ����Զ���ɫ
	mdiTabParams.m_bDocumentMenu = TRUE; // ��ѡ�������ұ�Ե�����ĵ��˵�
	EnableMDITabbedGroups(TRUE, mdiTabParams);

	m_wndRibbonBar.Create(this);
	m_wndRibbonBar.LoadFromResource(IDR_RIBBON);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}

	CString strTitlePane1;
	CString strTitlePane2;
	bNameValid = strTitlePane1.LoadString(IDS_STATUS_PANE1);
	ASSERT(bNameValid);
	bNameValid = strTitlePane2.LoadString(IDS_STATUS_PANE2);
	ASSERT(bNameValid);
	m_wndStatusBar.AddElement(new CMFCRibbonStatusBarPane(ID_STATUSBAR_PANE1, strTitlePane1, TRUE), strTitlePane1);
	m_wndStatusBar.AddExtendedElement(new CMFCRibbonStatusBarPane(ID_STATUSBAR_PANE2, strTitlePane2, TRUE), strTitlePane2);

	// ���� Visual Studio 2005 ��ʽͣ��������Ϊ
	CDockingManager::SetDockingMode(DT_SMART);
	// ���� Visual Studio 2005 ��ʽͣ�������Զ�������Ϊ
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// �������񽫴�������࣬��˽���ʱ��������ͣ��: 
	EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM | CBRS_ALIGN_RIGHT);

	// ���������á�Outlook��������: 
	if (!CreateOutlookBar(m_wndNavigationBar, ID_VIEW_NAVIGATION, m_wndOutlookPane1, m_wndOutlookPane2,
		250))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}

	// ����������: 
	if (!CreateCaptionBar())
	{
		TRACE0("δ�ܴ���������\n");
		return -1;      // δ�ܴ���
	}

	// �Ѵ��� Outlook ����Ӧ���������ͣ����
	EnableDocking(CBRS_ALIGN_LEFT);
	EnableAutoHidePanes(CBRS_ALIGN_RIGHT);
	// ���ڳ־�ֵ�����Ӿ�����������ʽ
	OnApplicationLook(theApp.m_nAppLook);

	// ������ǿ�Ĵ��ڹ����Ի���
	EnableWindowsDialog(ID_WINDOW_MANAGER, ID_WINDOW_MANAGER, TRUE);

	// ���ĵ�����Ӧ�ó��������ڴ��ڱ������ϵ�˳����н�������
	// ���Ľ��������Ŀ����ԣ���Ϊ��ʾ���ĵ�����������ͼ��
	ModifyStyle(0, FWS_PREFIXTITLE);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		 | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE | WS_SYSMENU;

	return TRUE;
}

BOOL CMainFrame::CreateOutlookBar(CMFCOutlookBar& bar, UINT uiID, CMFCOutlookBarPane& pane1,
	CMFCOutlookBarPane& pane2, int nInitialWidth)
{
	bar.SetMode2003();

	if (!bar.Create(_T("��ݹ���"), this, CRect(0, 0, nInitialWidth, 32000), uiID, WS_CHILD | WS_VISIBLE |
		CBRS_LEFT))
	{
		return FALSE; //����ʧ��
	}

	CMFCOutlookBarTabCtrl* pOutlookBar = (CMFCOutlookBarTabCtrl*)bar.GetUnderlyingWindow();

	if (pOutlookBar == NULL)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	pOutlookBar->EnableInPlaceEdit(TRUE);

	static UINT uiPageID = 1;

	DWORD dwPaneStyle = AFX_DEFAULT_TOOLBAR_STYLE | CBRS_FLOAT_MULTI;

	//Can float, can autohide, can resize, can not close
	DWORD dwStyle = AFX_CBRS_FLOAT | AFX_CBRS_AUTOHIDE | AFX_CBRS_RESIZE;

	pane1.Create(&bar, dwPaneStyle, uiPageID++, dwStyle);
	pane1.SetOwner(this);
	pane1.EnableTextLabels();
	pane1.EnableDocking(CBRS_ALIGN_ANY);

	pane2.Create(&bar, dwPaneStyle, uiPageID++, dwStyle);
	pane2.SetOwner(this);
	pane2.EnableTextLabels();
	pane2.EnableDocking(CBRS_ALIGN_ANY);

	CImageList images;
	CBitmap bmp;
	if (!bmp.LoadBitmap(IDB_NAVIGATION_LARGE_HC))
	{
		return FALSE;
	}


	BITMAP bm;
	bmp.GetBitmap(&bm);

	UINT nFlags = ILC_MASK | ILC_COLOR24;

	images.Create(32, bm.bmHeight, nFlags, 0, 0);
	images.Add(&bmp, RGB(0, 0, 0));



	//��ʼ��������
	//AddWorkSpace(_T("ҵ�����"), 8, ID_BUSINESS_DATA, pane1, ID_BUSINESS_DATA, images);
	//AddWorkSpace(_T("������֪ͨ"), 9, ID_SERVICE_MSG, pane1, ID_SERVICE_MSG, images);
	pOutlookBar->AddControl(&pane1, _T("�ճ�ҵ��"), 0, TRUE, dwStyle);
	pane1.EnableTextLabels();
	pane1.EnableDocking(CBRS_ALIGN_ANY);
	pane1.EnablePageScrollMode();

	////pane1.SetDefaultState();

	//AddWorkSpace(_T("��������..."), 0, ID_BASICINFO_OPTIONS, pane2, ID_BASICINFO_OPTIONS, images);
	AddWorkSpace(_T("����ѡ��"), 0, ID_FILE_OPTIONS, pane2, ID_FILE_OPTIONS, images);
	AddWorkSpace(_T("��ҵ��Ϣ"), 1, ID_FILE_ENTINFO, pane2, ID_FILE_ENTINFO, images);
	AddWorkSpace(_T("������Ϣ"), 2, ID_FILE_AGENCY, pane2, ID_FILE_AGENCY, images);
	AddWorkSpace(_T("�ⷿ��Ϣ"), 3, ID_FILE_WAREHOUSE, pane2, ID_FILE_WAREHOUSE, images);
	AddWorkSpace(_T("ְ����Ϣ"), 4, ID_FILE_STAFF, pane2, ID_FILE_STAFF, images);
	AddWorkSpace(_T("�ͻ���Ϣ"), 5, ID_FILE_CUSTOMER, pane2, ID_FILE_CUSTOMER, images);
	pOutlookBar->AddControl(&pane2, _T("ϵͳ������Ϣ"), 0, TRUE, dwStyle);

	pane1.EnableTextLabels();
	pane1.EnableDocking(CBRS_ALIGN_ANY);
	pane1.EnablePageScrollMode();

	////pane2.SetDefaultState();

	bar.SetPaneStyle(bar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	bar.FillDefaultTabsOrderArray();

	return TRUE;
}

void CMainFrame::AddWorkSpace(const CString& strName, const int iIconIndex, const UINT uiCmd, CMFCOutlookBarPane& pane,
	const UINT uiNewCmdID, CImageList& images)
{
	//��������

	pane.AddButton(images.ExtractIcon(iIconIndex), strName, uiCmd);

	BOOL bIsAlreadyExist = FALSE;
	for (POSITION pos = m_lstWorkspaces.GetHeadPosition(); pos != NULL; )
	{
		CWorkspaceObj* pWS = (CWorkspaceObj*)m_lstWorkspaces.GetNext(pos);
		ASSERT_VALID(pWS);

		if (pWS->m_uiCmd == uiCmd)
		{
			bIsAlreadyExist = TRUE;
			break;
		}
	}

	if (!bIsAlreadyExist)
	{
		m_lstWorkspaces.AddTail(new CWorkspaceObj(strName, uiCmd, iIconIndex, uiNewCmdID));
	}
}

BOOL CMainFrame::CreateCaptionBar()
{
	if (!m_wndCaptionBar.Create(WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, this, ID_VIEW_CAPTION_BAR, -1, TRUE))
	{
		TRACE0("δ�ܴ���������\n");
		return FALSE;
	}

	BOOL bNameValid;

	CString strTemp, strTemp2;
	bNameValid = strTemp.LoadString(IDS_CAPTION_BUTTON);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetButton(strTemp, ID_TOOLS_OPTIONS, CMFCCaptionBar::ALIGN_LEFT, FALSE);
	bNameValid = strTemp.LoadString(IDS_CAPTION_BUTTON_TIP);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetButtonToolTip(strTemp);

	bNameValid = strTemp.LoadString(IDS_CAPTION_TEXT);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetText(strTemp, CMFCCaptionBar::ALIGN_LEFT);

	m_wndCaptionBar.SetBitmap(IDB_INFO, RGB(255, 255, 255), FALSE, CMFCCaptionBar::ALIGN_LEFT);
	bNameValid = strTemp.LoadString(IDS_CAPTION_IMAGE_TIP);
	ASSERT(bNameValid);
	bNameValid = strTemp2.LoadString(IDS_CAPTION_IMAGE_TEXT);
	ASSERT(bNameValid);
	m_wndCaptionBar.SetImageToolTip(strTemp, strTemp2);

	return TRUE;
}

// CMainFrame ���

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame ��Ϣ��������

void CMainFrame::OnWindowManager()
{
	ShowWindowsDialog();
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(TRUE);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}

void CMainFrame::OnViewCaptionBar()
{
	m_wndCaptionBar.ShowWindow(m_wndCaptionBar.IsVisible() ? SW_HIDE : SW_SHOW);
	RecalcLayout(FALSE);
}

void CMainFrame::OnUpdateViewCaptionBar(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndCaptionBar.IsVisible());
}

void CMainFrame::OnOptions()
{
	// Create "Customize" page:
	std::auto_ptr<CMFCRibbonCustomizePropertyPage> apPageCustomize(new CMFCRibbonCustomizePropertyPage(&m_wndRibbonBar));

	// Create "Options" and "Resources" pages:
	std::auto_ptr<UI::CSystemConfigPage> apPageRes(new UI::CSystemConfigPage);

	// Create property sheet:
	std::tr1::shared_ptr<UI::CSystemConfigSheet> spPropSheet(new UI::CSystemConfigSheet(this, 0));
	spPropSheet->EnablePageHeader(max(60, afxGlobalData.GetTextHeight() * 3));

	spPropSheet->m_psh.dwFlags |= PSH_NOAPPLYNOW;

	spPropSheet->SetLook(CMFCPropertySheet::PropSheetLook_List, 124);

	spPropSheet->AddPage(apPageRes.release());
	spPropSheet->AddPage(apPageCustomize.release());


	spPropSheet->DoModal();

	//CMFCRibbonCustomizeDialog *pOptionsDlg = new CMFCRibbonCustomizeDialog(this, &m_wndRibbonBar);
	//ASSERT(pOptionsDlg != NULL);

	//pOptionsDlg->DoModal();
	//delete pOptionsDlg;
}



BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	int n = 0;
	if (pMsg->message == WM_KEYDOWN)
	{
		CWnd* pFocus = GetFocus();
		switch (pMsg->wParam)
		{
		case _T('N'):
			n = pMsg->lParam & 0xFFFF;
			//Helper::CToolkits::breakDate(pMsg->time, nYear, nMonth, nDay, nHour, nMinute, nSecond);
			if (n)
			{
				CTime tm(pMsg->time);
				AfxMessageBox(tm.Format(_T("%Y��%m��%d�� %H:%M:%S")));
			}
			break;
		}
	}

	return CMDIFrameWndEx::PreTranslateMessage(pMsg);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext)
{
	// TODO: �ڴ�����ר�ô����/����û���

	if (!CMDIFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}

	for (int i = 0; i < uiLastUserToolBarId - uiFirstUserToolBarId + 1; i++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, IDS_CUSTOMIZE);
		}
	}

	return TRUE;
}


void CMainFrame::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CMDIFrameWndEx::OnActivate(nState, pWndOther, bMinimized);

	if (nState != WA_INACTIVE)
	{
		theApp.SetActiveFrame(CYYGMISApp::MainFrame);
		theApp.m_pMainWnd = this;
	}
}


void CMainFrame::OnClose()
{
	theApp.RequestRealExit();
	CMDIFrameWndEx::OnClose();
}
