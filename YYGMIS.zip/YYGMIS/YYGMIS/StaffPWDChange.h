#pragma once

#include "TransparentLabel.h"

namespace BasicInfo
{
	// CStaffPWDChange �Ի���

	class CStaffPWDChange : public CDialogEx
	{
		DECLARE_DYNAMIC(CStaffPWDChange)

	public:
		CStaffPWDChange(Database::CStaffInfo* pUserObject, CWnd* pParent = NULL);   // ��׼���캯��
		virtual ~CStaffPWDChange();

		// �Ի�������
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_STAFF_PWDDLG };
#endif

	private:
		UI::Control::CTransparentLabel m_label1;
		UI::Control::CTransparentLabel m_label2;
		UI::Control::CTransparentLabel m_label3;
		UI::Control::CTransparentLabel m_label4;

		Database::CStaffInfo* m_pUserObject;

	private:
		CMFCControlRenderer m_Pat[4];
		CMFCToolBarImages	m_Icons;
		CImageList			m_ImageList;
		TCHAR				m_tcsTitle[MAX_PATH];

	public:
		BOOL m_bOK;

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		afx_msg void OnPaint();
		afx_msg BOOL OnEraseBkgnd(CDC* pDC);
		afx_msg void OnBnClickedOk();
		virtual BOOL OnInitDialog();
	};
}