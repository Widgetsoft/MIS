// InventoryView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "InventoryDoc.h"
#include "LocalDataGridView.h"
#include "InventoryView.h"
#include "InvBalPickupDlg.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define ID_GRID_BUS_INVT 0x6000

// CInventoryView

IMPLEMENT_DYNCREATE(CInventoryView, CView)

CInventoryView::CInventoryView()
	:m_ListCtrl(IDR_POPUP_BUSINESS_INV),
	m_uipInvtTimerID(-1)
{

}

CInventoryView::~CInventoryView()
{
}

void CInventoryView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s"), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetInventories(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 3; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

BEGIN_MESSAGE_MAP(CInventoryView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_SELINVITEM, &CInventoryView::OnEditSelinvitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_BUS_INVT, &CInventoryView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CInventoryView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CInventoryView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CInventoryView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CInventoryView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CInventoryView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CInventoryView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CInventoryView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CInventoryView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CInventoryView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CInventoryView::OnEditFind)
	ON_MESSAGE(WM_PRODINFO_CHANGED, &CInventoryView::OnDataChanged)
	ON_MESSAGE(WM_WSPINFO_CHANGED, &CInventoryView::OnDataChanged)
	ON_MESSAGE(WM_PSOPTION_CHANGED, &CInventoryView::OnDataChanged)
	ON_MESSAGE(WM_PRODBAL_CHANGED, &CInventoryView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CInventoryView ��ͼ

void CInventoryView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CInventoryView ���

#ifdef _DEBUG
void CInventoryView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CInventoryView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CInventoryDoc* CInventoryView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CInventoryDoc)));
	return reinterpret_cast<CInventoryDoc*>(m_pDocument);
}
#endif //_DEBUG


// CInventoryView ��Ϣ��������


int CInventoryView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_BUS_INVT);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 3; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 7:
			pTrait = new CGridColumnTraitEdit;
			break;
		default:
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}


	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��������Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CInventoryView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CInventoryView::OnEditSelinvitem()
{
	std::vector<CString> vectNewItemIDs;
	for each (auto iter in GetDocument()->m_vector)
	{
		CString strTemp = iter->GetCellText(8);
		strTemp.Append(iter->GetCellText(9));
		vectNewItemIDs.push_back(strTemp);
	}

	auto nNewGlue = GetDocument()->m_vector.GetCount();

	Database::CInventoriesVector vectNew;
	std::shared_ptr<CInvBalPickupDlg> pPickDlg(new CInvBalPickupDlg(&vectNew, vectNewItemIDs));
	pPickDlg->DoModal();

	auto nFinalCount = nNewGlue + vectNew.GetCount();
	for (auto iter : vectNew)
	{
		auto newItem = GetDocument()->m_vector.NewItem();
		for (UINT uiIter = 1; uiIter != iter->GetColCount(); uiIter++)
		{
			newItem->SetCellText(uiIter, iter->GetCellText(uiIter));
		}
		newItem->SetState(Database::NewItem);
		GetDocument()->m_vector.AddItem(newItem);
		GetDocument()->m_vectNewItems.AddItem(newItem);
	} 
	if (nFinalCount > nNewGlue)
	{
		int nItem = (int)nNewGlue;
		for (int rowId = nItem; rowId != nFinalCount; rowId++)
		{
			m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
			nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
			m_ListCtrl.SetItemData(nItem, rowId);
			for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 3; ++col)
			{
				int nCellCol = col + 1;	// +1 because of hidden column
				const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
				m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
			}
		}

		GetDocument()->SetModifiedFlag();
		m_ListCtrl.ClearSelections();
		m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
		m_ListCtrl.EnsureVisible(nItem, TRUE);
	}
}

void CInventoryView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 7:
		if (pDispInfo->item.pszText != NULL)
		{
			GetDocument()->m_vector.SetCellText(nRow, nCol, pDispInfo->item.pszText);
			m_ListCtrl.SetItemText(nRow, nCol, GetDocument()->m_vector.GetCellText(nRow, nCol));
		}
		break;
	default:
		break;
	}
	*pResult = 0;
}

void CInventoryView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CInventoryView::OnEditRefresh()
{
	this->LoadData();
}


void CInventoryView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
	if (theApp.m_bInitialized)
	{
		pCmdUI->Enable(FALSE);
	}
}


void CInventoryView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CInventoryView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
	if (theApp.m_bInitialized)
	{
		pCmdUI->Enable(FALSE);
	}
}


void CInventoryView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CInventoryView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CInventoryView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CInventoryView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CInventoryView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CInventoryView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipInvtTimerID != UINT(-1))
	{
		KillTimer(m_uipInvtTimerID);
		m_uipInvtTimerID = UINT(-1);
	}
	m_uipInvtTimerID = SetTimer(40, 1040, NULL);
	return 0L;
}



void CInventoryView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipInvtTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipInvtTimerID != UINT(-1))
			{
				KillTimer(m_uipInvtTimerID);
				m_uipInvtTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
