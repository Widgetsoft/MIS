#pragma once

namespace UI
{
	namespace Business
	{
		class COptionsPage;
		// COptionsDlg

		class COptionsDlg : public CMFCPropertySheet
		{
			DECLARE_DYNAMIC(COptionsDlg)


			// Construction
		public:
			COptionsDlg(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

			// Attributes
		public:
			COptionsPage*  m_pPage11;

			// Implementation
		public:
			virtual ~COptionsDlg();

		protected:
			DECLARE_MESSAGE_MAP()
		};
	}
}
