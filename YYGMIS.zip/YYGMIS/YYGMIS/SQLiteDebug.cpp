// SQLiteDebug.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "SQLiteDebug.h"
#include "afxdialogex.h"


// CSQLiteDebug �Ի���

IMPLEMENT_DYNAMIC(CSQLiteDebug, CDialogEx)

CSQLiteDebug::CSQLiteDebug(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_SQLITECONSOLE, pParent)
{

}

CSQLiteDebug::~CSQLiteDebug()
{
}

void CSQLiteDebug::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSQLiteDebug, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSQLiteDebug::OnBnClickedOk)
END_MESSAGE_MAP()


// CSQLiteDebug ��Ϣ��������


BOOL CSQLiteDebug::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_SQLITE_SQLRESULT);
	pEdit->SetLimitText(20000);
	((CEdit*)GetDlgItem(IDC_SQLITE_SQL))->SetLimitText(50000);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}


void CSQLiteDebug::OnBnClickedOk()
{
	CString strCommand;
	GetDlgItemText(IDC_SQLITE_SQL, strCommand);
	if (strCommand.GetLength() < 1)
	{
		return;
	}
	Concurrency::concurrent_vector< Concurrency::concurrent_vector<CString>* >* pRetTable =
		new Concurrency::concurrent_vector< Concurrency::concurrent_vector<CString>* >();
	LOCALEDB;
	if (pDataBase)
	{
		if ((strCommand.Mid(0, 6)).CompareNoCase(_T("SELECT")) == 0)
		{
			BOOL bRet = pDataBase->NormalQuery(strCommand, (PVOID*)&pRetTable, TRUE);
			if (bRet)
			{
				CString strResult;
				for (Concurrency::concurrent_vector< Concurrency::concurrent_vector<CString>* >::iterator it =
					pRetTable->begin(); it != pRetTable->end(); it++)
				{
					for (Concurrency::concurrent_vector<CString>::iterator itInner = (*it)->begin();
					itInner != (*it)->end(); itInner++)
					{
						CString strContent;
						strContent.Format(_T("%38s\t"), *itInner);
						strResult.Append(strContent);
						//= *itInner;
					}
					strResult.TrimRight(_T('\t'));
					strResult.Append(_T("\r\n"));
				}
				SetDlgItemText(IDC_SQLITE_SQLRESULT, strResult);
			}
		}
		else
		{
			if (strCommand.MakeLower().Find(_T("trigger")) != -1)
			{
				pDataBase->ExecuteNonQuery(strCommand.AllocSysString());
			}
			else
			{
				Concurrency::concurrent_vector<STDString> vectText;
				Helper::CToolkits::Split(strCommand.AllocSysString(), _T(";"), &vectText);
				pDataBase->ExecuteNonQueryBatch(&vectText, TRUE);
			}
		}
	}
	for (Concurrency::concurrent_vector< Concurrency::concurrent_vector<CString>* >::reverse_iterator it = pRetTable->rbegin();
	it != pRetTable->rend(); it++)
	{
		delete *it;
	}

	delete pRetTable;
}
