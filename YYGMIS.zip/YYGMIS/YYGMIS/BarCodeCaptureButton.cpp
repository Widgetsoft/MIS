// BarCodeCaptureButton.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "BarCodeCaptureButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace UI::Business;

// CBarCodeCaptureButton
IMPLEMENT_SERIAL(CBarCodeCaptureButton, CMFCToolBarComboBoxButton, 1)

BOOL CBarCodeCaptureButton::m_bHasFocus = FALSE;

BOOL CBarCodeCaptureButton::NotifyCommand(int iNotifyCode)
{
	BOOL bRes = CMFCToolBarComboBoxButton::NotifyCommand(iNotifyCode);
	switch (iNotifyCode)
	{
	case CBN_KILLFOCUS:
		m_bHasFocus = FALSE;
		bRes = TRUE;
		break;
	case CBN_SETFOCUS:
		m_bHasFocus = TRUE;
		bRes = TRUE;
		break;
	}

	return bRes;
}