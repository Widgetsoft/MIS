// WSPView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "WSPDoc.h"
#include "LocalDataGridView.h"
#include "WSPView.h"

using namespace BasicInfo;

#define ID_GRID_WSPINFO 0x9003

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
// CWSPView

IMPLEMENT_DYNCREATE(CWSPView, CView)

CWSPView::CWSPView()
	:m_ListCtrl(IDR_POPUP_EDIT),
	m_spEnterpriseDatas( new GenerialPattern::CItemsData())
{
	m_uipEntInfoTimerID = -1;
	m_uipWSPInfoTimerID = -1;
}

CWSPView::~CWSPView()
{
}

BEGIN_MESSAGE_MAP(CWSPView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CWSPView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_WSPINFO, &CWSPView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CWSPView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CWSPView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CWSPView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CWSPView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CWSPView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CWSPView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CWSPView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CWSPView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CWSPView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CWSPView::OnEditFind)
	ON_MESSAGE(WM_ENTINFO_CHANGED, &CWSPView::OnEntInfoDataChanged)
	ON_MESSAGE(WM_WSPINFO_CHANGED, &CWSPView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CWSPView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetWareHouseSalePoint(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 10)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

void CWSPView::LoadEntInfoes()
{
	m_spEnterpriseDatas->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(3));

	ASSERT(pComboTrait != NULL);
	pComboTrait->ClearFixedItems();


	LOCALEDB;
	GenerialPattern::CItemsData* pTempTable = nullptr;

	if (pDataBase != NULL &&  pDataBase->NormalGetItemsData(_T("SELECT compID ��ҵ����, compName ��ҵ����, compPhoneNum �绰����, compFaxNum �������, compValidAddr ע���ַ, compEmail ���ʵ�ַ, URL ��ҵ��ַ, compAddr ��ϵ��ַ, LegalRepresentative ��ҵ����, Memo ��ע, JM ���� FROM tsw_tabEnterpriseInfo WHERE  IsUsing = 1;"), &pTempTable))
	{
		int i = 0;
		for each (auto item in *pTempTable)
		{
			pComboTrait->AddItem(i, item.second->at(1).c_str());
			auto pData1 = new GenerialPattern::CItemData();
			pData1->AddRange(item.second->at(0).c_str(),
				item.second->at(1).c_str(),
				item.second->at(2).c_str(),
				item.second->at(3).c_str(),
				item.second->at(4).c_str(),
				item.second->at(5).c_str(),
				item.second->at(6).c_str(),
				item.second->at(7).c_str(),
				item.second->at(8).c_str(),
				item.second->at(9).c_str(),
				item.second->at(10).c_str(),
				NULL);
			m_spEnterpriseDatas->AddItemData(i, pData1);
			i++;
		}
		delete pTempTable;
	}

	const size_t itemCount = GetDocument()->m_vector.GetCount();
	for (int j = 0; j != itemCount; j++)
	{
		m_ListCtrl.SetItemText(j, 3, GetDocument()->m_vector.GetCellText(j, 3));
	}

	m_ListCtrl.RedrawItems(0, (int)(itemCount - 1));
}

// CWSPView ��ͼ

void CWSPView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CWSPView ���

#ifdef _DEBUG
void CWSPView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CWSPView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif

CWSPDoc* CWSPView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWSPDoc)));
	return reinterpret_cast<CWSPDoc*>(m_pDocument);
}
#endif //_DEBUG


// CWSPView ��Ϣ��������


int CWSPView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_WSPINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 3:
			pTrait = new CGridColumnTraitCombo();
			break;
		case 1:
		case 5:
		case 9:
		case 12:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 10:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("ͣ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("����"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 11:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("��"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 13:
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	LoadData();
	LoadEntInfoes();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("�ⷿ����������"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CWSPView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}




void CWSPView::OnEditNewitem()
{
	if (m_spEnterpriseDatas->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κε�ǰ��ҵ��Ϣ���޷�����ִ�иò�����"), _T("�����ⷿ����������ʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	Database::CWareHouseSalePoint* pItem = new Database::CWareHouseSalePoint();
	pItem->SetState(Database::NewItem);

	//1������ѡ��Ĭ��ֵ
	auto pOptionItem = m_spEnterpriseDatas->GetItemData(0);
	pItem->SetCellText(18, pOptionItem->at(0).c_str());
	pItem->SetCellText(3, pOptionItem->at(1).c_str());

	pItem->SetCellText(10, _T("1"));
	pItem->SetCellText(11, _T("1"));

	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	pItem->SetCellText(14, timeNow.Format());
	pItem->SetCellText(15, timeNow.Format());

	//���õ�ǰ��¼�û�
	pItem->SetCellText(16, _T("00000000-0000-0000-0000-000000000000"));
	pItem->SetCellText(17, _T("00000000-0000-0000-0000-000000000000"));

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 6; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 10)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}


void CWSPView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 2: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 13, tcsText);
				m_ListCtrl.SetItemText(nRow, 13, tcsText);
			}
		}
		break;
	case 3:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spEnterpriseDatas, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 18, varPair.first.c_str());
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CWSPView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CWSPView::OnEditRefresh()
{
	this->LoadData();
}


void CWSPView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CWSPView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CWSPView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CWSPView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CWSPView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CWSPView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CWSPView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CWSPView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CWSPView::OnEntInfoDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipEntInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipEntInfoTimerID);
		m_uipEntInfoTimerID = UINT(-1);
	}
	m_uipEntInfoTimerID = SetTimer(5, 1005, NULL);
	return 0L;
}

LRESULT CWSPView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipWSPInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipWSPInfoTimerID);
		m_uipWSPInfoTimerID = UINT(-1);
	}
	m_uipWSPInfoTimerID = SetTimer(6, 1006, NULL);
	return 0L;
}

void CWSPView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipEntInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipEntInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipEntInfoTimerID);
				m_uipEntInfoTimerID = UINT(-1);
			}
			LoadEntInfoes(); //���¼��������б�
			LoadData();
		}
	}
	else if (m_uipWSPInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipWSPInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipWSPInfoTimerID);
				m_uipWSPInfoTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
