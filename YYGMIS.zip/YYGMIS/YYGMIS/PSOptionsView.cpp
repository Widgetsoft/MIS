// PSOptionsView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "PSOptionsDoc.h"
#include "LocalDataGridView.h"
#include "PSOptionsView.h"

#define ID_GRID_PSOPTION 0x9010
using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPSOptionsView

IMPLEMENT_DYNCREATE(CPSOptionsView, CView)

CPSOptionsView::CPSOptionsView()
	:m_ListCtrl( IDR_POPUP_EDIT )
{
	m_uipPSOTimerID = -1;
}

CPSOptionsView::~CPSOptionsView()
{
}

BEGIN_MESSAGE_MAP(CPSOptionsView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CPSOptionsView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_PSOPTION, &CPSOptionsView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CPSOptionsView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CPSOptionsView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CPSOptionsView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CPSOptionsView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CPSOptionsView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CPSOptionsView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CPSOptionsView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CPSOptionsView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CPSOptionsView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CPSOptionsView::OnEditFind)
	ON_MESSAGE(WM_PSOPTION_CHANGED, &CPSOptionsView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()

void CPSOptionsView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 5; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

// CPSOptionsView ��ͼ

void CPSOptionsView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CPSOptionsView ���

#ifdef _DEBUG
void CPSOptionsView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CPSOptionsView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CPSOptionsDoc* CPSOptionsView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPSOptionsDoc)));
	return reinterpret_cast<CPSOptionsDoc*>(m_pDocument);
}
#endif //_DEBUG


// CPSOptionsView ��Ϣ��������

int CPSOptionsView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_PSOPTION);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitCombo* pComboTrait = nullptr;
	int idCat = 0;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 5; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;


		switch (col + 1)
		{
		case 1://ѡ���
			pComboTrait = new CGridColumnTraitCombo();
			pComboTrait->AddItem(idCat++, _T("��Ʒ���"));
			pComboTrait->AddItem(idCat++, _T("��Ʒ���"));
			pComboTrait->AddItem(idCat++, _T("��Ʒ����λ"));
			pComboTrait->AddItem(idCat++, _T("��Ʒ����λ"));
			pComboTrait->AddItem(idCat++, _T("�����ײ����"));
			pComboTrait->AddItem(idCat++, _T("�����ײ͹��"));
			pComboTrait->AddItem(idCat++, _T("�����ײ�����λ"));
			pComboTrait->AddItem(idCat++, _T("�����ײ͸���λ"));

			m_vectCategory.push_back(_T("��Ʒ���"));
			m_vectCategory.push_back(_T("��Ʒ���"));
			m_vectCategory.push_back(_T("��Ʒ����λ"));
			m_vectCategory.push_back(_T("��Ʒ����λ"));
			m_vectCategory.push_back(_T("�����ײ����"));
			m_vectCategory.push_back(_T("�����ײ͹��"));
			m_vectCategory.push_back(_T("�����ײ�����λ"));
			m_vectCategory.push_back(_T("�����ײ͸���λ"));
			pTrait = pComboTrait;
			break;
		case 3:
		case 4:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 5:
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}


	LoadData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��Ʒ������ѡ�����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CPSOptionsView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CPSOptionsView::OnEditNewitem()
{
	Database::CProductOptions* pItemOpion = new Database::CProductOptions();
	pItemOpion->SetState(Database::NewItem);
	pItemOpion->SetCellText(1, _T("��Ʒ���"));
	GetDocument()->m_vector.AddItem(pItemOpion);
	GetDocument()->m_vectNewItems.AddItem(pItemOpion);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 5; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CPSOptionsView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 2: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 5, tcsText);
				m_ListCtrl.SetItemText(nRow, 5, tcsText);
			}
		}
		break;
	case 1:	//������������
		if (pDispInfo->item.pszText != NULL)
		{
			auto strFindText = GenerialPattern::CItemData::ParallelFind(m_vectCategory,
				pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strFindText.c_str());
			m_ListCtrl.SetItemText(nRow, nCol, GetDocument()->m_vector.GetCellText(nRow, nCol));
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}



void CPSOptionsView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CPSOptionsView::OnEditRefresh()
{
	this->LoadData();
}


void CPSOptionsView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CPSOptionsView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CPSOptionsView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CPSOptionsView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CPSOptionsView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CPSOptionsView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CPSOptionsView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CPSOptionsView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}


LRESULT CPSOptionsView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipPSOTimerID != UINT(-1))
	{
		KillTimer(m_uipPSOTimerID);
		m_uipPSOTimerID = UINT(-1);
	}
	m_uipPSOTimerID = SetTimer(30, 1030, NULL);
	return 0L;
}

void CPSOptionsView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipPSOTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipPSOTimerID != UINT(-1))
			{
				KillTimer(m_uipPSOTimerID);
				m_uipPSOTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}
	CView::OnTimer(nIDEvent);
}
