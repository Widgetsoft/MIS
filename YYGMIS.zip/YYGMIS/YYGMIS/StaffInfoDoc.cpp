// StaffInfoDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "StaffInfoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace BasicInfo;

// CStaffInfoDoc

IMPLEMENT_DYNCREATE(CStaffInfoDoc, CDocument)

CStaffInfoDoc::CStaffInfoDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CStaffInfoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("Ա����Ϣά��"));
	return TRUE;
}

CStaffInfoDoc::~CStaffInfoDoc()
{
}


BEGIN_MESSAGE_MAP(CStaffInfoDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CStaffInfoDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CStaffInfoDoc::OnFileSave)
END_MESSAGE_MAP()


// CStaffInfoDoc ���

#ifdef _DEBUG
void CStaffInfoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CStaffInfoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CStaffInfoDoc ���л�

void CStaffInfoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CStaffInfoDoc ����


BOOL CStaffInfoDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CStaffInfoDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CStaffInfoDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	CString strTemp;
	Helper::CToolkits::EncryptionAES256(_T("1234567890"), theApp.m_strToken, strTemp);

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabStaffInfo(EID, EName, deptID, ESex, ETitleID, EDutyID, ESalary, EDegreeID, EBirthday, EPID, EEmail, EPhoneNum, EPostCode, EAddress, EMemo, JM, UID, EPassword, EIsOperator, EIsAdjusting, EIsRollBack, EIsPurchase, EIsSales, EIsStoreIn, EIsStoreOut, EIsUsing, CreateDate, ModifyDate, CreatedUser, ModifierUser) VALUES('%s', '%s', '%s', '%s', '%s', '%s', %s, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', %s, %s, %s, %s, %s, %s, %s, %s, DATETIME('now', 'localtime'), DATETIME('now', 'localtime'), '%s', '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 33),
			m_vectNewItems.GetCellText(i, 3),
			m_vectNewItems.GetCellText(i, 28),
			m_vectNewItems.GetCellText(i, 29),
			m_vectNewItems.GetCellText(i, 6),
			m_vectNewItems.GetCellText(i, 30),
			Database::CFlybyItem::FormatDate(m_vectNewItems.GetCellText(i, 8)),
			m_vectNewItems.GetCellText(i, 9),
			m_vectNewItems.GetCellText(i, 10),
			m_vectNewItems.GetCellText(i, 11),
			m_vectNewItems.GetCellText(i, 12),
			m_vectNewItems.GetCellText(i, 13),
			m_vectNewItems.GetCellText(i, 14),
			m_vectNewItems.GetCellText(i, 15),
			m_vectNewItems.GetCellText(i, 16),
			strTemp,
			(m_vectNewItems.GetCellText(i, 18).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 19).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 20).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 21).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 22).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 23).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 24).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 25).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			m_vectNewItems.GetCellText(i, 31),
			m_vectNewItems.GetCellText(i, 32));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabStaffInfo SET EName = '%s', deptID = '%s', ESex = '%s', ETitleID = '%s', EDutyID = '%s', ESalary = %s, EDegreeID = '%s', EBirthday = '%s', EPID = '%s', EEmail = '%s', EPhoneNum = '%s', EPostCode = '%s', EAddress = '%s', EMemo = '%s', JM = '%s', UID = '%s', EIsOperator = %s, EIsAdjusting = %s, EIsRollBack = %s, EIsPurchase = %s, EIsSales = %s, EIsStoreIn = %s, EIsStoreOut = %s, EIsUsing = %s,  ModifyDate = DATETIME('now','localtime'), ModifierUser = '%s'  WHERE EID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 33),
			m_vectModItems.GetCellText(i, 3),
			m_vectModItems.GetCellText(i, 28),
			m_vectModItems.GetCellText(i, 29),
			m_vectModItems.GetCellText(i, 6),
			m_vectModItems.GetCellText(i, 30),
			Database::CFlybyItem::FormatDate(m_vectModItems.GetCellText(i, 8)),
			m_vectModItems.GetCellText(i, 9),
			m_vectModItems.GetCellText(i, 10),
			m_vectModItems.GetCellText(i, 11),
			m_vectModItems.GetCellText(i, 12),
			m_vectModItems.GetCellText(i, 13),
			m_vectModItems.GetCellText(i, 14),
			m_vectModItems.GetCellText(i, 15),
			m_vectModItems.GetCellText(i, 16),
			(m_vectModItems.GetCellText(i, 18).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 19).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 20).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 21).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 22).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 23).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 24).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 25).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			m_vectModItems.GetCellText(i, 32),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabStaffInfo WHERE EID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_STAFFINFO_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("ְ����Ϣ���ݱ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
