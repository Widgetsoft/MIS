#pragma once
class CSystemInfo
{
public:
	CSystemInfo(BOOL bAutoGrow = FALSE);
	~CSystemInfo();

public:
	TCHAR m_strEntID[50];
	TCHAR m_strEntName[120];
	TCHAR m_strDeptID[50];
	TCHAR m_strDeptName[120];
	TCHAR m_strUserInnerID[50];
	TCHAR m_strUserName[20];
	TCHAR m_strUserID[20];

	BOOL m_bAutoGrow;
};

