#pragma once
namespace Business
{
	namespace Core
	{
		class CSaleBatchSaveWorker
		{
		public:
			CSaleBatchSaveWorker(CProgressCtrl& progressTotal, CProgressCtrl& progressSub, HWND hParentWnd);
			~CSaleBatchSaveWorker();

		public:
			BOOL ExecuteSaveBatch( std::shared_ptr<DataPattern::CTickitsData> pDataItems,
				concurrency::concurrent_vector<std::shared_ptr<DataPattern::SCTicketIDGroupPure>> vectEntity,
				CString& strMessage) noexcept;

		private:

			CProgressCtrl& m_progressTotal;
			CProgressCtrl& m_progressSub;
			HWND m_hParentWnd;
		};
	}
}

