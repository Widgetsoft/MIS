// CardVIPTypeDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "CardVIPTypeDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CCardVIPTypeDoc

IMPLEMENT_DYNCREATE(CCardVIPTypeDoc, CDocument)

CCardVIPTypeDoc::CCardVIPTypeDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CCardVIPTypeDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("��Ա�ȼ���Ϣ"));
	return TRUE;
}

CCardVIPTypeDoc::~CCardVIPTypeDoc()
{
}


BEGIN_MESSAGE_MAP(CCardVIPTypeDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CCardVIPTypeDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CCardVIPTypeDoc::OnFileSave)
END_MESSAGE_MAP()


// CCardVIPTypeDoc ���

#ifdef _DEBUG
void CCardVIPTypeDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CCardVIPTypeDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CCardVIPTypeDoc ���л�

void CCardVIPTypeDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CCardVIPTypeDoc ����


BOOL CCardVIPTypeDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CCardVIPTypeDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CCardVIPTypeDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabCardVIPTypes(CTID, CTCustomCode, CTName, DepositRate, SalesRate, ServiceRate, IntegralRate, CTMemo) VALUES('%s', '%s', '%s', %s, %s, %s, %s, '%s' );"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 3),
			m_vectNewItems.GetCellText(i, 4),
			m_vectNewItems.GetCellText(i, 5),
			m_vectNewItems.GetCellText(i, 6),
			m_vectNewItems.GetCellText(i, 7));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabCardVIPTypes SET CTCustomCode = '%s', CTName = '%s', DepositRate = %s, SalesRate = %s, ServiceRate = %s, IntegralRate = %s, CTMemo = '%s' WHERE CTID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 3),
			m_vectModItems.GetCellText(i, 4),
			m_vectModItems.GetCellText(i, 5),
			m_vectModItems.GetCellText(i, 6),
			m_vectModItems.GetCellText(i, 7),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabCardVIPTypes WHERE CTID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_CVIPTINFO_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("��Ա����������Ϣ����ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
