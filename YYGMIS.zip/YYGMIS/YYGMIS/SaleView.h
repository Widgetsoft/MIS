#pragma once


namespace Business
{
	// CSaleView ������ͼ

	class CSaleView : public CFormView
	{
		DECLARE_DYNCREATE(CSaleView)

	protected:
		CSaleView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
		virtual ~CSaleView();

	public:
		CSaleDoc* GetDocument() const;

	private: //˽�����ݳ�Ա
		CLocalDataGridView m_ListCtrl;

		CComboBox	m_cmbDepartment;
		CComboBox	m_cmbWarehouse;
		CComboBox	m_cmbExecuter;
		CComboBox	m_cmbCustomer;

		std::shared_ptr<GenerialPattern::CItemsData> m_lstCurrentProd;
		std::shared_ptr<GenerialPattern::CItemsData> m_lstCurrentSvs;

		CDateTimeCtrl	m_dateBusiness;

		DataPattern::EnumBusinessType m_enumDetailsType;

		BOOL m_bDataLoaded;

	private:
		//�ı��ǩ
		void ChangeLabels( BOOL bEnableInput = TRUE, BOOL bReloadOptions = FALSE );
		//���ػ���ѡ��
		void LoadTicketTitle();
		void ReLoadTableTitle();
		void ReloadTableData();

		//���¼���ԭʼ����
		
		//���㵥�кϼ�
		void ColculateSum(const UINT uiRow);
		//����ͳһ�ϼ�
		void ColculateTotalSum();

		BOOL PSSelectAutoComplete(int nRow, int nCol, const CString strKeyword);

	public:
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_SALEVIEW };
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		virtual void OnInitialUpdate();
		afx_msg LRESULT OnSalesChanged(WPARAM wParam, LPARAM lParam);
		afx_msg void OnWarehouseCloseup();
		afx_msg void OnExecuteManCloseup();
		afx_msg void OnDepartmentCloseup();
		afx_msg void OnCustomerEditUpdate();
		afx_msg void OnCustomerCloseup();
		afx_msg void OnSaleDateTimeChanged(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnCheckOutClick();
		afx_msg void OnMemoChanged();
		afx_msg void OnBeginLabelEdit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnUpdateEditSdNewitem(CCmdUI *pCmdUI);
		afx_msg void OnEditSdNewitem();
		afx_msg void OnUpdateEditSdModify(CCmdUI *pCmdUI);
		afx_msg void OnEditSdModify();
		afx_msg void OnUpdateEditSdDelete(CCmdUI *pCmdUI);
		afx_msg void OnEditSdDelete();
		afx_msg void OnUpdateEditSdRefresh(CCmdUI *pCmdUI);
		afx_msg void OnEditSdRefresh();
		afx_msg void OnUpdateEditSdRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditSdRevsel();
		afx_msg void OnUpdateEditSdFind(CCmdUI *pCmdUI);
		afx_msg void OnEditSdFind();
		afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	};
}

#ifndef _DEBUG
inline Business::CSaleDoc* Business::CSaleView::GetDocument() const
{
	return reinterpret_cast<CSaleDoc*>(m_pDocument);
}
#endif

