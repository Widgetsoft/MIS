// StockPage.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "LocalDataGridView.h"
#include "TickitsData.h"
#include "StockPage.h"
#include "TickitsFrame.h"
#include "afxdialogex.h"
#include "SystemInfo.h"
#include "WorkAssistant.h"
#include "SystemInfo.h"

using namespace Business;
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CStockPage �Ի���

IMPLEMENT_DYNAMIC(CStockPage, CMFCPropertyPage)

CStockPage::CStockPage()
	: CMFCPropertyPage(IDD_PROP_STOCK)
{

}

CStockPage::~CStockPage()
{
}

void CStockPage::DoDataExchange(CDataExchange* pDX)
{
	CMFCPropertyPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STOCK_LIST, m_ListCtrl);
	DDX_Control(pDX, IDC_STOCK_WSP, m_cmbWarehouse);
	DDX_Control(pDX, IDC_STOCK_MAN, m_cmbExecuter);
	DDX_Control(pDX, IDC_STOCK_DATE, m_dateStore);
}


BEGIN_MESSAGE_MAP(CStockPage, CMFCPropertyPage)
	ON_WM_CTLCOLOR()
	ON_EN_CHANGE(IDC_STOCK_DESC, &CStockPage::OnDescriptionChanged)
	ON_EN_CHANGE(IDC_STOCK_MEMO, &CStockPage::OnMemoChanged)
	ON_CBN_EDITUPDATE(IDC_STOCK_WSP, &CStockPage::OnWarehouseEditUpdate)
	ON_CBN_CLOSEUP(IDC_STOCK_WSP, &CStockPage::OnWarehouseCloseup)
	ON_CBN_EDITUPDATE(IDC_STOCK_MAN, &CStockPage::OnExecuteManEditUpdate)
	ON_CBN_CLOSEUP(IDC_STOCK_MAN, &CStockPage::OnExecuteManCloseup)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_STOCK_DATE, &CStockPage::OnStoreDateTimeChanged)
	ON_BN_CLICKED(IDC_STOCK_ISCHECKOUT, &CStockPage::OnCheckOutClick)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_STOCK_LIST, &CStockPage::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_NEWITEM, &CStockPage::OnUpdateEditNewitem)
	ON_COMMAND(ID_EDIT_NEWITEM, &CStockPage::OnEditNewitem)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CStockPage::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CStockPage::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CStockPage::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CStockPage::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CStockPage::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CStockPage::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CStockPage::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CStockPage::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CStockPage::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CStockPage::OnEditFind)
END_MESSAGE_MAP()


// CStockPage ��Ϣ��������


BOOL CStockPage::OnInitDialog()
{
	CMFCPropertyPage::OnInitDialog();

	//ִ�г�ʼ���Ի������
	auto pParentWndFrame = reinterpret_cast<CTickitsFrame*>(GetParent());
	m_spData = pParentWndFrame->m_spTickitData;
	ASSERT(m_spData != nullptr);

	m_enumTickType = pParentWndFrame->m_enumTickType;
	m_enumSourceTickType = pParentWndFrame->m_enumSourceTickType;

	m_ListCtrl.SetContextMenu(IDR_POPUP_NORMAL);
	//��ʼ���б���		
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	Database::CStockFlowDetails salD;

	for (int col = 0; col != salD.GetColCount() - 3; ++col)
	{
		CString title = salD.GetColumnName(col + 1);

		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 1:
			pTrait = new CGridColumnTraitCombo;
			break;
		case 5:
			pTrait = new CGridColumnTraitEdit;
			break;
		case 8:
			pTrait = new CGridColumnTraitMultilineEdit;
			break;
		default:
			break;
		}
		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��Ʒ��������"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	LoadProductCat();

	if (m_enumTickType == DataPattern::enumStoreOut)
	{
		SetDlgItemText(IDC_STOCK_LABEL1, _T("���ⵥ��:"));
		SetDlgItemText(IDC_STOCK_LABEL2, _T("��������:"));
		SetDlgItemText(IDC_STOCK_LABEL4, _T("����ⷿ:"));
		SetDlgItemText(IDC_STOCK_LABEL5, _T("����ժҪ:"));
		SetDlgItemText(IDC_STOCK_LABEL7, _T("�����Ҫ:"));
	}
	else if (m_enumTickType == DataPattern::enumStoreIn)
	{
		SetDlgItemText(IDC_STOCK_LABEL1, _T("��ⵥ��:"));
		SetDlgItemText(IDC_STOCK_LABEL2, _T("�������:"));
		SetDlgItemText(IDC_STOCK_LABEL4, _T("���ⷿ:"));
		SetDlgItemText(IDC_STOCK_LABEL5, _T("���ժҪ:"));
		SetDlgItemText(IDC_STOCK_LABEL7, _T("����Ҫ:"));
	}

	if (m_spData->GetInitialState() == Database::NewItem)
	{
		CreateStoreRecord();
	}
	else if (m_spData->GetInitialState() == Database::Initial)
	{
		GetDlgItem(IDC_STOCK_DATE)->EnableWindow(FALSE);
		GetDlgItem(IDC_STOCK_MAN)->EnableWindow(FALSE);
		GetDlgItem(IDC_STOCK_WSP)->EnableWindow(FALSE);
		GetDlgItem(IDC_STOCK_ISCHECKOUT)->EnableWindow(FALSE);
		((CEdit*)GetDlgItem(IDC_STOCK_DESC))->SetReadOnly(TRUE);
		((CEdit*)GetDlgItem(IDC_STOCK_MEMO))->SetReadOnly(TRUE);
	}

	LoadData();

	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}


HBRUSH CStockPage::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CMFCPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);

	switch (pWnd->GetDlgCtrlID())
	{
	case IDC_STOCK_ON:
	case IDC_STOCK_SUMMARY:
		pDC->SetTextColor(GetSysColor(COLOR_GRAYTEXT));
		hbr = GetSysColorBrush(COLOR_INFOBK);
		break;
	}

	return hbr;
}

void CStockPage::LoadProductCat()
{
	m_mapProd.ClearItemDatas();//�����������
	Database::CProductInfoVector vectInfo;
	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s"), vectInfo.m_strBindTable);
		pDataBase->GetProductInfo(strQuery, vectInfo);
	}

	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(1));
	pComboTrait->ClearFixedItems();

	for (int i = 0; i != vectInfo.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectInfo.GetCellText(i, 1) + _T('(') + vectInfo.GetCellText(i, 2) + _T(')'));
		std::auto_ptr<GenerialPattern::CItemData> apData(new GenerialPattern::CItemData());
		apData->AddRange(vectInfo.GetCellText(i, 0),
			vectInfo.GetCellText(i, 1) + _T('(') + vectInfo.GetCellText(i, 2) + _T(')'),
			vectInfo.GetCellText(i, 17), vectInfo.GetCellText(i, 12),
			vectInfo.GetCellText(i, 13), vectInfo.GetCellText(i, 3),
			vectInfo.GetCellText(i, 4), vectInfo.GetCellText(i, 5),
			vectInfo.GetCellText(i, 6), vectInfo.GetCellText(i, 7),
			vectInfo.GetCellText(i, 8), vectInfo.GetCellText(i, 10), NULL);
		m_mapProd.AddItemData(i, apData.release());
	}
}

void CStockPage::CreateStoreRecord()
{
	//����ģʽ
	std::auto_ptr<Database::CStockFlow> apStock(new Database::CStockFlow());
	apStock->SetCellText(1, _T("ϵͳ�Զ�����"));

	//////////////////////////////////////////////////////
	//����������ⵥ���
	if (m_enumTickType ==  DataPattern::enumStoreIn)
	{
		//��ⵥ
		apStock->SetCellText(11, _T("���"));
	}
	else
	{
		//���ⵥ
		apStock->SetCellText(11, _T("����"));
	}

	//�ֶ�����Ĭ�Ͽⷿ

	GenerialPattern::CItemData tempData;

	CString strQuery;
	strQuery.Append(_T("SELECT WSPID, WSPName FROM tsw_tabWareHouseSalePointInfo;"));
	Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbWarehouse, &tempData, nullptr);
	if (tempData.size() > 0)
	{
		apStock->SetCellText(4, tempData.at(1).c_str());
		apStock->SetCellText(20, tempData.at(0).c_str());
	}

	strQuery.Empty();
	strQuery.Append(_T("SELECT EID, EName FROM tsw_tabStaffInfo;"));
	Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbExecuter, &tempData, theApp.m_siInfo->m_strUserInnerID);

	if (tempData.size() > 0)
	{
		apStock->SetCellText(3, tempData.at(1).c_str());
		apStock->SetCellText(18, tempData.at(0).c_str());
	}

	//���ø�����Ա����
	apStock->SetCellText(15, theApp.m_siInfo->m_strUserInnerID);
	apStock->SetCellText(16, theApp.m_siInfo->m_strUserInnerID);
	apStock->SetCellText(17, theApp.m_siInfo->m_strUserInnerID);

	apStock->SetState(Database::NewItem);

	std::auto_ptr<Database::CStockFlowDetailsVector> apVector(new Database::CStockFlowDetailsVector());

	m_spData->AddDataItem(0, apStock->GetCellText(0), apStock.release(), apVector.release(), m_enumTickType, m_enumSourceTickType);
	m_spData->GetPage(0)->Last();
}

void CStockPage::LoadTicketDetails()
{
	Database::CFlybyData* pDetailsData = NULL;
	BOOL bSuc = m_spData->GetCurrentFlybyData(0, (PVOID*)&pDetailsData, FALSE);
	if (bSuc)
	{
		m_ListCtrl.DeleteAllItems();

		// Insert data into list-control by copying from datamodel
		int nItem = 0;
		for (size_t rowId = 0; rowId < pDetailsData->GetCount(); ++rowId)
		{
			nItem = m_ListCtrl.InsertItem(++nItem, pDetailsData->GetCellText(rowId, 1));
			m_ListCtrl.SetItemData(nItem, rowId);
			for (int col = 0; col < pDetailsData->GetColCount() - 3; ++col)
			{
				int nCellCol = col + 1;	// +1 because of hidden column
				const CString& strCellText = pDetailsData->GetCellText(rowId, nCellCol);
				m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
			}
		}
	}
}

void CStockPage::LoadData()
{
	Database::CFlybyItem* pItem = NULL;

	BOOL bSuc = m_spData->GetCurrentFlybyData(0, (PVOID*)&pItem);
	if (bSuc)
	{
		SetDlgItemText(IDC_STOCK_ON, pItem->GetCellText(1));
		COleDateTime dateTest;
		dateTest.ParseDateTime(pItem->GetCellText(2));
		m_dateStore.SetTime(dateTest);

		SetDlgItemText(IDC_STOCK_DESC, pItem->GetCellText(5));
		SetDlgItemText(IDC_STOCK_MEMO, pItem->GetCellText(10));

		CheckDlgButton(IDC_STOCK_ISCHECKOUT,
			pItem->GetCellText(8).Compare(_T("�����")) == 0);

		if (!Database::CFlybyItem::IsNullGuid(pItem->GetCellText(18)))
		{
			std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
			apItem->AddRange(pItem->GetCellText(18), pItem->GetCellText(3), NULL);
			Core::CWorkAssistant::LoadComboNormalData(m_spData, m_cmbExecuter, apItem.release());
		}
		//ͬ�������ÿⷿ
		if (!Database::CFlybyItem::IsNullGuid(pItem->GetCellText(20)))
		{
			std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
			apItem->AddRange(pItem->GetCellText(20), pItem->GetCellText(4), NULL);
			Core::CWorkAssistant::LoadComboNormalData(m_spData, m_cmbWarehouse, apItem.release());
		}

		//�����굥
		Database::CFlybyData* pDetailsData = NULL;
		bSuc = m_spData->GetCurrentFlybyData(0, (PVOID*)&pDetailsData, FALSE);
		if (bSuc)
		{
			m_ListCtrl.SetVector(pDetailsData);
			//�����굥
			if (m_spData->GetInitialState() == Database::Initial)
			{
				ReloadDetails();
			}
			LoadTicketDetails();
			ColculateTotalSum();//�������
		}
	}
}

void CStockPage::ReloadDetails()
{
	auto spVector = m_spData->GetPage(0)->GetCurrentTickitsItem()->GetItemDetails();
	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM tsw_viewStockFlowDetails WHERE ������ LIKE '%s'"), m_spData->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetCellText(0));
		Database::CStockFlowDetailsVector* pTargetVector = reinterpret_cast<Database::CStockFlowDetailsVector*>(spVector.get());
		pDataBase->GetStockFlowDetails(strQuery, *pTargetVector);
	}
}

void CStockPage::ColculateSum(const UINT uiRow)
{
	//����˰ǰ���
	Database::CFlybyData* pProdFlow = NULL;
	BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
	ASSERT(bSuccess);

	TCHAR* tcsStop = nullptr, *tcsStop1 = nullptr;

	double dblAmount = _tcstod(pProdFlow->GetCellText(uiRow, 4), &tcsStop) *
		_tcstod(pProdFlow->GetCellText(uiRow, 5), &tcsStop1);

	CString strTemp;
	strTemp.Format(_T("%.2f"), dblAmount);
	pProdFlow->SetCellText(uiRow, 7, strTemp);
	m_ListCtrl.SetItemText(uiRow, 7, strTemp);

	ColculateTotalSum();
}

void CStockPage::ColculateTotalSum()
{
	Database::CFlybyItem* pItem = NULL;
	Database::CFlybyData* pProdFlow = NULL;

	BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pItem);
	ASSERT(bSuccess);
	bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
	ASSERT(bSuccess);

	double dblQuantity = { 0 }, dblAmount = { 0 };
	int nCount = pProdFlow->GetCount();

	Concurrency::parallel_for(0, nCount, [pProdFlow, &dblQuantity, &dblAmount](const int i) {
		dblQuantity += _ttof(pProdFlow->GetCellText(i, 5));
		dblAmount += _ttof(pProdFlow->GetCellText(i, 7));
	});

	CString strTemp;
	strTemp.Format(_T("%.2f"), dblQuantity);
	pItem->SetCellText(6, strTemp);
	strTemp.Format(_T("%.2f"), dblAmount);
	pItem->SetCellText(7, strTemp);

	CString strSummary, strType;

	strType.Append(pItem->GetCellText(11));
	strSummary.Format(_T("%s����:%.2f;  %s���:%.2f��"),
		strType, dblQuantity, strType, dblAmount);
	SetDlgItemText(IDC_STOCK_SUMMARY, strSummary);
}

void CStockPage::OnDescriptionChanged()
{
	Database::CFlybyItem* pItem = NULL;
	BOOL bSucess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pItem);
	ASSERT(bSucess);
	if (pItem->GetState() != Database::Initial)
	{
		CString strText;
		GetDlgItemText(IDC_STOCK_DESC, strText);
		pItem->SetCellText(5, strText);
	}
}

void CStockPage::OnMemoChanged()
{
	Database::CFlybyItem* pItem = NULL;
	BOOL bSucess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pItem);
	ASSERT(bSucess);
	if (pItem->GetState() != Database::Initial)
	{
		CString strText;
		GetDlgItemText(IDC_STOCK_MEMO, strText);
		pItem->SetCellText(10, strText);
	}
}

void CStockPage::OnWarehouseEditUpdate()
{
	CString strText;
	m_cmbWarehouse.GetWindowText(strText);
	//�������¼�������
	CString strQuery;
	strQuery.Format(_T("SELECT WSPID, WSPName FROM tsw_tabWareHouseSalePointInfo WHERE WSPName LIKE '%%%s%%' OR WSPPhoneNum LIKE '%%%s%%' OR JM LIKE '%%%s%%' OR WSPAddress LIKE '%%%s%%' OR WSCustomCode LIKE '%%%s%%' OR WSMemo LIKE '%%%s%%'"),
		strText, strText, strText.MakeUpper(), strText, strText, strText);
	Core::CWorkAssistant::QIFilterOptions(m_spData, strQuery, m_cmbWarehouse, strText);
}

void CStockPage::OnWarehouseCloseup()
{
	Core::CWorkAssistant::QIValidateOptions(m_spData, m_cmbWarehouse, 20, 4);
}

void CStockPage::OnExecuteManEditUpdate()
{
	CString strText;
	m_cmbExecuter.GetWindowText(strText);
	//�������¼�������
	CString strQuery;
	strQuery.Format(_T("SELECT EID, EName FROM tsw_tabStaffInfo WHERE EName LIKE '%%%s%%' OR UID LIKE '%%%s%%' OR JM LIKE '%%%s%%' OR EPhoneNum LIKE '%%%s%%' OR EPID LIKE '%%%s%%' OR EMemo LIKE '%%%s%%'"),
		strText, strText, strText.MakeUpper(), strText, strText, strText);
	Core::CWorkAssistant::QIFilterOptions(m_spData, strQuery, m_cmbExecuter, strText);
}

void CStockPage::OnExecuteManCloseup()
{
	Core::CWorkAssistant::QIValidateOptions(m_spData, m_cmbExecuter, 18, 3);
}

void CStockPage::OnStoreDateTimeChanged(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
	Database::CFlybyItem* pItem = NULL;
	BOOL bSucess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pItem);
	ASSERT(bSucess);
	if (pItem->GetState() != Database::Initial)
	{
		LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
		COleDateTime tempDate(pDTChange->st);
		pItem->SetCellText(2, tempDate.Format());
	}
	*pResult = 0;
}

void CStockPage::OnCheckOutClick()
{
	if (m_spData->GetInitialState() != Database::Initial)
	{
		if (IsDlgButtonChecked(IDC_STOCK_ISCHECKOUT))
		{
			m_spData->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(8, _T("�����"));
		}
		else
		{
			m_spData->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(8, _T("δ���"));
		}
	}
}

void CStockPage::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;

	switch (nCol)
	{
	case 1:
		if (pDispInfo->item.pszText != NULL)
		{
			Database::CFlybyData* pProdFlow = NULL;
			BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
			ASSERT(bSuccess);
			GenerialPattern::CItemData* pData = nullptr;
			int nIndex = pDispInfo->item.lParam;
			if (nIndex == -1)
			{
				nIndex = m_mapProd.FindItem(pDispInfo->item.pszText);
			}
			if (nIndex != -1)
			{
				pData = m_mapProd.GetItemData(nIndex);
			}

			if (pData == nullptr)
			{
				m_ListCtrl.SetItemText(nRow, 1, pProdFlow->GetCellText(nRow, 1));	//Ʒ��
				//m_ListCtrl.SetItemText(nRow, 2, pProdFlow->GetCellText(nRow, 5));	//���
				//m_ListCtrl.SetItemText(nRow, 3, pProdFlow->GetCellText(nRow, 6));	//���
				//m_ListCtrl.SetItemText(nRow, 6, pProdFlow->GetCellText(nRow, 8));	//������λ
				//m_ListCtrl.SetItemText(nRow, 4, pProdFlow->GetCellText(nRow, 11)); //��浥��
				break;
			}

			pProdFlow->SetCellText(nRow, 9, pData->at(0).c_str());	//��Ʒ����
			pProdFlow->SetCellText(nRow, 1, pData->at(1).c_str());	//Ʒ��
			pProdFlow->SetCellText(nRow, 2, pData->at(5).c_str());	//���
			pProdFlow->SetCellText(nRow, 3, pData->at(6).c_str());	//���
			pProdFlow->SetCellText(nRow, 6, pData->at(8).c_str());	//������λ
			pProdFlow->SetCellText(nRow, 4, pData->at(11).c_str()); //��浥��

			m_ListCtrl.SetItemText(nRow, 1, pData->at(1).c_str());	//Ʒ��
			m_ListCtrl.SetItemText(nRow, 2, pData->at(5).c_str());	//���
			m_ListCtrl.SetItemText(nRow, 3, pData->at(6).c_str());	//���
			m_ListCtrl.SetItemText(nRow, 6, pData->at(8).c_str());	//������λ
			m_ListCtrl.SetItemText(nRow, 4, pData->at(11).c_str()); //��浥��

			ColculateSum(nRow);
		}
		break;
	case 5:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			Database::CFlybyData* pProdFlow = NULL;
			BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
			ASSERT(bSuccess);
			pProdFlow->SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
			ColculateSum(nRow);

		}
		break;
	default:	//���Ҳ�Ʒ��Ϣ
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			Database::CFlybyData* pProdFlow = NULL;
			BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
			ASSERT(bSuccess);
			pProdFlow->SetCellText(nRow, nCol, tcsText);
			ColculateSum(nRow);
		}
		break;
	}
	*pResult = 0;
}

void CStockPage::OnUpdateEditNewitem(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_spData->GetInitialState() == Database::NewItem ||
		m_spData->GetInitialState() == Database::Modified);
}


void CStockPage::OnEditNewitem()
{
	// ����������ϸ
	if (m_mapProd.GetSize()  < 1)
	{
		MessageBox(_T("ϵͳδ���ؿ��Բ����Ĳ�ƷĿ¼��Ϣ��ϵͳ�޷�ִ������������"),
			_T("������ʾ"), MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_cmbWarehouse.GetCount() < 1)
	{
		MessageBox(_T("ϵͳδ���ؿɲ����Ŀⷿ��Ϣ��ϵͳ�޷�ִ������������"),
			_T("������ʾ"), MB_OK | MB_ICONEXCLAMATION);
		m_cmbWarehouse.SetFocus();
		return;
	}

	if (m_cmbExecuter.GetCount() < 1)
	{
		MessageBox(_T("ϵͳδ���ؿɲ�����ҵ��Ա��Ϣ��ϵͳ�޷�ִ������������"),
			_T("������ʾ"), MB_OK | MB_ICONEXCLAMATION);
		m_cmbExecuter.SetFocus();
		return;
	}

	auto pStockFlow = new Database::CStockFlowDetails();

	auto pProd = m_mapProd.GetItemData(0);
	pStockFlow->SetCellText(9, pProd->at(0).c_str());	//��Ʒ����
	pStockFlow->SetCellText(1, pProd->at(1).c_str());	//Ʒ��
	pStockFlow->SetCellText(2, pProd->at(5).c_str());  //���
	pStockFlow->SetCellText(3, pProd->at(6).c_str());	//���
	pStockFlow->SetCellText(6, pProd->at(8).c_str());	//������λ
	pStockFlow->SetCellText(4, pProd->at(11).c_str()); //��浥��
	pStockFlow->SetState(Database::NewItem);

	Database::CFlybyData* pItemVector = NULL;
	Database::CFlybyItem* pItem = NULL;
	BOOL bSuccess = FALSE;

	bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pItemVector, FALSE);
	bSuccess = bSuccess && m_spData->GetCurrentFlybyData(0, (PVOID*)&pItem);

	ASSERT(bSuccess);	//���Ի�ȡ�ɹ�

	pStockFlow->SetCellText(10, pItem->GetCellText(0)); //�޸Ķ�������

	pItemVector->AddItem(pStockFlow);

	// �����굥����
	int nItem = pItemVector->GetCount() - 1;
	for (size_t rowId = nItem; rowId < pItemVector->GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, pItemVector->GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < pItemVector->GetColCount() - 3; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = pItemVector->GetCellText(rowId, nCellCol);
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(pItemVector->GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}


void CStockPage::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
	if (m_spData->GetInitialState() == Database::NewItem ||
		m_spData->GetInitialState() == Database::Modified)
	{
		POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
		pCmdUI->Enable(pos != NULL);
	}
}


void CStockPage::OnEditModify()
{
	Database::CFlybyData* pProdFlow = NULL;
	BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
	ASSERT(bSuccess);
	m_ListCtrl.LocalModify();
}


void CStockPage::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
	if (m_spData->GetInitialState() == Database::NewItem || m_spData->GetInitialState() == Database::Modified)
	{
		POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
		pCmdUI->Enable(pos != NULL);
	}
}


void CStockPage::OnEditDelete()
{
	m_ListCtrl.LocalDelete();
	ColculateTotalSum();
}


void CStockPage::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	if (m_spData->GetInitialState() == Database::NewItem || m_spData->GetInitialState() == Database::Modified)
	{
		pCmdUI->Enable(TRUE);
	}
}


void CStockPage::OnEditRefresh()
{
	ReloadDetails();
	LoadTicketDetails();
	ColculateTotalSum();
}



void CStockPage::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	Database::CFlybyData* pProdFlow = NULL;
	BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
	ASSERT(bSuccess);
	pCmdUI->Enable(pProdFlow->GetCount() > 0);
}



void CStockPage::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CStockPage::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	Database::CFlybyData* pProdFlow = NULL;
	BOOL bSuccess = m_spData->GetCurrentFlybyData(0, (PVOID*)&pProdFlow, FALSE);
	ASSERT(bSuccess);
	pCmdUI->Enable(pProdFlow->GetCount() > 0);
}


void CStockPage::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}



BOOL CStockPage::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		CWnd* pFocus = GetFocus();
		switch (pMsg->wParam)
		{
		case VK_HOME:
			if (pFocus)
			{
				//���¼��ؼ�¼
				//MessageBox( _T("��һ��") );
				BOOL bMoved = m_spData->GetPage(0)->First();
				if (bMoved)
				{
					//��������
					LoadData();
				}

			}
			break;
		case VK_PRIOR:
			if (pFocus)
			{
				//���¼��ؼ�¼
				//MessageBox( _T("��һ��") );

				BOOL bMoved = m_spData->GetPage(0)->Previous();
				if (bMoved)
				{
					//��������
					LoadData();
				}
			}
			break;
		case VK_NEXT:
			if (pFocus)
			{
				//���¼��ؼ�¼
				//MessageBox( _T("��һ��") );
				BOOL bMoved = m_spData->GetPage(0)->Next();
				if (bMoved)
				{
					//��������
					LoadData();
				}

			}
			break;
		case VK_END:
			if (pFocus)
			{
				//���¼��ؼ�¼
				//MessageBox( _T("��һ��") );
				BOOL bMoved = m_spData->GetPage(0)->Last();
				if (bMoved)
				{
					//��������
					LoadData();
				}

			}
			break;
		case _T('N'):
			if ((::GetKeyState(VK_CONTROL) & 0x8000))
			{
				if (m_spData->GetInitialState() == Database::NewItem)
				{
					CreateStoreRecord();
					//m_spData->GetPage(0)->Last();
					LoadData();
					//֪ͨ��������
				}

			}
			break;
		case _T('D'):
			if ((::GetKeyState(VK_CONTROL) & 0x8000))
			{
				if (m_spData->GetInitialState() == Database::NewItem
					&& m_spData->GetPage(0)->GetItemsCount() > 1)
				{
					CString strKey = m_spData->GetPage(0)->GetCurrentTickitsItem()->GetItem()->GetCellText(0);
					m_spData->GetPage(0)->DeleteItem(STDString(strKey));
					LoadData();
				}
			}
			break;
		}

	}

	return CMFCPropertyPage::PreTranslateMessage(pMsg);
}
