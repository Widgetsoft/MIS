#pragma once


namespace Business
{
	class CSaleServiceSaveDlg;

	// CSaleServiceSaveThread

	class CSaleServiceSaveThread : public CWinThread
	{
		DECLARE_DYNCREATE(CSaleServiceSaveThread)

	protected:
		CSaleServiceSaveThread();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��

	public:
		virtual ~CSaleServiceSaveThread();

	private:
		CSaleServiceSaveDlg* m_pOwner;

	public:
		virtual BOOL InitInstance();
		virtual int ExitInstance();

		inline void SetOwner( CSaleServiceSaveDlg* pOwner)
		{
			m_pOwner = pOwner;
		}

	protected:
		DECLARE_MESSAGE_MAP()
	public:
		virtual int Run();
	};
}


