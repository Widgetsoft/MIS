#pragma once
class CLocalDataGridView : public CGridListCtrlGroups {
public:
	CLocalDataGridView(UINT uiContextMenu = -1) noexcept;
	virtual ~CLocalDataGridView() noexcept;

public:
	virtual void OnContextMenuGrid(CWnd* pWnd, CPoint point);
	virtual void OnContextMenuCell(CWnd* pWnd, CPoint point, int nRow, int nCol);

	// Retrieves the text associated with a particular item.
	virtual CString GetItemText(int nItem, int nSubItem) const;
	virtual int GetItemText(int nItem, int nSubItem, LPTSTR lpszText, int nLen) const;
	// Sets the text associated with a particular item.
	virtual BOOL SetItemText(int nItem, int nSubItem, LPCTSTR lpszText);
	virtual int GetItemCount() const;

	virtual bool SortColumn(int nCol, bool bAscending);
	inline void SetVector(Database::CFlybyData* pVector) { m_pVector = pVector; }

	void RefreshData();

	// ������е�ѡ����
	void ClearSelections(void);
	void ReverseSelect();

	BOOL LocalModify(Database::CFlybyData* pModifyVector = NULL, UINT uiRestrictCol = -1, UINT uiTargetRestrictCol = -1, UINT uiModUserCol = -1,
		LPCTSTR lpctszModUserID = NULL);
	BOOL LocalDelete(Database::CFlybyData* pDeleteVector = NULL, Database::CFlybyData* pNewVector = NULL,
		UINT uiSkipCol = UINT(-1), LPCTSTR lpcstrFilter = NULL);


	BOOL LocalModify_If(Database::CFlybyData* pModifyVector, std::function<BOOL(const Database::CFlybyItem*)> MatchFunction);

	BOOL LocalDelete_If(Database::CFlybyData* pDeleteVector, Database::CFlybyData* pNewVector, std::function<BOOL(const Database::CFlybyItem*)> MatchFunction);

	inline void SetContextMenu(UINT uiContextMenu)
	{
		m_uiContextMenuID = uiContextMenu;
	}

	void InitFindReplaceDlg();

protected:
	UINT m_uiContextMenuID;
	Database::CFlybyData* m_pVector;
	CFindReplaceDialog* m_pFRDlg;
	int m_nFoundIndex;

public:
	afx_msg void OnLvnOdfinditem(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult);
	virtual int OnClickEditStart(int nRow, int nCol, CPoint pt, bool bDblClick);

protected:
	// CustomDraw handlers
	virtual void OnCustomDrawCell(int nRow, int nCol, NMLVCUSTOMDRAW* pLVCD, LRESULT* pResult);
	afx_msg LRESULT OnFindReplace(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

