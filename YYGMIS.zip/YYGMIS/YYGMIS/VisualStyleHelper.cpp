#include "stdafx.h"
#include "VisualStyleHelper.h"

using namespace UI;
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define TRANSPARENT_COLOR  RGB (200, 201, 202)

CBrush VisualStyleHelper::s_brBackground;
COLORREF VisualStyleHelper::s_clrBackground = TRANSPARENT_COLOR;

void VisualStyleHelper::DetermineCurrentThemeClr()
{
	CMFCVisualManager* pManager = CMFCVisualManager::GetInstance();
	if (pManager == NULL)
	{
		s_clrBackground = ::GetSysColor(COLOR_BTNFACE);
		return;
	}

	CMFCVisualManagerOffice2007* pManager2007 = DYNAMIC_DOWNCAST(CMFCVisualManagerOffice2007, pManager);
	if (pManager2007 != NULL)
	{
		switch (pManager2007->GetStyle())
		{
		default:
		case CMFCVisualManagerOffice2007::Office2007_LunaBlue:
			s_clrBackground = RGB(193, 215, 245);
			break;

		case CMFCVisualManagerOffice2007::Office2007_ObsidianBlack:
			s_clrBackground = RGB(225, 226, 229);
			break;

		case CMFCVisualManagerOffice2007::Office2007_Silver:
			s_clrBackground = RGB(208, 212, 221);
			break;

		case CMFCVisualManagerOffice2007::Office2007_Aqua:
			s_clrBackground = RGB(212, 218, 233);
			break;
		}
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManager)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerOfficeXP)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerWindows)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerWindows)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerOffice2003)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerVS2005)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerVS2008)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else if (pManager->IsKindOf(RUNTIME_CLASS(CMFCVisualManagerWindows7)))
	{
		s_clrBackground = (::GetSysColor(COLOR_WINDOW));
	}
	else
	{
		s_clrBackground = (::GetSysColor(COLOR_BTNFACE));
	}
}


CBrush& VisualStyleHelper::GetBackgroundBr()
{
	if ((HBRUSH)s_brBackground != 0)
	{
		s_brBackground.DeleteObject();
	}
	DetermineCurrentThemeClr();
	s_brBackground.CreateSolidBrush(s_clrBackground);
	return s_brBackground;
}

COLORREF VisualStyleHelper::GetBackgroundClr()
{
	return s_clrBackground;
}

HBRUSH VisualStyleHelper::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	//return ISGUI::VisualStyleHelper::OnCtlColor(pDC,pWnd,nCtlColor); 

	HBRUSH hbrRet = NULL;
	if (VisualStyleHelper::GetBackgroundBr().GetSafeHandle() != NULL)
	{
#define AFX_MAX_CLASS_NAME 255 
#define AFX_STATIC_CLASS _T("Static") 
#define AFX_BUTTON_CLASS _T("Button")
#define AFX_MFCBUTTON_CLASS _T("Mfc Button") 
#define AFX_EDIT_CLASS _T("Edit")
#define AFX_COMBOBOX_CLASS _T("ComboBox") 
#define AFX_SLIDE_CLASS _T("msctls_trackbar32") 

		if (nCtlColor == CTLCOLOR_STATIC)
		{
			TCHAR lpszClassName[AFX_MAX_CLASS_NAME + 1];
			int nChars = ::GetClassName(pWnd->GetSafeHwnd(), lpszClassName, AFX_MAX_CLASS_NAME);

			if ((nChars > 0)
				&& ((_tcsncmp(lpszClassName, AFX_STATIC_CLASS, nChars) == 0)
					|| (_tcsncmp(lpszClassName, AFX_BUTTON_CLASS, nChars) == 0)
					|| (_tcsncmp(lpszClassName, AFX_MFCBUTTON_CLASS, nChars) == 0)
					|| (_tcsncmp(lpszClassName, AFX_EDIT_CLASS, nChars) == 0)
					|| (_tcsncmp(lpszClassName, AFX_COMBOBOX_CLASS, nChars) == 0)
					|| (_tcsncmp(lpszClassName, AFX_SLIDE_CLASS, nChars) == 0)
					)
				)
			{
				pDC->SetBkMode(TRANSPARENT);
				hbrRet = (HBRUSH)VisualStyleHelper::GetBackgroundBr();
			}
			else
			{
				int i = 1;
			}
		}
		else if (nCtlColor == CTLCOLOR_DLG)
		{
			HBRUSH hbrRet = GetBackgroundBr();

			if (hbrRet != NULL)
				return hbrRet;
		}
	}


	return hbrRet;
}