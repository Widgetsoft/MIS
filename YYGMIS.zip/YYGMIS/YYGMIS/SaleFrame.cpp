// SaleFrame.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "SaleServiceWork.h"
#include "SaleFrame.h"
#include "BarCodeCaptureButton.h"
#include "OptionsDlg.h"

using namespace Business;

#define ID_SALE_BAR 0x6220

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSaleFrame

IMPLEMENT_DYNCREATE(CSaleFrame, CMDIFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

CSaleFrame::CSaleFrame()
	:m_pWorker( new Core::CSaleServiceWork( Database::Initial ))
{
	//m_wndMenuBar.m_bClearHashOnClose = TRUE;
	CMFCPopupMenu::SetForceShadow(TRUE);
	m_bCanConvertControlBarToMDIChild = TRUE;
	m_bMainWndHide = FALSE;
}

CSaleFrame::~CSaleFrame()
{
}

/////////////////////////////////////////
//���ߺ���
CMFCToolBarComboBoxButton* CSaleFrame::GetPageCombo()
{
	CMFCToolBarComboBoxButton* pPageCombo = nullptr;
	CObList listButtons;
	if (CMFCToolBar::GetCommandButtons(ID_SALE_AT, listButtons) > 0)
	{
		for (auto posCombo = listButtons.GetHeadPosition(); pPageCombo == nullptr && 
			posCombo != nullptr; )
		{
			auto pCombo = DYNAMIC_DOWNCAST(CMFCToolBarComboBoxButton, listButtons.GetNext(posCombo));
			if (pCombo != nullptr && pCombo->GetEditCtrl()->GetSafeHwnd() == ::GetFocus())
			{
				pPageCombo = pCombo;
			}
		}
	}

	return pPageCombo;
}


BEGIN_MESSAGE_MAP(CSaleFrame, CMDIFrameWndEx)
	ON_WM_CREATE()
	ON_WM_ACTIVATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_SALE_CLOSE, &CSaleFrame::OnSaleClose)
	ON_WM_ENABLE()
	ON_UPDATE_COMMAND_UI(ID_WINDOW_NEW, &CSaleFrame::OnUpdateWindowNew)
	ON_WM_SIZE()
	ON_COMMAND(ID_VIEW_FULLSCREEN, OnViewFullScreen)
	ON_COMMAND(ID_TOOLS_OPTIONS, OnToolsOptions)
	ON_COMMAND(ID_VIEW_CUSTOMIZE, OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_RESETTOOLBAR, OnToolbarReset)
	ON_REGISTERED_MESSAGE(AFX_WM_ON_GET_TAB_TOOLTIP, OnGetTabToolTip)
	ON_REGISTERED_MESSAGE(AFX_WM_CUSTOMIZEHELP, OnHelpCustomizeToolbars)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, OnToolbarCreateNew)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CSaleFrame ��Ϣ��������


int CSaleFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

	m_pMainWnd = theApp.m_pMainWnd;

	if (CMDIFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	////////////////////////////////////////////////////

	//CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));

	CMFCToolBarComboBoxButton::SetFlatMode();


	CMFCToolBar::EnableQuickCustomization();

	// Create menu bar:
	if (!m_wndMenuBar.Create(this, AFX_DEFAULT_TOOLBAR_STYLE, IDR_SALEFRAME))
	{
		TRACE0("δ�ܴ����˵���\n");
		return -1;      // fail to create
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// Menu will not take the focus on activation:
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	// Create main toolbar:
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) || !m_wndToolBar.LoadToolBar(IDR_SALEFRAME, 0, 0, FALSE, 0, 0, theApp.m_bHiColorIcons ? IDB_SALE_HC : 0))
	{
		TRACE0("δ�ܴ���������\n");
		return -1;      // fail to create
	}


	BOOL bValidString;
	CString strMainToolbarTitle;
	bValidString = strMainToolbarTitle.LoadString(IDS_MAIN_TOOLBAR);
	m_wndToolBar.SetWindowText(strMainToolbarTitle);

	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, _T("�Զ���..."));


	// Create status bar:
	if (!m_wndStatusBar.Create(this) || !m_wndStatusBar.SetIndicators(indicators, sizeof(indicators) / sizeof(UINT)))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}
	m_wndStatusBar.SetPaneStyle(0, SBPS_STRETCH);

	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);

	EnableDocking(CBRS_ALIGN_ANY);	
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	CRect rectMainToolBar;
	m_wndToolBar.GetWindowRect(&rectMainToolBar);

	// Allow user-defined toolbars operations:
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	// Enable windows manager:
	EnableWindowsDialog(ID_WINDOW_MANAGER, _T("����(&W)..."), TRUE);

	// Enable conttol bar context menu(list of bars + customize command):
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, _T("�Զ���..."), ID_VIEW_TOOLBARS, FALSE, TRUE);

	EnableFullScreenMode(ID_VIEW_FULLSCREEN);

	return 0;
}

LRESULT CSaleFrame::OnToolbarReset(WPARAM wp, LPARAM)
{
	UINT uiToolBarId = (UINT)wp;
	if (uiToolBarId == IDR_SALEFRAME)
	{
		m_wndToolBar.ReplaceButton(ID_SALE_AT, UI::Business::CBarCodeCaptureButton());
	}

	return 0;
}

LRESULT CSaleFrame::OnHelpCustomizeToolbars(WPARAM /*wp*/, LPARAM /*lp*/)
{
	// int iPageNum = (int) wp;

	// CMFCToolBarsCustomizeDialog* pDlg = (CMFCToolBarsCustomizeDialog*) lp;
	// ASSERT_VALID(pDlg);

	// TODO: show help about page number iPageNum

	return 0;
}



void CSaleFrame::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CMDIFrameWndEx::OnActivate(nState, pWndOther, bMinimized);

	if (nState != WA_INACTIVE)
	{
		theApp.SetActiveFrame(CYYGMISApp::SaleFrame);
		theApp.m_pMainWnd = this;
		m_bMainWndHide = FALSE;
		//this->RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
	}
}


void CSaleFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* Automatic menus scaning */, AFX_CUSTOMIZE_MENU_SHADOWS | AFX_CUSTOMIZE_TEXT_LABELS | AFX_CUSTOMIZE_MENU_ANIMATIONS);

	pDlgCust->EnableUserDefinedToolbars();

	// Setup combboxes:
	pDlgCust->ReplaceButton(ID_EDIT_FIND, UI::Business::CBarCodeCaptureButton());

	//CMFCToolBarComboBoxButton comboButtonConfig(ID_DUMMY_SELECT_ACTIVE_CONFIGURATION, GetCmdMgr()->GetCmdImage(ID_DUMMY_SELECT_ACTIVE_CONFIGURATION, FALSE), CBS_DROPDOWNLIST);
	//comboButtonConfig.AddItem(_T("Win32 Debug"));
	//comboButtonConfig.AddItem(_T("Win32 Release"));
	//comboButtonConfig.SelectItem(0);

	//pDlgCust->ReplaceButton(ID_DUMMY_SELECT_ACTIVE_CONFIGURATION, comboButtonConfig);

	// Add dropdown resources button:
	//pDlgCust->AddButton(_T("Build"), CMFCDropDownToolbarButton(_T("Add Resource"), &m_wndToolbarResource));

	// Setup undo/redo buttons:
	//pDlgCust->ReplaceButton(ID_EDIT_UNDO, CUndoButton(ID_EDIT_UNDO, _T("&Undo")));
	//pDlgCust->ReplaceButton(ID_EDIT_REDO, CUndoButton(ID_EDIT_REDO, _T("&Redo")));

	pDlgCust->Create();
}


void CSaleFrame::OnClose()
{
	theApp.m_pMainWnd = m_pMainWnd;
	theApp.SetActiveFrame(CYYGMISApp::MainFrame);

	if (!theApp.m_bRealExit)
	{
		m_bMainWndHide = TRUE;
		this->ShowWindow(SW_HIDE);
		theApp.m_pMainWnd->SetForegroundWindow();
		return;
	}


	//POSITION pos = m_lstMailFrames.Find(this);
	//if (pos != NULL)
	//{
	//	m_lstMailFrames.RemoveAt(pos);
	//}

	//theApp.SetSaleFrameNull();

	CMDIFrameWndEx::OnClose();
}

BOOL CSaleFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext)
{
	if (!CMDIFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}

	CMDITabInfo mdiTabParams;
	mdiTabParams.m_bTabCustomTooltips = TRUE;
	mdiTabParams.m_bDocumentMenu = FALSE;
	mdiTabParams.m_bTabIcons = FALSE;
	mdiTabParams.m_style = CMFCTabCtrl::STYLE_3D_ROUNDED;
	EnableMDITabbedGroups(TRUE, mdiTabParams);

	return TRUE;
}

void CSaleFrame::OnSaleClose()
{
	SendMessage(WM_CLOSE);
}

void CSaleFrame::OnChangeLook()
{
	CWindowDC dc(NULL);

	//BOOL bIsHiColor = theApp.m_bHiColorIcons;

	//for (POSITION pos = m_lstMailFrames.GetHeadPosition(); pos != NULL;)
	//{
	//	CSaleFrame* pFrame = (CSaleFrame*)m_lstMailFrames.GetNext(pos);
	//	ASSERT_VALID(pFrame);

	//	pFrame->m_wndToolBar.LoadBitmap(bIsHiColor ? IDB_SALE_HC : IDR_SALEFRAME);
	//	pFrame->RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE);
	//}
}


void CSaleFrame::OnViewFullScreen()
{
	ShowFullScreen();
}

void CSaleFrame::OnToolsOptions()
{
	UI::Business::COptionsDlg *pDlgOptions = new UI::Business::COptionsDlg(_T("ѡ��"), this);
	pDlgOptions->DoModal();
	delete pDlgOptions;
}

void CSaleFrame::OnEnable(BOOL bEnable)
{
	CWnd* pWnd = GetNextWindow();
	while (pWnd != NULL)
	{
		if (pWnd->IsKindOf(RUNTIME_CLASS(CMDIFrameWndEx)))
		{
			pWnd->EnableWindow(bEnable);
		}
		pWnd = pWnd->GetNextWindow();
	}
}


void CSaleFrame::OnUpdateWindowNew(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
}


void CSaleFrame::OnSize(UINT nType, int cx, int cy)
{
	CMDIFrameWndEx::OnSize(nType, cx, cy);

	if (nType == SIZE_MINIMIZED)
	{
		SendMessage(WM_CLOSE);
	}
}

LRESULT CSaleFrame::OnToolbarCreateNew(WPARAM wp, LPARAM lp)
{
	LRESULT lres = CMDIFrameWndEx::OnToolbarCreateNew(wp, lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, _T("�Զ���..."));
	return lres;
}

LRESULT CSaleFrame::OnGetTabToolTip(WPARAM /*wp*/, LPARAM lp)
{
	CMFCTabToolTipInfo* pInfo = (CMFCTabToolTipInfo*)lp;
	ASSERT(pInfo != NULL);
	if (!pInfo)
	{
		return 0;
	}

	ASSERT_VALID(pInfo->m_pTabWnd);

	if (!pInfo->m_pTabWnd->IsMDITab())
	{
		return 0;
	}

	CFrameWnd* pFrame = DYNAMIC_DOWNCAST(CFrameWnd, pInfo->m_pTabWnd->GetTabWnd(pInfo->m_nTabIndex));
	if (pFrame == NULL)
	{
		return 0;
	}

	CDocument* pDoc = pFrame->GetActiveDocument();
	if (pDoc == NULL)
	{
		return 0;
	}

	pInfo->m_strText = pDoc->GetPathName();
	return 0;
}
