#pragma once

namespace Business
{
	// CInvBalPickupDlg �Ի���

	class CInvBalPickupDlg : public CDialogEx
	{
		DECLARE_DYNAMIC(CInvBalPickupDlg)

	public:
		CInvBalPickupDlg(Database::CInventoriesVector* pNewVector, std::vector<CString> vectNewItemIDs, CWnd* pParent = NULL);   // ��׼���캯��
		virtual ~CInvBalPickupDlg();

	private:
		CLocalDataGridView m_ListCtrl;
		CImageList m_ImageList1;		   //ͼ����Դ
		Database::CInventoriesVector* m_pNewVector;
		std::shared_ptr<Database::CInventoriesSelVector> m_spAllItems;
		std::vector<CString> m_vectNewItemIDs;

	protected:
		void LoadListItems();

	private:
		CMFCControlRenderer m_Pat[4];
		CMFCToolBarImages	m_Icons;
		CImageList			m_ImageList;
		TCHAR				m_tcsTitle[MAX_PATH];

		// �Ի�������
#ifdef AFX_DESIGN_TIME
		enum { IDD = IDD_INVSEL_DLG };
#endif

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

		DECLARE_MESSAGE_MAP()
	public:
		virtual BOOL OnInitDialog();
		afx_msg void OnPaint();
		afx_msg BOOL OnEraseBkgnd(CDC* pDC);
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnBnClickedOk();
		afx_msg void OnUpdateEditRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditRevsel();
		afx_msg void OnUpdateEditFind(CCmdUI *pCmdUI);
		afx_msg void OnEditFind();
	};
}
