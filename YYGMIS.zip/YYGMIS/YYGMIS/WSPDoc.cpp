// WSPDoc.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "WSPDoc.h"

using namespace BasicInfo;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CWSPDoc

IMPLEMENT_DYNCREATE(CWSPDoc, CDocument)

CWSPDoc::CWSPDoc()
	:m_vectNewItems(TRUE)
	, m_vectModItems(TRUE)
{
}

BOOL CWSPDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	this->SetTitle(_T("�ⷿ����������"));
	return TRUE;
}

CWSPDoc::~CWSPDoc()
{
}


BEGIN_MESSAGE_MAP(CWSPDoc, CDocument)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, &CWSPDoc::OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE, &CWSPDoc::OnFileSave)
END_MESSAGE_MAP()


// CWSPDoc ���

#ifdef _DEBUG
void CWSPDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CWSPDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CWSPDoc ���л�

void CWSPDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO:  �ڴ����Ӵ洢����
	}
	else
	{
		// TODO:  �ڴ����Ӽ��ش���
	}
}
#endif


// CWSPDoc ����


BOOL CWSPDoc::SaveModified()
{
	if (this->IsModified())
	{
		UINT uiResult = MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
			_T("���Ƿ���Ҫ�Ըղ����ݱ��ִ�б��������"), _T("������ʾ"), MB_ICONQUESTION | MB_YESNOCANCEL);
		if (uiResult == IDYES)
		{
			OnFileSave();
		}
		else if (uiResult == IDCANCEL)
		{
			return FALSE;
		}
	}

	return TRUE;
}


void CWSPDoc::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(this->IsModified());
}


void CWSPDoc::OnFileSave()
{
	//ִ�б���
	Concurrency::concurrent_vector<CString> vectUpdates;

	for (int i = 0; i != (int)(m_vectNewItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("INSERT INTO tsw_tabWareHouseSalePointInfo(WSPID, WSCustomCode, WSPName, compID, WSPCheif, WSPPhoneNum, WSPFaxNum, WSPhEmail, WSPPostCode, WSPAddress, WSPIsUsing, WSPIsSalesPoint, WSMemo, JM, CreateDate, ModifyDate, CreatedUser, ModifierUser) VALUES('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', %s, %s, '%s', '%s', DATETIME('now','localtime'), DATETIME('now','localtime'), '%s', '%s');"),
			m_vectNewItems.GetCellText(i, 0),
			m_vectNewItems.GetCellText(i, 1),
			m_vectNewItems.GetCellText(i, 2),
			m_vectNewItems.GetCellText(i, 18),
			m_vectNewItems.GetCellText(i, 4),
			m_vectNewItems.GetCellText(i, 5),
			m_vectNewItems.GetCellText(i, 6),
			m_vectNewItems.GetCellText(i, 7),
			m_vectNewItems.GetCellText(i, 8),
			m_vectNewItems.GetCellText(i, 9),
			(m_vectNewItems.GetCellText(i, 10).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectNewItems.GetCellText(i, 11).Compare(_T("��")) == 0) ? _T("1") : _T("0"),
			m_vectNewItems.GetCellText(i, 12),
			m_vectNewItems.GetCellText(i, 13),
			m_vectNewItems.GetCellText(i, 16),
			m_vectNewItems.GetCellText(i, 17));
		vectUpdates.push_back(ptStrTemp);
	}
	for (int i = 0; i != (int)(m_vectModItems.GetCount()); i++)
	{
		CString ptStrTemp;
		ptStrTemp.Format(_T("UPDATE tsw_tabWareHouseSalePointInfo SET WSCustomCode = '%s', WSPName = '%s', compID = '%s', WSPCheif = '%s', WSPPhoneNum = '%s', WSPFaxNum = '%s', WSPhEmail = '%s', WSPPostCode = '%s', WSPAddress = '%s', WSPIsUsing = %s, WSPIsSalesPoint = %s, WSMemo = '%s', JM = '%s',  ModifyDate = DATETIME('now','localtime'), ModifierUser = '%s'  WHERE WSPID LIKE '%s';"),
			m_vectModItems.GetCellText(i, 1),
			m_vectModItems.GetCellText(i, 2),
			m_vectModItems.GetCellText(i, 18),
			m_vectModItems.GetCellText(i, 4),
			m_vectModItems.GetCellText(i, 5),
			m_vectModItems.GetCellText(i, 6),
			m_vectModItems.GetCellText(i, 7),
			m_vectModItems.GetCellText(i, 8),
			m_vectModItems.GetCellText(i, 9),
			(m_vectModItems.GetCellText(i, 10).Compare(_T("����")) == 0) ? _T("1") : _T("0"),
			(m_vectModItems.GetCellText(i, 11).Compare(_T("��")) == 0) ? _T("1") : _T("0"),
			m_vectModItems.GetCellText(i, 12),
			m_vectModItems.GetCellText(i, 13),
			m_vectModItems.GetCellText(i, 17),
			m_vectModItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	for (int i = (int)(m_vectDelItems.GetCount()) - 1; i != -1; i--)
	{
		CString ptStrTemp;

		ptStrTemp.Format(_T("DELETE FROM tsw_tabWareHouseSalePointInfo WHERE WSPID = '%s';"),
			m_vectDelItems.GetCellText(i, 0));
		vectUpdates.push_back(ptStrTemp);
	}

	LOCALEDB;
	if (pDataBase != NULL)
	{
		BOOL bSuc = pDataBase->ExecuteNonQueryBatch(&vectUpdates);
		if (bSuc)
		{
			m_vectNewItems.ClearItems();
			m_vectModItems.ClearItems();
			m_vectDelItems.ClearItems();
			for (int i = 0; i != m_vector.GetCount(); i++)
			{
				m_vector.GetItem(i)->SetState(Database::Initial);
			}

			SetModifiedFlag(FALSE);
			theApp.SendLocalMsg(WM_WSPINFO_CHANGED, NULL, NULL, FALSE);
		}
		else
		{
			MessageBox(AfxGetMainWnd()->GetSafeHwnd(),
				_T("�ⷿ������������Ϣ���ݱ���ʧ�ܣ������޸�һЩ��Ŀ������ִ�б��������"), _T("������ʾ"), MB_OK | MB_ICONHAND);
		}
	}
}
