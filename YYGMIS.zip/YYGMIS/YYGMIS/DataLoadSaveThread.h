#pragma once

namespace Business
{
	class CDataProcessDlg;
	// CDataLoadSaveThread

	class CDataLoadSaveThread : public CWinThread
	{
		DECLARE_DYNCREATE(CDataLoadSaveThread)

	protected:
		CDataLoadSaveThread();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��

	public:
		virtual ~CDataLoadSaveThread();

	public:
		virtual BOOL InitInstance();
		virtual int ExitInstance();

	public:
		inline void SetOwner(CDataProcessDlg* pOwner) { m_pOwner = pOwner; }

	private:
		CDataProcessDlg* m_pOwner;

	protected:
		DECLARE_MESSAGE_MAP()
	public:
		virtual int Run();
	};
}


