// TickitsFrame.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "DataProcessDlg.h"
#include "TickitsFrame.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CTickitsFrame

IMPLEMENT_DYNAMIC(CTickitsFrame, CMFCPropertySheet)

CTickitsFrame::CTickitsFrame(CWnd* pWndParent, const std::unordered_map<UINT, CString> mapPageTitles,
	LPCTSTR lpctszTitle, DataPattern::CTickitsData* tickitData, DataPattern::EnumBusinessType enumTickType,
	UINT nSelectedPage, const DWORD dwImageID,	GenerialPattern::CItemData* pItemKeys,
	DataPattern::EnumBusinessType enumSourceTickType)
	:CMFCPropertySheet(lpctszTitle, pWndParent, nSelectedPage),
	m_dwImageID(dwImageID),
	m_mapPageTitles(mapPageTitles),
	m_spTickitData(tickitData),
	m_spMainKeys(pItemKeys),
	m_spOldTickitsData(nullptr),
	m_enumTickType(enumTickType),
	m_enumSourceTickType(enumSourceTickType)
{
	m_Icons.SetImageSize(CSize(32, 32));
	m_Icons.Load(m_dwImageID);

	CMFCControlRendererInfo params(_T(""), CLR_DEFAULT, CRect(0, 0, 350, 60), CRect(83, 58, 266, 1), CRect(0, 0, 0, 0), CRect(0, 0, 0, 0), FALSE);

	params.m_uiBmpResID = IDB_HEADERPART_1;
	m_Pat[0].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_2;
	m_Pat[1].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_3;
	m_Pat[2].Create(params);
	params.m_uiBmpResID = IDB_HEADERPART_4;
	m_Pat[3].Create(params);
	m_nCurrentPage = 0;

	if (m_spTickitData->GetInitialState() == Database::Modified
		|| m_spTickitData->GetInitialState() == Database::Deleted)
	{
		std::shared_ptr<DataPattern::CTickitsData> spOleItem(
			new DataPattern::CTickitsData(m_spTickitData->GetInitialState()));
		m_spOldTickitsData.swap(spOleItem);
	}
}

CTickitsFrame::~CTickitsFrame()
{

}


BEGIN_MESSAGE_MAP(CTickitsFrame, CMFCPropertySheet)
END_MESSAGE_MAP()


// CTickitsFrame ��Ϣ��������

BOOL CTickitsFrame::OnInitDialog()
{
	if (m_spTickitData.get() == NULL)
	{
		MessageBox(_T("����ϵͳ���ݲ�����������ϵͳ�޷�ִ�иò�����"),
			_T("��������"), MB_OK | MB_ICONERROR);
		return FALSE;
	}

	if (m_spTickitData->GetInitialState() != Database::NewItem &&
		(m_spMainKeys.get() == NULL || m_spMainKeys->size() < 1))
	{
		MessageBox(_T("����ϵͳ�޷��ṩ�ɲ���������Դ������ϵͳ�޷�ִ�иò�����"),
			_T("��������"), MB_OK | MB_ICONERROR);
		return FALSE;
	}

	//�������й����ĵ��ݵ���������

	BOOL bResult = CMFCPropertySheet::OnInitDialog();

	// Ensure that the Options dialog is fully visible on screen
	CRect rectDialog;
	GetWindowRect(&rectDialog);

	int cxScreen = GetSystemMetrics(SM_CXSCREEN);
	int cyScreen = GetSystemMetrics(SM_CYMAXIMIZED) - (GetSystemMetrics(SM_CYSCREEN) - GetSystemMetrics(SM_CYMAXIMIZED));

	if ((rectDialog.left < 0) || (rectDialog.top < 0))
	{
		SetWindowPos(NULL, rectDialog.left < 0 ? 0 : rectDialog.left, rectDialog.top < 0 ? 0 : rectDialog.top, 0, 0, SWP_NOSIZE);
	}
	else if ((rectDialog.right > cxScreen) || (rectDialog.bottom > cyScreen))
	{
		SetWindowPos(NULL, rectDialog.right > cxScreen ? cxScreen - rectDialog.Width() : rectDialog.left, rectDialog.bottom > cyScreen ? cyScreen - rectDialog.Height() : rectDialog.top, 0, 0, SWP_NOSIZE);
	}

	if (m_spTickitData->GetInitialState() == Database::NewItem)
	{
		SetDlgItemText(IDOK, _T("����"));
	}
	else if (m_spTickitData->GetInitialState() == Database::Modified)
	{
		SetDlgItemText(IDOK, _T("�޸�"));
	}
	else if (m_spTickitData->GetInitialState() == Database::Deleted)
	{
		SetDlgItemText(IDOK, _T("ɾ��"));
	}

	return bResult;
}

void CTickitsFrame::OnDrawPageHeader(CDC* pDC, int nPage, CRect rectHeader)
{
	//\r\n��ݼ�������ʾ����������(Ctrl+N);ɾ������(Ctrl+D);��ת����һҳ(Home);��������һҳ(PgUp);��������һҳ(PgDn);��ת��ĩβҳ(End)��
	CSize sizeIcon = m_Icons.GetImageSize();
	CDrawingManager dm(*pDC);

	COLORREF clrFill = afxGlobalData.clrBarFace;
	CMFCControlRenderer* pRenderer = NULL;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_OFF_2007_BLUE:
		pRenderer = &m_Pat[1];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_BLACK:
		pRenderer = &m_Pat[2];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_SILVER:
		pRenderer = &m_Pat[0];
		break;
	case ID_VIEW_APPLOOK_OFF_2007_AQUA:
		pRenderer = &m_Pat[3];
		break;

	default:
		if (theApp.m_bHiColorIcons)
		{
			pRenderer = &m_Pat[1];
		}
		break;
	}

	if (pRenderer != NULL)
	{
		pRenderer->Draw(pDC, rectHeader);
	}
	else
	{
		dm.FillGradient(rectHeader, pDC->GetPixel(rectHeader.left, rectHeader.bottom), clrFill);
	}

	rectHeader.bottom -= 10;

	CRect rectIcon = rectHeader;
	rectIcon.left += 20;
	rectIcon.right = rectIcon.left + sizeIcon.cx;

	m_Icons.DrawEx(pDC, rectIcon, nPage, CMFCToolBarImages::ImageAlignHorzLeft, CMFCToolBarImages::ImageAlignVertCenter);

	CString strText = m_mapPageTitles.find(nPage)->second;

	CRect rectText = rectHeader;
	rectText.left = rectIcon.right + 10;
	rectText.right -= 20;

	CFont* pOldFont = pDC->SelectObject(&afxGlobalData.fontBold);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(afxGlobalData.clrBarText);

	UINT uiFlags = DT_SINGLELINE | DT_VCENTER;

	CRect rectTextCalc = rectText;
	pDC->DrawText(strText, rectTextCalc, uiFlags | DT_CALCRECT);

	if (rectTextCalc.right > rectText.right)
	{
		rectText.DeflateRect(0, 10);
		uiFlags = DT_WORDBREAK;
	}

	pDC->DrawText(strText, rectText, uiFlags);

	pDC->SelectObject(pOldFont);
}



BOOL CTickitsFrame::OnCommand(WPARAM wParam, LPARAM lParam)
{
	CString strMessage;
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if ((UINT)wParam == IDOK)
	{
		//CSaveAllDatas* pDataSave = new CSaveAllDatas(
		//	m_tickitData, NULL, this, FALSE, m_pOldTickitsData);
		//pDataSave->DoModal();
		//BOOL bSuccess = pDataSave->m_bOK;
		//delete pDataSave;
		//if (bSuccess)
		//{
		//	EnumBusinessType enumType = m_tickitData->GetTickitsType();
		//	if (m_pOldTickitsData != NULL)
		//	{
		//		enumType = m_pOldTickitsData->GetTickitsType();
		//	}
		//	switch (enumType)
		//	{
		//	case enumPurchaseTickits:
		//		theApp.SendLocalMsg(WM_BUSINESS_PURCHAR_CHANGED, NULL, NULL);
		//		break;
		//	case enumPurchaseBack:
		//		theApp.SendLocalMsg(WM_BUSINESS_PURCHARB_CHANGED, NULL, NULL);
		//		break;
		//	case enumSalesOrder:
		//		theApp.SendLocalMsg(WM_BUSINESS_SALESORDER_CHANGED, NULL, NULL);
		//		break;
		//	case enumSalesTikits:
		//		theApp.SendLocalMsg(WM_BUSINESS_SALES_CHANGED, NULL, NULL);
		//		break;
		//	case enumSalesOrderToSales:
		//		theApp.SendLocalMsg(WM_BUSINESS_SALESORDERS_CHANGED, NULL, NULL);
		//		break;
		//	case enumSalesBack:
		//		theApp.SendLocalMsg(WM_BUSINESS_SALESB_CHANGED, NULL, NULL);
		//		break;
		//	case enumTickitsReg:
		//		theApp.SendLocalMsg(WM_BUSINESS_TICKREG_CHANGED, NULL, NULL);
		//		break;
		//	case enumTickitsUnreg:
		//		theApp.SendLocalMsg(WM_BUSINESS_TICKUNREG_CHANGED, NULL, NULL);
		//		break;
		//	case enumTickitsSales:
		//		theApp.SendLocalMsg(WM_BUSINESS_TICKSALES_CHANGED, NULL, NULL);
		//		break;
		//	case enumTickitsRecycle:
		//		theApp.SendLocalMsg(WM_BUSINESS_TICKRETURN_CHANGED, NULL, NULL);
		//		break;
		//	case enumPayment:
		//		theApp.SendLocalMsg(WM_ACOUNT_PAYMENT_CHANGED, NULL, NULL);
		//		break;
		//	case enumPaymable:
		//		theApp.SendLocalMsg(WM_ACOUNT_PAYABLE_CHANGED, NULL, NULL);
		//		break;
		//	case enumService:
		//		theApp.SendLocalMsg(WM_BUSINESS_SERVICE_CHANSE, NULL, NULL);
		//		break;
		//	case enumStoreIn:
		//		theApp.SendLocalMsg(WM_STORE_STORIN_CHANGED, NULL, NULL);
		//		break;
		//	case enumStoreOut:
		//		theApp.SendLocalMsg(WM_STORE_STOROUT_CHANGED, NULL, NULL);
		//		break;
		//	case enumBorrow:
		//		theApp.SendLocalMsg(WM_STORE_BORROW_CHANGED, NULL, NULL);
		//		break;
		//	case enumReturnTo:
		//		theApp.SendLocalMsg(WM_STORE_RETURNTO_CHANGED, NULL, NULL);
		//		break;
		//	case enumLend:
		//		theApp.SendLocalMsg(WM_STORE_LEND_CHANGED, NULL, NULL);
		//		break;
		//	case enumReturnFrom:
		//		theApp.SendLocalMsg(WM_STORE_RETURNFROM_CHANGED, NULL, NULL);
		//		break;
		//	case enumComposite:
		//		theApp.SendLocalMsg(WM_STORE_COMPOSITE_CHANGED, NULL, NULL);
		//		break;
		//	case enumDispatch:
		//		theApp.SendLocalMsg(WM_STORE_DISPATCH_CHANGED, NULL, NULL);
		//		break;
		//	case enumStoreLoss:
		//		theApp.SendLocalMsg(WM_STORE_LOSS_CHANGED, NULL, NULL);
		//		break;
		//	case enumCheckBenefit:
		//		theApp.SendLocalMsg(WM_STORE_CHECKBENEFIT_CHANGED, NULL, NULL);
		//		break;
		//	case enumCheckLoss:
		//		theApp.SendLocalMsg(WM_STORE_CHECKBDEFICIT_CHANGED, NULL, NULL);
		//		break;
		//	}
		//}
		//else
		//{
		//	return TRUE;
		//}
	}

	return CMFCPropertySheet::OnCommand(wParam, lParam);
}


INT_PTR CTickitsFrame::DoModal()
{
	if (m_spTickitData->GetInitialState() != Database::NewItem)
	{
		CDataProcessDlg* pDataSave;
		if (m_spTickitData->GetInitialState() == Database::Modified ||
			m_spTickitData->GetInitialState() == Database::Deleted)
		{
			pDataSave = new CDataProcessDlg(
				m_spTickitData, m_enumTickType, m_spMainKeys, this, TRUE, m_enumSourceTickType, m_spOldTickitsData);
		}
		else
		{
			pDataSave = new CDataProcessDlg(
				m_spTickitData, m_enumTickType, m_spMainKeys, this, TRUE, m_enumSourceTickType);
		}
		pDataSave->DoModal();
		BOOL bSuccess = pDataSave->m_bOK;
		delete pDataSave;
		if (!bSuccess)
		{
			return FALSE;
		}
	}

	return CMFCPropertySheet::DoModal();
}
