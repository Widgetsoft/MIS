// ServiceInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "ServiceInfoDoc.h"
#include "LocalDataGridView.h"
#include "ServiceInfoView.h"
#include "SystemInfo.h"

using namespace BasicInfo;
#define ID_GRID_SVCINFO 0x9013

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CServiceInfoView

IMPLEMENT_DYNCREATE(CServiceInfoView, CView)

CServiceInfoView::CServiceInfoView()
	:m_ListCtrl( IDR_POPUP_EDIT ),
	m_spEquipInfoDatas( new GenerialPattern::CItemsData()),
	m_spTypes(new GenerialPattern::CItemsData()),
	m_spSpecs(new GenerialPattern::CItemsData()),
	m_sp1Units(new GenerialPattern::CItemsData()),
	m_sp2Units(new GenerialPattern::CItemsData())
{
	m_uipMetaTimerID = -1;
	m_uipEquipInfoTimerID = -1;
	m_uipTimerID = -1;
}

CServiceInfoView::~CServiceInfoView()
{
}

BEGIN_MESSAGE_MAP(CServiceInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CServiceInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_SVCINFO, &CServiceInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CServiceInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CServiceInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CServiceInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CServiceInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CServiceInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CServiceInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CServiceInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CServiceInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CServiceInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CServiceInfoView::OnEditFind)
	ON_MESSAGE(WM_PSOPTION_CHANGED, &CServiceInfoView::OnOptInfoDataChanged)
	ON_MESSAGE(WM_EQUIPINFO_CHANGED, &CServiceInfoView::OnEquipInfoDataChanged)
	ON_MESSAGE(WM_SVCINFO_CHANGED, &CServiceInfoView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()

void CServiceInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetServiceInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 11; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 10)
			{
				if (strCellText.Compare(_T("�Ƽ�")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 12)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 13)
			{
				if (strCellText.Compare(_T("��������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 14)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

void CServiceInfoView::LoadEquipInfoes()
{
	m_spEquipInfoDatas->ClearItemDatas();
	CGridColumnTraitCombo* pComboTrait =
		reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(9));

	ASSERT(pComboTrait != NULL);
	pComboTrait->ClearFixedItems();


	pComboTrait->AddItem(0, _T("��"));
	auto pData = new GenerialPattern::CItemData();
	CString strEmptyID;
	Helper::CToolkits::ConvertGUID(GUID_NULL, strEmptyID);
	pData->AddRange(strEmptyID, _T("��"),
		_T("���Ϊ��"), _T("����Ϊ��"), NULL);
	m_spEquipInfoDatas->AddItemData(0, pData);

	GenerialPattern::CItemsData* pTempTable = nullptr;

	LOCALEDB;

	if (pDataBase != NULL &&  pDataBase->NormalGetItemsData(_T("SELECT EIID, EIName || '(' || EICustomCode || ')', EISpec, JM FROM tsw_tabEquipmentInfo;"), &pTempTable))
	{
		for (int i = 0; i != (int)pTempTable->GetSize(); i++)
		{
			pComboTrait->AddItem(i + 1, pTempTable->GetItemData(i)->at(1).c_str());
			auto pData1 = new GenerialPattern::CItemData();
			pData1->AddRange(pTempTable->GetItemData(i)->at(0).c_str(),
				pTempTable->GetItemData(i)->at(1).c_str(),
				pTempTable->GetItemData(i)->at(2).c_str(),
				pTempTable->GetItemData(i)->at(3).c_str(),
				NULL);
			m_spEquipInfoDatas->AddItemData(i + 1, pData1);
		}
		delete pTempTable;
	}


	const size_t itemCount = GetDocument()->m_vector.GetCount();
	for (int j = 0; j != itemCount; j++)
	{
		m_ListCtrl.SetItemText(j, 9, GetDocument()->m_vector.GetCellText(j, 9));
	}

	m_ListCtrl.RedrawItems(0, (int)(itemCount - 1));

}

void CServiceInfoView::LoadMetaData()
{
	Database::CProductOptionsVector vectOption1, vectOption2, vectOption3, vectOption4;

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '�����ײ����'"), vectOption1.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption1);
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '�����ײ͹��'"), vectOption2.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption2);
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '�����ײ�����λ'"), vectOption3.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption3);
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '�����ײ͸���λ'"), vectOption3.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption4);
	}

	m_spTypes->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(3));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption1.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption1.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption1.GetCellText(i, 0),
			vectOption1.GetCellText(i, 2),
			vectOption1.GetCellText(i, 5),
			vectOption1.GetCellText(i, 3),
			vectOption1.GetCellText(i, 4),
			vectOption1.GetCellText(i, 1), NULL);
		m_spTypes->AddItemData(i, pData);
	}

	m_spSpecs->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(4));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption2.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption2.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption2.GetCellText(i, 0),
			vectOption2.GetCellText(i, 2),
			vectOption2.GetCellText(i, 5),
			vectOption2.GetCellText(i, 3),
			vectOption2.GetCellText(i, 4),
			vectOption2.GetCellText(i, 1), NULL);
		m_spSpecs->AddItemData(i, pData);
	}

	m_sp1Units->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(5));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption3.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption3.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption3.GetCellText(i, 0),
			vectOption3.GetCellText(i, 2),
			vectOption3.GetCellText(i, 5),
			vectOption3.GetCellText(i, 3),
			vectOption3.GetCellText(i, 4),
			vectOption3.GetCellText(i, 1), NULL);
		m_sp1Units->AddItemData(i, pData);
	}

	m_sp2Units->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(6));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption4.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption4.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption4.GetCellText(i, 0),
			vectOption4.GetCellText(i, 2),
			vectOption4.GetCellText(i, 5),
			vectOption4.GetCellText(i, 3),
			vectOption4.GetCellText(i, 4),
			vectOption4.GetCellText(i, 1), NULL);
		m_sp2Units->AddItemData(i, pData);
	}
}

// CServiceInfoView ��ͼ

void CServiceInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CServiceInfoView ���

#ifdef _DEBUG
void CServiceInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CServiceInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CServiceInfoDoc* CServiceInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CServiceInfoDoc)));
	return reinterpret_cast<CServiceInfoDoc*>(m_pDocument);
}
#endif //_DEBUG


// CServiceInfoView ��Ϣ��������


int CServiceInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_SVCINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 11; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 3:
		case 4:
		case 5:
		case 6:
		case 9:
			pTrait = new CGridColumnTraitCombo();
			break;
		case 2:
		case 15:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 10:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("�Ƽ�"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("��ʱ"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 11:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("�ɴ���"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 12:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("�ɻ���"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 13:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("��������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("������"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 14:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("ͣ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("����"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 16:
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	LoadData();
	LoadMetaData();
	LoadEquipInfoes();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("������Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CServiceInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}


void CServiceInfoView::OnEditNewitem()
{
	if (m_spTypes->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������ײͷ��������Ϣ���޷�����ִ�иò�����"), _T("�����ײͷ�����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_spSpecs->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ��ײͷ�������Ϣ���޷�����ִ�иò�����"), _T("�����ײͷ�����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_sp1Units->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ��ײͷ�����������λ��Ϣ���޷�����ִ�иò�����"), _T("�����ײͷ�����Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_sp2Units->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ��ײͷ��񸨼�����λ��Ϣ���޷�����ִ�иò�����"), _T("������Ʒ��Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	Database::CServiceInfo* pItem = new Database::CServiceInfo();
	pItem->SetState(Database::NewItem);

	//1������ѡ��Ĭ��ֵ
	auto pOptionItem = m_spTypes->GetItemData(0);
	pItem->SetCellText(22, pOptionItem->at(0).c_str());
	pItem->SetCellText(3, pOptionItem->at(1).c_str());

	pOptionItem = m_spSpecs->GetItemData(0);
	pItem->SetCellText(23, pOptionItem->at(0).c_str());
	pItem->SetCellText(4, pOptionItem->at(1).c_str());

	pOptionItem = m_sp1Units->GetItemData(0);
	pItem->SetCellText(24, pOptionItem->at(0).c_str());
	pItem->SetCellText(5, pOptionItem->at(1).c_str());

	pOptionItem = m_sp2Units->GetItemData(0);
	pItem->SetCellText(25, pOptionItem->at(0).c_str());
	pItem->SetCellText(6, pOptionItem->at(1).c_str());

	pOptionItem = m_spEquipInfoDatas->GetItemData(0);
	pItem->SetCellText(21, pOptionItem->at(0).c_str());
	pItem->SetCellText(9, pOptionItem->at(1).c_str());

	pItem->SetCellText(19, theApp.m_siInfo->m_strUserInnerID);
	pItem->SetCellText(20, theApp.m_siInfo->m_strUserInnerID);

	pItem->SetCellText(26, theApp.m_siInfo->m_strEntID);

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 11; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 10)
			{
				if (strCellText.Compare(_T("�Ƽ�")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 11)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 12)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 13)
			{
				if (strCellText.Compare(_T("��������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 14)
			{
				if (strCellText.Compare(_T("ͣ��")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CServiceInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 1: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 16, tcsText);
				m_ListCtrl.SetItemText(nRow, 16, tcsText);
			}
		}
		break;
	case 3:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spTypes, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 22, varPair.first.c_str());
		}
		break;
	case 4:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spSpecs, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 23, varPair.first.c_str());
		}
		break;
	case 5:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_sp1Units, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 24, varPair.first.c_str());
		}
		break;
	case 6:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_sp2Units, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 25, varPair.first.c_str());
		}
		break;
	case 9:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spEquipInfoDatas, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 21, varPair.first.c_str());
		}
		break;
	case 7:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.6f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	case 8:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}


void CServiceInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CServiceInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CServiceInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CServiceInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CServiceInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CServiceInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CServiceInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CServiceInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CServiceInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CServiceInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}


LRESULT CServiceInfoView::OnOptInfoDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipMetaTimerID != UINT(-1))
	{
		KillTimer(m_uipMetaTimerID);
		m_uipMetaTimerID = UINT(-1);
	}
	m_uipMetaTimerID = SetTimer(34, 1034, NULL);
	return 0L;
}

LRESULT CServiceInfoView::OnEquipInfoDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipEquipInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipEquipInfoTimerID);
		m_uipEquipInfoTimerID = UINT(-1);
	}
	m_uipEquipInfoTimerID = SetTimer(35, 1035, NULL);
	return 0L;
}

LRESULT CServiceInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipTimerID != UINT(-1))
	{
		KillTimer(m_uipTimerID);
		m_uipTimerID = UINT(-1);
	}
	m_uipTimerID = SetTimer(36, 1036, NULL);
	return 0L;
}

void CServiceInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipMetaTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipMetaTimerID != UINT(-1))
			{
				KillTimer(m_uipMetaTimerID);
				m_uipMetaTimerID = UINT(-1);
			}
			LoadMetaData(); //���¼��������б�
			LoadData();
		}
	}
	else if (m_uipEquipInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipEquipInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipEquipInfoTimerID);
				m_uipEquipInfoTimerID = UINT(-1);
			}
			LoadEquipInfoes();
			LoadData(); //���¼��������б�
		}
	}
	else if (m_uipTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipTimerID != UINT(-1))
			{
				KillTimer(m_uipTimerID);
				m_uipTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
