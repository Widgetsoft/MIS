#pragma once
namespace BasicInfo
{
	// CStaffInfoDoc �ĵ�

	class CStaffInfoDoc : public CDocument
	{
		DECLARE_DYNCREATE(CStaffInfoDoc)

	public:
		CStaffInfoDoc();
		virtual ~CStaffInfoDoc();

	public:
		Database::CStaffInfoVector m_vector;
		Database::CStaffInfoVector m_vectNewItems;
		Database::CStaffInfoVector m_vectModItems;
		Database::CStaffInfoVector m_vectDelItems;

#ifndef _WIN32_WCE
		virtual void Serialize(CArchive& ar);   // Ϊ�ĵ� I/O ��д
#endif
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		virtual BOOL OnNewDocument();

		DECLARE_MESSAGE_MAP()
		virtual BOOL SaveModified();
	public:
		afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
		afx_msg void OnFileSave();
	};
}
