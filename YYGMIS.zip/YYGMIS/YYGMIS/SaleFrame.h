#pragma once

namespace Business
{
	// CSaleFrame ���

	class CSaleFrame : public CMDIFrameWndEx
	{
		DECLARE_DYNCREATE(CSaleFrame)
	public:
		CSaleFrame();          
		virtual ~CSaleFrame();

	public:
		std::shared_ptr<Core::CSaleServiceWork> m_pWorker;
		BOOL m_bMainWndHide;

		// Attributes
	protected:  // control bar embedded members
		CMFCMenuBar m_wndMenuBar;
		CMFCToolBar m_wndToolBar;
		CMFCStatusBar m_wndStatusBar;
		CWnd* m_pMainWnd;

	protected:
		CMFCToolBarComboBoxButton* GetPageCombo();

		// Operations
	public:
		static void OnChangeLook();

		virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, CWnd* pParentWnd = NULL, CCreateContext* pContext = NULL);

	protected:
		DECLARE_MESSAGE_MAP()
	public:
		afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
		afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
		afx_msg void OnClose();
		afx_msg void OnSaleClose();
		afx_msg void OnEnable(BOOL bEnable);
		afx_msg void OnUpdateWindowNew(CCmdUI *pCmdUI);
		afx_msg void OnSize(UINT nType, int cx, int cy);

		afx_msg void OnViewFullScreen();
		afx_msg void OnToolsOptions();

		afx_msg void OnViewCustomize();
		afx_msg LRESULT OnToolbarReset(WPARAM, LPARAM);
		afx_msg LRESULT OnGetTabToolTip(WPARAM wp, LPARAM lp);
		afx_msg LRESULT OnHelpCustomizeToolbars(WPARAM wp, LPARAM lp);
		LRESULT OnToolbarCreateNew(WPARAM wp, LPARAM lp);
	};
}


