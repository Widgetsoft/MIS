#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "WorkAssistant.h"

using namespace Business;
using namespace Business::Core;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CWorkAssistant::CWorkAssistant()
{
	//�������ڴ�
	COleDateTime timeNow = COleDateTime::GetCurrentTime();
	CString strTime;
	strTime.Format(_T("%4d%02d%02d"), timeNow.GetYear(), timeNow.GetMonth(), timeNow.GetDay());
	_tcscpy_s(tcsYear, 9, strTime);
}


CWorkAssistant::~CWorkAssistant()
{
}


UINT CWorkAssistant::GetCurrentIndex(const DataPattern::EnumBusinessType enumType,
	LPCTSTR lpctstrColName, LPCTSTR lpctstrTableName) const
{
	UINT uiRet = 1;

	CString strPrefix = GetTickitPrefix(enumType);
	CString strQuery;
	strQuery.Format(_T("SELECT MAX(CAST( SUBSTR(%s, 12, 5) AS INT)) AS ��ǰ���� FROM %s GROUP BY SUBSTR(%s,  1, 3 ), SUBSTR(%s,  4, 8 ) HAVING SUBSTR(%s,  1, 3 ) LIKE '%s' AND SUBSTR(%s,  4, 8 ) LIKE '%s';")
		, lpctstrColName, lpctstrTableName, lpctstrColName, lpctstrColName, lpctstrColName, strPrefix, lpctstrColName, tcsYear);
	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		GenerialPattern::CItemData* pItemData = nullptr;
		if (pDataBase->NormalGetItemData(strQuery, &pItemData) && pItemData != nullptr)
		{
			if (pItemData->size() > 0 && !pItemData->at(0).empty())
			{
				UINT nTemp = UINT_MAX;
				nTemp = _ttoi(pItemData->at(0).c_str());
				if (nTemp != UINT_MAX)
				{
					uiRet = nTemp + 1;
				}
			}
			delete pItemData;
		}
	}

	return uiRet;
}

CString CWorkAssistant::GetTickitPrefix(const DataPattern::EnumBusinessType enumType)
{
	CString strRet;
	switch (enumType)
	{
	case DataPattern::enumPurchaseTickits:
		strRet.Append(_T("GPB")); //General Purchase Bill
		break;
	case DataPattern::enumSalesTikits:
		strRet.Append(_T("GSB")); //General Sale Bill
		break;
	case DataPattern::enumReceivableTickets:
		strRet.Append(_T("GRB")); //ʵ�տ�
		break;
	case DataPattern::enumPayableTicket:
		strRet.Append(_T("GPB")); //ʵ�տ�
		break;
	case DataPattern::enumServiceTikits:
		strRet.Append(_T("GSB"));
		break;
	case DataPattern::enumStoreIn:
		strRet.Append(_T("SIT"));
		break;
	case DataPattern::enumStoreOut:
		strRet.Append(_T("SOT"));
		break;
	case DataPattern::enumStoreLoss:
		strRet.Append(_T("PLT")); //General Product Loss
		break;
	}

	return strRet;
}

void CWorkAssistant::NormalComboBoxProxy(CComboBox& cmbTarget, Database::CFlybyItem* pAssumeObject,
	std::shared_ptr<DataPattern::CTickitsData> spData, size_t szPage, const UINT uiCol, const UINT uiCol1, 
	const BOOL bResetItems,	LPCTSTR lpcszTargetID)
{
	if (bResetItems)
	{
		if (lpcszTargetID == nullptr)
		{
			cmbTarget.SetCurSel(0);
		}
		else if (lpcszTargetID != nullptr)
		{
			int nFound = CB_ERR;
			for (int nSel = 0; nSel != cmbTarget.GetCount(); nSel++)
			{
				GenerialPattern::CItemData* pItem =
					reinterpret_cast<GenerialPattern::CItemData*>(cmbTarget.GetItemDataPtr(nSel));
				if (pItem->at(0).compare(lpcszTargetID) == 0)
				{
					nFound = nSel;
					break;
				}
			}

			if (nFound != CB_ERR)
			{
				cmbTarget.SetCurSel(nFound);
			}
			else
			{
				//�Ҳ���
				cmbTarget.SetCurSel(0);
			}
		}
	}
	GenerialPattern::CItemData* pItem =
		reinterpret_cast<GenerialPattern::CItemData*>(cmbTarget.GetItemDataPtr(0));

	Database::CFlybyItem* pDataItem = NULL;
	if (spData != nullptr)
	{
		spData->GetCurrentFlybyData(szPage, (PVOID*)&pDataItem);
	}
	else
	{
		pDataItem = pAssumeObject;
	}
	
	pDataItem->SetCellText(uiCol, pItem->at(0).c_str());
	pDataItem->SetCellText(uiCol1, pItem->at(1).c_str());
}

void CWorkAssistant::LoadComboNormalData(std::shared_ptr<DataPattern::CTickitsData> spData, 
	CComboBox& cmbTarget, GenerialPattern::CItemData* pAddItem, size_t szPage,
	const BOOL bUpdateItem, const UINT uiCol, const UINT uiCol1)
{
	int nFound = cmbTarget.FindStringExact(-1, pAddItem->at(1).c_str());

	if (nFound != CB_ERR)
	{
		//�����Ա�ID
		GenerialPattern::CItemData* pItem = 
			reinterpret_cast<GenerialPattern::CItemData*>(cmbTarget.GetItemDataPtr(nFound));
		ASSERT(pItem != NULL);
		if( _tcscmp(pItem->at(0).c_str(), pAddItem->at(0).c_str()) != 0)
		{
			//����ID��ͬ���������¼���
			nFound = CB_ERR;
		}
	}
	if (nFound == CB_ERR)
	{
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(pAddItem->at(0).c_str(), pAddItem->at(1).c_str(), NULL);
		int nIndex = cmbTarget.AddString(apItem->at(1).c_str());
		cmbTarget.SetItemDataPtr(nIndex, apItem.release());
		cmbTarget.SetCurSel(nIndex);
	}
	else
	{
		//����ѡ����Ŀ
		cmbTarget.SetCurSel(nFound);
	}

	if (bUpdateItem)
	{
		Database::CFlybyItem* pDataItem = NULL;
		spData->GetCurrentFlybyData(szPage, (PVOID*)&pDataItem);
		ASSERT(pDataItem != NULL);
		pDataItem->SetCellText(uiCol, pAddItem->at(0).c_str());
		pDataItem->SetCellText(uiCol1, pAddItem->at(1).c_str());
	}
}

void CWorkAssistant::QIFilterOptions(std::shared_ptr<DataPattern::CTickitsData> spData,
	LPCTSTR lpcszQuery, CComboBox& cmbTarget, LPCTSTR strText, size_t szPage, BOOL bAddNullItem)
{
	Database::CFlybyItem* pData = NULL;
	BOOL bSuccess = spData->GetCurrentFlybyData(szPage, (void**)&pData);
	ASSERT(bSuccess); //�����Ƿ�ɹ�

	if (pData->GetState() != Database::Initial)	//�ж��Ƿ�Ϊ�༭ģʽ
	{
		for (int nSize = cmbTarget.GetCount() - 1; nSize != -1; nSize--)
		{
			PVOID pvDate = cmbTarget.GetItemDataPtr(nSize);
			if (pvDate)
			{
				delete pvDate;
			}
			cmbTarget.DeleteString(nSize);
		}

		if (bAddNullItem)
		{
			CString strNullID;
			Helper::CToolkits::ConvertGUID(GUID_NULL, strNullID);
			std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
			apItem->AddRange(strNullID, _T(""), NULL);
			int nAdded = cmbTarget.AddString(apItem->at(1).c_str());
			cmbTarget.SetItemDataPtr(nAdded, apItem.release());
		}

		if (_tcslen(strText) < 1)
		{
			if (cmbTarget.GetDroppedState() == TRUE)
			{
				cmbTarget.ShowDropDown(FALSE);
			}
		}
		else
		{
			//�������¼�������
			CString strQuery;
			strQuery.Append(lpcszQuery);
			LOCALEDB;
			GenerialPattern::CItemsData* pDatas = NULL;
			if (pDataBase && pDataBase->NormalGetItemsData(strQuery, &pDatas))
			{
				int nCount = pDatas->GetSize();
				if (nCount > 0)
				{
					for (int i = 0; i != nCount; i++)
					{
						std::auto_ptr<GenerialPattern::CItemData> apItem(pDatas->GetItemData(i));
						int nAdded = cmbTarget.AddString(apItem->at(1).c_str());
						cmbTarget.SetItemDataPtr(nAdded, apItem.release());
					}

					if (cmbTarget.GetDroppedState() == FALSE)
					{
						cmbTarget.ShowDropDown(TRUE);
						cmbTarget.SendMessage(WM_SETCURSOR, 0, 0);
					}
				}
			}
		}
	}
}

GenerialPattern::CItemData*  CWorkAssistant::QIValidateOptions(std::shared_ptr<DataPattern::CTickitsData> spData,
	CComboBox& cmbTarget, const UINT uiCol, const UINT uiCol1, size_t szPage)
{
	GenerialPattern::CItemData* pItemData = nullptr;
	int nIndex = CB_ERR;
	Database::CFlybyItem* pData = NULL;
	BOOL bSuccess = spData->GetCurrentFlybyData(szPage, (void**)&pData);
	ASSERT(bSuccess); //�����Ƿ�ɹ�
	if (cmbTarget.GetCount() > 0 && pData->GetState() != Database::Initial)
	{
		CString strText;
		nIndex = cmbTarget.GetCurSel();
		if (nIndex == CB_ERR) //δ���ҵ�����
		{
			cmbTarget.GetWindowText(strText);
			nIndex = cmbTarget.FindStringExact(0, strText.Trim());
			if (nIndex == CB_ERR)
			{
				nIndex = cmbTarget.FindString(0, strText.Trim());
				if (nIndex == CB_ERR)
				{
					nIndex = 0;
				}
			}
		}

	}
	if (nIndex != CB_ERR)
	{
		cmbTarget.SetCurSel(nIndex);
		//���ü�¼��ֵ
		pItemData =
			reinterpret_cast<GenerialPattern::CItemData*>(cmbTarget.GetItemDataPtr(nIndex));
		pData->SetCellText(uiCol, pItemData->at(0).c_str());
		pData->SetCellText(uiCol1, pItemData->at(1).c_str());
	}

	return pItemData;
}

void CWorkAssistant::ComboLoadAllItems(LPCTSTR lpcszQuery, CComboBox& cmbTarget,
	GenerialPattern::CItemData* pFeedback, LPCTSTR lpszNormalID, BOOL bContainsNULLItem)
{
	//���ԭʼ���ݵ�����
	for (int nSize = cmbTarget.GetCount() - 1; nSize != -1; nSize--)
	{
		PVOID pvDate = cmbTarget.GetItemDataPtr(nSize);
		if (pvDate)
		{
			delete pvDate;
		}
		cmbTarget.DeleteString(nSize);
	}

	//���¼�������
	CString strQuery;
	strQuery.Append(lpcszQuery);
	LOCALEDB;
	GenerialPattern::CItemsData* pDatas = NULL;
	std::vector<CString> vectHolder;
	if (bContainsNULLItem)
	{
		CString strNullID;
		Helper::CToolkits::ConvertGUID(GUID_NULL, strNullID);
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(strNullID, _T(""), NULL);
		int nAdded = cmbTarget.AddString(apItem->at(1).c_str());
		vectHolder.push_back(strNullID);
		vectHolder.push_back(_T(""));
		cmbTarget.SetItemDataPtr(nAdded, apItem.release());
	}

	int nCurSel = -1;

	if (pDataBase && pDataBase->NormalGetItemsData(strQuery, &pDatas))
	{
		int nCount = pDatas->GetSize();
		if (nCount > 0)
		{
			for (int i = 0; i != nCount; i++)
			{
				std::auto_ptr<GenerialPattern::CItemData> apItem(pDatas->GetItemData(i));
				int nAdded = cmbTarget.AddString(apItem->at(1).c_str());
				if (lpszNormalID != nullptr && _tcscmp(lpszNormalID, apItem->at(0).c_str()) == 0)
				{
					nCurSel = nAdded;
					if (pFeedback != nullptr)
					{
						pFeedback->clear();
						pFeedback->AddRange(apItem->at(0).c_str(), apItem->at(1).c_str(), nullptr);
					}
				}
				else
				{
					if (pFeedback != nullptr && i == 0)
					{
						pFeedback->clear();
						pFeedback->AddRange(apItem->at(0).c_str(), apItem->at(1).c_str(), nullptr);
					}
				}

				cmbTarget.SetItemDataPtr(nAdded, apItem.release());
			}
			if (nCurSel == -1)
			{
				nCurSel = 0;
				cmbTarget.SetCurSel(nCurSel);
			}
		}
	}

	if (bContainsNULLItem && nCurSel == -1)
	{
		cmbTarget.SetCurSel(0);
		if (pFeedback != nullptr)
		{
			pFeedback->clear();
			pFeedback->AddRange(vectHolder.at(0), vectHolder.at(1), nullptr);
		}
	}
}