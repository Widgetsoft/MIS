#include "stdafx.h"
#include "TransparentLabel.h"
using namespace UI::Control;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CTransparentLabel

IMPLEMENT_DYNAMIC(CTransparentLabel, CStatic)

CTransparentLabel::CTransparentLabel()
{

}

CTransparentLabel::~CTransparentLabel()
{
}


BEGIN_MESSAGE_MAP(CTransparentLabel, CStatic)
	ON_WM_CTLCOLOR_REFLECT()
END_MESSAGE_MAP()



// CTransparentLabel ��Ϣ��������

HBRUSH CTransparentLabel::CtlColor(CDC* pDC, UINT /*nCtlColor*/)
{
	pDC->SetBkMode(TRANSPARENT);
	return (HBRUSH)GetStockObject(NULL_BRUSH);
}
