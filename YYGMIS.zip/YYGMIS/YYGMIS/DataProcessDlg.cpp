// DataProcessDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "DataProcessDlg.h"
#include "afxdialogex.h"
#include "DataLoadSaveThread.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDataProcessDlg �Ի���

IMPLEMENT_DYNAMIC(CDataProcessDlg, CDialogEx)

CDataProcessDlg::CDataProcessDlg(std::shared_ptr<DataPattern::CTickitsData> spDatas, DataPattern::EnumBusinessType enumTickType,
	std::shared_ptr<GenerialPattern::CItemData> spItemKeys,
	CWnd* pParent, BOOL bLoadOnly, DataPattern::EnumBusinessType enumSourceTickType
	, std::shared_ptr<DataPattern::CTickitsData> spOldTickitsData)
	: CDialogEx(IDD_GENERAL_DP_DLG, pParent),
	m_spItemKeys(spItemKeys),
	m_mutex(FALSE, NULL),
	m_bOK(FALSE),
	m_threadWorker(NULL),
	m_spTickitsData(spDatas),
	m_enumTickType(enumTickType),
	m_bLoadOnly(bLoadOnly),
	m_enumSourceTickType(enumSourceTickType),
	m_spOldTickitsData(spOldTickitsData)
{

}

CDataProcessDlg::~CDataProcessDlg()
{
}

void CDataProcessDlg::DoDataExchange(CDataExchange* pDX)
{
	DDX_Control(pDX, IDC_PROGRESS1, m_progressTotal);
	DDX_Control(pDX, IDC_PROGRESS2, m_progressSub);
	DDX_Control(pDX, IDC_GENERAL_DP_LABEL1, m_label1);

	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDataProcessDlg, CDialogEx)
	ON_WM_CLOSE()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()


// CDataProcessDlg ��Ϣ��������


BOOL CDataProcessDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set WS_EX_LAYERED on this window 
	SetWindowLong(this->GetSafeHwnd(), GWL_EXSTYLE,
		GetWindowLong(this->GetSafeHwnd(), GWL_EXSTYLE) | WS_EX_LAYERED);
	// Make this window 70% alpha
	::SetLayeredWindowAttributes(this->GetSafeHwnd(), 0, (255 * 70) / 100, LWA_ALPHA);

	//CProgressCtrl* pProgress = (CProgressCtrl*)GetDlgItem(IDC_DESIGN_BLOB_PROGRESS);
	//DWORD dwStyle = pProgress->GetStyle();
	//dwStyle |= PBS_MARQUEE;
	//SetWindowLongPtr(pProgress->GetSafeHwnd(), GWL_STYLE, dwStyle);
	//pProgress->SetMarquee(TRUE, 0);
	//pProgress->ShowWindow(SW_HIDE);


	return TRUE;  // return TRUE unless you set the focus to a control
				  // �쳣: OCX ����ҳӦ���� FALSE
}

void CDataProcessDlg::Start()
{
	m_threadWorker = (CDataLoadSaveThread*)AfxBeginThread(RUNTIME_CLASS(CDataLoadSaveThread), THREAD_PRIORITY_NORMAL,
		0, CREATE_SUSPENDED);
	m_threadWorker->SetOwner(this);
	m_threadWorker->ResumeThread();
}

void CDataProcessDlg::OnClose()
{
	if (m_threadWorker!= nullptr)
	{
		delete m_threadWorker;
	}

	CDialogEx::OnClose();
}


INT_PTR CDataProcessDlg::DoModal()
{
	Start();
	return CDialogEx::DoModal();
}


BOOL CDataProcessDlg::OnEraseBkgnd(CDC* pDC)
{
	CRect rcClient;
	GetClientRect(&rcClient);

	CDrawingManager dm(*pDC);
	dm.FillGradient(rcClient, RGB(236, 246, 237), RGB(255, 255, 255), TRUE);
	return TRUE;
}
