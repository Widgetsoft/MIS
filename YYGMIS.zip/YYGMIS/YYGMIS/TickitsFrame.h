#pragma once

namespace Business
{
	// CTickitsFrame

	class CTickitsFrame : public CMFCPropertySheet
	{
		DECLARE_DYNAMIC(CTickitsFrame)

	public:
		CTickitsFrame(CWnd* pWndParent, const std::unordered_map<UINT, CString> mapPageTitles, LPCTSTR lpctszTitle, DataPattern::CTickitsData* tickitData,
			DataPattern::EnumBusinessType enumTickType, UINT nSelectedPage = 0, const DWORD dwImageID = -1, GenerialPattern::CItemData* pItemKeys = NULL,
			DataPattern::EnumBusinessType enumSourceTickType = DataPattern::enumUnknown);

		virtual ~CTickitsFrame();

	public:
		std::shared_ptr<DataPattern::CTickitsData> m_spTickitData;
		DataPattern::EnumBusinessType m_enumTickType;
		DataPattern::EnumBusinessType m_enumSourceTickType;

	private:
		CMFCToolBarImages m_Icons;
		CMFCControlRenderer m_Pat[4];
		const DWORD m_dwImageID;
		const std::unordered_map<UINT, CString> m_mapPageTitles;
		UINT m_nCurrentPage;

		std::shared_ptr<GenerialPattern::CItemData> m_spMainKeys;
		std::shared_ptr<DataPattern::CTickitsData> m_spOldTickitsData;
	protected:
		virtual void OnDrawPageHeader(CDC* pDC, int nPage, CRect rectHeader);
		DECLARE_MESSAGE_MAP()

	public:
		virtual BOOL OnInitDialog();
		virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
		virtual INT_PTR DoModal();
	};
}


