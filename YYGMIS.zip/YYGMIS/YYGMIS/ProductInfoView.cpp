// ProductInfoView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "ProductInfoDoc.h"
#include "LocalDataGridView.h"
#include "ProductInfoView.h"
#include "SystemInfo.h"

using namespace BasicInfo;
#define ID_GRID_PRODUCTINFO 0x9011

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CProductInfoView

IMPLEMENT_DYNCREATE(CProductInfoView, CView)

CProductInfoView::CProductInfoView()
	:m_ListCtrl(IDR_POPUP_EDIT),
	m_spTypes( new GenerialPattern::CItemsData()),
	m_spSpecs(new GenerialPattern::CItemsData()),
	m_sp1Units(new GenerialPattern::CItemsData()),
	m_sp2Units(new GenerialPattern::CItemsData())
{
	m_uipMetaTimerID = -1;
	m_uipProdInfoTimerID = -1;
}

CProductInfoView::~CProductInfoView()
{
}

BEGIN_MESSAGE_MAP(CProductInfoView, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_NEWITEM, &CProductInfoView::OnEditNewitem)
	ON_NOTIFY(LVN_ENDLABELEDIT, ID_GRID_PRODUCTINFO, &CProductInfoView::OnLvnEndlabeledit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH, &CProductInfoView::OnUpdateEditRefresh)
	ON_COMMAND(ID_EDIT_REFRESH, &CProductInfoView::OnEditRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODIFY, &CProductInfoView::OnUpdateEditModify)
	ON_COMMAND(ID_EDIT_MODIFY, &CProductInfoView::OnEditModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CProductInfoView::OnUpdateEditDelete)
	ON_COMMAND(ID_EDIT_DELETE, &CProductInfoView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REVSEL, &CProductInfoView::OnUpdateEditRevsel)
	ON_COMMAND(ID_EDIT_REVSEL, &CProductInfoView::OnEditRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CProductInfoView::OnUpdateEditFind)
	ON_COMMAND(ID_EDIT_FIND, &CProductInfoView::OnEditFind)
	ON_MESSAGE(WM_PSOPTION_CHANGED, &CProductInfoView::OnOptInfoDataChanged)
	ON_MESSAGE(WM_PRODINFO_CHANGED, &CProductInfoView::OnDataChanged)
	ON_WM_TIMER()
END_MESSAGE_MAP()


void CProductInfoView::LoadData()
{
	GetDocument()->m_vectNewItems.ClearItems();
	GetDocument()->m_vectModItems.ClearItems();
	GetDocument()->m_vectDelItems.ClearItems();
	GetDocument()->m_vector.ClearItems();

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s "), GetDocument()->m_vector.m_strBindTable);
		pDataBase->GetProductInfo(strQuery, GetDocument()->m_vector);
	}

	m_ListCtrl.DeleteAllItems();

	// Insert data into list-control by copying from datamodel
	int nItem = 0;
	for (size_t rowId = 0; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 9; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);

			if (nCellCol == 14)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 15)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 16)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}

	GetDocument()->SetModifiedFlag(FALSE);
}

void CProductInfoView::LoadMetaData()
{
	Database::CProductOptionsVector vectOption1, vectOption2, vectOption3, vectOption4;

	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '��Ʒ���'"), vectOption1.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption1);
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '��Ʒ���'"), vectOption2.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption2);
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '��Ʒ����λ'"), vectOption3.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption3);
		strQuery.Format(_T("SELECT * FROM %s WHERE ��Ŀ���� LIKE '��Ʒ����λ'"), vectOption3.m_strBindTable);
		pDataBase->GetProductOptions(strQuery, vectOption4);
	}

	m_spTypes->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(3));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption1.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption1.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption1.GetCellText(i, 0),
			vectOption1.GetCellText(i, 2),
			vectOption1.GetCellText(i, 5),
			vectOption1.GetCellText(i, 3),
			vectOption1.GetCellText(i, 4),
			vectOption1.GetCellText(i, 1), NULL);
		m_spTypes->AddItemData(i, pData);
	}

	m_spSpecs->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(4));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption2.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption2.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption2.GetCellText(i, 0),
			vectOption2.GetCellText(i, 2),
			vectOption2.GetCellText(i, 5),
			vectOption2.GetCellText(i, 3),
			vectOption2.GetCellText(i, 4),
			vectOption2.GetCellText(i, 1), NULL);
		m_spSpecs->AddItemData(i, pData);
	}

	m_sp1Units->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(5));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption3.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption3.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption3.GetCellText(i, 0),
			vectOption3.GetCellText(i, 2),
			vectOption3.GetCellText(i, 5),
			vectOption3.GetCellText(i, 3),
			vectOption3.GetCellText(i, 4),
			vectOption3.GetCellText(i, 1), NULL);
		m_sp1Units->AddItemData(i, pData);
	}

	m_sp2Units->ClearItemDatas();
	pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(6));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption4.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption4.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption4.GetCellText(i, 0),
			vectOption4.GetCellText(i, 2),
			vectOption4.GetCellText(i, 5),
			vectOption4.GetCellText(i, 3),
			vectOption4.GetCellText(i, 4),
			vectOption4.GetCellText(i, 1), NULL);
		m_sp2Units->AddItemData(i, pData);
	}
}

// CProductInfoView ��ͼ

void CProductInfoView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO:  �ڴ����ӻ��ƴ���
}


// CProductInfoView ���

#ifdef _DEBUG
void CProductInfoView::AssertValid() const
{
	CView::AssertValid();
}

#ifndef _WIN32_WCE
void CProductInfoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif
CProductInfoDoc* CProductInfoView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CProductInfoDoc)));
	return reinterpret_cast<CProductInfoDoc*>(m_pDocument);
}
#endif //_DEBUG


// CProductInfoView ��Ϣ��������


int CProductInfoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	const DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | LVS_SHOWSELALWAYS
		| LVS_REPORT /*| LVS_OWNERDATA*/;
	m_ListCtrl.Create(dwStyle, rectDummy, this, ID_GRID_PRODUCTINFO);

	m_ListCtrl.SetVector(&GetDocument()->m_vector);

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	// Create Columns
	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	CGridColumnTraitImage* pImageTrait = nullptr;

	for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 9; ++col)
	{
		const CString& title = GetDocument()->m_vector.GetColTitle(col + 1);
		CGridColumnTrait* pTrait = NULL;
		switch (col + 1)
		{
		case 3:
		case 4:
		case 5:
		case 6:
			pTrait = new CGridColumnTraitCombo();
			break;
		case 1:
		case 12:
		case 13:
			pTrait = new CGridColumnTraitMultilineEdit();
			break;
		case 14:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("�ɴ���"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 15:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("�ɻ���"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		case 16:
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("������"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("������"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
		default:
			pTrait = new CGridColumnTraitEdit;
			break;
		}

		m_ListCtrl.InsertColumnTrait(col + 1, title, LVCFMT_LEFT, 100, col, pTrait);
	}

	LoadData();
	LoadMetaData();

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("��Ʒ��Ϣ����"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);

	return 0;
}


void CProductInfoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	CRect rcClient;
	GetClientRect(rcClient);

	m_ListCtrl.SetWindowPos(NULL, rcClient.left + 1, rcClient.top + 2, rcClient.Width() - 2, rcClient.Height() - 2,
		SWP_NOACTIVATE | SWP_NOZORDER);
}



void CProductInfoView::OnEditNewitem()
{
	if (m_spTypes->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в�������Ʒ�����Ϣ���޷�����ִ�иò�����"), _T("������Ʒ��Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_spSpecs->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ���Ʒ�����Ϣ���޷�����ִ�иò�����"), _T("������Ʒ��Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_sp1Units->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ���Ʒ��������λ��Ϣ���޷�����ִ�иò�����"), _T("������Ʒ��Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}
	if (m_sp2Units->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κ���Ʒ��������λ��Ϣ���޷�����ִ�иò�����"), _T("������Ʒ��Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	Database::CProductInfo* pItem = new Database::CProductInfo();
	pItem->SetState(Database::NewItem);

	//1������ѡ��Ĭ��ֵ
	auto pOptionItem = m_spTypes->GetItemData(0);
	pItem->SetCellText(22, pOptionItem->at(0).c_str());
	pItem->SetCellText(3, pOptionItem->at(1).c_str());

	pOptionItem = m_spSpecs->GetItemData(0);
	pItem->SetCellText(23, pOptionItem->at(0).c_str());
	pItem->SetCellText(4, pOptionItem->at(1).c_str());

	pOptionItem = m_sp1Units->GetItemData(0);
	pItem->SetCellText(24, pOptionItem->at(0).c_str());
	pItem->SetCellText(5, pOptionItem->at(1).c_str());

	pOptionItem = m_sp2Units->GetItemData(0);
	pItem->SetCellText(25, pOptionItem->at(0).c_str());
	pItem->SetCellText(6, pOptionItem->at(1).c_str());

	pItem->SetCellText(20, theApp.m_siInfo->m_strUserInnerID);
	pItem->SetCellText(21, theApp.m_siInfo->m_strUserInnerID);

	GetDocument()->m_vector.AddItem(pItem);
	GetDocument()->m_vectNewItems.AddItem(pItem);

	// Insert data into list-control by copying from datamodel
	int nItem = GetDocument()->m_vector.GetCount() - 1;
	for (size_t rowId = nItem; rowId < GetDocument()->m_vector.GetCount(); ++rowId)
	{
		m_ListCtrl.SetOutlineColor(RGB(255, 0, 0));
		nItem = m_ListCtrl.InsertItem(++nItem, GetDocument()->m_vector.GetCellText(rowId, 1));
		m_ListCtrl.SetItemData(nItem, rowId);
		for (int col = 0; col < GetDocument()->m_vector.GetColCount() - 9; ++col)
		{
			int nCellCol = col + 1;	// +1 because of hidden column
			const CString& strCellText = GetDocument()->m_vector.GetCellText(rowId, nCellCol);
			if (nCellCol == 14)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 15)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			else if (nCellCol == 16)
			{
				if (strCellText.Compare(_T("������")) == 0)
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
				}
				else
				{
					m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
				}
			}
			m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
		}
	}
	GetDocument()->SetModifiedFlag();
	m_ListCtrl.ClearSelections();
	m_ListCtrl.SelectRow(GetDocument()->m_vector.GetCount() - 1, TRUE);
	m_ListCtrl.EnsureVisible(nItem, TRUE);
}

void CProductInfoView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;
	switch (nCol)
	{
	case 1: //�������Ƽ�����
		if (pDispInfo->item.pszText != NULL && _tcscmp(pDispInfo->item.pszText, _T("")) != 0)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
			_tcscpy_s(tcsText, MAX_PATH, _T(""));
			CString strJMText(GetDocument()->m_vector.GetCellText(nRow, nCol));
			Helper::CToolkits::GetPYJM(strJMText, tcsText);
			if (_tcscmp(tcsText, _T("")) != 0)
			{
				GetDocument()->m_vector.SetCellText(nRow, 17, tcsText);
				m_ListCtrl.SetItemText(nRow, 17, tcsText);
			}
		}
		break;
	case 3:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spTypes, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 22, varPair.first.c_str());
		}
		break;
	case 4:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spSpecs, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 23, varPair.first.c_str());
		}
		break;
	case 5:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_sp1Units, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 24, varPair.first.c_str());
		}
		break;
	case 6:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_sp2Units, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			GetDocument()->m_vector.SetCellText(nRow, nCol, varPair.second.c_str());
			GetDocument()->m_vector.SetCellText(nRow, 25, varPair.first.c_str());
		}
		break;
	case 7:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.6f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	case 8:
		if (pDispInfo->item.pszText != NULL)
		{
			int nTemp = 0;
			nTemp = _ttoi(pDispInfo->item.pszText);
			CString strTemp;
			strTemp.Format(_T("%i"), nTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	case 9:
	case 10:
	case 11:
		if (pDispInfo->item.pszText != NULL)
		{
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			GetDocument()->m_vector.SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);
		}
		break;
	default:
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			GetDocument()->m_vector.SetCellText(nRow, nCol, tcsText);
		}
		break;
	}
	*pResult = 0;
}

void CProductInfoView::OnUpdateEditRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CProductInfoView::OnEditRefresh()
{
	this->LoadData();
}


void CProductInfoView::OnUpdateEditModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CProductInfoView::OnEditModify()
{
	m_ListCtrl.LocalModify(&(GetDocument()->m_vectModItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CProductInfoView::OnUpdateEditDelete(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	pCmdUI->Enable(pos != NULL);
}


void CProductInfoView::OnEditDelete()
{
	m_ListCtrl.LocalDelete(&(GetDocument()->m_vectDelItems), &(GetDocument()->m_vectNewItems));

	GetDocument()->SetModifiedFlag(GetDocument()->m_vectNewItems.GetCount() > 0 ||
		GetDocument()->m_vectModItems.GetCount() > 0 ||
		GetDocument()->m_vectDelItems.GetCount() > 0);
}


void CProductInfoView::OnUpdateEditRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CProductInfoView::OnEditRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CProductInfoView::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(GetDocument()->m_vector.GetCount() > 0);
}


void CProductInfoView::OnEditFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}

LRESULT CProductInfoView::OnOptInfoDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipMetaTimerID != UINT(-1))
	{
		KillTimer(m_uipMetaTimerID);
		m_uipMetaTimerID = UINT(-1);
	}
	m_uipMetaTimerID = SetTimer(31, 1031, NULL);
	return 0L;
}

LRESULT CProductInfoView::OnDataChanged(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	UNREFERENCED_PARAMETER(lParam);
	if (m_uipProdInfoTimerID != UINT(-1))
	{
		KillTimer(m_uipProdInfoTimerID);
		m_uipProdInfoTimerID = UINT(-1);
	}
	m_uipProdInfoTimerID = SetTimer(32, 1032, NULL);
	return 0L;
}



void CProductInfoView::OnTimer(UINT_PTR nIDEvent)
{
	if (m_uipMetaTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipMetaTimerID != UINT(-1))
			{
				KillTimer(m_uipMetaTimerID);
				m_uipMetaTimerID = UINT(-1);
			}
			LoadMetaData();
			LoadData(); //���¼��������б�
		}
	}
	else if (m_uipProdInfoTimerID == nIDEvent)
	{
		if (GetDocument()->m_vectNewItems.GetCount() < 1 &&
			GetDocument()->m_vectModItems.GetCount() < 1 &&
			GetDocument()->m_vectDelItems.GetCount() < 1)
		{
			if (m_uipProdInfoTimerID != UINT(-1))
			{
				KillTimer(m_uipProdInfoTimerID);
				m_uipProdInfoTimerID = UINT(-1);
			}
			LoadData(); //���¼��������б�
		}
	}

	CView::OnTimer(nIDEvent);
}
