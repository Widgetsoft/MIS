#pragma once

namespace UI
{
	namespace Control
	{
		// CTransparentCheckbox

		class CTransparentCheckbox : public CButton
		{
			DECLARE_DYNAMIC(CTransparentCheckbox)

		public:
			CTransparentCheckbox();
			virtual ~CTransparentCheckbox();

		protected:
			DECLARE_MESSAGE_MAP()
			virtual void PreSubclassWindow();
		};
	}
}

