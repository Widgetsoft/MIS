// PaymentView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "SaleDoc.h"
#include "LocalDataGridView.h"
#include "PaymentView.h"
#include "WorkAssistant.h"
#include "SaleServiceWork.h"
#include "SystemInfo.h"
#include "VisualStyleHelper.h"

using namespace Business;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPaymentView

IMPLEMENT_DYNCREATE(CPaymentView, CFormView)

CPaymentView::CPaymentView()
	: CFormView(IDD_PAYMENTVIEW),
	m_spListPayment( new GenerialPattern::CItemsData())
{
	m_bTitleInitialize = FALSE;
}

CPaymentView::~CPaymentView()
{
}

void CPaymentView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PAYMENT_DETAILS, m_ListCtrl);
	DDX_Control(pDX, IDC_PAYMENT_DEPT, m_cmbDepartment);
	DDX_Control(pDX, IDC_PAYMENT_MAN, m_cmbExecuter);
	DDX_Control(pDX, IDC_PAYMENT_DATE, m_dateBusiness);	
}

//�ı��ǩ
void CPaymentView::ToggleControls(BOOL bEnableInput, BOOL bReloadOptions)
{
	GetDlgItem(IDC_PAYMENT_DEPT)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_PAYMENT_DATE)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_PAYMENT_MAN)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_PAYMENT_CHECKOUT)->EnableWindow(bEnableInput);
	GetDlgItem(IDC_PAYMENT_CARD)->EnableWindow(bEnableInput);

	if (bReloadOptions)
	{
		GenerialPattern::CItemData tempDeptData, tempStaffData;

		//�����տ��
		CString strQuery;
		strQuery.Append(_T("SELECT deptID, deptName FROM tsw_tabAgencyInfo;"));
		Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbDepartment, &tempDeptData);

		//����
		strQuery.Empty();
		strQuery.Append(_T("SELECT EID, EName FROM tsw_tabStaffInfo;"));
		Core::CWorkAssistant::ComboLoadAllItems(strQuery, m_cmbExecuter, &tempStaffData, theApp.m_siInfo->m_strUserInnerID);

	}
}

void CPaymentView::ReloadPaymentWay()
{
	Database::CItemOptionsVector vectOption1;
	LOCALEDB;
	if (pDataBase != NULL && pDataBase->m_bDBOpened)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s WHERE ѡ��� LIKE '���㷽ʽ'"), vectOption1.m_strBindTable);
		pDataBase->GetItemOptions(strQuery, vectOption1);
	}

	m_spListPayment->ClearItemDatas();

	CGridColumnTraitCombo* pComboTrait = reinterpret_cast<CGridColumnTraitCombo*>(m_ListCtrl.GetColumnTrait(3));
	pComboTrait->ClearFixedItems();
	for (int i = 0; i != vectOption1.GetCount(); i++)
	{
		pComboTrait->AddItem(i, vectOption1.GetCellText(i, 2));
		GenerialPattern::CItemData* pData = new GenerialPattern::CItemData();
		pData->AddRange(vectOption1.GetCellText(i, 0),
			vectOption1.GetCellText(i, 2),
			vectOption1.GetCellText(i, 5),
			vectOption1.GetCellText(i, 3),
			vectOption1.GetCellText(i, 4),
			vectOption1.GetCellText(i, 1), NULL);
		m_spListPayment->AddItemData(i, pData);
	}
}

void CPaymentView::LoadTicketTitle()
{
	auto pItemData = GetDocument()->GetDataset();

	if (!pItemData->IsExistsPage(0) && !pItemData->IsExistsPage(1))
	{
		//���������ݣ����ü���
		ToggleControls(FALSE);
		return;
	}


	auto InitialTicketsType = m_enumDetailsType;

	m_enumDetailsType = pItemData->GetPage(0)->GetCurrentTickitsItem()->GetTickitsType();

	//�տ�����¼
	auto pPaymentItem = pItemData->GetPage(1)->GetCurrentTickitsItem()->GetItem();

	//�����Զ�����
	SetDlgItemText(IDC_PAYMENT_NO, pPaymentItem->GetCellText(1));

	//����ҵ������
	COleDateTime dateTemp;
	dateTemp.ParseDateTime(pPaymentItem->GetCellText(2));
	SYSTEMTIME sysTime;
	dateTemp.GetAsSystemTime(sysTime);
	m_dateBusiness.SetTime(sysTime);

	//���ط�����
	if (!Database::CFlybyItem::IsNullGuid(pPaymentItem->GetCellText(23)))
	{
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(pPaymentItem->GetCellText(23), pPaymentItem->GetCellText(3), NULL);
		Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbDepartment, apItem.release(), 1);
	}

	//����ҵ����Ա
	if (!Database::CFlybyItem::IsNullGuid(pPaymentItem->GetCellText(20)))
	{
		std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
		apItem->AddRange(pPaymentItem->GetCellText(20), pPaymentItem->GetCellText(6), NULL);
		Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbExecuter, apItem.release());
	}

	//���ؽ��׶���
	SetDlgItemText(IDC_PAYMENT_OBJECT, pPaymentItem->GetCellText(4));

	CheckDlgButton(IDC_PAYMENT_CHECKOUT,
		pPaymentItem->GetCellText(11).Compare(_T("�����")) == 0);

	BOOL bLabelChanged = m_enumDetailsType != InitialTicketsType;

	ToggleControls(pPaymentItem->GetState() != Database::Initial, bLabelChanged);

	ColculateTotalSum();
}

void CPaymentView::ReLoadTableTitle()
{
	m_ListCtrl.DeleteAllItems();
	for (int n = m_ListCtrl.GetColumnCount() - 1; n != -1; n--)
	{
		m_ListCtrl.DeleteColumn(n);
	}

	Database::CPaymentFlowDetailsVector detailHolder;

	auto nColumnsCount = detailHolder.GetColCount() - 3;

	// Create and attach image list
	m_ImageList.Create(16, 16, ILC_COLOR16 | ILC_MASK, 1, 0);
	int nStateImageIdx = CGridColumnTraitDateTime::AppendStateImages(m_ListCtrl, m_ImageList);	// Add checkboxes
	m_ListCtrl.SetImageList(&m_ImageList, LVSIL_SMALL);

	m_ListCtrl.InsertHiddenLabelColumn();	// Requires one never uses column 0

	int nCurrentCol = 0;
	CGridColumnTraitImage* pImageTrait = nullptr;
	for (int n = 0; n != nColumnsCount; n++)
	{
		nCurrentCol = n + 1;
		const CString& title = detailHolder.GetColTitle(nCurrentCol);
		CGridColumnTrait* pTrait = NULL;
		switch (nCurrentCol)
		{
		case 3:
			pTrait = new CGridColumnTraitCombo;
			break;
		case 4: //ʹ�û�δʹ��
			pImageTrait = new CGridColumnTraitImage;
			pImageTrait->AddImageIndex(nStateImageIdx, _T("δʹ��"), false);
			pImageTrait->AddImageIndex(nStateImageIdx + 1, _T("ʹ��"), true);
			pImageTrait->SetToggleSelection(true);
			pTrait = pImageTrait;
			break;
			break;
		case 1:
		case 2:
			pTrait = new CGridColumnTraitEdit;
			break;
		default:
			break;
		}
		m_ListCtrl.InsertColumnTrait(nCurrentCol, title, LVCFMT_LEFT, 100, n, pTrait);
	}
	ReloadPaymentWay();
}


void CPaymentView::ReloadTableData()
{
	m_ListCtrl.DeleteAllItems();
	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(1) && !pDataSet->GetPage(1)->IsCurrentTickitsItemNULL())
	{
		// Insert data into list-control by copying from datamodel
		auto pPaymentDetails = pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItemDetails();
		int nItem = 0;
		m_ListCtrl.SetVector(pPaymentDetails.get());
		for (size_t rowId = 0; rowId <pPaymentDetails->GetCount(); ++rowId)
		{
			nItem = m_ListCtrl.InsertItem(++nItem, pPaymentDetails->GetCellText(rowId, 1));
			m_ListCtrl.SetItemData(nItem, rowId);
			for (int col = 0; col < pPaymentDetails->GetColCount() - 3; ++col)
			{
				int nCellCol = col + 1;	// +1 because of hidden column
				const CString& strCellText = pPaymentDetails->GetCellText(rowId, nCellCol);

				if (nCellCol == 4)
				{
					if (strCellText.Compare(_T("δʹ��")) == 0)
					{
						m_ListCtrl.SetCellImage(nItem, nCellCol, 0);	// unchecked
					}
					else
					{
						m_ListCtrl.SetCellImage(nItem, nCellCol, 1);	// checked
					}
				}
				m_ListCtrl.SetItemText(nItem, nCellCol, strCellText);
			}
		}

		//ColculateTotalSum();
	}
}

void CPaymentView::ColculateTotalSum()
{
	auto pItemData = GetDocument()->GetDataset();

	//�����¼����
	auto pRealSaleItem = pItemData->GetPage(1)->GetCurrentTickitsItem();

	auto pItem = pRealSaleItem->GetItem();
	auto  pPayFlow = pRealSaleItem->GetItemDetails();


	double dblAmount = { 0 };
	int nCount = pPayFlow->GetCount();

	auto enumTicket = m_enumDetailsType;

	Concurrency::parallel_for(0, nCount, [enumTicket, pPayFlow, &dblAmount](const int i) {
		TCHAR *tcsTemp = nullptr;
		dblAmount += _tcstod(pPayFlow->GetCellText(i, 2), &tcsTemp);
	});

	CString strTemp;
	strTemp.Format(_T("%.2f"), dblAmount);
	pItem->SetCellText(9, strTemp);

	CString strSummary;
	strSummary.Format(_T("Ӧ�����:%s; ʵ�����:%s�������Ż�:%s��;Ƿ�ѽ��:%s;�˵�״̬:%s��"),
		pItem->GetCellText(8), pItem->GetCellText(9), pItem->GetCellText(7), pItem->GetCellText(10),
		pItem->GetCellText(5));
	SetDlgItemText(IDC_PAYMENT_SUM, strSummary);
}

BEGIN_MESSAGE_MAP(CPaymentView, CFormView)
	ON_MESSAGE(WM_SALSVC_CREATE_MSG, OnPaymentChanged)
	ON_CBN_CLOSEUP(IDC_PAYMENT_MAN, OnExecuteManCloseup)
	ON_CBN_CLOSEUP(IDC_PAYMENT_DEPT, OnDepartmentCloseup)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_PAYMENT_DATE, OnPaymentDateTimeChanged)
	ON_BN_CLICKED(IDC_PAYMENT_CHECKOUT, OnCheckOutClick)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_PAYMENT_DETAILS, OnLvnEndlabeledit)
	ON_BN_CLICKED(IDC_PAYMENT_CARD, &CPaymentView::OnBnClickedPaymentCard)

	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_NEWITEM, &CPaymentView::OnUpdateEditSdNewitem)
	ON_COMMAND(ID_EDIT_SD_NEWITEM, &CPaymentView::OnEditSdNewitem)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_MODIFY, &CPaymentView::OnUpdateEditSdModify)
	ON_COMMAND(ID_EDIT_SD_MODIFY, &CPaymentView::OnEditSdModify)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_DELETE, &CPaymentView::OnUpdateEditSdDelete)
	ON_COMMAND(ID_EDIT_SD_DELETE, &CPaymentView::OnEditSdDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_REFRESH, &CPaymentView::OnUpdateEditSdRefresh)
	ON_COMMAND(ID_EDIT_SD_REFRESH, &CPaymentView::OnEditSdRefresh)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_REVSEL, &CPaymentView::OnUpdateEditSdRevsel)
	ON_COMMAND(ID_EDIT_SD_REVSEL, &CPaymentView::OnEditSdRevsel)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SD_FIND, &CPaymentView::OnUpdateEditSdFind)
	ON_COMMAND(ID_EDIT_SD_FIND, &CPaymentView::OnEditSdFind)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CPaymentView ���

#ifdef _DEBUG
void CPaymentView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPaymentView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
CSaleDoc* CPaymentView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSaleDoc)));
	return reinterpret_cast<CSaleDoc*>(m_pDocument);
}
#endif //_DEBUG


// CPaymentView ��Ϣ��������

LRESULT CPaymentView::OnPaymentChanged(WPARAM wParam, LPARAM lParam)
{
	DataPattern::PPSChangeParameter pSenderParameter =
		reinterpret_cast<DataPattern::PPSChangeParameter>(lParam);
	if (pSenderParameter != nullptr)
	{
		//�����Լ�������Ϣ
		if (pSenderParameter->pLaunchSource != nullptr)
		{
			if (pSenderParameter->pLaunchSource->IsKindOf(RUNTIME_CLASS(CPaymentView)))
			{
				//�Լ����ģ�������
				return 0L;
			}
		}

		//ָ���ƶ������һ��
		auto enumChangeObject = pSenderParameter->ChangeObject;

		switch (enumChangeObject)
		{
		case DataPattern::enumAllControl:
			LoadTicketTitle();
			if (!m_bTitleInitialize)
			{
				ToggleControls(FALSE, TRUE);
				m_bTitleInitialize = TRUE;;
				ReLoadTableTitle();
			}
			ReloadTableData();
			break;
		case DataPattern::enumListCtrl:
			if (!m_bTitleInitialize)
			{
				ToggleControls(FALSE, TRUE);
				m_bTitleInitialize = TRUE;;
				ReLoadTableTitle();
			}
			ReloadTableData();
			break;
		case DataPattern::enumTextBox:
			if (_tcscmp(_T("IDC_PAYMENT_SUM"), pSenderParameter->ObjectIDs) == 0)
			{
				ColculateTotalSum();
			}
			else if (_tcscmp(_T("IDC_PAYMENT_OBJECT"), pSenderParameter->ObjectIDs) == 0)
			{
				//�տ�����¼
				auto pPaymentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
				//���ؽ��׶���
				SetDlgItemText(IDC_PAYMENT_OBJECT, pPaymentItem->GetCellText(4));
			}
			break;
		case DataPattern::enumDataTimePick:
			if (_tcscmp(_T("IDC_PAYMENT_DATE"), pSenderParameter->ObjectIDs) == 0)
			{
				//�������ڴ���
				auto pPaymentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
				COleDateTime dateTemp;
				dateTemp.ParseDateTime(pPaymentItem->GetCellText(2));
				SYSTEMTIME sysTime;
				dateTemp.GetAsSystemTime(sysTime);
				m_dateBusiness.SetTime(sysTime);
			}
			break;
		case DataPattern::enumComboBox:
			if (_tcscmp(_T("IDC_PAYMENT_DEPT"), pSenderParameter->ObjectIDs) == 0)
			{
				//������Ϣ����
				auto pItemData = GetDocument()->GetDataset();
				auto pPaymentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
				if (!Database::CFlybyItem::IsNullGuid(pPaymentItem->GetCellText(23)))
				{
					std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
					apItem->AddRange(pPaymentItem->GetCellText(23), pPaymentItem->GetCellText(3), NULL);
					Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbDepartment, apItem.release(), 1);
				}

			}
			else if (_tcscmp(_T("IDC_PAYMENT_MAN"), pSenderParameter->ObjectIDs) == 0)
			{
				//�տ��˴���
				auto pItemData = GetDocument()->GetDataset();
				auto pPaymentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
				if (!Database::CFlybyItem::IsNullGuid(pPaymentItem->GetCellText(20)))
				{
					std::auto_ptr<GenerialPattern::CItemData> apItem(new GenerialPattern::CItemData());
					apItem->AddRange(pPaymentItem->GetCellText(20), pPaymentItem->GetCellText(6), NULL);
					Core::CWorkAssistant::LoadComboNormalData(pItemData, m_cmbExecuter, apItem.release());
				}
			}
			break;
		case DataPattern::enumCheckBox:
			if (_tcscmp(_T("IDC_PAYMENT_CHECKOUT"), pSenderParameter->ObjectIDs) == 0)
			{
				auto pPaymentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
				//���ؽ��׶���
				CheckDlgButton(IDC_PAYMENT_CHECKOUT,
					pPaymentItem->GetCellText(11).Compare(_T("�����")) == 0);
			}
			break;
		}
	}

	return 0L;
}

void CPaymentView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	GetDocument()->SetTitle(_T("�տ��"));

	// Give better margin to editors
	m_ListCtrl.SetCellMargin(1.3);
	m_ListCtrl.SetContextMenu(IDR_POPUP_SALE_EDIT);

	CGridRowTraitXP* pRowTrait = new CGridRowTraitXP;
	m_ListCtrl.SetDefaultRowTrait(pRowTrait);

	CViewConfigSectionWinApp* pColumnProfile = new CViewConfigSectionWinApp(_T("���ۼ������տ��"));
	pColumnProfile->AddProfile(_T("Ĭ��"));
	pColumnProfile->AddProfile(_T("�Զ���"));
	m_ListCtrl.SetupColumnConfig(pColumnProfile);
}

void CPaymentView::OnExecuteManCloseup()
{
	auto pDataSet = GetDocument()->GetDataset();
	//�������
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 1, 20, 6);
}

void CPaymentView::OnDepartmentCloseup()
{
	auto pDataSet = GetDocument()->GetDataset();
	//���������¼
	Core::CWorkAssistant::NormalComboBoxProxy(m_cmbExecuter, nullptr, pDataSet, 1, 23, 3);
}

void CPaymentView::OnPaymentDateTimeChanged(NMHDR *pNMHDR, LRESULT *pResult)
{
	BOOL bEabled = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial;
	if (bEabled)
	{
		LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
		Database::CFlybyItem* pItem = NULL;
		BOOL bSucess = GetDocument()->GetDataset()->GetCurrentFlybyData(1, (PVOID*)&pItem);
		ASSERT(bSucess);
		if (pItem->GetState() != Database::Initial)
		{
			LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
			COleDateTime tempDate(pDTChange->st);
			pItem->SetCellText(2, tempDate.Format());
			//������������
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(2, tempDate.Format());
			if (GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetTickitsType() ==
				DataPattern::enumSalesTikits)
			{
				//���ó�������
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(2, tempDate.Format());
			}
			//���ͱ��֪ͨ�����۵�
			auto pCurrentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
			GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
				Business::DataPattern::enumDataTimePick, _T("IDC_SALE_DATE"), 0, nullptr);

		}
	}
	*pResult = 0;
}

void CPaymentView::OnCheckOutClick()
{
	BOOL bEabled = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial;
	if (bEabled)
	{
		BOOL bIsCheckout = IsDlgButtonChecked(IDC_PAYMENT_CHECKOUT);
		GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(6, bIsCheckout ? _T("�����") : _T("δ���"));
		GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(11, bIsCheckout ? _T("�����") : _T("δ���"));
		GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(8, bIsCheckout ? _T("�����") : _T("δ���"));
		if (bIsCheckout)
		{
			//��������˺��������
			COleDateTime oleDateNow = COleDateTime::GetCurrentTime();
			CString strCheckoutData = oleDateNow.Format();
			//�������ۡ����񵥵����״̬
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(12, theApp.m_siInfo->m_strUserInnerID);
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(7, theApp.m_siInfo->m_strUserName);
			GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetItem()->SetCellText(16, strCheckoutData);
			//���������¼
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(21, theApp.m_siInfo->m_strUserInnerID);
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(12, theApp.m_siInfo->m_strUserName);
			GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem()->SetCellText(17, strCheckoutData);
			if (GetDocument()->GetDataset()->GetPage(0)->GetCurrentTickitsItem()->GetTickitsType() ==
				DataPattern::enumSalesTikits)
			{
				//��������������
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(17, theApp.m_siInfo->m_strUserInnerID);
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(9, theApp.m_siInfo->m_strUserName);
				GetDocument()->GetDataset()->GetPage(2)->GetCurrentTickitsItem()->GetItem()->SetCellText(14, strCheckoutData);
			}
		}

		//���ͱ��֪ͨ�����۵�
		auto pCurrentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem()->GetItem();
		GetDocument()->SendSynchronizationMessage(this, m_enumDetailsType, pCurrentItem->GetState(),
			Business::DataPattern::enumCheckBox, _T("IDC_SALE_CHECKOUT"), 0, nullptr);
	}
}

void CPaymentView::OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult)
{
	auto spDataset = GetDocument()->GetDataset();

	Database::CFlybyData* pPaymentFlow = NULL;
	BOOL bSuccess = spDataset->GetCurrentFlybyData(1, (PVOID*)&pPaymentFlow, FALSE);

	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;

	switch (nCol)
	{
	case 2:
		//����۸�
		if (pDispInfo->item.pszText != NULL)
		{
			CString strPrevious = pPaymentFlow->GetCellText(nRow, nCol);
			double dblTemp = { 0 };
			TCHAR* ptstrStop = nullptr;
			dblTemp = _tcstod(pDispInfo->item.pszText, &ptstrStop);
			dblTemp = abs(dblTemp); //ֻȡ����ֵ
			CString strTemp;
			strTemp.Format(_T("%.2f"), dblTemp);
			pPaymentFlow->SetCellText(nRow, nCol, strTemp);
			m_ListCtrl.SetItemText(nRow, nCol, strTemp);

			if (strPrevious.Compare(strTemp) != 0)
			{
				ColculateTotalSum();
			}
		}
		break;
	case 3:
		if (pDispInfo->item.pszText != NULL)
		{
			std::pair<STDString, STDString> varPair =
				GenerialPattern::CItemsData::GetMatchItem(
					*m_spListPayment, (int)(pDispInfo->item.lParam), pDispInfo->item.pszText);


			//1���������ݱ���Ԫ��ֵ
			m_ListCtrl.SetItemText(nRow, nCol, varPair.second.c_str());

			//2���������ݱ�����Ԫ��ֵ
			pPaymentFlow->SetCellText(nRow, nCol, varPair.second.c_str());
			pPaymentFlow->SetCellText(nRow, 5, varPair.first.c_str());
		}
		break;
	default:	//���Ҳ�Ʒ��Ϣ
		if (pDispInfo->item.pszText != NULL)
		{
			TCHAR tcsText[MAX_PATH];
			_tcscpy_s(tcsText, MAX_PATH, pDispInfo->item.pszText);
			pPaymentFlow->SetCellText(nRow, nCol, tcsText);
		}
		break;
	}

	*pResult = 0;
}

void CPaymentView::OnBnClickedPaymentCard()
{
	// ��Աˢ������
}


void CPaymentView::OnUpdateEditSdNewitem(CCmdUI *pCmdUI)
{
	BOOL bEnabled = FALSE;
	//�鿴��ǰ���ݵ�
	auto spDataset = GetDocument()->GetDataset();
	if (spDataset->IsExistsPage(1) && !(spDataset->GetPage(1)->IsCurrentTickitsItemNULL()))
	{
		if (spDataset->GetPage(1)->GetCurrentTickitsItem()->GetItem()->GetState() !=
			Database::Initial)
		{
			bEnabled = TRUE;
		}
	}
	pCmdUI->Enable(bEnabled);
}


void CPaymentView::OnEditSdNewitem()
{
	if (m_spListPayment->GetSize() < 1)
	{
		MessageBox(_T("ϵͳ�в������κθ��ʽ��Ϣ���޷�����ִ�иò�����"), _T("����������Ϣʧ��"),
			MB_OK | MB_ICONEXCLAMATION);
		return;
	}

	std::auto_ptr<Database::CPaymentFlowDetails> apPaymentItem(new Database::CPaymentFlowDetails());
	apPaymentItem->SetState(Database::NewItem);

	//1������ѡ��Ĭ��ֵ
	auto pOptionItem = m_spListPayment->GetItemData(0);
	apPaymentItem->SetCellText(5, pOptionItem->at(0).c_str());
	apPaymentItem->SetCellText(3, pOptionItem->at(1).c_str());
	apPaymentItem->SetCellText(4, _T("δʹ��"));

	//�ҽӵ�ǰ����
	auto pCurrentItem = GetDocument()->GetDataset()->GetPage(1)->GetCurrentTickitsItem();
	//�ҽӵ�ǰ����
	apPaymentItem->SetCellText(6, pCurrentItem->GetItem()->GetCellText(0));

	pCurrentItem->GetItemDetails()->AddItem(apPaymentItem.release());
	
	ReloadTableData();
}

void CPaymentView::OnUpdateEditSdModify(CCmdUI *pCmdUI)
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	BOOL bEnable = pos != nullptr;

	pCmdUI->Enable(FALSE);

	auto pDataSet = GetDocument()->GetDataset();
	if (bEnable && pDataSet->IsExistsPage(1) && !pDataSet->GetPage(1)->IsCurrentTickitsItemNULL())
	{
		if (pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial)
		{
			pCmdUI->Enable();
		}
	}
}

void CPaymentView::OnEditSdModify()
{
	m_ListCtrl.LocalModify();
}

void CPaymentView::OnUpdateEditSdDelete(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);


	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	BOOL bEnable = pos != nullptr;

	auto pDataSet = GetDocument()->GetDataset();
	if (bEnable && pDataSet->IsExistsPage(1) && !pDataSet->GetPage(1)->IsCurrentTickitsItemNULL())
	{
		if (pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial)
		{
			pCmdUI->Enable();
		}
	}
}

void CPaymentView::OnEditSdDelete()
{
	m_ListCtrl.LocalDelete();
	ColculateTotalSum();
}


void CPaymentView::OnUpdateEditSdRefresh(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);

	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(1) && !pDataSet->GetPage(1)->IsCurrentTickitsItemNULL())
	{
		if (pDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem()->GetState() != Database::Initial)
		{
			pCmdUI->Enable();
		}
	}
}


void CPaymentView::OnEditSdRefresh()
{
	//���¼������ݲ�����
	LOCALEDB;
	CString strQuery;
	auto m_spDataSet = GetDocument()->GetDataset();
	auto pMainItemID = m_spDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItem();
	auto spVector1 = m_spDataSet->GetPage(1)->GetCurrentTickitsItem()->GetItemDetails();
	strQuery.Format(_T("SELECT * FROM tsw_viewPaymentDetails WHERE �������� LIKE '%s'"),
		pMainItemID->GetCellText(0));
	auto pTargetVector1 = reinterpret_cast<Database::CPaymentFlowDetailsVector*>(spVector1.get());
	pDataBase->GetPaymentFlowDetails(strQuery, *pTargetVector1);
	
	this->ReloadTableData();
	this->ColculateTotalSum();
}


void CPaymentView::OnUpdateEditSdRevsel(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(1) && !pDataSet->GetPage(1)->IsCurrentTickitsItemNULL())
	{
		Database::CFlybyData* pProdFlow = NULL;
		BOOL bSuccess = pDataSet->GetCurrentFlybyData(1, (PVOID*)&pProdFlow, FALSE);
		pCmdUI->Enable(pProdFlow->GetCount() > 0);
	}
}


void CPaymentView::OnEditSdRevsel()
{
	m_ListCtrl.ReverseSelect();
}


void CPaymentView::OnUpdateEditSdFind(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
	auto pDataSet = GetDocument()->GetDataset();
	if (pDataSet->IsExistsPage(1) && !pDataSet->GetPage(1)->IsCurrentTickitsItemNULL())
	{
		Database::CFlybyData* pProdFlow = NULL;
		BOOL bSuccess = pDataSet->GetCurrentFlybyData(1, (PVOID*)&pProdFlow, FALSE);
		pCmdUI->Enable(pProdFlow->GetCount() > 0);
	}
}


void CPaymentView::OnEditSdFind()
{
	m_ListCtrl.InitFindReplaceDlg();
}


HBRUSH CPaymentView::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	return UI::VisualStyleHelper::OnCtlColor(pDC, pWnd, nCtlColor);
}
