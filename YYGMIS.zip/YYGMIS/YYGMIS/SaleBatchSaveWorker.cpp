#include "stdafx.h"
#include "YYGMIS.h"
#include "TickitsData.h"
#include "SaleBatchSaveWorker.h"
#include "SystemInfo.h"
#include "WorkAssistant.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Business;
using namespace Business::Core;

CSaleBatchSaveWorker::CSaleBatchSaveWorker(CProgressCtrl& progressTotal, CProgressCtrl& progressSub, HWND hParentWnd)
	: m_progressTotal(progressTotal), m_progressSub(progressSub), m_hParentWnd(hParentWnd)
{

}


CSaleBatchSaveWorker::~CSaleBatchSaveWorker()
{
}

BOOL CSaleBatchSaveWorker::ExecuteSaveBatch(std::shared_ptr<DataPattern::CTickitsData> pDataItems,
	concurrency::concurrent_vector<std::shared_ptr<DataPattern::SCTicketIDGroupPure>> vectEntity,
	CString& strMessage) noexcept
{
	//���ɸ�����䲢�ۼ���Ʒ������
	BOOL bRet = TRUE;
	CString strUpdate;

	//��һ������������������
	if (vectEntity.size() > 0)
	{
		concurrency::parallel_sort(vectEntity.begin(), vectEntity.end(),
			[](const auto left, const auto right)->bool {
			return left->ModifyTime < right->ModifyTime;
		});
	}

	LOCALEDB;

	//�ڶ������ۼӿ���������ɸ������
	concurrency::concurrent_unordered_map<STDString, double> mapBalance;
	const size_t nSizeCount = vectEntity.size();

	CWorkAssistant Assistance;
	UINT uiCurrentSaleNum = Assistance.GetCurrentIndex(DataPattern::enumSalesTikits,
		_T("SalesCustomID"), _T("tsw_tabSalesFlow"));
	UINT uiCurrentServiceNum = Assistance.GetCurrentIndex(DataPattern::enumServiceTikits,
		_T("SvcCustomID"), _T("tsw_tabServiceFlow"));
	UINT uiCurrentPaymentNum = Assistance.GetCurrentIndex(DataPattern::enumReceivableTickets,
		_T("PayCustomID"), _T("tsw_tabPaymentFlow"));
	UINT uiCurrentStockoutNum = Assistance.GetCurrentIndex(DataPattern::enumReceivableTickets,
		_T("StockCustomID"), _T("tsw_tabStockFlow"));

	CString strInnerKey;
	CString strQueryTemp;


	double dblTempOut = { 0 };
	TCHAR* tcsStop = nullptr;

	for (const auto it : vectEntity)
	{
		//��ʼ����
		if (it->CurrentState == Database::NewItem
			|| it->CurrentState == Database::Modified)
		{
			auto pMainItem = pDataItems->GetDataItemItem(0, it->MainID);
			auto pMainItemDetails = pDataItems->GetDataItemValues(0, it->MainID);

			if (pMainItemDetails->GetCount() < 1)
			{
				//�����ڿ���굥
				strMessage.Format(_T("���ۻ�������ݲ�����ϵͳҪ�󣬡�%s�������ۻ������ĿΪ�գ�ϵͳ�޷�ִ����������!"),
					pMainItem->GetCellText(1));
				bRet = FALSE;
				break;
			}

			if (it->CurrentState == Database::NewItem) //��������
			{
				if (it->enumBusinessType == DataPattern::enumSalesTikits)
				{
					//��Ʒ���۵�

					//������Ʒ���۵�ID
					strInnerKey.Format(_T("%s%s%05d"), CWorkAssistant::GetTickitPrefix(DataPattern::enumSalesTikits),
						Assistance.GetDateSeg(), uiCurrentSaleNum++);
					pMainItem->SetCellText(1, strInnerKey);

					//1.1�����������������
					strUpdate.AppendFormat(_T("INSERT INTO tsw_tabSalesFlow(SalesID,SalesCustomID,SalesDate, BusinessMan, IsCheckOut, CheckOutDate, CheckoutManID, Memo, CreateDate, ModifyDate, CreatedUser, ModifierUser, custID, deptID)"
						" VALUES('%s','%s','%s', '%s', %s, '%s', '%s', '%s', DATETIME('now','localtime'), DATETIME('now','localtime'), '%s', '%s', '%s', '%s')��"),
						pMainItem->GetCellText(0)
						, pMainItem->GetCellText(1)
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(2))
						, pMainItem->GetCellText(11)
						, (pMainItem->GetCellText(6).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(16))
						, pMainItem->GetCellText(12)
						, pMainItem->GetCellText(9)
						, pMainItem->GetCellText(17)
						, pMainItem->GetCellText(18)
						, pMainItem->GetCellText(13)
						, pMainItem->GetCellText(10)
						);
					//1.2�������������굥�������
					double dblCurrentScore = { 0 };
					for (const auto pSaleIter : *pMainItemDetails)
					{
						tcsStop = nullptr;
						dblCurrentScore += _tcstod(pSaleIter->GetCellText(10), &tcsStop);
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabSalesFlowDetails(SalesDetailsID, Price, Quantity, Discount,Score, Commission, Memo, ProdID, SalesID)"
							" VALUES('%s', %s, %s, %s, %s, %s, '%s', '%s', '%s')��"),
							pSaleIter->GetCellText(0)
							, pSaleIter->GetCellText(4)
							, pSaleIter->GetCellText(5)
							, pSaleIter->GetCellText(7)
							, pSaleIter->GetCellText(10)
							, pSaleIter->GetCellText(11)
							, pSaleIter->GetCellText(12)
							, pSaleIter->GetCellText(14)
							, pMainItem->GetCellText(0));
					}
					//1.3����ѯ�ͻ��Ļ�Ա����
					strQueryTemp.Format(_T("SELECT * FROM tsw_viewCardInfo WHERE �ͻ����� LIKE '%s';"), pMainItem->GetCellText(13));
					Database::CCardInfoVector cardVector;
					if (pDataBase->GetCardInfo(strQueryTemp, cardVector) && cardVector.GetCount() > 0)
					{
						tcsStop = nullptr;
						
						double dblCurrentRate = _tcstod(pMainItem->GetCellText(8), &tcsStop);
						if (dblCurrentRate != 0)
						{
							dblCurrentRate = dblCurrentScore / dblCurrentRate;
						}

						//������ּ�¼
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabCardUIRecord(CUIRID, CardID, Summary, Debit, Credit, RealMoney, TableDate, TableUser, CurrentRate, SourceID, CreditRecordType)"
							" VALUES('%s', '%s', '���۵���:%s', %.2f, 0, %.6f, DATETIME('now','localtime'), '%s', %.2f, '%s', 0)��"),
							pMainItem->GenerateNewID(),
							cardVector.GetCellText(0, 0),
							pMainItem->GetCellText(1),
							dblCurrentScore,
							dblCurrentRate,
							pMainItem->GetCellText(11),
							0, //������μ���
							pMainItem->GetCellText(0));
					}


					//���ɳ��ⵥ�������
					auto pStockOutItem = pDataItems->GetDataItem(2, it->StockOutID)->GetItem();
					auto pStockOutItemDetails = pDataItems->GetDataItemValues(2, it->StockOutID);
					//���ɳ���ID
					strInnerKey.Format(_T("%s%s%05d"), CWorkAssistant::GetTickitPrefix(DataPattern::enumStoreOut),
						Assistance.GetDateSeg(), uiCurrentStockoutNum++);
					pStockOutItem->SetCellText(1, strInnerKey);
					//�����������
					if (pStockOutItemDetails->GetCount() < 1)
					{
						//�����ڿ���굥
						strMessage.Format(_T("�������ݲ�����ϵͳҪ�󣬡�%s���ĳ�����ĿΪ�գ�ϵͳ�޷�ִ����������!"),
							pMainItem->GetCellText(1));
						bRet = FALSE;
						break;
					}

					//2.1�����ɿ��������
					strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlow(StockID, StockCustomID, StockDate, StockManID, WSPID, StockDescripion, IsCheckOut, CheckOutDate, CheckoutManID, Memo, IsStockIn, StockSourceID, CreateDate, ModifyDate, CreatedUser, ModifierUser)"
						" VALUES('%s', '%s', '%s', '%s', '%s', '%s', %s, '%s', '%s', '%s', %i, '%s', DATETIME('now','localtime'), DATETIME('now','localtime'), '%s', '%s')��"),
						pStockOutItem->GetCellText(0)
						, pStockOutItem->GetCellText(1)
						, Database::CFlybyItem::FormatDateTime(pStockOutItem->GetCellText(2))
						, pStockOutItem->GetCellText(18)
						, pStockOutItem->GetCellText(20)
						, pStockOutItem->GetCellText(5)
						, (pStockOutItem->GetCellText(8).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
						, Database::CFlybyItem::FormatDateTime(pStockOutItem->GetCellText(14))
						, pStockOutItem->GetCellText(17)
						, pStockOutItem->GetCellText(10)
						, (pStockOutItem->GetCellText(11).Compare(_T("���")) == 0 ? 1 : 0)
						, pMainItem->GetCellText(0)
						, pStockOutItem->GetCellText(15)
						, pStockOutItem->GetCellText(16)
						);
					for (const auto outIter : *pStockOutItemDetails)
					{
						//�ۼӳ����
						tcsStop = nullptr;
						dblTempOut = -_tcstod(outIter->GetCellText(5), &tcsStop);
						strQueryTemp.Format(_T("%s@%s"), pStockOutItem->GetCellText(20), outIter->GetCellText(9));
						auto& itStock = mapBalance.find((LPCTSTR)strQueryTemp);
						if (itStock == mapBalance.end())
						{
							mapBalance.insert(std::pair<STDString, double>((LPCTSTR)strQueryTemp,
								dblTempOut));
						}
						else
						{
							itStock->second += dblTempOut;
						}

						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlowDetails(SDID, Price, Quantity, Memo, ProdID, StockID)"
							" VALUES('%s', %s, %s, '%s', '%s', '%s')��"),
							outIter->GetCellText(0)
							, outIter->GetCellText(4)
							, outIter->GetCellText(5)
							, outIter->GetCellText(8)
							, outIter->GetCellText(9)
							, pStockOutItem->GetCellText(0));
					}

				}
				else
				{
					//����
					//���������������
					strInnerKey.Format(_T("%s%s%05d"), CWorkAssistant::GetTickitPrefix(DataPattern::enumServiceTikits),
						Assistance.GetDateSeg(), uiCurrentServiceNum++);
					pMainItem->SetCellText(1, strInnerKey);

					//1.1�����������������
					strUpdate.AppendFormat(_T("INSERT INTO tsw_tabServiceFlow(SvcID, SvcCustomID, IsCheckOut, ServiceDate, BusinessMan, CheckOutDate, CheckoutManID, Memo, CreateDate, ModifyDate, CreatedUser, ModifierUser, custID, deptID)"
						" VALUES('%s', '%s', %s, '%s', '%s', '%s', %s', '%s', DATETIME(current_timestamp, 'localtime'), DATETIME('now','localtime'), '%s', '%s', '%s', '%s')��"),
						pMainItem->GetCellText(0)
						, pMainItem->GetCellText(1)
						, (pMainItem->GetCellText(6).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(2))
						, pMainItem->GetCellText(11)
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(16))
						, pMainItem->GetCellText(12)
						, pMainItem->GetCellText(9)
						, pMainItem->GetCellText(17)
						, pMainItem->GetCellText(18)
						, pMainItem->GetCellText(13)
						, pMainItem->GetCellText(10)
						);
					//1.2�������������굥�������
					double dblCurrentScore = { 0 };
					for (const auto pServIter : *pMainItemDetails)
					{
						tcsStop = nullptr;
						dblCurrentScore += _tcstod(pServIter->GetCellText(12), &tcsStop);
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabServiceFlowDetails(SvcDetailsID, Price, Quantity, StartTime, EndTime, Discount, Score, Commission, Memo, ServiceID, SvcID)"
							" VALUES('%s', %s, %s, '%s', '%s', %s, %s, %s, '%s', '%s', '%s')��"),
							pServIter->GetCellText(0)
							, pServIter->GetCellText(4)
							, pServIter->GetCellText(5)
							, Database::CFlybyItem::FormatDateTime(pServIter->GetCellText(6))
							, Database::CFlybyItem::FormatDateTime(pServIter->GetCellText(7))
							, pServIter->GetCellText(9)
							, pServIter->GetCellText(12)
							, pServIter->GetCellText(13)
							, pServIter->GetCellText(15)
							, pServIter->GetCellText(17)
							, pServIter->GetCellText(18)
							, pMainItem->GetCellText(0));
					}

					//1.3����ѯ�ͻ��Ļ�Ա����
					strQueryTemp.Format(_T("SELECT * FROM tsw_viewCardInfo WHERE �ͻ����� LIKE '%s';"), pMainItem->GetCellText(13));
					Database::CCardInfoVector cardVector;
					if (pDataBase->GetCardInfo(strQueryTemp, cardVector) && cardVector.GetCount() > 0)
					{
						tcsStop = nullptr;

						double dblCurrentRate = _tcstod(pMainItem->GetCellText(8), &tcsStop);
						if (dblCurrentRate != 0)
						{
							dblCurrentRate = dblCurrentScore / dblCurrentRate;
						}

						//������ּ�¼
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabCardUIRecord(CUIRID, CardID, Summary, Debit, Credit, RealMoney, TableDate, TableUser, CurrentRate, SourceID, CreditRecordType)"
							" VALUES('%s', '%s', '���񵥺�:%s', %.2f, 0, %.6f, DATETIME(current_timestamp, 'localtime'), '%s', %.2f, '%s', 0)��"),
							pMainItem->GenerateNewID(),
							cardVector.GetCellText(0, 0),
							pMainItem->GetCellText(1),
							dblCurrentScore,
							dblCurrentRate,
							pMainItem->GetCellText(11),
							0, //������μ���
							pMainItem->GetCellText(0));
					}
				}
				//���ɸ���������
				//���ɸ��ID
				auto pPaymentItem = pDataItems->GetDataItemItem(1, it->PaymentID);
				auto pPaymentItemDetails = pDataItems->GetDataItemValues(1, it->PaymentID);

				if (pPaymentItemDetails->GetCount() < 1)
				{
					//�����ڿ���굥
					strMessage.Format(_T("�������ݲ�����ϵͳҪ�󣬡�%s���ĸ�����ĿΪ�գ�ϵͳ�޷�ִ����������!"),
						pMainItem->GetCellText(1));
					bRet = FALSE;
					break;
				}

				strInnerKey.Format(_T("%s%s%05d"), CWorkAssistant::GetTickitPrefix(DataPattern::enumReceivableTickets),
					Assistance.GetDateSeg(), uiCurrentPaymentNum++);

				pPaymentItem->SetCellText(1, strInnerKey);
				strUpdate.AppendFormat(_T("INSERT INTO tsw_tabPaymentFlow(PayID, PayCustomID, PayDate, PaymentState, ExecuteMan, Discount, Payable, Payed, IsCheckOut, CheckOutDate, CheckoutManID, PaymentType, ObjectType, CreateDate, ModifyDate, CreatedUser , ModifierUser, objectID, sourceID, deptID)"
					" VALUES('%s', '%s', '%s', '%s', '%s', %s, %s, %s, %s, '%s', '%s', '%s', '%s', DATETIME(current_timestamp, 'localtime'), DATETIME(current_timestamp, 'localtime'), '%s', '%s', '%s', '%s', '%s')��"),
					pPaymentItem->GetCellText(0)
					, pPaymentItem->GetCellText(1)
					, Database::CFlybyItem::FormatDateTime(pPaymentItem->GetCellText(2))
					, pPaymentItem->GetCellText(5)
					, pPaymentItem->GetCellText(20)
					, pPaymentItem->GetCellText(7)
					, pPaymentItem->GetCellText(8)
					, pPaymentItem->GetCellText(9)
					, (pPaymentItem->GetCellText(11).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
					, Database::CFlybyItem::FormatDateTime(pPaymentItem->GetCellText(17))
					, pPaymentItem->GetCellText(21)
					, pPaymentItem->GetCellText(13)
					, pPaymentItem->GetCellText(14)
					, pPaymentItem->GetCellText(18)
					, pPaymentItem->GetCellText(19)
					, pPaymentItem->GetCellText(22)
					, pMainItem->GetCellText(0)
					, pPaymentItem->GetCellText(23)
					);

				double dblCurrentScore = { 0 };
				for (const auto pPayIter : *pPaymentItemDetails)
				{
					tcsStop = nullptr;
					dblCurrentScore += _tcstod(pPayIter->GetCellText(2), &tcsStop);
					strUpdate.AppendFormat(_T("INSERT INTO tsw_tabPaymentFlowDetails(PayDetailsID, PayCatalog, Payed, PayMethodName, IsCredit, PayID)"
						" VALUES('%s', '%s', %s, '%s', %i, '%s')��"),
						pPayIter->GetCellText(0)
						, pPayIter->GetCellText(1)
						, pPayIter->GetCellText(2)
						, pPayIter->GetCellText(5)
						, (pPayIter->GetCellText(4).Compare(_T("ʹ��")) == 0 ? 1 : 0)
						, pPaymentItem->GetCellText(0));
				}

			}
			else if (it->CurrentState == Database::Modified)
			{
				if (it->enumBusinessType == DataPattern::enumSalesTikits)
				{
					//1���޸���Ʒ���۵�
					//1.1 �޸�����
					strUpdate.AppendFormat(_T("UPDATE tsw_tabSalesFlow SET SalesCustomID = '%s',SalesDate = '%s', BusinessMan = '%s', IsCheckOut = %s, CheckOutDate = '%s', CheckoutManID = '%s', Memo = '%s', ModifyDate = DATETIME(current_timestamp, 'localtime'), ModifierUser = '%s', custID = '%s', deptID = '%s' WHERE SalesID LIKE '%s'��"),
						pMainItem->GetCellText(1)
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(2))
						, pMainItem->GetCellText(11)
						, (pMainItem->GetCellText(6).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(16))
						, pMainItem->GetCellText(12)
						, pMainItem->GetCellText(9)
						, pMainItem->GetCellText(18)
						, pMainItem->GetCellText(13)
						, pMainItem->GetCellText(10)
						, pMainItem->GetCellText(0)
						);
					//1.2 ɾ���굥
					strUpdate.AppendFormat(_T("DELETE FROM tsw_tabSalesFlowDetails WHERE SalesID LIKE '%s'��"), pMainItem->GetCellText(0));
					//1.3 ɾ�����ּ�¼
					strUpdate.AppendFormat(_T("DELETE FROM tsw_tabCardUIRecord WHERE SourceID LIKE '%s'��"), pMainItem->GetCellText(0));


					//1.4�������������굥�������
					double dblCurrentScore = { 0 };
					for (const auto pSaleIter : *pMainItemDetails)
					{
						tcsStop = nullptr;
						dblCurrentScore += _tcstod(pSaleIter->GetCellText(10), &tcsStop);
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabSalesFlowDetails(SalesDetailsID, Price, Quantity, Discount,Score, Commission, Memo, ProdID, SalesID)"
							" VALUES('%s', %s, %s, %s, %s, %s, '%s', '%s', '%s')��"),
							pSaleIter->GetCellText(0)
							, pSaleIter->GetCellText(4)
							, pSaleIter->GetCellText(5)
							, pSaleIter->GetCellText(7)
							, pSaleIter->GetCellText(10)
							, pSaleIter->GetCellText(11)
							, pSaleIter->GetCellText(12)
							, pSaleIter->GetCellText(14)
							, pMainItem->GetCellText(0));
					}
					//1.5�����ɻ��ּ�¼
					strQueryTemp.Format(_T("SELECT * FROM tsw_viewCardInfo WHERE �ͻ����� LIKE '%s';"), pMainItem->GetCellText(13));
					Database::CCardInfoVector cardVector;
					if (pDataBase->GetCardInfo(strQueryTemp, cardVector) && cardVector.GetCount() > 0)
					{
						tcsStop = nullptr;

						double dblCurrentRate = _tcstod(pMainItem->GetCellText(8), &tcsStop);
						if (dblCurrentRate != 0)
						{
							dblCurrentRate = dblCurrentScore / dblCurrentRate;
						}

						//������ּ�¼
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabCardUIRecord(CUIRID, CardID, Summary, Debit, Credit, RealMoney, TableDate, TableUser, CurrentRate, SourceID, CreditRecordType)"
							" VALUES('%s', '%s', '���۵���:%s', %.2f, 0, %.6f, '%s', '%s', %.2f, '%s', 0)��"),
							pMainItem->GenerateNewID(),
							cardVector.GetCellText(0, 0),
							pMainItem->GetCellText(1),
							dblCurrentScore,
							dblCurrentRate,
							Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(14)),
							pMainItem->GetCellText(11),
							0, //������μ���
							pMainItem->GetCellText(0));
					}

					//2����Ʒ���ⵥ
					auto pStockOutItem = pDataItems->GetDataItem(2, it->StockOutID)->GetItem();
					auto pStockOutItemDetails = pDataItems->GetDataItemValues(2, it->StockOutID);
					if (pStockOutItemDetails->GetCount() < 1)
					{
						//�����ڿ���굥
						strMessage.Format(_T("�������ݲ�����ϵͳҪ�󣬡�%s���ĳ�����ĿΪ��,ϵͳ�޷�ִ�������޸�!"),
							pMainItem->GetCellText(1));
						bRet = FALSE;
						break;
					}


					//2.1��������������

					double dblTempOut = { 0 };
					TCHAR* tcsStop = nullptr;
					strQueryTemp.Format(_T("SELECT DISTINCT WSPID FROM tsw_tabStockFlow WHERE StockID LIKE '%s';"), it->StockOutID);
					GenerialPattern::CItemData* pDataRow = nullptr;
					pDataBase->NormalGetItemData(strQueryTemp, &pDataRow);
					if (pDataRow == nullptr || pDataRow->size() < 1)
					{
						bRet = FALSE;
						strMessage.Format(_T("�Ҳ�������Ϊ��%s������س����¼��ϵͳ�޷�ִ������ɾ��!"),
							pMainItem->GetCellText(1));
						break;
					}
					strQueryTemp.Format(_T("SELECT * FROM tsw_viewStockFlowDetails WHERE ������ LIKE '%s';"), it->StockOutID);
					Database::CStockFlowDetailsVector vectorStockTemp;
					if (pDataBase->GetStockFlowDetails(strQueryTemp, vectorStockTemp))
					{
						for (const auto outIter : vectorStockTemp)
						{
							//��ת��ǰ�ĳ�������
							tcsStop = nullptr;
							dblTempOut = _tcstod(outIter->GetCellText(5), &tcsStop);
							strQueryTemp.Format(_T("%s@%s"), pDataRow->at(0).c_str(), outIter->GetCellText(9));
							auto& itStock = mapBalance.find((LPCTSTR)strQueryTemp);
							if (itStock == mapBalance.end())
							{
								mapBalance.insert(std::pair<STDString, double>((LPCTSTR)strQueryTemp,
									dblTempOut));
							}
							else
							{
								itStock->second += dblTempOut;
							}
						}
					}
					delete pDataRow;

					//2.2�����ɿ���޸����
					strUpdate.AppendFormat(_T("UPDATE tsw_tabStockFlow SET StockCustomID = '%s', StockDate = '%s', StockManID = '%s', WSPID = '%s', StockDescripion = '%s', IsCheckOut = %s, CheckOutDate = '%s', CheckoutManID = '%s', Memo = '%s', IsStockIn = %s, StockSourceID = '%s', ModifyDate = DATETIME(current_timestamp, 'localtime'), ModifierUser = '%s' WHERE StockID LIKE '%s'��"),
						pStockOutItem->GetCellText(1)
						, Database::CFlybyItem::FormatDateTime(pStockOutItem->GetCellText(2))
						, pStockOutItem->GetCellText(18)
						, pStockOutItem->GetCellText(20)
						, pStockOutItem->GetCellText(5)
						, (pStockOutItem->GetCellText(8).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
						, Database::CFlybyItem::FormatDateTime(pStockOutItem->GetCellText(14))
						, pStockOutItem->GetCellText(17)
						, pStockOutItem->GetCellText(10)
						, (pStockOutItem->GetCellText(11).Compare(_T("���")) == 0 ? 1 : 0)
						, pMainItem->GetCellText(0)
						, pStockOutItem->GetCellText(16)
						, pStockOutItem->GetCellText(0)
						);
					//2.3�� ɾ����ʷ�����굥��Ϣ�������µ��굥
					strUpdate.AppendFormat(_T("DELETE FROM tsw_tabStockFlowDetails WHERE StockID LIKE '%s'��"), pStockOutItem->GetCellText(0));
					for (const auto outIter : *pStockOutItemDetails)
					{
						//�ۼӳ����
						tcsStop = nullptr;
						dblTempOut = -_tcstod(outIter->GetCellText(5), &tcsStop);
						strQueryTemp.Format(_T("%s@%s"), pStockOutItem->GetCellText(20), outIter->GetCellText(9));
						auto& itStock = mapBalance.find((LPCTSTR)strQueryTemp);
						if (itStock == mapBalance.end())
						{
							mapBalance.insert(std::pair<STDString, double>((LPCTSTR)strQueryTemp,
								dblTempOut));
						}
						else
						{
							itStock->second += dblTempOut;
						}

						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabStockFlowDetails(SDID, Price, Quantity, Memo, ProdID, StockID)"
							" VALUES('%s', %s, %s, '%s', '%s', '%s')��"),
							outIter->GetCellText(0)
							, outIter->GetCellText(4)
							, outIter->GetCellText(5)
							, outIter->GetCellText(8)
							, outIter->GetCellText(9)
							, pStockOutItem->GetCellText(0));
					}
				}
				else
				{
					//ִ�з����޸�
					//1.1�����������޸����
					strUpdate.AppendFormat(_T("UPDATE tsw_tabServiceFlow SET SvcCustomID = '%s', IsCheckOut= %s, ServiceDate = '%s', BusinessMan = '%s', CheckOutDate = '%s', CheckoutManID = '%s', Memo = '%s', ModifyDate = DATETIME(current_timestamp, 'localtime'), ModifierUser = '%s', custID = '%s', deptID = '%s' WHERE SvcID LIKE '%s'��"),
						pMainItem->GetCellText(1)
						, (pMainItem->GetCellText(6).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(2))
						, pMainItem->GetCellText(11)
						, Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(16))
						, pMainItem->GetCellText(12)
						, pMainItem->GetCellText(9)
						, pMainItem->GetCellText(18)
						, pMainItem->GetCellText(13)
						, pMainItem->GetCellText(10)
						, pMainItem->GetCellText(0)
						);
					//1.2��ɾ���굥����
					strUpdate.AppendFormat(_T("DELETE FROM tsw_tabServiceFlowDetails WHERE SvcID LIKE '%s'��"), pMainItem->GetCellText(0));
					//1.3�������굥����
					strUpdate.AppendFormat(_T("DELETE FROM tsw_tabCardUIRecord WHERE SourceID LIKE '%s'��"), pMainItem->GetCellText(0));
					//1.4�������������굥�������
					double dblCurrentScore = { 0 };
					for (const auto pServIter : *pMainItemDetails)
					{
						tcsStop = nullptr;
						dblCurrentScore += _tcstod(pServIter->GetCellText(12), &tcsStop);
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabServiceFlowDetails(SvcDetailsID, Price, Quantity, StartTime, EndTime, Discount, Score, Commission, Memo, ServiceID, SvcID)"
							" VALUES('%s', %s, %s, '%s', '%s', %s, %s, %s, '%s', '%s', '%s')��"),
							pServIter->GetCellText(0)
							, pServIter->GetCellText(4)
							, pServIter->GetCellText(5)
							, Database::CFlybyItem::FormatDateTime(pServIter->GetCellText(6))
							, Database::CFlybyItem::FormatDateTime(pServIter->GetCellText(7))
							, pServIter->GetCellText(9)
							, pServIter->GetCellText(12)
							, pServIter->GetCellText(13)
							, pServIter->GetCellText(15)
							, pServIter->GetCellText(17)
							, pServIter->GetCellText(18)
							, pMainItem->GetCellText(0));
					}

					//1.5����ѯ�ͻ��Ļ�Ա����
					strQueryTemp.Format(_T("SELECT * FROM tsw_viewCardInfo WHERE �ͻ����� LIKE '%s';"), pMainItem->GetCellText(13));
					Database::CCardInfoVector cardVector;
					if (pDataBase->GetCardInfo(strQueryTemp, cardVector) && cardVector.GetCount() > 0)
					{
						tcsStop = nullptr;

						double dblCurrentRate = _tcstod(pMainItem->GetCellText(8), &tcsStop);
						if (dblCurrentRate != 0)
						{
							dblCurrentRate = dblCurrentScore / dblCurrentRate;
						}

						//������ּ�¼
						strUpdate.AppendFormat(_T("INSERT INTO tsw_tabCardUIRecord(CUIRID, CardID, Summary, Debit, Credit, RealMoney, TableDate, TableUser, CurrentRate, SourceID, CreditRecordType)"
							" VALUES('%s', '%s', '���񵥺�:%s', %.2f, 0, %.6f, '%s', '%s', %.2f, '%s', 0)��"),
							pMainItem->GenerateNewID(),
							cardVector.GetCellText(0, 0),
							pMainItem->GetCellText(1),
							dblCurrentScore,
							dblCurrentRate,
							Database::CFlybyItem::FormatDateTime(pMainItem->GetCellText(14)),
							pMainItem->GetCellText(11),
							0, //������μ���
							pMainItem->GetCellText(0));
					}
				}

				//���ɸ���޸����
				auto pPaymentItem = pDataItems->GetDataItemItem(1, it->PaymentID);
				auto pPaymentItemDetails = pDataItems->GetDataItemValues(1, it->PaymentID);

				if (pPaymentItemDetails->GetCount() < 1)
				{
					//�����ڿ���굥
					strMessage.Format(_T("�������ݲ�����ϵͳҪ�󣬡�%s���ĸ�����ĿΪ�գ�ϵͳ�޷�ִ�������޸�!"),
						pMainItem->GetCellText(1));
					bRet = FALSE;
					break;
				}

				strUpdate.AppendFormat(_T("UPDATE tsw_tabPaymentFlow SET PayCustomID = '%s', PayDate = '%s', PaymentState = '%s', ExecuteMan = '%s', Discount = %s, Payable = %s, Payed = %s, IsCheckOut = %s, CheckOutDate = '%s', CheckoutManID = '%s', PaymentType = '%s', ObjectType = '%s', ModifyDate = DATETIME(current_timestamp, 'localtime'), ModifierUser = '%s', objectID = '%s', sourceID = '%s', deptID = '%s' WHERE PayID LIKE '%s'��"),
					pPaymentItem->GetCellText(1)
					, Database::CFlybyItem::FormatDateTime(pPaymentItem->GetCellText(2))
					, pPaymentItem->GetCellText(5)
					, pPaymentItem->GetCellText(20)
					, pPaymentItem->GetCellText(7)
					, pPaymentItem->GetCellText(8)
					, pPaymentItem->GetCellText(9)
					, (pPaymentItem->GetCellText(11).Compare(_T("�����")) == 0 ? _T("1") : _T("0"))
					, Database::CFlybyItem::FormatDateTime(pPaymentItem->GetCellText(17))
					, pPaymentItem->GetCellText(21)
					, pPaymentItem->GetCellText(13)
					, pPaymentItem->GetCellText(14)
					, pPaymentItem->GetCellText(19)
					, pPaymentItem->GetCellText(22)
					, pMainItem->GetCellText(0)
					, pPaymentItem->GetCellText(23)
					, pPaymentItem->GetCellText(0)
					);

				//ɾ�������Ŀ
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabPaymentFlowDetails WHERE PayID LIKE '%s'��"), pPaymentItem->GetCellText(0));
				double dblCurrentScore = { 0 };
				for (const auto pPayIter : *pPaymentItemDetails)
				{
					tcsStop = nullptr;
					dblCurrentScore += _tcstod(pPayIter->GetCellText(2), &tcsStop);
					strUpdate.AppendFormat(_T("INSERT INTO tsw_tabPaymentFlowDetails(PayDetailsID, PayCatalog, Payed, PayMethodName, IsCredit, PayID)"
						" VALUES('%s', '%s', %s, '%s', %i, '%s')��"),
						pPayIter->GetCellText(0)
						, pPayIter->GetCellText(1)
						, pPayIter->GetCellText(2)
						, pPayIter->GetCellText(5)
						, (pPayIter->GetCellText(4).Compare(_T("ʹ��")) == 0 ? 1 : 0)
						, pPaymentItem->GetCellText(0));
				}
			}
		}
		else if (it->CurrentState == Database::Deleted)
		{
			//��������棬����ɾ�����
			if (it->enumBusinessType == DataPattern::enumSalesTikits)
			{
				double dblTempOut = { 0 };
				TCHAR* tcsStop = nullptr;

				CString strQueryTemp;
				strQueryTemp.Format(_T("SELECT DISTINCT WSPID FROM tsw_tabStockFlow WHERE StockID LIKE '%s';"), it->StockOutID);
				GenerialPattern::CItemData* pDataRow = nullptr;
				pDataBase->NormalGetItemData(strQueryTemp, &pDataRow);
				if (pDataRow == nullptr || pDataRow->size() < 1)
				{
					bRet = FALSE;
					strMessage.Format(_T("�Ҳ������ŵ��ݣ�ϵͳ�޷�ִ������ɾ��!"));
					break;
				}
				strQueryTemp.Format(_T("SELECT * FROM tsw_viewStockFlowDetails WHERE ������ LIKE '%s';"), it->StockOutID);
				Database::CStockFlowDetailsVector vectorStockTemp;
				if (pDataBase->GetStockFlowDetails(strQueryTemp, vectorStockTemp))
				{
					for (const auto outIter : vectorStockTemp)
					{
						//ɾ����ǰ�ĳ�������
						tcsStop = nullptr;
						dblTempOut = _tcstod(outIter->GetCellText(5), &tcsStop);
						strQueryTemp.Format(_T("%s@%s"), pDataRow->at(0).c_str(), outIter->GetCellText(9));
						auto& itStock = mapBalance.find((LPCTSTR)strQueryTemp);
						if (itStock == mapBalance.end())
						{
							mapBalance.insert(std::pair<STDString, double>((LPCTSTR)strQueryTemp,
								dblTempOut));
						}
						else
						{
							itStock->second += dblTempOut;
						}
					}
				}

				delete pDataRow;

				//��������ɾ�����
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabSalesFlowDetails WHERE SalesID LIKE '%s'��"), it->MainID);
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabSalesFlow WHERE SalesID LIKE '%s'��"), it->MainID);
				//���ɳ��ⵥɾ�����
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabStockFlowDetails WHERE StockID LIKE '%s'��"), it->StockOutID);
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabStockFlow WHERE StockID LIKE '%s'��"), it->StockOutID);
			}
			else
			{
				//��������ɾ�����
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabServiceFlowDetails WHERE SvcID LIKE '%s'��"), it->MainID);
				strUpdate.AppendFormat(_T("DELETE FROM tsw_tabServiceFlow WHERE SvcID LIKE '%s'��"), it->MainID);
			}
			strUpdate.AppendFormat(_T("DELETE FROM tsw_tabCardUIRecord WHERE SourceID LIKE '%s'��"), it->MainID);
			//���ɸ��ɾ�����
			strUpdate.AppendFormat(_T("DELETE FROM tsw_tabPaymentFlowDetails WHERE PayID LIKE '%s'��"), it->PaymentID);
			strUpdate.AppendFormat(_T("DELETE FROM tsw_tabPaymentFlow WHERE PayID LIKE '%s'��"), it->PaymentID);
		}
	}

	if (bRet && mapBalance.size() > 0)
	{
		CString strTemp;
		//��֤���
		for each (const auto iter in mapBalance)
		{
			//����棬�������㣬���˳�
			//�ⷿ@Ʒ��
			Concurrency::concurrent_vector<STDString> vectItems;
			Helper::CToolkits::Split(iter.first.c_str(), _T("@"), &vectItems);
			if (vectItems.size() > 0)
			{
				strTemp.Format(_T("SELECT COUNT(*) FROM tsw_tabInventories WHERE WSPID LIKE '%s' AND ProdID LIKE '%s' AND (StockQuantity + %f >= 0)"),
					vectItems.at(0).c_str(), vectItems.at(1).c_str(), iter.second);
				GenerialPattern::CItemData* pQueryItem = NULL;
				BOOL bQS = pDataBase->NormalGetItemData(strTemp, &pQueryItem);
				if (pQueryItem == nullptr || pQueryItem->size() < 1)
				{
					strMessage.Format(_T("�������ѯʧ�ܣ��������ݱ��治�ɹ���"));
					bRet = FALSE;
					break;
				}

				int nCount = _ttoi(pQueryItem->at(0).c_str());
				if (nCount <= 0)
				{
					strMessage.Format(_T("������Ʒ��������㣬�������ݱ��治�ɹ���"));
					bRet = FALSE;
					break;
				}

				delete pQueryItem;
			}
			strUpdate.AppendFormat(_T("UPDATE tsw_tabInventories SET StockQuantity = StockQuantity + %.2f WHERE WSPID LIKE '%s' AND ProdID LIKE '%s'��"),
				iter.second, vectItems.at(0).c_str(), vectItems.at(1).c_str());
		}
		//ִ�����
		if (bRet)
		{
			Concurrency::concurrent_vector<STDString> strArgs;
			Helper::CToolkits::Split(strUpdate, _T("��"), &strArgs);
			bRet = pDataBase->ExecuteNonQueryBatch(&strArgs, TRUE);
		}
		else
		{
			MessageBox(m_hParentWnd, strMessage, _T("ִ�����ݱ���ʱ����"), MB_ICONSTOP | MB_OK);
		}
	}

	return bRet;
}

