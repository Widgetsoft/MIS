#pragma once

namespace BasicInfo
{
	// CStaffInfoView ��ͼ

	class CStaffInfoView : public CView
	{
		DECLARE_DYNCREATE(CStaffInfoView)

	protected:
		CStaffInfoView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
		virtual ~CStaffInfoView();

	private:
		CLocalDataGridView m_ListCtrl; //���ݿؼ�
		CImageList m_ImageList;		   //ͼ����Դ

	private:
		void LoadData();
		void LoadDeptInfoes();
		void LoadMetaData();

		Concurrency::concurrent_vector<STDString> m_vectSex;
		std::shared_ptr<GenerialPattern::CItemsData> m_spDeptDatas;
		std::shared_ptr<GenerialPattern::CItemsData> m_spTitles;		//ְ����Ϣ����
		std::shared_ptr<GenerialPattern::CItemsData> m_spDuty;			//ְ����Ϣ����
		std::shared_ptr<GenerialPattern::CItemsData> m_spDegree;		//ѧ����Ϣ����

		UINT_PTR m_uipMetaTimerID;	   
		UINT_PTR m_uipDeptInfoTimerID;
		UINT_PTR m_uipStaffInfoTimerID;

	public://����
		CStaffInfoDoc* GetDocument() const;

	public:
		virtual void OnDraw(CDC* pDC);      // ��д�Ի��Ƹ���ͼ
#ifdef _DEBUG
		virtual void AssertValid() const;
#ifndef _WIN32_WCE
		virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	protected:
		DECLARE_MESSAGE_MAP()
	public:
		afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
		afx_msg void OnSize(UINT nType, int cx, int cy);
		afx_msg void OnEditNewitem();
		afx_msg void OnLvnEndlabeledit(NMHDR *pNMHDR, LRESULT *pResult);
		afx_msg void OnUpdateEditRefresh(CCmdUI *pCmdUI);
		afx_msg void OnEditRefresh();
		afx_msg void OnUpdateEditModify(CCmdUI *pCmdUI);
		afx_msg void OnEditModify();
		afx_msg void OnUpdateEditDelete(CCmdUI *pCmdUI);
		afx_msg void OnEditDelete();
		afx_msg void OnUpdateEditRevsel(CCmdUI *pCmdUI);
		afx_msg void OnEditRevsel();
		afx_msg void OnUpdateEditFind(CCmdUI *pCmdUI);
		afx_msg void OnEditFind();
		afx_msg LRESULT OnOptInfoDataChanged(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnDeptInfoDataChanged(WPARAM wParam, LPARAM lParam);
		afx_msg LRESULT OnDataChanged(WPARAM wParam, LPARAM lParam);
		afx_msg void OnTimer(UINT_PTR nIDEvent);
		afx_msg void OnUpdateFileStaffPwd(CCmdUI *pCmdUI);
		afx_msg void OnFileStaffPwd();
	};
}

#ifndef _DEBUG
inline BasicInfo::CStaffInfoDoc* BasicInfo::CStaffInfoView::GetDocument() const
{
	return reinterpret_cast<CStaffInfoDoc*>(m_pDocument);
}
#endif

