#include "StdAfx.h"
#include <string>
#include "Toolkits.h"
#include <regex>
#include <afxinet.h>
#include <atlsocket.h>
#include <unordered_map>
#include <concurrent_vector.h>

#ifndef _WIN64
#include "../Helper/include/openssl/evp.h"
#ifdef _DEBUG
#pragma comment(lib,"../Debug/ssleay32MDd.lib")
#pragma comment(lib,"../Debug/libeay32MDd.lib")
#else
#pragma comment(lib,"../Release/ssleay32MD.lib")
#pragma comment(lib,"../Release/libeay32MD.lib")
#endif
#else
#include "../Helper/include64/openssl/evp.h"
#ifdef _DEBUG
#pragma comment(lib,"../x64/Debug/ssleay32MDd.lib")
#pragma comment(lib,"../x64/Debug/libeay32MDd.lib")
#else
#pragma comment(lib,"../x64/Release/ssleay32MD.lib")
#pragma comment(lib,"../x64/Release/libeay32MD.lib")
#endif
#endif


#pragma comment (lib, "Ws2_32.lib")

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#ifdef UNICODE 
	typedef std::wcmatch TMatch;
	typedef std::wregex  TRegex;
	typedef std::wstring TString;
	//typedef ltow ltot
#else
	typedef std::cmatch TMatch;
	typedef std::regex  TRegex;
	typedef std::string TString;
#endif

#ifndef STDString
#ifdef UNICODE
	typedef std::wstring STDString;
#else
	typedef std::string STDString;
#endif
#endif

STDString Helper::CToolkits::m_strPathPJJMFile = STDString(_T(""));

//��Ϣ����

//����Ƿ����µİ汾
typedef std::unordered_map<STDString, STDString> IdentityRow;

////////////////
//��������
void Helper::CToolkits::EncriptInfo( PTSTR strContent, PTSTR strKey, CString& strRet )
{
	if( strRet.GetLength() > 0 )
	{
		strRet.Remove( strRet.GetLength() - 1 );
	}
	for( int i = 0; i != _tcslen(strContent); i++ )
	{
		long dwChar = strContent[ i ];
		for( int j = 0; j != _tcslen(strKey); j++ )
		{
			long dwKey = strKey[ j ];
			dwChar = dwChar ^ dwKey;
		}
		strRet.AppendChar( (TCHAR)dwChar ); 
	}
}

void Helper::CToolkits::EncriptInfos( PVOID pvContent, PTSTR strKey, PVOID pvRet )
{
	Concurrency::concurrent_vector<STDString>* pvRetRef = 
		reinterpret_cast<Concurrency::concurrent_vector<STDString>*>( pvRet );
	Concurrency::concurrent_vector<STDString>* pvContentRef = 
		reinterpret_cast<Concurrency::concurrent_vector<STDString>*>( pvContent );

	pvRetRef->clear();
	Concurrency::concurrent_vector<STDString>::iterator it = pvContentRef->begin();
	for( ; it != pvContentRef->end(); it++ )
	{
		CString strTemp;
		TCHAR tcsTemp[MAX_PATH * 10];
		_tcscpy_s( tcsTemp, MAX_PATH * 10, it->c_str() );
		EncriptInfo( tcsTemp, strKey, strTemp );
		pvRetRef->push_back( STDString(strTemp) );
	}
}

void Helper::CToolkits::EncryptionAES256(PTSTR strContent, PTSTR strKey, CString& strRet, BOOL bEncryption)
{
	EVP_CIPHER_CTX ctx;
	EVP_CIPHER_CTX_init(&ctx);

	CString strInitialContent;

	auto strKeyTemp = CT2ALocal(strKey);
	std::string strContentTemp;

	if (bEncryption)
	{
		strContentTemp.append(CT2ALocal(strContent).c_str());
	}
	else
	{
		Concurrency::concurrent_vector<STDString> myVector;
		Split(strContent, _T(":"), &myVector);
		for each (auto item in myVector)
		{
			strContentTemp.push_back((unsigned char)_ttoi(item.c_str()));
		}
	}

	int nLeft = 32 - strKeyTemp.length();
	unsigned char key[32];
	if (nLeft > 0)
	{
		for (int n = 0; n != nLeft; n++)
		{
			key[n] = 0x00;
		}
		for (int n = nLeft; n != 32; n++)
		{
			key[n] = strKeyTemp.at(n - nLeft);
		}
	}
	else
	{
		for (int n = 0; n != 32; n++)
		{
			key[n] = strKeyTemp.at(n);
		}
	}
	unsigned char iv[] = { 0x10, 0x21, 0x12, 0x33, 0x04, 0x51, 0x16, 0x27, 0x18, 0x39, 0x18, 0x11, 0x12, 0x13, 0x14, 0x15 };

	std::vector<unsigned char> encrypted;
	size_t max_output_len = strContentTemp.length() + (strContentTemp.length() % 16) + 16;
	encrypted.resize(max_output_len);

	// Enc is 1 to encrypt, 0 to decrypt, or -1 (see documentation).
	EVP_CipherInit_ex(&ctx, EVP_aes_256_cbc(), nullptr, key, iv, bEncryption);

	// EVP_CipherUpdate can encrypt all your data at once, or you can do
	// small chunks at a time.
	int actual_size = 0;
	EVP_CipherUpdate(&ctx,
		&encrypted[0], &actual_size,
		reinterpret_cast<unsigned char *>(&strContentTemp[0]), strContentTemp.size());

	// EVP_CipherFinal_ex is what applies the padding.  If your data is
	// a multiple of the block size, you'll get an extra AES block filled
	// with nothing but padding.
	int final_size;
	EVP_CipherFinal_ex(&ctx, &encrypted[actual_size], &final_size);
	actual_size += final_size;

	encrypted.resize(actual_size);

	std::string strFinalPWD;
	for (int i = 0; i != actual_size; i++)
	{
		if (bEncryption)
		{
			if (i > 0)
			{
				strRet.Append(_T(":"));
			}
			strRet.AppendFormat(_T("%u"), static_cast<unsigned int>(encrypted[i]));
		}
		else
		{
			strRet.AppendFormat(_T("%c"), encrypted[i]);
		}
	}

	EVP_CIPHER_CTX_cleanup(&ctx);
}


///////////////////////////////////////
//���ߺ���
BOOL Helper::CToolkits::GetLocalIPAddr( PTSTR ptszOutIP, const int nHoldLength)
{
	BOOL bRet = FALSE;
	char szHostName[MAX_PATH];
	memset( szHostName, 0, MAX_PATH );
	
	int  ErrorCode = 0;
	WSADATA wsaData;
	WORD wVersionRequested;
	wVersionRequested = MAKEWORD(2, 2);
	ErrorCode = WSAStartup(wVersionRequested, &wsaData );
	ErrorCode = gethostname( szHostName, MAX_PATH );
	if(  ErrorCode == 0 )
	{
		struct addrinfo *result = nullptr;
		struct addrinfo *ptr = nullptr;
		struct addrinfo hints;
		struct sockaddr_in  *sockaddr_ipv4;
		struct sockaddr_in6 *sockaddr_ipv6;
		ZeroMemory(&hints, sizeof(struct addrinfo));
		hints.ai_family = AF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		INT dwRetval = getaddrinfo(szHostName, nullptr, &hints, &result);
		if (dwRetval == 0)
		{
			CString LocalIP;
			for (ptr = result; ptr != nullptr; ptr = ptr->ai_next)
			{
				if (ptr->ai_family == AF_INET)
				{
					TCHAR ipstringbuffer[16];
					if (LocalIP.GetLength() > 0)
					{
						LocalIP.AppendChar(_T('@'));
					}
					sockaddr_ipv4 = (struct sockaddr_in *) ptr->ai_addr;
					InetNtop(AF_INET, &sockaddr_ipv4->sin_addr, ipstringbuffer, 16);
					LocalIP.Append(ipstringbuffer);
				}
				else if(ptr->ai_family == AF_INET6)
				{
					TCHAR ipstringbuffer[46];
					if (LocalIP.GetLength() > 0)
					{
						LocalIP.AppendChar(_T('@'));
					}
					sockaddr_ipv6 = (struct sockaddr_in6 *) ptr->ai_addr;
					InetNtop(AF_INET6, &sockaddr_ipv6->sin6_addr, ipstringbuffer, 46);
					LocalIP.Append(ipstringbuffer);
				}
			}
			if (LocalIP.GetLength() > 0)
			{
				_stprintf_s(ptszOutIP, nHoldLength, _T("%s"), LocalIP.AllocSysString());
				bRet = TRUE;
			}
		}
	}
	else
	{
		ErrorCode = WSAGetLastError();
		switch( ErrorCode )
		{
		case WSAEFAULT:
			AfxMessageBox( _T("�������������Ч") );
			break;
		case WSANOTINITIALISED:
			AfxMessageBox( _T("�����ڵ��ô˺�����ǰ����֤�ѳɹ�WSAStartup���ã�") );
			break;
		case WSAENETDOWN:
			AfxMessageBox( _T("��������ϵͳ��ʧ�ܣ�") );
			break;
		case WSAEINPROGRESS:
			AfxMessageBox( _T("ϵͳ���ڴ���һ��Sockets 1.1������ϵͳ�ṩ�����ڴ���һ���ص�������") );
			break;
		}
	}
	WSACleanup();
	return bRet;
}

BOOL Helper::CToolkits::Ping( PTSTR ptszIP )
{
	BOOL bRet = FALSE;
	CInternetSession session( _T("My Transport Session" ) );
	CStdioFile* pFile = nullptr;
	CHAR szBuff[MAX_PATH];
	try
	{
		pFile = session.OpenURL(ptszIP);
		bRet = (pFile->Read(szBuff, 32) > 0);
		delete pFile;
	}
	catch( CInternetException* pEx )
	{
		 //TCHAR sz[1024];
		 //pEx->GetErrorMessage(sz, 1024);
		 //_tprintf_s(_T("ERROR!  %s\n"), sz);
		 pEx->Delete();
	}	
	session.Close();
	return bRet;
}

BOOL Helper::CToolkits::GetInternetIPAddr( PTSTR strParseURL, PTSTR ptszOutIP )
{
	//http://archive.apnic.net/cgi-bin/myip-js.pl
	BOOL bRet = FALSE;
	CInternetSession session( _T("My Transport Session" ) );
	CStdioFile* pFile = nullptr;
	CHAR szBuff[MAX_PATH * 10];
	try
	{
		pFile = session.OpenURL(strParseURL);
		while (pFile->Read(szBuff, MAX_PATH) > 0)
		{
			printf_s("%259s", szBuff);
			TCHAR tcsURL[MAX_PATH * 10], tcsRegExp[MAX_PATH * 10];
			//_stprintf_s( tcsURL, MAX_PATH, _T("%s"), szBuff );
			_tcscpy_s( tcsURL, MAX_PATH * 10, CA2T(szBuff) );
			//_tcscpy_s( tcsRegExp, MAX_PATH * 10, 
			//	_T("((2[0-4][[:digit:]]|25[0-5]|[01]?[[:digit:]][[:digit:]]?).){3}(2[0-4][[:digit:]]|25[0-5]|[01]?[[:digit:]][[:digit:]]?)") );
			_tcscpy_s( tcsRegExp, MAX_PATH * 10, _T("((?:(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d))") );			
			if( RegexFind( tcsURL, tcsRegExp, ptszOutIP ) )
			{
				break;
			}
		}
		delete pFile;
		bRet = TRUE;
	}
	catch( CInternetException* pEx )
	{
		 TCHAR sz[1024];
		 pEx->GetErrorMessage(sz, 1024);
		 _tprintf_s(_T("ERROR!  %s\n"), sz);
		 pEx->Delete();
	}
	
	session.Close();
	
	return bRet && (_tcscmp(ptszOutIP, _T("N/A")));
}

BOOL Helper::CToolkits::RegexFind( PTSTR ptszSource, PTSTR ptszExpr, PTSTR pszOutResult )
{
	BOOL fResult = FALSE;
	TMatch mr;
	TRegex rx( ptszExpr );
	std::regex_constants::match_flag_type f1 = 
		std::regex_constants::match_any;
	if( std::regex_search( ptszSource, mr, rx ) )
	{
		fResult = TRUE;		
		_tcscpy_s( pszOutResult, MAX_PATH, mr.str().c_str() );
	}
	else
	{
		_tcscpy_s( pszOutResult, MAX_PATH, _T("N/A") );
	}

	return fResult;
}

BOOL Helper::CToolkits::RegexPhoneFind( PTSTR ptszSource, PTSTR ptszExpr,
	PVOID* ppResults )
{
	BOOL fResult = FALSE;
	TMatch mr;
	TRegex rx( ptszExpr );
	const TCHAR* first = ptszSource;
	const TCHAR* second = first + _tcslen( ptszSource );
	std::regex_constants::match_flag_type f1 = 
		std::regex_constants::match_any;
	std::auto_ptr<Concurrency::concurrent_vector<PhoneNumInfo>> apResults( new Concurrency::concurrent_vector<PhoneNumInfo>() );
	fResult = TRUE;	
	while( std::regex_search( first, second, mr, rx) )
	{		
		BOOL fResult1 = FALSE;
		PhoneNumInfo info;
		_tcscpy_s( info.szNum, 20, _T("") );
		info.ComingDate = 0;
		info.LineNum = UINT(-1);
		//��ʼ����
		PTSTR ptszText = SysAllocString(mr[0].str().c_str() );

		TMatch mr1;
		TRegex rx1( _T("L\\d+\\W+") );
		if( std::regex_search( ptszText, mr1, rx1  ) )
		{
			CString strTempLine( mr1.str().c_str() );
			rx1 = TRegex(_T("\\d+"));
			if( std::regex_search( strTempLine.AllocSysString(), mr1, rx1  ) )
			{
				int nLine = 0;
				nLine = _ttoi( mr1.str().c_str() );
				info.LineNum = nLine;
				fResult1 = TRUE;
			}
		}


		rx1 = TRegex( _T("\\d{4,16}") );
		if( std::regex_search( ptszText, mr1, rx1  ) )
		{
			_tcscpy_s( info.szNum, 20, mr1.str().c_str() );
			fResult1 = fResult1 && TRUE;
		}

		COleDateTime dtNow( COleDateTime::GetCurrentTime() );
		info.ComingDate = dtNow.m_dt;

		SysFreeString( ptszText );
		fResult = fResult && fResult1;
		apResults->push_back( info );
		first = mr[0].second;
	}
	if( fResult )
	{
		*ppResults = apResults.release();
	}
	return fResult;
}

BOOL Helper::CToolkits::RegexPhoneReplace( PTSTR ptszSource, PTSTR ptszExpr, PTSTR ptszRep, 
	PVOID* ppResults, PTSTR pszResult )
{
	BOOL bRet = RegexPhoneFind( ptszSource, ptszExpr, ppResults );
	if( bRet )
	{
		RegexReplace( ptszSource, ptszExpr, ptszRep, pszResult );
	}
	return bRet;
}

void Helper::CToolkits::RegexReplace( PTSTR ptszSource, PTSTR ptszExpr, PTSTR ptszRep, PTSTR Result )
{
	TCHAR* first = ptszSource;
	TCHAR* last = first + _tcslen( first );
	TRegex rx( ptszExpr );
	TString fmt(ptszRep);


	//std::regex_constants::match_flag_type f1 = 
	//	std::regex_constants::match_any;
	//*std::regex_replace(Result, first, last, rx, fmt) = _T('\0');
}

/// <summary>
///���ش����ݵĸ�ʽ����ʾ</summary>
/// <returns> 
/// ת�����Ĵ�����.</returns>
PTSTR Helper::CToolkits::BigNumToString( LONG lNum, PTSTR szBuf )
{
	TCHAR szNum[100];
	_stprintf_s( szNum, 100, TEXT("%d"), lNum );
	NUMBERFMT nf;
	nf.NumDigits = 0;
	nf.LeadingZero = FALSE;
	nf.Grouping = 3;
	nf.lpDecimalSep = _T(".");
	nf.lpThousandSep = _T(",");
	nf.NegativeOrder = 0;
	GetNumberFormat( LOCALE_USER_DEFAULT, 0, szNum, &nf, szBuf, 100 );

	return szBuf;
}

#include <fstream>
#include <iostream>

//�Զ���IO��
#ifdef UNICODE
	typedef std::basic_ifstream<wchar_t, std::char_traits<wchar_t> > _ifstreamT;
#else
	typedef std::basic_ifstream<char, std::char_traits<char> > _ifstreamT;
#endif

//#include <tuple>

void Helper::CToolkits::GetPYJM( PCTSTR pctstrInput, PTSTR pctstrOut)
{
	std::ifstream inputStream;
	inputStream.open(m_strPathPJJMFile.c_str());
	if (!inputStream.fail())
	{
		char inputPY[10], inputWords[1024];
		CString strPY, strWords;
		//strcpy_s(strTemp, MAX_PATH, CT2A( pctstrInput ) );
		size_t nLength = _tcslen( pctstrInput );
		//�����ֵ�
		Concurrency::concurrent_vector<std::pair<TCHAR, TCHAR>> dict;
		for( int i = 0; i != nLength; i++ )
		{
			dict.push_back( std::pair< TCHAR, TCHAR >( _T('��'), pctstrInput[i] ) );
		}
		while( !inputStream.eof() )
		{
			inputStream >> inputPY >> inputWords;
			strPY.Format(_T("%s"), CA2TLocal(inputPY).c_str());
			strWords.Format(_T("%s"), CA2TLocal(inputWords).c_str());
			for( int i = 0; i != nLength; i++ )
			{
				TCHAR ptTempCh[2] = { pctstrInput[i] } ;
				if( strWords.FindOneOf(ptTempCh) != -1 )
				{
					for( size_t nest = nLength - 1; nest != -1; nest-- )
					{
						if (dict[nest].second == pctstrInput[i] && dict[nest].first == _T('��'))
						{
							dict[nest].first = _totupper(strPY.GetAt(0));
						}
					}
				}
			}
		}
		inputStream.close();
		nLength = dict.size();
		CString strTemp;
		for( int i = 0; i != nLength; i++ )
		{
			if( dict[i].first == _T('��') )
			{
				strTemp.AppendChar( pctstrInput[i] );
			}
			else
			{
				strTemp.AppendChar( dict[i].first );
			}
		}
		_tcscpy_s( pctstrOut, MAX_PATH, strTemp );
	}
}

void Helper::CToolkits::Split( LPCTSTR lpcstrSource, LPCTSTR lpcstrSeps, PVOID pRetVector )
{
	if( pRetVector == nullptr )
	{
		pRetVector = std::auto_ptr<Concurrency::concurrent_vector<STDString>>( new Concurrency::concurrent_vector<STDString>() ).release();
	}
	if( lpcstrSource == nullptr )
	{
		return;
	}

	auto pRet = reinterpret_cast<Concurrency::concurrent_vector<STDString>*>( pRetVector );

	pRet->clear();
	TCHAR *strSource = new TCHAR[_tcslen(lpcstrSource) + 1];
	TCHAR *strSeps = new TCHAR[_tcslen(lpcstrSeps) + 1];
	_tcscpy_s( strSource, _tcslen(lpcstrSource) + 1, lpcstrSource );
	_tcscpy_s( strSeps, _tcslen(lpcstrSeps) + 1, lpcstrSeps );
	TCHAR *token = nullptr;
	TCHAR *next_token = nullptr;
	// Establish string and get the first token:
    token = _tcstok_s( strSource, strSeps, &next_token);
	// While there are tokens in "strSource"
	while (token != nullptr)
	{
		// Get next token:
		if (token != nullptr)
		{
			if( _tcslen(token) > 0 )
			{
				pRet->push_back( STDString(token) );
			}
			token = _tcstok_s( nullptr, strSeps, &next_token);
		}
	}
	delete [] strSource;
	delete [] strSeps;

}

void Helper::CToolkits::ConvertCNRMB( double dblInput, CString& strResult )
{
	//�ж��Ƿ�Ϊ����
    BOOL isNegative = (dblInput < 0);
    //��ȡ��������
    ULONG Numerics = (long)std::abs(dblInput);

	CString strTemp;
	strTemp.Format( _T("%u"), Numerics );
	if( strTemp.GetLength() < 17 )
	{
		TCHAR CNRMBNum[10] =  { _T('��'), _T('Ҽ'), _T('��'), _T('��'), _T('��'), _T('��'),
			_T('½'), _T('��'), _T('��'), _T('��') };
        TCHAR CNRMBDigtName[3] = { _T('��'), _T('��'), _T('��') };
        TCHAR CNRMBBitFlag[16] = { _T('Բ'), _T('ʰ'), _T('��'), __T('Ǫ'), _T('��'), _T('ʰ'), _T('��'),
			_T('Ǫ'), _T('��'), _T('ʰ'), _T('��'), _T('Ǫ'), _T('��'), _T('ʰ'), _T('��'), _T('Ǫ')};
        //��ȡС������
        float digt = std::abs(dblInput) - Numerics;
        digt = std::ceil(digt * 100.0f) / 100.0f;
		CString strDigit;
		strDigit.Format( _T("%f"), digt );
		CString strReturn;
		if( digt > 0.0f )
		{
			int j = 1;
			for (int i = 2; i != strDigit.GetLength(); i++)
			{
				switch (strDigit[i])
				{
					case _T('1'):
						strReturn.AppendChar(CNRMBNum[1]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('2'):
						strReturn.AppendChar(CNRMBNum[2]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('3'):
						strReturn.AppendChar(CNRMBNum[3]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('4'):
						strReturn.AppendChar(CNRMBNum[4]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('5'):
						strReturn.AppendChar(CNRMBNum[5]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('6'):
						strReturn.AppendChar(CNRMBNum[6]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('7'):
						strReturn.AppendChar(CNRMBNum[7]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('8'):
						strReturn.AppendChar(CNRMBNum[8]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
					case _T('9'):
						strReturn.AppendChar(CNRMBNum[9]);
						strReturn.AppendChar(CNRMBDigtName[j]);
						break;
				}
				j--;
			}
		}
		else
		{
			strReturn.AppendChar(CNRMBDigtName[2]);
		}

        CString sdigt(strReturn);
        strReturn.Delete(0, strReturn.GetLength());
        //ѭ��������������
        CString str( strTemp );
        BOOL existsNum = FALSE;
        if (Numerics > 0)
        {
			int j = 0;
            for (int i = str.GetLength() - 1; i >= 0; i--, j++)
            {
                switch (str[i])
                {
				case _T('0'):
					{
                        switch (j)
                        {
						case 0: //Ԫλ
							strReturn.AppendChar(CNRMBBitFlag[j]);
							break;
						case 4: //��λ
                            //����λ�Ƿ�Ϊ0
                            if (!(str.GetLength() > 8 && ( str[i - 1] == _T('0') ) && (str[i - 2] == _T('0')) && (str[i - 3] == _T('0'))))
                            {
                                strReturn.AppendChar(CNRMBBitFlag[j]);
                            }
                            break;
						case 8: //��λ
							if (!(str.GetLength() > 12 && ( str[i - 1] == _T('0') ) && (str[i - 2] == _T('0')) && (str[i - 3] == _T('0'))))
							{
								strReturn.AppendChar(CNRMBBitFlag[j]);
							}
							break;
						case 12: //��λ
							if (!(str.GetLength() > 16 && ( str[i - 1] == _T('0') ) && (str[i - 2] == _T('0')) && (str[i - 3] == _T('0'))))
							{
								strReturn.AppendChar(CNRMBBitFlag[j]);
							}
							break;
                        }
                        if (existsNum)
                        {
                            strReturn.AppendChar(CNRMBNum[0]);
                        }
                        existsNum = false;                       
					}
					break;
				case _T('1'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[1] );
                    existsNum = true;
                    break;
				case _T('2'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[2] );
                    existsNum = true;
                    break;
				case _T('3'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[3] );
                    existsNum = true;
                    break;
				case _T('4'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[4] );
                    existsNum = true;
                    break;
				case _T('5'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[5] );
                    existsNum = true;
                    break;
				case _T('6'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[6] );
                    existsNum = true;
                    break;
				case _T('7'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[7] );
                    existsNum = true;
                    break;
				case _T('8'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[8] );
                    existsNum = true;
                    break;
				case _T('9'):
                    strReturn.AppendChar(CNRMBBitFlag[j]);
					strReturn.AppendChar( CNRMBNum[9] );
                    existsNum = true;
                    break;
                }
            }
		}
        if (isNegative)
        {
            strReturn.AppendChar(_T('��'));
        }

		strResult.Append(strReturn.MakeReverse());

        strResult.Append(sdigt);

	}
	else
    {
        strResult = _T("�������");
    }
}

LPTSTR Helper::CToolkits::GetFormatedItem( LPCTSTR lpszFirst, UINT nColWidth, UINT nPerCNWordWidth,
	UINT nPerENWordWidth, int& nRows, int& nMaxWidth)
{
	CString strRet;
	
	nMaxWidth = 0;
	
	size_t nWords = _tcslen( lpszFirst );
	if( nWords > 260 )
	{
		return _T("");
	}
	if( nWords > 0 )
	{
		nRows = 1;
		int nRowsWidth = 0;
		for( UINT i =0; i < nWords; i++ )
		{
			if( (int)(lpszFirst[i] ) <= 255 )
			{
				nRowsWidth += nPerENWordWidth;
			}
			else
			{
				nRowsWidth += nPerCNWordWidth;
			}
			
			strRet.AppendChar(  lpszFirst[i] );

			if( nMaxWidth < nRowsWidth )
			{
				nMaxWidth = nRowsWidth;
			}

			if( (i != (nWords - 1) ) && (nRowsWidth + nPerENWordWidth + nPerCNWordWidth >= nColWidth ) )
			{
				nRowsWidth = 0;
				nRows += 1;
				strRet.Append( _T("\n") );
			}
		}
	}

	if( strRet.GetLength() < 1)
	{
		strRet.Append(_T(" ") );
		nMaxWidth = nPerENWordWidth;
		nRows = 1;
	}

	return strRet.AllocSysString();
}

BOOL Helper::CToolkits::GenerateNewID(CString& retNewID)
{
	BOOL bRet = FALSE;
	GUID idNew = GUID_NULL;
	bRet = SUCCEEDED(CoCreateGuid(&idNew));

	if (bRet)
	{
		retNewID.Delete(0, retNewID.GetLength());

		LPOLESTR pOleStr = nullptr;
		HRESULT hr = StringFromIID(idNew, &pOleStr);
		bRet = SUCCEEDED(hr);
		retNewID.Append(pOleStr);
	}

	return bRet;
}

BOOL Helper::CToolkits::ConvertGUID( const GUID guid, CString& retValue )
{
	retValue.Delete( 0, retValue.GetLength() );
	BOOL bRet = FALSE;
	LPOLESTR pOleStr = nullptr;
	HRESULT hr = StringFromIID( guid, &pOleStr );
	bRet = SUCCEEDED( hr );
	retValue.Append( pOleStr );
	return bRet;
}

BOOL Helper::CToolkits::ConvertStrToGUID(CString strID, GUID* pRet)
{
	return IIDFromString(strID, pRet) == S_OK;
}

BOOL Helper::CToolkits::CheckVersion(LPCTSTR lpcstrServiecIP, USHORT uiPort)
{
	CString strInitialServiceIP = lpcstrServiecIP;
	BOOL bRet = Helper::CToolkits::Ping(_T("http://www.bing.com"));
	if( bRet )
	{
		bRet = FALSE;
		CInternetSession session(_T("Update Session"));
		CHttpConnection* pServer = nullptr;
		CHttpFile* pFile = nullptr;

		try
		{
			CString strServerName;
			INTERNET_PORT nPort = uiPort;
			DWORD dwRet = 0;

			pServer = session.GetHttpConnection(strInitialServiceIP, nPort);
			DWORD m_dwHttpRequestFlags = HSR_DOWNLOAD | INTERNET_FLAG_EXISTING_CONNECT | INTERNET_FLAG_NO_AUTO_REDIRECT;
			pFile = pServer->OpenRequest(CHttpConnection::HTTP_VERB_GET, _T("/UpdateSvs/GetUpdateFiles?SoftwareName=tsw"));
			pFile->SendRequest();
			pFile->QueryInfoStatusCode(dwRet);

			if (dwRet == HTTP_STATUS_OK)
			{
				CString strLenth;
				pFile->QueryInfo(HTTP_QUERY_CONTENT_LENGTH, strLenth);
				ULONG ul = _ttol( strLenth );
				//�����ļ�
				CString strFileName;
				//��ȡ����Ŀ¼
				TCHAR tcsPath[MAX_PATH];
				::GetModuleFileName(nullptr,tcsPath, MAX_PATH);

				STDString strAppPath( tcsPath );
				size_t m = strAppPath.rfind( _T('\\') );
				strFileName.Append( strAppPath.substr( 0, m + 1 ).c_str() );
				CString strDict;
				strDict.Append( strFileName );
				strFileName.Append( _T("UpdateNew.ini") );
				CHAR szBuff[1024];
				RtlSecureZeroMemory( szBuff, 1024 );
				UINT uiPos;
				Concurrency::concurrent_vector<STDString> vectContent, vectInitial;
				IdentityRow FinalRow, PlusRow;
				CString str;
				while (uiPos = pFile->Read(szBuff, 1024) > 0)
				{
					str.Append( CA2T(szBuff) );
					RtlSecureZeroMemory( szBuff, 1024 );
				}
				Helper::CToolkits::Split( str.GetBuffer(), _T("\r\n"), &vectContent );
				str.ReleaseBuffer(0);
				if( vectContent.size() > 0 && vectContent.at(vectContent.size() - 1) == _T("0" ))
				{
					vectContent.resize( vectContent.size() - 1 );
				}
				if( vectContent.size() > 0 )
				{
					//��ʼ�ԱȰ汾�ţ������ɸ��¼��±�
					CString strDictBack( strDict );
					Concurrency::concurrent_vector<STDString> tempVector1, tempVector2;
					strDict.Append( _T("Update.ini") );
					if( PathFileExists( strDict ) )
					{
						CopyFile( strDict, strDictBack + _T("UpdateBack.ini"), FALSE );
						//ִ���ļ������汾�Ա�
						//���ݸ��������ļ�
						HANDLE hFileInitial = CreateFile( strDict, GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr );
						if( hFileInitial != INVALID_HANDLE_VALUE )
						{
							
							DWORD dwSize = GetFileSize( hFileInitial, nullptr ) + 1;
							char *pBuffer = new char[dwSize];
							RtlSecureZeroMemory( pBuffer, dwSize );
							DWORD dwReaded;
							ReadFile( hFileInitial, pBuffer, dwSize, &dwReaded, nullptr );	
							CString strTargetTemp;
							strTargetTemp.Append(CA2T( pBuffer ));
							delete [] pBuffer;
							CloseHandle( hFileInitial );
							Helper::CToolkits::Split( strTargetTemp.GetBuffer(), _T("\r\n"), &vectInitial );
							strTargetTemp.ReleaseBuffer(0);
							for( auto iterRow = vectContent.begin(); iterRow != vectContent.end(); iterRow++ )
							{
								auto row = *iterRow;
								Helper::CToolkits::Split( row.c_str(), _T("\t"), &tempVector1 );
								BOOL bFound = FALSE;
								for( auto iterRow1 = vectInitial.begin(); iterRow1 != vectInitial.end(); iterRow1++ )
								{
									auto row1 = *iterRow1;
									Helper::CToolkits::Split( row1.c_str(), _T("\t"), &tempVector2 ); 
									if( _tcscmp(tempVector1.at(0).c_str(), tempVector2.at(0).c_str() ) == 0)
									{
										bFound = TRUE;
										double dblVer1 = _ttof( tempVector1.at(2).c_str() ),
											dblVer2 =  _ttof( tempVector2.at(2).c_str() );
										if( dblVer1 != dblVer2 )
										{
											//���°汾
											FinalRow.insert( IdentityRow::value_type( tempVector1.at(0), row ) );
											PlusRow.insert( IdentityRow::value_type( tempVector1.at(0), row ) );											
										}
									}
								}
								if( !bFound )
								{
									//׷�Ӱ汾
									FinalRow.insert( IdentityRow::value_type( tempVector1.at(0), row ) );
									PlusRow.insert( IdentityRow::value_type( tempVector1.at(0), row ) );
								}								
							}
							//׷��ʣ���ԭʼ�б�
							for( auto iterRow1 = vectInitial.begin(); iterRow1 != vectInitial.end(); iterRow1++ )
							{
								auto row1 = *iterRow1;
								Helper::CToolkits::Split( row1.c_str(), _T("\t"), &tempVector2 );
								IdentityRow::iterator itFound = FinalRow.find( tempVector2.at(0) );
								if( itFound == FinalRow.end() )
								{
									FinalRow.insert( IdentityRow::value_type( tempVector2.at(0), row1) );
								}
							}
						}
					}
					else
					{
						//��ȫ׷��
						for( auto iterRow = vectContent.begin(); iterRow != vectContent.end(); iterRow++ )
						{
							auto row = *iterRow;
							//Ԥ���ļ�
							Helper::CToolkits::Split( row.c_str(), _T("\t"), &tempVector1 );
							PlusRow.insert( IdentityRow::value_type( tempVector1.at(0), row ));
							FinalRow.insert( IdentityRow::value_type( tempVector1.at(0), row ));
						}
					}
				}
				if( PlusRow.size() > 0 )
				{
					//���´�����ִ��д��
					HANDLE hFileNew = CreateFile( strDict, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr );
					HANDLE hFilePlus = CreateFile( strFileName, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr );
					if( hFileNew != INVALID_HANDLE_VALUE && hFilePlus != INVALID_HANDLE_VALUE )
					{
						for( auto pairIter = FinalRow.begin(); pairIter != FinalRow.end(); pairIter++ )
						{
							auto pair = *pairIter;
							const UINT uiTL = 1024;
							char buff[uiTL];
							RtlSecureZeroMemory( buff, uiTL );
							sprintf_s( buff, uiTL, "%s\r\n",  (char*)CT2A(pair.second.c_str() ) );
							DWORD dwWrote;
							WriteFile( hFileNew, buff, (DWORD)strlen(buff), &dwWrote, nullptr );
						}
						for( auto pairIter = PlusRow.begin(); pairIter != PlusRow.end(); pairIter++ )
						{
							auto pair = *pairIter;
							const UINT uiTL = 1024;
							char buff[uiTL];
							RtlSecureZeroMemory( buff, uiTL );
							sprintf_s( buff, uiTL, "%s\r\n",  (char*)CT2A(pair.second.c_str() ) );
							DWORD dwWrote;
							WriteFile( hFilePlus, buff, (DWORD)strlen(buff), &dwWrote, nullptr );
						}
						//ִ��д��
						bRet = TRUE;
					}
					if( hFileNew != INVALID_HANDLE_VALUE )
					{
						CloseHandle( hFileNew );
					}
					if( hFilePlus != INVALID_HANDLE_VALUE )
					{
						CloseHandle( hFilePlus );
					}
				}
			}
			delete pFile;
			delete pServer;
		}
		catch (CInternetException* pEx)
		{
			//catch errors from WinInet
			TCHAR pszError[64];
			pEx->GetErrorMessage(pszError, 64);
			_tprintf_s(_T("%63s"), pszError);
		}
		session.Close();
	}
	return bRet;
}

CString Helper::CToolkits::GetErrorFormatedMessage( DWORD dwErrorID )
{
	CString strRet;
	// Get the error code
	DWORD dwError = dwErrorID;

	HLOCAL hlocal = nullptr;   // Buffer that gets the error message string

	// Use the default system locale since we look for Windows messages.
	// Note: this MAKELANGID combination has 0 as value
	DWORD systemLocale = MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL);

	// Get the error code's textual description
	BOOL fOk = FormatMessage(
		FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS |
		FORMAT_MESSAGE_ALLOCATE_BUFFER, 
		nullptr, dwError, systemLocale, 
		(PTSTR) &hlocal, 0, nullptr);

	if (!fOk) {
		// Is it a network-related error?
		HMODULE hDll = LoadLibraryEx(TEXT("netmsg.dll"), nullptr, 
		DONT_RESOLVE_DLL_REFERENCES);

		if (hDll != nullptr) {
		fOk = FormatMessage(
			FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_IGNORE_INSERTS |
			FORMAT_MESSAGE_ALLOCATE_BUFFER,
			hDll, dwError, systemLocale,
			(PTSTR) &hlocal, 0, nullptr);
		FreeLibrary(hDll);
		}
	}

	if (fOk && (hlocal != nullptr)) {
		strRet.Format( _T("%s"), (PCTSTR) LocalLock(hlocal) );
		LocalFree(hlocal);
	} else {
		strRet.Format( _T("%s"), _T("�ô���δ�ҵ���Ӧ������������") );
	}
	return strRet;
}

std::string Helper::CToolkits::CT2ALocal(const TCHAR* tcsInput)
{
	std::string strRet;
	int nLength = WideCharToMultiByte(CP_ACP, 0, tcsInput, -1, nullptr, 0, nullptr, nullptr);
	if (nLength > 0)
	{
		PSTR pStrRet = (char*)HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, nLength);
		WideCharToMultiByte(CP_ACP, 0, tcsInput, -1, pStrRet, nLength, nullptr, nullptr);
		strRet.append(pStrRet);
		HeapFree(GetProcessHeap(), 0, pStrRet);
	}
	return strRet;
}

STDString Helper::CToolkits::CA2TLocal(const char* strInput)
{
	STDString stdstrRet;
	int nLength = MultiByteToWideChar(CP_ACP, 0, strInput, -1, nullptr, 0);
	if (nLength > 0)
	{
		PTSTR ptStrRet = (TCHAR*)HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, nLength * sizeof(TCHAR));
		MultiByteToWideChar(CP_ACP, 0, strInput, -1, ptStrRet, nLength);
		stdstrRet.append(ptStrRet);
		HeapFree(GetProcessHeap(), 0, ptStrRet);
	}
	return stdstrRet;
}
