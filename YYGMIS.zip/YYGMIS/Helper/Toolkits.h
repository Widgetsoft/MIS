#pragma once

namespace Helper
{
	typedef struct AFX_EXT_CLASS __PhoneNumInfo
	{
		UINT LineNum;
		TCHAR szNum[20];
		DATE ComingDate;
	} PhoneNumInfo, *PPhoneNumInfo;

	class AFX_EXT_CLASS CStopwatch
	{
	public:
		CStopwatch(){ QueryPerformanceFrequency(&m_liPerfFreq); Start(); }
		void Start() { QueryPerformanceCounter( &m_liPerfStart ); }

		__int64 Now() const	
		{ //Return # of milliseconds since Start was called
			LARGE_INTEGER liPerfNow;
			QueryPerformanceCounter( &liPerfNow );
			return (((liPerfNow.QuadPart - m_liPerfStart.QuadPart) * 1000 ) / m_liPerfFreq.QuadPart );
		}

		__int64 NowInMicro() const {
			//Return # of microseconds since Start was called
			LARGE_INTEGER liPerfNow;
			QueryPerformanceCounter( &liPerfNow );
			return ((( liPerfNow.QuadPart - m_liPerfStart.QuadPart) * 1000000 ) / m_liPerfFreq.QuadPart );
		};

	private:
		LARGE_INTEGER m_liPerfFreq;		//Counts per second
		LARGE_INTEGER m_liPerfStart;	//Starting count
	};

	class AFX_EXT_CLASS CToolkits :
		public CObject
	{
	public:
		static BOOL GenerateNewID(CString& retNewID);
		static BOOL ConvertStrToGUID(CString strID, GUID* pRet);
		static BOOL ConvertGUID( const GUID guid, CString& retValue );
		static void EncriptInfo( PTSTR strContent, PTSTR strKey, CString& strRet );
		static void EncriptInfos( PVOID pvContent, PTSTR strKey, PVOID pvRet );
		static void EncryptionAES256(PTSTR strContent, PTSTR strKey, CString& strRet, BOOL bEncryption = TRUE);
		static BOOL Ping( PTSTR ptszIP );
		static BOOL GetLocalIPAddr( PTSTR ptszOutIP, const int nHoldLength = 1024 );
		static BOOL GetInternetIPAddr(PTSTR strParseURL, PTSTR ptszOutIP );
		static BOOL RegexPhoneFind( PTSTR ptszSource, PTSTR ptszExpr, PVOID* ppResults );
		static BOOL RegexPhoneReplace( PTSTR ptszSource, PTSTR ptszExpr, PTSTR ptszRep, PVOID* ppResults, PTSTR pszResult );
		static BOOL RegexFind( PTSTR ptszSource, PTSTR ptszExpr, PTSTR Result );
		static void RegexReplace( PTSTR ptszSource, PTSTR ptszExpr, PTSTR ptszRep, PTSTR Result );
		static PTSTR BigNumToString( LONG lNum, PTSTR szBuf );
		static void GetPYJM( PCTSTR pctstrInput, PTSTR pctstrOut );
		static void Split( LPCTSTR strSource, LPCTSTR strToken, PVOID pRet );
		static void ConvertCNRMB( double dblInput, CString& strResult );
		static LPTSTR GetFormatedItem( LPCTSTR lpszFirst, UINT nColWidth, UINT nPerCNWordWidth, UINT nPerENWordWidth, int& nRows, int& nMaxWidth);
		static CString GetErrorFormatedMessage( DWORD dwErrorID );
		static BOOL CheckVersion(LPCTSTR lpcstrServiecIP = _T("221.3.159.5"), USHORT uiPort = 8080);
		

		static std::string CT2ALocal(const TCHAR* tcsInput);
		static STDString CA2TLocal(const char* strInput);
		//static void ConvertCNRMBSimple( double dblInput, Concurrency::concurrent_vector<CString>& vectorResult );

		static STDString m_strPathPJJMFile;
	};

	#undef AFX_DATA
	#define AFX_DATA
}

