// Helper.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#include "stdafx.h"
#include "Helper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


// Ψһ��Ӧ�ó������


#include "afxdllx.h"    // standard MFC Extension DLL routines

static AFX_EXTENSION_MODULE NEAR extensionDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		// Extension DLL one-time initialization.
		if (!AfxInitExtensionModule(extensionDLL, hInstance))
		   return 0;

		// Other initialization could be done here, as long as
		// it doesn't result in direct or indirect calls to AfxGetApp.
		// This extension DLL needs to add doc templates to the
		// app object, so it waits for the application to boot
		// and call an initialization function (see below).
	}
	return 1;   // ok
}

// Exported DLL initialization is run in context of running application
extern "C" void WINAPI InitHelper()
{
	// create a new CDynLinkLibrary for this app
	#pragma warning(push)
	#pragma warning(disable:6211) //silence prefast warning because CDynLinkLibrary is cleaned up elsewhere
	new CDynLinkLibrary(extensionDLL);
	#pragma warning(pop)

	// Register the doc templates we provide to the app
	//CWinApp* pApp = AfxGetApp();
	//ENSURE(pApp != NULL);
	// add other initialization here
}