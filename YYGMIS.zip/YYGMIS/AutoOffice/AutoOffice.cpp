// AutoOffice.cpp : ���� DLL �ĳ�ʼ�����̡�
//

#include "stdafx.h"
#include "AutoOffice.h"
#include <afxwin.h>
#include <afxdllx.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

static AFX_EXTENSION_MODULE AutoOfficeDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// ���ʹ�� lpReserved���뽫���Ƴ�
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("AutoOffice.DLL ���ڳ�ʼ��!\n");

		// ��չ DLL һ���Գ�ʼ��
		if (!AfxInitExtensionModule(AutoOfficeDLL, hInstance))
			return 0;

		// ���� DLL ���뵽��Դ����
		// ע��:  �������չ DLL ��
		//  MFC ���� DLL (�� ActiveX �ؼ�)��ʽ���ӵ���
		//  �������� MFC Ӧ�ó������ӵ�������Ҫ
		//  �����д� DllMain ���Ƴ������������һ��
		//  �Ӵ���չ DLL �����ĵ����ĺ����С�  ʹ�ô���չ DLL ��
		//  ���� DLL Ȼ��Ӧ��ʽ
		//  ���øú����Գ�ʼ������չ DLL��  ����
		//  CDynLinkLibrary ���󲻻ḽ�ӵ�
		//  ���� DLL ����Դ���������������ص�
		//  ���⡣

		new CDynLinkLibrary(AutoOfficeDLL);

	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("AutoOffice.DLL ������ֹ!\n");

		// �ڵ�����������֮ǰ��ֹ�ÿ�
		AfxTermExtensionModule(AutoOfficeDLL);
	}
	return 1;   // ȷ��
}

// �����Ϳ������á������ࡱ�����ļ�������ɵ� IDispatch ��װ��

#pragma region Import the libraries

#import "libid:2DF8D04C-5BFA-101B-BDE5-00AA0044DE52" rename( "RGB", "MSORGB" ) rename( "DocumentProperties", "MSODocumentProperties" )
//[OR]
//#import "C:\\Program Files\\Common Files\\Microsoft Shared\\OFFICE14\\MSO.DLL" \
//	rename( "RGB", "MSORGB" ) rename( "DocumentProperties", "MSODocumentProperties" )

// CApplication ��װ��

using namespace Office;

#import "libid:0002E157-0000-0000-C000-000000000046" 
//[OR]
//#import "C:\\Program Files\\Common Files\\Microsoft Shared\\VBA\\VBA7\\VBE7.DLL"

using namespace VBIDE;

#import "libid:00020813-0000-0000-C000-000000000046" \
	rename("DialogBox", "ExcelDialogBox") \
	rename("RGB", "ExcelRGB" ) \
	rename("CopyFile", "ExcelCopyFile") \
	rename("ReplaceText", "ExcelReplaceText") \
	no_auto_exclude
//[OR]
//#import "C:\\Program Files\\Microsoft Office\\Office14\\EXCEL.EXE" \
//	rename("DialogBox", "ExcelDialogBox") \
//	rename("RGB", "ExcelRGB" ) \
//	rename("CopyFile", "ExcelCopyFile") \
//	rename("ReplaceText", "ExcelReplaceText") \
//	no_auto_exclude

#pragma endregion

#include <ATLComTime.h>

#include "CApplication.h"
#include "CWorkbooks.h"
#include "CWorkbook.h"
#include "CWorksheets.h"
#include "CWorksheet.h"
#include "CRanges.h"
#include "CRange.h"
#include "CFont0.h"
#include "CBorders.h"
#include "CBorder.h"
#include "CPageSetup.h"
#include "CWindow0.h"
#include <concurrent_vector.h>

#define xlVAlignMiddle (short)-4108
#define xlVAlignTop (short)-4160
#define xlVAlignBottom (short)-4107

#define xlHAlignDefault (short)1
#define xlHAlignCenter (short)-4108
#define xlHAlignLeft (short)-4131
#define xlHAlignRight (short)-4152


#pragma region Excel�ļ�����
//�Զ���ȡ��ͷ��ĸ
static CString GetTitlePrefix(size_t uiInput)
{
	const size_t i = 'A' - 1;
	size_t iCount = uiInput;
	int iChar;
	CString strRetTemp;
	std::string strTemp;
	while (iCount > 0)
	{
		iChar = iCount % 26;
		iCount = iCount / 26;

		char cTemp = (char)(iChar + i);
		strTemp.push_back(cTemp);
	}

	strRetTemp.Append(CA2T(strTemp.c_str()));
	CString strRetTemp1(strRetTemp.MakeReverse());

	return strRetTemp1;
}


CAutoOffice::CAutoOffice()
{
	::CoInitialize(nullptr);
}

CAutoOffice::~CAutoOffice()
{
	::CoUninitialize();
}


//�������ܣ���Excel�ļ��ж�ȡ����
//lpzsFileName������ȡ���ݵ��ļ���
//ppReturnData: ���ݶ�ȡ����
//bContainsHeader:�Ƿ����������У���һ�У�
//����ֵ�������Ƿ�ɹ���ʶ
BOOL CAutoOffice::ReadDataFromXls(LPCTSTR lpzsFileName,
	PVOID* ppDataReturn,
	BOOL bContainsHeader)
{ //Concurrency::concurrent_vector<CString>>** ppReturnData
	BOOL bRetValue = FALSE;

	COleVariant covMissing((long)DISP_E_PARAMNOTFOUND, VT_ERROR),
		covTrue((short)TRUE), covFalse((short)FALSE);

	CApplication app;
	CWorkbooks *pWorkbooks = nullptr;
	CWorkbook *pWorkbook = nullptr;
	CWorksheets *pWorksheets = nullptr;
	CWorksheet *pWorksheet = nullptr;
	CRange *pRange = nullptr;
	CRange *pRangeInfo = nullptr;

	_ATLTRY
	{
		if (!app.CreateDispatch(_T("Excel.Application")))
		{
			MessageBox(nullptr, _T("�޷�����Excel�ļ�������"), _T("������ʾ"), MB_OK | MB_ICONEXCLAMATION);
			return bRetValue;
		}

	app.put_Visible(FALSE);

	pWorkbooks = new CWorkbooks(app.get_Workbooks());

	pWorkbook = new CWorkbook(pWorkbooks->Open(lpzsFileName,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing,
		covMissing));


	pWorksheets = new CWorksheets(pWorkbook->get_Worksheets());
	pWorksheet = new CWorksheet(pWorkbook->get_ActiveSheet());

	pRange = new CRange(pWorksheet->get_UsedRange());

	//��ȡ����
	pRangeInfo = new CRange(pRange->get_Rows());
	const LONG lRows = pRangeInfo->get_Count();
	pRangeInfo->ReleaseDispatch();
	delete pRangeInfo;
	pRangeInfo = nullptr;

	//��ȡ����
	pRangeInfo = new CRange(pRange->get_Columns());
	const LONG lColumn = pRangeInfo->get_Count();
	pRangeInfo->ReleaseDispatch();
	delete pRangeInfo;
	pRangeInfo = nullptr;

	std::auto_ptr<Concurrency::concurrent_vector<Concurrency::concurrent_vector<CString>>> apReturn
		(new Concurrency::concurrent_vector<Concurrency::concurrent_vector<CString>>());

	volatile LONG lRowsVol = 1L;
	if (bContainsHeader)
	{
		lRowsVol = 2L;
	}
	for (; lRowsVol != lRows + 1; lRowsVol++)
	{
		Concurrency::concurrent_vector<CString> vectTemp;
		for (volatile LONG lColumnsVol = 1; lColumnsVol != lColumn + 1; lColumnsVol++)
		{
			CRange* pRangeTemp = new CRange(pRange->get_Item(COleVariant(lRowsVol),
				COleVariant(lColumnsVol)).pdispVal);
			COleVariant varTemp = pRangeTemp->get_Value2();
			CString strTemp;
			if (varTemp.vt == VT_BSTR)
			{
				strTemp = varTemp.bstrVal;
				//��֤����

			}
			else if (varTemp.vt == VT_INT)
			{
				strTemp.Format(_T("%i"), varTemp.intVal);
			}
			else if (varTemp.vt == VT_R8)
			{
				double dbValue = varTemp.dblVal;
				strTemp.Format(_T("%.2f"), dbValue);
				strTemp = strTemp.TrimRight(_T(".00"));
			}
			else if (varTemp.vt == VT_DATE)
			{
				COleDateTime dateTime(varTemp.date);
				strTemp = dateTime.Format(VAR_DATEVALUEONLY);
			}
			else if (varTemp.vt == VT_EMPTY)
			{
				strTemp = _T("");
			}
			else
			{
				strTemp = _T("");
			}

			vectTemp.push_back(strTemp);

			pRangeTemp->ReleaseDispatch();
			delete pRangeTemp;
			pRangeTemp = nullptr;
		}
		apReturn->push_back(vectTemp);
	}
	bRetValue = TRUE;
	app.Quit();
	*ppDataReturn = apReturn.release();
	}
		_ATLCATCH(exArg)
	{
		//UNREFERENCED_PARAMETER( exArg );
		exArg->m_bAutoDelete = TRUE;
		exArg->ReportError();
	}

	if (pRange != nullptr)
	{
		pRange->ReleaseDispatch();
		delete pRange;
		pRange = nullptr;
	}

	if (pWorksheet != nullptr)
	{
		pWorksheet->ReleaseDispatch();
		delete pWorksheet;
		pWorksheet = nullptr;
	}

	if (pWorksheets != nullptr)
	{
		pWorksheets->ReleaseDispatch();
		delete pWorksheets;
		pWorksheets = nullptr;
	}

	if (pWorkbook != nullptr)
	{
		pWorkbook->ReleaseDispatch();
		delete pWorkbook;
		pWorkbook = nullptr;
	}

	if (pWorkbooks != nullptr)
	{
		pWorkbooks->ReleaseDispatch();
		delete pWorkbooks;
		pWorkbooks = nullptr;
	}

	app.ReleaseDispatch();
	return bRetValue;
}

//�������ܣ�������д�뵽Excel�ļ��ļ���
//lpzsFileName��������ݵ�Excel�ļ���
//ppReturnData: ��Ŵ�д���ļ����ݵ�����
//lpszTableName:��������
//����ֵ�������Ƿ�ɹ���ʶ
BOOL CAutoOffice::WriteDataToXls(LPCTSTR lpszFileName,
	PVOID pWillExportArray, LPCTSTR lpszTableName)
{
	Concurrency::concurrent_vector<Concurrency::concurrent_vector<CString>>* pExportArray =
		reinterpret_cast<Concurrency::concurrent_vector<Concurrency::concurrent_vector<CString>>*>(pWillExportArray);
	BOOL bRetValue = FALSE;
	if (pExportArray == nullptr || pExportArray->size() < 1 || (*pExportArray)[0].size() < 1)
	{
		return bRetValue;
	}
	COleVariant covMissing((long)DISP_E_PARAMNOTFOUND, VT_ERROR),
		covTrue((short)TRUE), covFalse((short)FALSE);
	CApplication app;
	CWorkbooks *pWorkbooks = nullptr;
	CWorkbook *pWorkbook = nullptr;
	CWorksheets* pWorksheets = nullptr;
	CWorksheet* pWorksheet = nullptr;
	CRange* pRangeHeader = nullptr;
	CRange* pRangeRow = nullptr;
	CFont0* pFont = nullptr;

	CBorders* pBorders;
	//CBorder* pBottomborder;
	CPageSetup* pPage;
	CWindow0* pWin;


	_ATLTRY
	{
		if (!app.CreateDispatch(_T("Excel.Application")))
		{
			MessageBox(nullptr, _T("�޷�����Excel�ļ�������"), _T("������ʾ"), MB_OK | MB_ICONEXCLAMATION);
			return bRetValue;
		}
	CString strFileName(lpszFileName);
	app.put_Visible(FALSE);
	app.put_UserControl(FALSE);

	pWorkbooks = new CWorkbooks(app.get_Workbooks());

	TCHAR szPath[MAX_PATH];
	::GetCurrentDirectory(MAX_PATH, szPath);

	pWorkbook = new CWorkbook(pWorkbooks->Add(covMissing));	//Add����Ҳ����Ϊģ���ļ�
	pWorksheets = new CWorksheets(pWorkbook->get_Worksheets());
	pWorksheet = new CWorksheet(pWorksheets->get_Item(COleVariant(_T("Sheet1"))));
	if (lpszTableName == nullptr)
	{
		lpszTableName = _T("δ�����ĵ�");
	}

	pWorksheet->put_Name(lpszTableName);

	//ִ��д�뵥Ԫ����
	const size_t uiRow = pExportArray->size();
	const size_t uiCol = (*pExportArray)[0].size();
	const CString strTitle(GetTitlePrefix(uiCol));
	CString strTarget(strTitle);
	strTarget.Append(_T("1"));
	pRangeHeader = new CRange(pWorksheet->get_Range(COleVariant(_T("A1")),  COleVariant(strTarget)));
	pRangeHeader->put_HorizontalAlignment(COleVariant(xlHAlignCenter));
	pRangeHeader->put_VerticalAlignment(COleVariant(xlVAlignMiddle));
	pFont = new CFont0(pRangeHeader->get_Font());
	pFont->put_Color(COleVariant((long)RGB(0,0,255)));
	pFont->put_Name(COleVariant(_T("����_GB2312")));
	pFont->put_Size(COleVariant((short)12));
	pRangeHeader->put_RowHeight(COleVariant((short)35));

	Concurrency::concurrent_vector<CString> arrTitle = (*pExportArray)[0];

	for (int i = 1; i != uiCol + 1; i++)
	{
		pRangeHeader->put_Item(COleVariant(1L), COleVariant((long)i), COleVariant(arrTitle[i - 1]));
	}
	pBorders = new CBorders(pRangeHeader->get_Borders());
	pBorders->put_Weight(COleVariant((short)2));

	pBorders->ReleaseDispatch();
	delete pBorders;
	pBorders = nullptr;

	pFont->ReleaseDispatch();
	delete pFont;
	pFont = nullptr;

	//��ʼ�������

	for (int iOut = 1; iOut != uiRow; iOut++)
	{
		CString strTemp(strTitle);
		strTarget.Format(_T("%i"), iOut + 1);
		strTemp.Append(strTarget);
		strTarget.Format(_T("A%i"), iOut + 1);
		pRangeRow = new CRange(pWorksheet->get_Range(COleVariant(strTarget),
			COleVariant(strTemp)));
		Concurrency::concurrent_vector<CString> arrTitle = (*pExportArray)[iOut];
		for (int j = 0; j != uiCol; j++)
		{
			pRangeRow->put_Item(COleVariant(1L /*(long)(iOut)*/), COleVariant((long)(j + 1)), COleVariant(arrTitle[j]));
		}

		pRangeRow->put_HorizontalAlignment(COleVariant(xlHAlignCenter));
		pRangeRow->put_VerticalAlignment(COleVariant(xlVAlignMiddle));
		pRangeHeader->put_RowHeight(COleVariant((short)18));

		pBorders = new CBorders(pRangeRow->get_Borders());
		pBorders->put_Weight(COleVariant((short)2));

		pBorders->ReleaseDispatch();
		delete pBorders;
		pBorders = nullptr;

		pRangeRow->ReleaseDispatch();
		delete pRangeRow;
		pRangeRow = nullptr;
	}

	pRangeRow = new CRange(pRangeHeader->get_EntireColumn());
	pRangeRow->AutoFit();

	pRangeRow->ReleaseDispatch();
	delete pRangeRow;
	pRangeRow = nullptr;

	pRangeHeader->ReleaseDispatch();
	delete pRangeHeader;
	pRangeHeader = nullptr;

	//����ҳü��ҳ��
	pPage = new CPageSetup(pWorksheet->get_PageSetup());
	pPage->put_HeaderMargin(1.0f / 0.035f); //�������¼�ҳü�߾࣬1/0.035 : ��1����ת���� points����
	pPage->put_TopMargin(2.7f / 0.035f);
	pPage->put_BottomMargin(1.5f / 0.035f);
	pPage->put_FooterMargin(1.0f / 0.035f);

	CString strTitlesTemp(_T("&\"����,����\"&24"));
	strTitlesTemp.Append(lpszTableName);
	pPage->put_CenterHeader(strTitlesTemp);// ��Ҫ��б�ܽ�����ת�壬VB����"ת��

	pPage->put_PrintTitleRows(_T("$1:$1"));  //1 2����Ϊ�ش���
	pPage->put_PrintTitleColumns(_T("$A:$B")); //A B����Ϊ�ش���
	pPage->put_Orientation(2);//xlLandscape=2 ����

	pPage->ReleaseDispatch();
	delete pPage;
	pPage = nullptr;

	pRangeRow = new CRange(pWorksheet->get_Range(COleVariant(_T("B2")), COleVariant(_T("B2"))));
	pRangeRow->Select();
	pWin = new CWindow0(app.get_ActiveWindow());
	pWin->put_FreezePanes(TRUE);

	pRangeRow->ReleaseDispatch();
	delete pRangeRow;
	pRangeRow = nullptr;

	pWin->ReleaseDispatch();
	delete pWin;
	pWin = nullptr;

	app.put_DisplayAlerts(FALSE);
	pWorksheet->SaveAs(strFileName, covMissing, covMissing, covMissing, covMissing, covMissing,
		covMissing, covMissing, covMissing, covMissing);
	app.Quit();

	bRetValue = TRUE;
	}
		_ATLCATCH(exArg)
	{
		exArg->m_bAutoDelete = TRUE;
		//UNREFERENCED_PARAMETER( exArg );
	}

	//�ͷ�����ָ������

	if (pWorksheet != nullptr)
	{
		pWorksheet->ReleaseDispatch();
		delete pWorksheet;
		pWorksheet = nullptr;
	}

	if (pWorksheets != nullptr)
	{
		pWorksheets->ReleaseDispatch();
		delete pWorksheets;
		pWorksheets = nullptr;
	}

	if (pWorkbook != nullptr)
	{
		pWorkbook->ReleaseDispatch();
		delete pWorkbook;
		pWorkbook = nullptr;
	}

	if (pWorkbooks != nullptr)
	{
		pWorkbooks->ReleaseDispatch();
		delete pWorkbooks;
		pWorkbooks = nullptr;
	}

	app.ReleaseDispatch();

	return bRetValue;
}
#pragma endregion

