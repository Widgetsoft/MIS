#pragma once

class AFX_EXT_CLASS CAutoOffice
{
public:
	CAutoOffice();
	virtual ~CAutoOffice();

public:
	BOOL ReadDataFromXls(LPCTSTR lpzsFileName,
		PVOID* ppDataReturn,
		BOOL bContainsHeader = FALSE);
	BOOL WriteDataToXls(LPCTSTR lpszFileName,
		PVOID pExportArray,
		LPCTSTR lpszTableName = NULL);
};

#undef AFX_DATA
#define AFX_DATA