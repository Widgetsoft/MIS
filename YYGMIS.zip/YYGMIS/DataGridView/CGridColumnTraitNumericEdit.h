#pragma once

//------------------------------------------------------------------------
// Author:  Rolf Kristensen	
// Source:  http://www.codeproject.com/KB/list/CGridListCtrlEx.aspx
// License: Free to use for all (New BSD License)
//------------------------------------------------------------------------

#include "CGridColumnTraitImage.h"

//------------------------------------------------------------------------
//! CGridColumnTraitNumericEdit implements a CEdit as cell-editor
//------------------------------------------------------------------------
class AFX_EXT_CLASS CGridColumnTraitNumericEdit : public CGridColumnTraitImage
{
public:
	CGridColumnTraitNumericEdit();

	void SetStyle(DWORD dwStyle);
	DWORD GetStyle() const;

	void SetLimitText(UINT nMax);
	UINT GetLimitText() const;

	void SetAllowNegativeValues(bool allow);
	bool GetAllowNegativeValues() const;

	void SetDigitsAfterDecimal(UINT nMax);
	UINT GetDigitsAfterDecimal() const;

	void SetDigitsBeforeDecimal(UINT nMax);
	UINT GetDigitsBeforeDecimal() const;

	virtual CWnd* OnEditBegin(CGridListCtrlEx& owner, int nRow, int nCol);
	virtual int OnSortRows(LPCTSTR pszLeftValue, LPCTSTR pszRightValue, bool bAscending);

protected:
	virtual void Accept(CGridColumnTraitVisitor& visitor);
	virtual CEdit* CreateEdit(CGridListCtrlEx& owner, int nRow, int nCol, const CRect& rect);

	DWORD m_EditStyle;				//!< Style to use when creating CEdit
	UINT m_EditLimitText;			//!< Max number of characters the CEdit will accept

	bool m_AllowNegativeValues;	// determines whether negative values are allowed
	UINT m_DigitsBeforeDecimal;	// number of digits before the decimal, if allowed
	UINT m_DigitsAfterDecimal;	// number of digits to allow after decimal
};

//------------------------------------------------------------------------
//! CEdit for inplace edit. For internal use by CGridColumnTraitNumericEdit
//------------------------------------------------------------------------
class AFX_EXT_CLASS CGridNumericEditorText : public CEdit
{
public:
	CGridNumericEditorText(int nRow, int nCol, bool AllowNegativeValues, UINT DigitsAfterDecimal, UINT DigitsBeforeDecimal);
	virtual void EndEdit(bool bSuccess);

protected:
	afx_msg void OnKillFocus(CWnd *pNewWnd);
	afx_msg void OnNcDestroy();
	afx_msg void OnEnChange();
	virtual	BOOL PreTranslateMessage(MSG* pMsg);
	DECLARE_MESSAGE_MAP();

private:
	struct _LocaleInfo
	{
		TCHAR	chDecimalSymbol;	// character used for decimal separator
		TCHAR	chNegationSymbol;	// character used for negative sign

		_LocaleInfo()
		{
			//
			// you MAY initialize these variables to 
			// any other value you like, for e.g., zero
			//
			chDecimalSymbol = _T('.');	// reasonable default!
			chNegationSymbol = _T('-');	// reasonable default!

			CString	strT;	// temporary string
			/**
			 *	retrieve the symbol used as the decimal separator
			 */
			int	iResult = ::GetLocaleInfo(LOCALE_USER_DEFAULT, 
										  LOCALE_SDECIMAL, 
										  strT.GetBufferSetLength(2), 2);
			strT.ReleaseBuffer();
			if (iResult)	chDecimalSymbol = strT[0];

			/**
			 *	retrieve the symbol used as the negative sign
			 */
			iResult = ::GetLocaleInfo(LOCALE_USER_DEFAULT, 
									  LOCALE_SNEGATIVESIGN, 
									  strT.GetBufferSetLength(2), 2);
			strT.ReleaseBuffer();
			if (iResult)	chNegationSymbol = strT[0];
		}
	};

	bool is_digit_key_allowed(CString strBuffer, DWORD dwSelStart, DWORD dwSelEnd, int iDecimalPos);

protected:
	int		m_Row;					//!< The index of the row being edited
	int		m_Col;					//!< The index of the column being edited
	bool	m_Completed;			//!< Ensure the editor only reacts to a single close event
	bool	m_Modified;				//!< Register if text was modified while the editor was open

	bool m_AllowNegativeValues;	// determines whether negative values are allowed
	UINT m_DigitsBeforeDecimal;	// number of digits before the decimal, if allowed
	UINT m_DigitsAfterDecimal;	// number of digits to allow after decimal
	bool m_InitialModify;

private:
	static const _LocaleInfo DefUserLocale;
};

#undef AFX_DATA
#define AFX_DATA