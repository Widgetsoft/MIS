#pragma once
// Initialize the DLL, register the classes etc
//extern "C" AFX_EXT_API void WINAPI InitDataGridView();

#include <atlsimpcoll.h>
#include <cstringt.h>

#include "CGridListCtrlEx.h"
#include "CGridListCtrlGroups.h"
#include "CGridColumnTraitDateTime.h"
#include "CGridColumnTraitEdit.h"
#include "CGridColumnTraitCombo.h"
#include "CGridColumnTraitProgress.h"
#include "CGridColumnTraitNumericEdit.h"
#include "CGridColumnTraitMultilineEdit.h"
#include "CGridRowTraitXP.h"
#include "ViewConfigSection.h"



#undef AFX_DATA
#define AFX_DATA