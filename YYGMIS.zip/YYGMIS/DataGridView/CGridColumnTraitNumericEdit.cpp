//------------------------------------------------------------------------
// Author:  Rolf Kristensen	
// Source:  http://www.codeproject.com/KB/list/CGridListCtrlEx.aspx
// License: Free to use for all (New BSD License)
//------------------------------------------------------------------------

#include "stdafx.h"
#pragma warning(disable:4100)	// unreferenced formal parameter

#include "CGridColumnTraitNumericEdit.h"

#include "CGridColumnTraitVisitor.h"
#include "CGridListCtrlEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//------------------------------------------------------------------------
//! CGridColumnTraitNumericEdit - Constructor
//------------------------------------------------------------------------
CGridColumnTraitNumericEdit::CGridColumnTraitNumericEdit()
	:m_EditStyle(ES_AUTOHSCROLL | ES_NOHIDESEL | WS_BORDER)
	,m_EditLimitText(UINT_MAX)
	,m_AllowNegativeValues(true)
	,m_DigitsAfterDecimal(0)
	,m_DigitsBeforeDecimal(0)
{
}

//------------------------------------------------------------------------
//! Accept Visitor Pattern
//------------------------------------------------------------------------
void CGridColumnTraitNumericEdit::Accept(CGridColumnTraitVisitor& visitor)
{
	visitor.Visit(*this);
}

//------------------------------------------------------------------------
//! Set style used when creating CEdit for cell value editing
//!
//! @param dwStyle Style flags
//------------------------------------------------------------------------
void CGridColumnTraitNumericEdit::SetStyle(DWORD dwStyle)
{
	m_EditStyle = dwStyle;
}

//------------------------------------------------------------------------
//! Get style used when creating CEdit for cell value editing
//------------------------------------------------------------------------
DWORD CGridColumnTraitNumericEdit::GetStyle() const
{
	return m_EditStyle;
}

//------------------------------------------------------------------------
//! Set max number of characters the CEdit will accept
//!
//! @param nMax The text limit, in characters.
//------------------------------------------------------------------------
void CGridColumnTraitNumericEdit::SetLimitText(UINT nMax)
{
	m_EditLimitText = nMax;
}

//------------------------------------------------------------------------
//! Get max number of characters the CEdit will accept
//------------------------------------------------------------------------
UINT CGridColumnTraitNumericEdit::GetLimitText() const
{
	return m_EditLimitText;
}

void CGridColumnTraitNumericEdit::SetAllowNegativeValues(bool allow)
{
	m_AllowNegativeValues = allow;
}

bool CGridColumnTraitNumericEdit::GetAllowNegativeValues() const
{
	return m_AllowNegativeValues;
}

void CGridColumnTraitNumericEdit::SetDigitsAfterDecimal(UINT nMax)
{
	m_DigitsAfterDecimal = nMax;
}

UINT CGridColumnTraitNumericEdit::GetDigitsAfterDecimal() const
{
	return m_DigitsAfterDecimal;
}

void CGridColumnTraitNumericEdit::SetDigitsBeforeDecimal(UINT nMax)
{
	m_DigitsBeforeDecimal = nMax;
}

UINT CGridColumnTraitNumericEdit::GetDigitsBeforeDecimal() const
{
	return m_DigitsBeforeDecimal;
}

//------------------------------------------------------------------------
//! Create a CEdit as cell value editor
//!
//! @param owner The list control starting a cell edit
//! @param nRow The index of the row
//! @param nCol The index of the column
//! @param rect The rectangle where the inplace cell value editor should be placed
//! @return Pointer to the cell editor to use
//------------------------------------------------------------------------
CEdit* CGridColumnTraitNumericEdit::CreateEdit(CGridListCtrlEx& owner, int nRow, int nCol, const CRect& rect)
{
	// Get the text-style of the cell to edit
	DWORD dwStyle = m_EditStyle;
	HDITEM hd = {0};
	hd.mask = HDI_FORMAT;
	VERIFY( owner.GetHeaderCtrl()->GetItem(nCol, &hd) );
	if (hd.fmt & HDF_CENTER)
		dwStyle |= ES_CENTER;
	else if (hd.fmt & HDF_RIGHT)
		dwStyle |= ES_RIGHT;
	else
		dwStyle |= ES_LEFT;

	CEdit* pEdit = new CGridNumericEditorText(nRow, nCol, m_AllowNegativeValues, m_DigitsAfterDecimal, m_DigitsBeforeDecimal);
	VERIFY( pEdit->Create( WS_CHILD | dwStyle, rect, &owner, 0) );

	// Configure font
	pEdit->SetFont(owner.GetCellFont());

	// First item (Label) doesn't have a margin (Subitems does)
	if (nCol==0)
		pEdit->SetMargins(0, 0);
	else
		pEdit->SetMargins(4, 0);

	if (m_EditLimitText!=UINT_MAX)
		pEdit->SetLimitText(m_EditLimitText);

	return pEdit;
}

//------------------------------------------------------------------------
//! Overrides OnEditBegin() to provide a CEdit cell value editor
//!
//! @param owner The list control starting edit
//! @param nRow The index of the row for the cell to edit
//! @param nCol The index of the column for the cell to edit
//! @return Pointer to the cell editor to use (NULL if cell edit is not possible)
//------------------------------------------------------------------------
CWnd* CGridColumnTraitNumericEdit::OnEditBegin(CGridListCtrlEx& owner, int nRow, int nCol)
{
	// Get position of the cell to edit
	CRect rectCell = GetCellEditRect(owner, nRow, nCol);

	// Create edit control to edit the cell
	CEdit* pEdit = CreateEdit(owner, nRow, nCol, rectCell);
	VERIFY(pEdit!=NULL);

	pEdit->SetWindowText(owner.GetItemText(nRow, nCol));
	pEdit->SetSel(0, -1, 0);

	return pEdit;
}

//------------------------------------------------------------------------
//! Compares two cell values according to specified sort order
//!
//! @param pszLeftValue Left cell value
//! @param pszRightValue Right cell value
//! @param bAscending Perform sorting in ascending or descending order
//! @return Is left value less than right value (-1) or equal (0) or larger (1)
//------------------------------------------------------------------------
int CGridColumnTraitNumericEdit::OnSortRows(LPCTSTR pszLeftValue, LPCTSTR pszRightValue, bool bAscending)
{
	if (m_DigitsAfterDecimal > 0)
	{
		double nLeftValue = _ttof(pszLeftValue);
		double nRightValue = _ttof(pszRightValue);
		if (bAscending)
		{
			double v = nLeftValue - nRightValue;
			if ( v == 0 )
				return 0;
			
			return ((v > 0) ? 1 : -1);
		}
		else
		{
			double v = nRightValue - nLeftValue;
			if ( v == 0 )
				return 0;
			
			return ((v > 0) ? 1 : -1);
		}
	}
	else
	{
		int nLeftValue = _ttoi(pszLeftValue);
		int nRightValue = _ttoi(pszRightValue);
		if (bAscending)
			return nLeftValue - nRightValue;
		else
			return nRightValue - nLeftValue;
	}
}


//------------------------------------------------------------------------
// CGridNumericEditorText (For internal use)
//------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CGridNumericEditorText, CEdit)
	//{{AFX_MSG_MAP(CGridNumericEditorText)
	ON_WM_KILLFOCUS()
	ON_WM_NCDESTROY()
	ON_CONTROL_REFLECT(EN_CHANGE, OnEnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// initialize static variable(s)
const CGridNumericEditorText::_LocaleInfo CGridNumericEditorText::DefUserLocale;

//------------------------------------------------------------------------
//! CGridNumericEditorText - Constructor
//------------------------------------------------------------------------
CGridNumericEditorText::CGridNumericEditorText(int nRow, int nCol, bool AllowNegativeValues, UINT DigitsAfterDecimal, UINT DigitsBeforeDecimal)
	:m_Row(nRow)
	,m_Col(nCol)
	,m_Completed(false)
	,m_Modified(false)
	,m_InitialModify(false)
	,m_AllowNegativeValues(AllowNegativeValues)
	,m_DigitsAfterDecimal(DigitsAfterDecimal)
	,m_DigitsBeforeDecimal(DigitsBeforeDecimal)
{}

//------------------------------------------------------------------------
//! The cell value editor was closed and the entered should be saved.
//!
//! @param bSuccess Should the entered cell value be saved
//------------------------------------------------------------------------
void CGridNumericEditorText::EndEdit(bool bSuccess)
{
	// Avoid two messages if key-press is followed by kill-focus
	if (m_Completed)
		return;

	m_Completed = true;

	// Send Notification to parent of ListView ctrl
	CString str;
	GetWindowText(str);

	LV_DISPINFO dispinfo = {0};
	dispinfo.hdr.hwndFrom = GetParent()->m_hWnd;
	dispinfo.hdr.idFrom = GetDlgCtrlID();
	dispinfo.hdr.code = LVN_ENDLABELEDIT;

	dispinfo.item.iItem = m_Row;
	dispinfo.item.iSubItem = m_Col;
	if (bSuccess && m_Modified)
	{
		dispinfo.item.mask = LVIF_TEXT;
		dispinfo.item.pszText = str.GetBuffer(0);
		dispinfo.item.cchTextMax = str.GetLength();
	}
	ShowWindow(SW_HIDE);
	GetParent()->GetParent()->SendMessage( WM_NOTIFY, GetParent()->GetDlgCtrlID(), (LPARAM)&dispinfo );
	PostMessage(WM_CLOSE);
}

//------------------------------------------------------------------------
//! WM_KILLFOCUS message handler called when CEdit is loosing focus
//! to other control. Used register that cell value editor should close.
//!
//! @param pNewWnd Pointer to the window that receives the input focus (may be NULL or may be temporary).
//------------------------------------------------------------------------
void CGridNumericEditorText::OnKillFocus(CWnd *pNewWnd)
{
	CEdit::OnKillFocus(pNewWnd);
	EndEdit(true);
}

//------------------------------------------------------------------------
//! WM_NCDESTROY message handler called when CEdit window is about to
//! be destroyed. Used to delete the inplace CEdit editor object as well.
//! This is necessary when the CDateTimeCtrl is created dynamically.
//------------------------------------------------------------------------
void CGridNumericEditorText::OnNcDestroy()
{
	CEdit::OnNcDestroy();
	delete this;
}

//------------------------------------------------------------------------
//! EN_CHANGE notification handler to monitor text modifications
//------------------------------------------------------------------------
void CGridNumericEditorText::OnEnChange()
{
	if (m_InitialModify)
		m_Modified = true;
	else
		m_InitialModify = true;
}

//------------------------------------------------------------------------
//! Hook to proces windows messages before they are dispatched.
//! Catch keyboard events that can should cause the cell value editor to close
//!
//! @param pMsg Points to a MSG structure that contains the message to process
//! @return Nonzero if the message was translated and should not be dispatched; 0 if the message was not translated and should be dispatched.
//------------------------------------------------------------------------
//BOOL CGridNumericEditorText::PreTranslateMessage(MSG* pMsg)
//{
//	switch(pMsg->message)
//	{
//		case WM_KEYDOWN:
//		{
//			switch(pMsg->wParam)
//			{
//				case VK_RETURN: EndEdit(true); return TRUE;
//				case VK_TAB: EndEdit(true); return FALSE;
//				case VK_ESCAPE: EndEdit(false);return TRUE;
//			}
//			break;
//		};
//		case WM_MOUSEWHEEL: EndEdit(true); return FALSE;	// Don't steal event
//	}
//
//	return CEdit::PreTranslateMessage(pMsg);
//}

BOOL CGridNumericEditorText::PreTranslateMessage(MSG* pMsg)
{
	switch ( pMsg->message )
	{
		case WM_KEYDOWN:
		{
			switch ( pMsg->wParam )
			{
				case VK_RETURN: EndEdit(true); return TRUE;
				case VK_TAB: EndEdit(true); return FALSE;
				case VK_ESCAPE: EndEdit(false);return TRUE;
			}
			break;
		};
		case WM_MOUSEWHEEL: EndEdit(true); return FALSE;	// Don't steal event
	}

	CString	strBuffer;			// edit control's text buffer
	DWORD	dwSelStart = 0,		// selection starting position
			dwSelEnd = 0;		// selection ending position
	int		iPos = 0;			// to hold the return value of CString::Find
	UINT	nKeyCode = (UINT)pMsg->wParam;	// virtual key code of the key pressed

	// not a WM_KEYDOWN message?
	if ( pMsg->message != WM_KEYDOWN )
		return CEdit::PreTranslateMessage(pMsg);

	// CTRL+C, CTRL+X, or, CTRL+V?
	if ( (nKeyCode == _T('C') || nKeyCode == _T('X') || nKeyCode == _T('V')) && (::GetKeyState(VK_CONTROL) & 0x8000) )
		return CEdit::PreTranslateMessage(pMsg);

	switch ( nKeyCode )
	{
		// subtract key?
		case VK_SUBTRACT:
		case 0xBD:
		{
			//TRACE0("(Info) CGridNumericEditorText::PreTranslateMessage: nKeyCode = VK_SUBTRACT\n");

			// get into this only if negative values are allowed!
			if ( m_AllowNegativeValues )
			{
				GetWindowText(strBuffer);
				if ( strBuffer.IsEmpty() )
					break;

				// retrieve selection range
				SendMessage(EM_GETSEL, (WPARAM)&dwSelStart, (LPARAM)&dwSelEnd);

				// is the selection beginning from the very first character?
				if ( !dwSelStart )
				{
					// NOTE: if text buffer starts from a decimal symbol, 
					//		 then we cannot accept a negative symbol until the 
					//		 decimal points symbol falls within the current 
					//		 selection range

					/**
					 *	Removed By Gurmeet S. Kochar (Mar 04, 2004)
					 */
					// if (strBuffer[0] == _T('.'))

					if ( strBuffer[0] == DefUserLocale.chDecimalSymbol )
					{
						// decimal symbol falls within the current selection range?
						if ( dwSelEnd != dwSelStart )
							// accept the negative symbol as it is going to 
							// replace the currently selected text
							break;

						::MessageBeep(MB_ICONEXCLAMATION);
						return (TRUE);
					}

					// check to make sure the first character is not 
					// already a negative sign
					if ( strBuffer[0] != DefUserLocale.chNegationSymbol )
						break;
					
					// the first character is a negative sign but 
					// is it within the current selection range?
					if ( dwSelEnd != dwSelStart )
						break;
				}
			}

			::MessageBeep(MB_ICONEXCLAMATION);
			return (TRUE);
		}

		// digits on the main section of keyboard?
		case 0x30:	case 0x31:	case 0x32:	case 0x33:	case 0x34:
		case 0x35:	case 0x36:	case 0x37:	case 0x38:	case 0x39:
		// digits on the numeric keypad?
		case 0x60:	case 0x61:	case 0x62:	case 0x63:	case 0x64:
		case 0x65:	case 0x66:	case 0x67:	case 0x68:	case 0x69:
		// decimal symbol?
		case VK_DECIMAL:
		case 0xBE:
		{
			//TRACE1("(Info) CGridNumericEditorText::PreTranslateMessage: nKeyCode = %d\n", nKeyCode);

			GetWindowText(strBuffer);
			if ( strBuffer.IsEmpty() )
				break;

			iPos = strBuffer.Find(DefUserLocale.chDecimalSymbol);

			// get the current selection range
			SendMessage(EM_GETSEL, (WPARAM)&dwSelStart, (LPARAM)&dwSelEnd);
			
			// decimal symbol?
			if ( nKeyCode == VK_DECIMAL || nKeyCode == 0xBE )
			{
				//TRACE0("(Info) CGridNumericEditorText::PreTranslateMessage: nKeyCode = VK_DECIMAL\n");

				ASSERT(m_DigitsAfterDecimal >= 0 && m_DigitsAfterDecimal <= 9);

				// accept integer values only?
				if ( !m_DigitsAfterDecimal )
				{
					::MessageBeep(MB_ICONEXCLAMATION);
					return (TRUE);
				}

				// a decimal symbol is already there?
				if ( iPos >= 0 )
				{
					if ( (dwSelEnd == dwSelStart) && (iPos < (int)dwSelStart || iPos > (int)dwSelEnd) )
					{
						// there can be only one decimal symbol in a numeric value
						::MessageBeep(MB_ICONEXCLAMATION);
						return (TRUE);
					}
				}
			}
			else // one of the digit keys has been pressed?
			{
				if ( !is_digit_key_allowed(strBuffer, dwSelStart, dwSelEnd, iPos) )
				{
					::MessageBeep(MB_ICONEXCLAMATION);
					return (TRUE);
				}
			}

			// neither a digit nor a decimal symbol is allowed 
			// at the starting of the text when the value in the 
			// text buffer is a negative value
			
			if ( (!dwSelStart) && (strBuffer[0] == DefUserLocale.chNegationSymbol) )
			{
				// negative sign is within the current selection range?
				if ( dwSelEnd == dwSelStart )
				{
					::MessageBeep(MB_ICONEXCLAMATION);
					return (TRUE);
				}
			}

			break;
		}
		default:
		{
			if ( (nKeyCode >= 0x01 && nKeyCode <= 0x40)
				|| (nKeyCode >= 0x5B && nKeyCode <= 0x69)
				|| (nKeyCode >= 0x70 && nKeyCode <= 0xB9)
				|| (nKeyCode >= 0xE5 && nKeyCode <= 0xFE) )
			{
				// spaces are not allowed in numeric values!
				if ( nKeyCode == VK_SPACE )
				{
					::MessageBeep(MB_ICONEXCLAMATION);
					return (TRUE);
				}

				break;
			}

			return (TRUE);	// eat message; ignore the key!!!
		}
	}

	return CEdit::PreTranslateMessage(pMsg);
}


bool CGridNumericEditorText::is_digit_key_allowed(CString strBuffer, DWORD dwSelStart, DWORD dwSelEnd, int iDecimalPos)
{
	if ( iDecimalPos >= 0 && m_DigitsAfterDecimal > 0 ) // value contains a decimal symbol?
	{
		// dwSelStart > iPos : user is typing text after the decimal symbol?
		// dwSelStart == dwSelEnd : the selection is empty?
		// strBuffer.Mid... : number of digits after decimal symbol is 
		//					  going to exceed than the value specified  
		//					  by m_DigitsAfterDecimal?
		if ( ((int)dwSelStart > iDecimalPos) && 
			 (dwSelStart == dwSelEnd) &&
			 (strBuffer.Mid(iDecimalPos+1).GetLength() >= (int)m_DigitsAfterDecimal) )
		{
			return false;
		}

		// dwSelStart > iPos : user is typing text after the decimal symbol?
		// dwSelStart == dwSelEnd : the selection is empty?
		// strBuffer.Left... : number of digits before the decimal symbol is 
		//					  going to exceed the value specified  
		//					  by m_DigitsBeforeDecimal?
		if ( ((int)dwSelStart < iDecimalPos) && 
			 (dwSelStart == dwSelEnd) &&
			 (strBuffer.Left(iDecimalPos+1).GetLength() >= (int)m_DigitsBeforeDecimal) )
		{
			return false;
		}
	}
	else
	{
		// m_DigitsAfterDecimal > 0 : we are allowing decimals
		// strBuffer.GetLength... : number of digits before the decimal symbol is 
		//					  going to exceed the value specified  
		//					  by m_DigitsBeforeDecimal?
		if ( (m_DigitsAfterDecimal > 0) && (strBuffer.GetLength() >= (int)m_DigitsBeforeDecimal) )
			return false;
	}

	return true;
}